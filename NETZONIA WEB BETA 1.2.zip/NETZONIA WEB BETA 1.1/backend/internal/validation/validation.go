// Package validation contém validadores de entrada portados literalmente de
// legacy-desktop-reference/security.go. São puros (sem dependência de SO ou
// Wails), por isso foram trazidos sem alteração de regra para preservar o
// mesmo padrão de segurança usado no Desktop (bloqueio de argument
// injection, limites de tamanho, host/porta/OID/community válidos).
package validation

import (
	"errors"
	"fmt"
	"math"
	"net"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

var hostnamePattern = regexp.MustCompile(`^[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,62}(?:\.[a-zA-Z0-9][a-zA-Z0-9\-]{0,62})*)?$`)
var oidPattern = regexp.MustCompile(`^(?:\.?[0-9]+)(?:\.[0-9]+)*$`)

// ValidateHost replica validateHost do legado (security.go).
func ValidateHost(host string) error {
	host = strings.TrimSpace(host)
	if host == "" {
		return errors.New("host vazio")
	}
	if len(host) > 253 || strings.HasPrefix(host, "-") {
		return errors.New("host inválido")
	}
	if ip := net.ParseIP(host); ip != nil {
		return nil
	}
	if hostnamePattern.MatchString(host) {
		return nil
	}
	return errors.New("host inválido — use um endereço IP ou hostname válido")
}

// ValidatePort replica validatePort do legado.
func ValidatePort(port int, defaultPort int) (int, error) {
	if port == 0 && defaultPort > 0 {
		port = defaultPort
	}
	if port < 1 || port > 65535 {
		return 0, errors.New("porta inválida: use um valor entre 1 e 65535")
	}
	return port, nil
}

// ValidateOID replica validateOID do legado.
func ValidateOID(oid string) (string, error) {
	oid = strings.TrimSpace(oid)
	if oid == "" {
		oid = "1.3.6.1.2.1.1.3.0"
	}
	if len(oid) > 256 || !oidPattern.MatchString(oid) {
		return "", errors.New("OID SNMP inválido")
	}
	if strings.HasPrefix(oid, "-") {
		return "", errors.New("OID SNMP inválido")
	}
	return oid, nil
}

// ValidateBoundedText replica validateBoundedText do legado.
func ValidateBoundedText(name, value string, minRunes, maxRunes int, allowNewline bool) (string, error) {
	value = strings.TrimSpace(value)
	n := len([]rune(value))
	if n < minRunes {
		return "", fmt.Errorf("%s obrigatório", name)
	}
	if n > maxRunes {
		return "", fmt.Errorf("%s excede o tamanho máximo de %d caracteres", name, maxRunes)
	}
	for _, r := range value {
		if unicode.IsControl(r) && !(allowNewline && (r == '\n' || r == '\r' || r == '\t')) {
			return "", fmt.Errorf("%s contém caracteres de controle inválidos", name)
		}
	}
	return value, nil
}

// ValidateSNMPCommunity replica validateSNMPCommunity do legado.
func ValidateSNMPCommunity(community string) (string, error) {
	value, err := ValidateBoundedText("community SNMP", community, 1, 128, false)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(value, "-") {
		return "", errors.New("community SNMP inválida")
	}
	return value, nil
}

// ValidateFinite replica validateFinite do legado.
func ValidateFinite(name string, value float64, min, max float64) error {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return fmt.Errorf("%s deve ser um número finito", name)
	}
	if value < min || value > max {
		return fmt.Errorf("%s fora do intervalo permitido (%s a %s)", name,
			strconv.FormatFloat(min, 'f', -1, 64), strconv.FormatFloat(max, 'f', -1, 64))
	}
	return nil
}
