package tools

import (
	"context"
	"testing"
)

func TestIPOrigemDaRequisicao_RemoteAddr(t *testing.T) {
	res := IPOrigemDaRequisicao("203.0.113.9:54321", "")
	if res.IP != "203.0.113.9" {
		t.Errorf("ip = %q, esperado 203.0.113.9", res.IP)
	}
}

func TestIPOrigemDaRequisicao_ForwardedFor(t *testing.T) {
	res := IPOrigemDaRequisicao("10.0.0.1:8080", "198.51.100.7, 10.0.0.1")
	if res.IP != "198.51.100.7" {
		t.Errorf("ip = %q, esperado 198.51.100.7 (primeiro da cadeia X-Forwarded-For)", res.IP)
	}
}

func TestWakeOnLAN_MacInvalido(t *testing.T) {
	if err := WakeOnLAN("nao-e-mac", "255.255.255.255"); err == nil {
		t.Fatal("esperava erro para MAC inválido")
	}
}

func TestWakeOnLAN_BroadcastPublicoBloqueado(t *testing.T) {
	if err := WakeOnLAN("AA:BB:CC:DD:EE:FF", "8.8.8.8"); err == nil {
		t.Fatal("esperava bloqueio de destino público")
	}
}

func TestBuildMagicPacket(t *testing.T) {
	packet, err := buildMagicPacket("AA:BB:CC:DD:EE:FF")
	if err != nil {
		t.Fatalf("erro inesperado ao montar magic packet: %v", err)
	}
	if len(packet) != 102 {
		t.Fatalf("tamanho = %d, esperado 102", len(packet))
	}
	for i := 0; i < 6; i++ {
		if packet[i] != 0xFF {
			t.Fatalf("prefixo inválido no byte %d", i)
		}
	}
	want := []byte{0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF}
	for repetition := 0; repetition < 16; repetition++ {
		for i, value := range want {
			if packet[6+repetition*6+i] != value {
				t.Fatalf("MAC inválido na repetição %d", repetition)
			}
		}
	}
}

func TestParseMAC_FormatosAceitos(t *testing.T) {
	if _, err := parseMAC("AA-BB-CC-DD-EE-FF"); err != nil {
		t.Fatalf("esperava aceitar MAC com hífen: %v", err)
	}
	if _, err := parseMAC("aa:bb:cc:dd:ee:ff"); err != nil {
		t.Fatalf("esperava aceitar MAC minúsculo: %v", err)
	}
}

func TestResolvePublicTargetBloqueiaRedePrivada(t *testing.T) {
	if _, err := resolvePublicTarget(context.Background(), "127.0.0.1"); err == nil {
		t.Fatal("esperava bloqueio de loopback para evitar SSRF")
	}
	if _, err := resolvePublicTarget(context.Background(), "192.168.1.1"); err == nil {
		t.Fatal("esperava bloqueio de rede privada para evitar SSRF")
	}
}
