package tools

import "testing"

func TestCalcularVLSM_Basico(t *testing.T) {
	res, err := CalcularVLSM("192.168.0.0/24", []int{50, 20, 10})
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	if len(res) != 3 {
		t.Fatalf("esperava 3 sub-redes, obteve %d", len(res))
	}
	// Maior demanda (50 hosts) processada primeiro: precisa de /26 (62 hosts úteis).
	if res[0].Rede != "192.168.0.0/26" {
		t.Errorf("rede[0] = %s, esperado 192.168.0.0/26", res[0].Rede)
	}
	if res[0].HostsUsaveis != 62 {
		t.Errorf("hostsUsaveis[0] = %d, esperado 62", res[0].HostsUsaveis)
	}
	if res[0].Mascara != "255.255.255.192" {
		t.Errorf("mascara[0] = %s, esperado 255.255.255.192", res[0].Mascara)
	}
	// 20 hosts precisa de /27 (30 úteis), alocada após a /26 (192.168.0.64/27).
	if res[1].Rede != "192.168.0.64/27" {
		t.Errorf("rede[1] = %s, esperado 192.168.0.64/27", res[1].Rede)
	}
	// 10 hosts precisa de /28 (14 úteis), alocada após a /27 (192.168.0.96/28).
	if res[2].Rede != "192.168.0.96/28" {
		t.Errorf("rede[2] = %s, esperado 192.168.0.96/28", res[2].Rede)
	}
}

func TestCalcularVLSM_BlocoInvalido(t *testing.T) {
	if _, err := CalcularVLSM("nao-e-cidr", []int{10}); err == nil {
		t.Fatal("esperava erro para bloco inválido")
	}
}

func TestCalcularVLSM_IPv6Rejeitado(t *testing.T) {
	if _, err := CalcularVLSM("2001:db8::/32", []int{10}); err == nil {
		t.Fatal("esperava erro para IPv6 (apenas IPv4 suportado)")
	}
}

func TestCalcularVLSM_SemEspaco(t *testing.T) {
	// /29 só tem 8 endereços; pedir 50 hosts não cabe.
	if _, err := CalcularVLSM("10.0.0.0/29", []int{50}); err == nil {
		t.Fatal("esperava erro por falta de espaço no bloco")
	}
}

func TestCalcularVLSM_HostsZeroOuNegativo(t *testing.T) {
	if _, err := CalcularVLSM("10.0.0.0/24", []int{0}); err == nil {
		t.Fatal("esperava erro para quantidade de hosts zero")
	}
}
