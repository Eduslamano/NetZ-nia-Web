// Portado de legacy-desktop-reference/novos_modulos.go (CalcularVLSM),
// função 15 da matriz. Mesma lógica e mensagens de erro do Desktop.
package tools

import (
	"errors"
	"fmt"
	"net"
	"sort"
	"strconv"
	"strings"
)

type SubnetVLSM struct {
	Rede         string `json:"rede"`
	Mascara      string `json:"mascara"`
	Broadcast    string `json:"broadcast"`
	Hosts        int    `json:"hosts"`
	HostsUsaveis int    `json:"hostsUsaveis"`
}

func CalcularVLSM(bloco string, hosts []int) ([]SubnetVLSM, error) {
	_, ipnet, err := net.ParseCIDR(strings.TrimSpace(bloco))
	if err != nil {
		return nil, fmt.Errorf("bloco inválido: %w", err)
	}
	if ipnet.IP.To4() == nil {
		return nil, errors.New("apenas IPv4 suportado")
	}
	if len(hosts) == 0 {
		return nil, errors.New("informe ao menos uma quantidade de hosts")
	}
	if len(hosts) > 512 {
		return nil, errors.New("quantidade excessiva de sub-redes solicitadas")
	}

	hostsOrdenados := append([]int(nil), hosts...)
	for _, h := range hostsOrdenados {
		if h < 1 {
			return nil, errors.New("quantidade de hosts deve ser maior que zero")
		}
		if int64(h) > int64(^uint32(0))-2 {
			return nil, errors.New("quantidade de hosts excede a capacidade do IPv4")
		}
	}
	sort.Slice(hostsOrdenados, func(i, j int) bool { return hostsOrdenados[i] > hostsOrdenados[j] })

	base := ipnet.IP.To4()
	_, blocoPrefix := ipnet.Mask.Size()
	if blocoPrefix != 32 {
		return nil, errors.New("máscara IPv4 inválida")
	}
	var resultados []SubnetVLSM

	for _, h := range hostsOrdenados {
		needed := uint64(h) + 2
		bits := uint(0)
		for (uint64(1)<<bits) < needed && bits < 32 {
			bits++
		}
		if bits > 32 || (uint64(1)<<bits) < needed {
			return nil, errors.New("quantidade de hosts excede a capacidade de uma sub-rede IPv4")
		}
		prefix := 32 - int(bits)
		mask := net.CIDRMask(prefix, 32)
		if len(mask) != 4 {
			return nil, errors.New("não foi possível calcular uma máscara IPv4 válida")
		}
		network := make(net.IP, 4)
		copy(network, base)
		for i := 0; i < 4; i++ {
			network[i] &= mask[i]
		}
		broadcast := make(net.IP, 4)
		copy(broadcast, network)
		for i := 0; i < 4; i++ {
			broadcast[i] |= ^mask[i]
		}
		if !ipnet.Contains(network) || !ipnet.Contains(broadcast) {
			return nil, fmt.Errorf("o bloco %s não possui espaço suficiente para todas as sub-redes solicitadas", bloco)
		}
		total := uint64(1) << bits
		if total > uint64(^uint(0)>>1) {
			return nil, errors.New("sub-rede calculada excede a capacidade numérica desta plataforma")
		}
		resultados = append(resultados, SubnetVLSM{
			Rede:         network.String() + "/" + strconv.Itoa(prefix),
			Mascara:      fmt.Sprintf("%d.%d.%d.%d", mask[0], mask[1], mask[2], mask[3]),
			Broadcast:    broadcast.String(),
			Hosts:        int(total),
			HostsUsaveis: int(total) - 2,
		})

		base = make(net.IP, 4)
		copy(base, broadcast)
		carry := true
		for i := 3; i >= 0 && carry; i-- {
			if base[i] < 255 {
				base[i]++
				carry = false
			} else {
				base[i] = 0
			}
		}
		if carry && len(resultados) < len(hostsOrdenados) {
			return nil, fmt.Errorf("o bloco %s não possui espaço suficiente para todas as sub-redes solicitadas", bloco)
		}
	}
	return resultados, nil
}
