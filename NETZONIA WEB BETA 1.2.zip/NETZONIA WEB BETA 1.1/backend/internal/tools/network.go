// Adaptado de legacy-desktop-reference/backend.go e novos_modulos.go —
// funções 11 (Teste DNS) e 26 (SSL), classificadas SERVER_API na auditoria:
// a medição parte do servidor Go, não da máquina do usuário, e a resposta
// deve deixar isso explícito para não ser confundida com diagnóstico local.
package tools

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"

	"netzonia-web/backend/internal/validation"
)

// --- 11) Teste DNS ---

type DNSItem struct {
	Servidor   string `json:"servidor"`
	IPServidor string `json:"ipServidor"`
	TempoMs    int64  `json:"tempoMs"`
	Resultado  string `json:"resultado"`
}

type DNSResult struct {
	Hostname   string    `json:"hostname"`
	Resultados []DNSItem `json:"resultados"`
	Origem     string    `json:"origem"`
}

func TesteDNS(ctx context.Context, hostname string) (DNSResult, error) {
	hostname = strings.TrimSpace(hostname)
	if hostname == "" {
		hostname = "google.com"
	}
	if err := validation.ValidateHost(hostname); err != nil {
		return DNSResult{}, err
	}
	servers := []struct{ name, ip string }{
		{"ISP do servidor (padrão)", ""},
		{"Cloudflare", "1.1.1.1"},
		{"Google", "8.8.8.8"},
		{"OpenDNS", "208.67.222.222"},
		{"Quad9", "9.9.9.9"},
	}
	res := DNSResult{Hostname: hostname, Origem: "servidor NetZônia"}
	for _, s := range servers {
		resolver := net.DefaultResolver
		ipServer := "auto"
		if s.ip != "" {
			ipServer = s.ip
			d := net.Dialer{Timeout: 3 * time.Second}
			target := s.ip
			resolver = &net.Resolver{PreferGo: true, Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				return d.DialContext(ctx, network, net.JoinHostPort(target, "53"))
			}}
		}
		callCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
		start := time.Now()
		ips, err := resolver.LookupIPAddr(callCtx, hostname)
		elapsed := time.Since(start).Milliseconds()
		cancel()
		item := DNSItem{Servidor: s.name, IPServidor: ipServer, TempoMs: elapsed}
		if err != nil {
			item.Resultado = "ERRO: " + err.Error()
		} else {
			parts := make([]string, 0, 3)
			for i, ip := range ips {
				if i >= 3 {
					break
				}
				parts = append(parts, ip.IP.String())
			}
			item.Resultado = strings.Join(parts, ", ")
		}
		res.Resultados = append(res.Resultados, item)
	}
	return res, nil
}

// --- 26) Validador de Certificado SSL ---

type SSLResult struct {
	Host          string   `json:"host"`
	DiasRestantes int      `json:"diasRestantes"`
	Emissor       string   `json:"emissor"`
	Subject       string   `json:"subject"`
	Alertas       []string `json:"alertas"`
	OK            bool     `json:"ok"`
}

func ValidarCertificadoSSL(ctx context.Context, host string, port int) (SSLResult, error) {
	host = strings.TrimSpace(host)
	port, err := validation.ValidatePort(port, 443)
	if err != nil {
		return SSLResult{}, err
	}
	targetIP, err := resolvePublicTarget(ctx, host)
	if err != nil {
		return SSLResult{}, err
	}
	rawConn, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", net.JoinHostPort(targetIP, strconv.Itoa(port)))
	if err != nil {
		return SSLResult{}, fmt.Errorf("falha TLS: %w", err)
	}
	defer rawConn.Close()
	conn := tls.Client(rawConn, &tls.Config{InsecureSkipVerify: true, ServerName: host}) //nolint:gosec -- certificado é coletado e verificado manualmente abaixo.
	if err := conn.HandshakeContext(ctx); err != nil {
		return SSLResult{}, fmt.Errorf("falha TLS: %w", err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(15 * time.Second))
	state := conn.ConnectionState()
	if len(state.PeerCertificates) == 0 {
		return SSLResult{}, errors.New("servidor não apresentou certificado")
	}
	cert := state.PeerCertificates[0]
	dias := int(time.Until(cert.NotAfter).Hours() / 24)
	alertas := []string{}
	intermediates := x509.NewCertPool()
	for _, c := range state.PeerCertificates[1:] {
		intermediates.AddCert(c)
	}
	if _, err := cert.Verify(x509.VerifyOptions{DNSName: host, Intermediates: intermediates}); err != nil {
		alertas = append(alertas, "Falha na validação da cadeia/hostname do certificado")
	}
	if dias < 0 {
		alertas = append(alertas, "CERTIFICADO EXPIRADO")
	} else if dias < 30 {
		alertas = append(alertas, fmt.Sprintf("Certificado expira em %d dias", dias))
	}
	return SSLResult{Host: host, DiasRestantes: dias, Emissor: cert.Issuer.CommonName, Subject: cert.Subject.CommonName, Alertas: alertas, OK: len(alertas) == 0}, nil
}

// --- 13) IP Externo ---
// O legado consulta um serviço externo a partir do computador do usuário,
// então IPExterno reflete a rede do usuário. Um servidor Web não pode
// replicar isso sem o navegador chamar um serviço à parte; em vez de
// fingir esse comportamento, o endpoint expõe o que o servidor HTTP sabe
// de verdade: o endereço de origem visto na requisição (com suporte a
// X-Forwarded-For quando o servidor está atrás de proxy/load balancer).
// Isso é uma função diferente da original, mas honesta quanto à origem.
type IPOrigemResult struct {
	IP     string `json:"ip"`
	Origem string `json:"origem"`
}

func IPOrigemDaRequisicao(remoteAddr, forwardedFor string) IPOrigemResult {
	if forwardedFor != "" {
		parts := strings.Split(forwardedFor, ",")
		ip := strings.TrimSpace(parts[0])
		if ip != "" {
			return IPOrigemResult{IP: ip, Origem: "cabeçalho X-Forwarded-For (confiável apenas se o proxy for controlado pela Netzônia)"}
		}
	}
	host, _, err := net.SplitHostPort(remoteAddr)
	if err != nil {
		host = remoteAddr
	}
	return IPOrigemResult{IP: host, Origem: "endereço de origem da conexão TCP com o servidor"}
}

// --- 20) Wake-on-LAN ---
// Portado de legacy-desktop-reference/novos_modulos.go (WakeOnLAN). Só tem
// efeito real se o servidor estiver na mesma LAN (ou VLAN roteada) do
// equipamento alvo — por isso é classificado HYBRID na auditoria.
func WakeOnLAN(macAddr, broadcast string) error {
	packet, err := buildMagicPacket(macAddr)
	if err != nil {
		return err
	}
	if strings.TrimSpace(broadcast) == "" {
		broadcast = "255.255.255.255"
	}
	broadcastIP := net.ParseIP(strings.TrimSpace(broadcast))
	if broadcastIP == nil || broadcastIP.To4() == nil ||
		!(broadcastIP.IsPrivate() || broadcastIP.Equal(net.IPv4bcast)) {
		return errors.New("broadcast inválido — use 255.255.255.255 ou um endereço IPv4 privado autorizado")
	}
	addr := net.JoinHostPort(broadcast, "9")
	udpAddr, err := net.ResolveUDPAddr("udp4", addr)
	if err != nil {
		return fmt.Errorf("endereço de broadcast inválido: %w", err)
	}
	conn, err := net.DialUDP("udp4", nil, udpAddr)
	if err != nil {
		return fmt.Errorf("falha ao abrir socket UDP: %w", err)
	}
	defer conn.Close()
	_ = conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if _, err := conn.Write(packet); err != nil {
		return fmt.Errorf("falha ao enviar magic packet: %w", err)
	}
	return nil
}

// buildMagicPacket mantém a montagem do pacote separada do envio UDP. Assim a
// regra pode ser testada sem depender de broadcast disponível no ambiente.
func buildMagicPacket(macAddr string) ([]byte, error) {
	mac, err := parseMAC(macAddr)
	if err != nil {
		return nil, err
	}
	packet := make([]byte, 0, 102)
	for i := 0; i < 6; i++ {
		packet = append(packet, 0xFF)
	}
	for i := 0; i < 16; i++ {
		packet = append(packet, mac...)
	}
	return packet, nil
}

func parseMAC(macAddr string) ([]byte, error) {
	mac := strings.TrimSpace(macAddr)
	mac = strings.NewReplacer("-", ":").Replace(mac)
	parts := strings.Split(mac, ":")
	if len(parts) != 6 {
		return nil, errors.New("endereço MAC inválido — use o formato AA:BB:CC:DD:EE:FF")
	}
	out := make([]byte, 6)
	for i, p := range parts {
		if len(p) != 2 {
			return nil, errors.New("endereço MAC inválido — use o formato AA:BB:CC:DD:EE:FF")
		}
		var b byte
		if _, err := fmt.Sscanf(p, "%02x", &b); err != nil {
			return nil, errors.New("endereço MAC inválido — use o formato AA:BB:CC:DD:EE:FF")
		}
		out[i] = b
	}
	return out, nil
}

// --- 6) Latência ---
// O legado mede ICMP echo a partir da máquina do usuário. Um servidor HTTP
// não tem privilégio de socket ICMP bruto por padrão; para não fingir um
// resultado ICMP que não é real, o servidor mede round-trip de conexão TCP
// (handshake) na porta informada (ou 443 por padrão), deixando explícito
// que é uma medição TCP a partir do servidor — não ICMP, não do cliente.
type LatencyResult struct {
	Sequencia int    `json:"sequencia"`
	TempoMs   int64  `json:"tempoMs"`
	Erro      string `json:"erro,omitempty"`
}

func TestarLatenciaTCP(ctx context.Context, host string, port int, tentativas int) ([]LatencyResult, error) {
	host = strings.TrimSpace(host)
	port, err := validation.ValidatePort(port, 443)
	if err != nil {
		return nil, err
	}
	targetIP, err := resolvePublicTarget(ctx, host)
	if err != nil {
		return nil, err
	}
	if tentativas < 1 || tentativas > 10 {
		tentativas = 4
	}
	addr := net.JoinHostPort(targetIP, strconv.Itoa(port))
	resultados := make([]LatencyResult, 0, tentativas)
	for i := 1; i <= tentativas; i++ {
		start := time.Now()
		d := net.Dialer{Timeout: 3 * time.Second}
		conn, dialErr := d.DialContext(ctx, "tcp", addr)
		elapsed := time.Since(start).Milliseconds()
		item := LatencyResult{Sequencia: i, TempoMs: elapsed}
		if dialErr != nil {
			item.Erro = dialErr.Error()
		} else {
			_ = conn.Close()
		}
		resultados = append(resultados, item)
	}
	return resultados, nil
}

// resolvePublicTarget evita SSRF para redes internas. Diagnósticos de LAN
// pertencem ao futuro Netzônia Agent, nunca ao servidor Web público.
func resolvePublicTarget(ctx context.Context, host string) (string, error) {
	if err := validation.ValidateHost(host); err != nil {
		return "", err
	}
	var addresses []net.IP
	if ip := net.ParseIP(host); ip != nil {
		addresses = []net.IP{ip}
	} else {
		resolved, err := net.DefaultResolver.LookupIP(ctx, "ip", host)
		if err != nil {
			return "", fmt.Errorf("não foi possível resolver o host: %w", err)
		}
		addresses = resolved
	}
	if len(addresses) == 0 {
		return "", errors.New("host não possui endereço IP")
	}
	for _, ip := range addresses {
		if ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() ||
			ip.IsMulticast() || ip.IsUnspecified() {
			return "", errors.New("destino privado ou reservado bloqueado no servidor Web; use o Netzônia Agent para diagnósticos locais")
		}
	}
	return addresses[0].String(), nil
}
