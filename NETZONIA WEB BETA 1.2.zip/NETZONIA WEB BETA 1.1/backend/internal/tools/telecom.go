// Portado de legacy-desktop-reference/novos_modulos.go — funções 16, 17, 18
// e 24 da matriz (Orçamento Óptico GPON/FTTH, Banda CFTV, Conversor de
// Grandezas Telecom e Gerador de String Wi-Fi). Mesma lógica e mensagens.
package tools

import (
	"crypto/rand"
	"errors"
	"fmt"
	"math"
	"math/big"
	"strings"

	"netzonia-web/backend/internal/validation"
)

// --- 16) Orçamento Óptico GPON/FTTH ---

type OrcamentoOpticoResult struct {
	NivelRecebido  float64 `json:"nivelRecebido"`
	AtenuacaoTotal float64 `json:"atenuacaoTotal"`
	OK             bool    `json:"ok"`
	Mensagem       string  `json:"mensagem"`
}

func CalcularOrcamentoOptico(potencia, distanciaKm, attPorKm float64, splitters []float64) (OrcamentoOpticoResult, error) {
	if err := validation.ValidateFinite("potência", potencia, -100, 100); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if err := validation.ValidateFinite("distância", distanciaKm, 0, 1000); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if err := validation.ValidateFinite("atenuação por km", attPorKm, 0, 100); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if len(splitters) > 128 {
		return OrcamentoOpticoResult{}, errors.New("quantidade excessiva de splitters")
	}
	attTotal := distanciaKm * attPorKm
	for _, loss := range splitters {
		if err := validation.ValidateFinite("atenuação de splitter", loss, 0, 100); err != nil {
			return OrcamentoOpticoResult{}, err
		}
		attTotal += loss
	}
	nivel := potencia - attTotal
	ok := nivel >= -27.0
	msg := fmt.Sprintf("Nível recebido: %.2f dBm (atenuação total: %.2f dB)", nivel, attTotal)
	if !ok {
		msg += " — ABAIXO DO LIMITE MÍNIMO DE -27 dBm!"
	}
	return OrcamentoOpticoResult{NivelRecebido: nivel, AtenuacaoTotal: attTotal, OK: ok, Mensagem: msg}, nil
}

// --- 17) Banda CFTV ---

type CFTVResult struct {
	BandaMbps float64 `json:"bandaMbps"`
	StorageTB float64 `json:"storageTB"`
	Mensagem  string  `json:"mensagem"`
}

func CalcularBandaCFTV(resolucao string, fps, cameras, dias int, codec string) (CFTVResult, error) {
	mbpsPorCam := map[string]float64{"720p": 1.0, "1080p": 2.0, "2mp": 2.0, "3mp": 3.5, "4mp": 4.0, "5mp": 5.0, "4k": 8.0, "8mp": 8.0}
	base, ok := mbpsPorCam[strings.ToLower(strings.TrimSpace(resolucao))]
	if !ok {
		return CFTVResult{}, errors.New("resolução CFTV não suportada")
	}
	if fps < 1 || fps > 240 {
		return CFTVResult{}, errors.New("FPS deve estar entre 1 e 240")
	}
	if cameras < 1 || cameras > 10000 {
		return CFTVResult{}, errors.New("quantidade de câmeras inválida")
	}
	if dias < 1 || dias > 3650 {
		return CFTVResult{}, errors.New("quantidade de dias inválida")
	}
	codec = strings.ToLower(strings.TrimSpace(codec))
	if codec != "" && codec != "h264" && codec != "h265" && codec != "hevc" {
		return CFTVResult{}, errors.New("codec não suportado")
	}
	base *= float64(fps) / 15.0
	if codec == "h265" || codec == "hevc" {
		base *= 0.6
	}
	bandaTotal := base * float64(cameras)
	storageTB := (bandaTotal / 8.0) * 3600.0 * 24.0 * float64(dias) / (1024.0 * 1024.0)
	return CFTVResult{BandaMbps: bandaTotal, StorageTB: storageTB, Mensagem: fmt.Sprintf("Banda estimada: %.1f Mbps | Armazenamento: %.2f TB (%d dias)", bandaTotal, storageTB, dias)}, nil
}

// --- 18) Conversor de Grandezas Telecom ---

type ConversaoResult struct {
	Entrada  float64 `json:"entrada"`
	Saida    float64 `json:"saida"`
	Unidade  string  `json:"unidade"`
	Mensagem string  `json:"mensagem"`
}

func ConverterGrandezas(tipo string, valor float64) (ConversaoResult, error) {
	if math.IsNaN(valor) || math.IsInf(valor, 0) {
		return ConversaoResult{}, errors.New("valor deve ser um número finito")
	}
	tipo = strings.ToLower(strings.TrimSpace(tipo))
	if tipo == "mw_dbm" && valor <= 0 {
		return ConversaoResult{}, errors.New("mW deve ser maior que zero para conversão em dBm")
	}
	if (tipo == "mbps_mbs" || tipo == "mbs_mbps") && valor < 0 {
		return ConversaoResult{}, errors.New("taxa de transferência não pode ser negativa")
	}
	switch tipo {
	case "dbm_mw":
		mw := math.Pow(10, valor/10.0)
		if math.IsInf(mw, 0) {
			return ConversaoResult{}, errors.New("resultado fora do intervalo numérico")
		}
		return ConversaoResult{Entrada: valor, Saida: mw, Unidade: "mW", Mensagem: fmt.Sprintf("%.2f dBm = %.4f mW", valor, mw)}, nil
	case "mw_dbm":
		dbm := 10 * math.Log10(valor)
		return ConversaoResult{Entrada: valor, Saida: dbm, Unidade: "dBm", Mensagem: fmt.Sprintf("%.4f mW = %.2f dBm", valor, dbm)}, nil
	case "mbps_mbs":
		mbs := valor / 8.0
		return ConversaoResult{Entrada: valor, Saida: mbs, Unidade: "MB/s", Mensagem: fmt.Sprintf("%.2f Mbps = %.2f MB/s", valor, mbs)}, nil
	case "mbs_mbps":
		mbps := valor * 8.0
		if math.IsInf(mbps, 0) {
			return ConversaoResult{}, errors.New("resultado fora do intervalo numérico")
		}
		return ConversaoResult{Entrada: valor, Saida: mbps, Unidade: "Mbps", Mensagem: fmt.Sprintf("%.2f MB/s = %.2f Mbps", valor, mbps)}, nil
	default:
		return ConversaoResult{}, errors.New("tipo de conversão desconhecido: use dbm_mw, mw_dbm, mbps_mbs ou mbs_mbps")
	}
}

// --- 24) Gerador de String Wi-Fi ---

func GerarStringWiFi(ssid, senha, tipoSeg string) (string, error) {
	if ssid == "" {
		return "", errors.New("SSID obrigatório")
	}
	if tipoSeg == "" {
		tipoSeg = "WPA"
	}
	if senha == "" {
		return fmt.Sprintf("WIFI:T:nopass;S:%s;;", escapeWiFi(ssid)), nil
	}
	return fmt.Sprintf("WIFI:T:%s;S:%s;P:%s;;", tipoSeg, escapeWiFi(ssid), escapeWiFi(senha)), nil
}

func escapeWiFi(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `;`, `\;`)
	s = strings.ReplaceAll(s, `:`, `\:`)
	s = strings.ReplaceAll(s, `,`, `\,`)
	return s
}

// --- 27) Gerador de Senhas Seguras ---

func GerarSenha(tamanho int, maiusculas, minusculas, numeros, simbolos bool) (string, error) {
	if tamanho < 4 || tamanho > 128 {
		return "", errors.New("tamanho deve ser entre 4 e 128")
	}
	var chars string
	if maiusculas {
		chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	}
	if minusculas {
		chars += "abcdefghijklmnopqrstuvwxyz"
	}
	if numeros {
		chars += "0123456789"
	}
	if simbolos {
		chars += "!@#$%^&*()-_=+[]{}|;:,.<>?"
	}
	if chars == "" {
		return "", errors.New("pelo menos um tipo de caractere deve ser selecionado")
	}
	n := big.NewInt(int64(len(chars)))
	result := make([]byte, tamanho)
	for i := 0; i < tamanho; i++ {
		v, err := rand.Int(rand.Reader, n)
		if err != nil {
			return "", fmt.Errorf("falha ao gerar aleatoriedade: %w", err)
		}
		result[i] = chars[v.Int64()]
	}
	return string(result), nil
}
