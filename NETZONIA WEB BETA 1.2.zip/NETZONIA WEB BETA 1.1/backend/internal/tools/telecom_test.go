package tools

import (
	"math"
	"testing"
)

func TestCalcularOrcamentoOptico(t *testing.T) {
	res, err := CalcularOrcamentoOptico(3, 5, 0.35, []float64{15.5})
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	// atenuação total = 5*0.35 + 15.5 = 17.25 ; nível = 3 - 17.25 = -14.25
	if math.Abs(res.AtenuacaoTotal-17.25) > 1e-9 {
		t.Errorf("atenuacaoTotal = %v, esperado 17.25", res.AtenuacaoTotal)
	}
	if math.Abs(res.NivelRecebido-(-14.25)) > 1e-9 {
		t.Errorf("nivelRecebido = %v, esperado -14.25", res.NivelRecebido)
	}
	if !res.OK {
		t.Error("esperava OK=true (acima de -27 dBm)")
	}
}

func TestCalcularOrcamentoOptico_AbaixoDoLimite(t *testing.T) {
	res, err := CalcularOrcamentoOptico(0, 100, 0.35, nil)
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	if res.OK {
		t.Error("esperava OK=false (abaixo de -27 dBm)")
	}
}

func TestCalcularBandaCFTV(t *testing.T) {
	res, err := CalcularBandaCFTV("1080p", 15, 8, 30, "h265")
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	// base 2.0 Mbps * (15/15) = 2.0 ; h265 * 0.6 = 1.2 ; * 8 câmeras = 9.6 Mbps
	if math.Abs(res.BandaMbps-9.6) > 1e-9 {
		t.Errorf("bandaMbps = %v, esperado 9.6", res.BandaMbps)
	}
}

func TestCalcularBandaCFTV_ResolucaoInvalida(t *testing.T) {
	if _, err := CalcularBandaCFTV("9999p", 15, 1, 1, ""); err == nil {
		t.Fatal("esperava erro para resolução não suportada")
	}
}

func TestConverterGrandezas_DbmParaMw(t *testing.T) {
	res, err := ConverterGrandezas("dbm_mw", 0)
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	if math.Abs(res.Saida-1.0) > 1e-9 {
		t.Errorf("0 dBm deveria ser 1 mW, obteve %v", res.Saida)
	}
}

func TestConverterGrandezas_MwParaDbmInvalido(t *testing.T) {
	if _, err := ConverterGrandezas("mw_dbm", 0); err == nil {
		t.Fatal("esperava erro para mW <= 0")
	}
}

func TestGerarStringWiFi_ComSenha(t *testing.T) {
	res, err := GerarStringWiFi("MinhaRede", "senha123", "WPA")
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	want := "WIFI:T:WPA;S:MinhaRede;P:senha123;;"
	if res != want {
		t.Errorf("string = %q, esperado %q", res, want)
	}
}

func TestGerarStringWiFi_RedeAberta(t *testing.T) {
	res, err := GerarStringWiFi("RedeLivre", "", "")
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	want := "WIFI:T:nopass;S:RedeLivre;;"
	if res != want {
		t.Errorf("string = %q, esperado %q", res, want)
	}
}

func TestGerarStringWiFi_SsidVazio(t *testing.T) {
	if _, err := GerarStringWiFi("", "x", "WPA"); err == nil {
		t.Fatal("esperava erro para SSID vazio")
	}
}

func TestGerarSenha_Tamanho(t *testing.T) {
	senha, err := GerarSenha(20, true, true, true, true)
	if err != nil {
		t.Fatalf("erro inesperado: %v", err)
	}
	if len(senha) != 20 {
		t.Errorf("tamanho da senha = %d, esperado 20", len(senha))
	}
}

func TestGerarSenha_SemTipoDeCaractere(t *testing.T) {
	if _, err := GerarSenha(10, false, false, false, false); err == nil {
		t.Fatal("esperava erro sem nenhum tipo de caractere selecionado")
	}
}

func TestGerarSenha_TamanhoForaDoLimite(t *testing.T) {
	if _, err := GerarSenha(2, true, true, true, true); err == nil {
		t.Fatal("esperava erro para tamanho menor que 4")
	}
	if _, err := GerarSenha(200, true, true, true, true); err == nil {
		t.Fatal("esperava erro para tamanho maior que 128")
	}
}
