package httpapi

import (
	"context"
	"net"
	"net/http"
	"os"
	"strings"
	"time"
)

// contextWithTimeout deriva do contexto da requisição (cancelado se o
// cliente desconectar) com um timeout adicional, para nunca deixar uma
// ferramenta de rede (DNS, latência) bloqueada indefinidamente no servidor.
func contextWithTimeout(r *http.Request, d time.Duration) (context.Context, context.CancelFunc) {
	return context.WithTimeout(r.Context(), d)
}

func trustedForwardedFor(r *http.Request) string {
	if !strings.EqualFold(os.Getenv("NETZONIA_TRUST_PROXY"), "true") {
		return ""
	}
	first, _, _ := strings.Cut(r.Header.Get("X-Forwarded-For"), ",")
	if ip := net.ParseIP(strings.TrimSpace(first)); ip != nil {
		return ip.String()
	}
	return ""
}

func requestClientIP(r *http.Request) string {
	if forwarded := trustedForwardedFor(r); forwarded != "" {
		return forwarded
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	if ip := net.ParseIP(strings.TrimSpace(host)); ip != nil {
		return ip.String()
	}
	return "unknown"
}
