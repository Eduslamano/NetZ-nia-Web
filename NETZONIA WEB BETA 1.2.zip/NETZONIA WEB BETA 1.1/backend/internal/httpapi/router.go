package httpapi

import (
	"encoding/json"
	"io"
	"net/http"
	"os"
	"strings"
	"time"

	"netzonia-web/backend/internal/tools"
)

const maxBodyBytes = 1 << 20 // 1 MiB — limite de tamanho de corpo da requisição

// NewRouter monta todas as rotas da API. Cada handler de ferramenta segue o
// mesmo padrão: decodifica JSON com limite de tamanho, valida, chama a
// função de tools/ (portada/adaptada do legado) e responde no envelope
// padronizado {ok, data} ou {ok:false, error}.
func NewRouter() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("/api/health", handleHealth)

	// WEB_NATIVE — cálculos puros, migração completa (prioridade máxima).
	mux.HandleFunc("/api/tools/vlsm", handleVLSM)
	mux.HandleFunc("/api/tools/orcamento-optico", handleOrcamentoOptico)
	mux.HandleFunc("/api/tools/cftv", handleCFTV)
	mux.HandleFunc("/api/tools/conversor-telecom", handleConversorTelecom)
	mux.HandleFunc("/api/tools/wifi-string", handleWifiString)
	mux.HandleFunc("/api/tools/senha", handleGerarSenha)

	// SERVER_API — a medição parte do servidor, não do cliente.
	mux.HandleFunc("/api/tools/dns", handleDNS)
	mux.HandleFunc("/api/tools/ssl", handleSSL)
	mux.HandleFunc("/api/tools/latencia", handleLatencia)
	mux.HandleFunc("/api/tools/ip-origem", handleIPOrigem)

	// HYBRID — só tem efeito se o servidor estiver na mesma LAN do alvo.
	mux.HandleFunc("/api/tools/wol", handleWakeOnLAN)

	return corsMiddleware(withCommonHeaders(rateLimitMiddleware(mux)))
}

func withCommonHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Cache-Control", "no-store")
		next.ServeHTTP(w, r)
	})
}

func decodeJSON(w http.ResponseWriter, r *http.Request, dst any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		fail(w, http.StatusBadRequest, "corpo da requisição inválido")
		return false
	}
	if err := dec.Decode(&struct{}{}); err != io.EOF {
		fail(w, http.StatusBadRequest, "o corpo deve conter um único objeto JSON")
		return false
	}
	return true
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		fail(w, http.StatusMethodNotAllowed, "use GET")
		return
	}
	ok(w, map[string]any{
		"service": "netzonia-api",
		"time":    time.Now().UTC().Format(time.RFC3339),
	})
}

// --- WEB_NATIVE ---

func handleVLSM(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Bloco string `json:"bloco"`
		Hosts []int  `json:"hosts"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.CalcularVLSM(req.Bloco, req.Hosts)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleOrcamentoOptico(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Potencia    float64   `json:"potencia"`
		DistanciaKm float64   `json:"distanciaKm"`
		AttPorKm    float64   `json:"attPorKm"`
		Splitters   []float64 `json:"splitters"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.CalcularOrcamentoOptico(req.Potencia, req.DistanciaKm, req.AttPorKm, req.Splitters)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleCFTV(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Resolucao string `json:"resolucao"`
		FPS       int    `json:"fps"`
		Cameras   int    `json:"cameras"`
		Dias      int    `json:"dias"`
		Codec     string `json:"codec"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.CalcularBandaCFTV(req.Resolucao, req.FPS, req.Cameras, req.Dias, req.Codec)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleConversorTelecom(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Tipo  string  `json:"tipo"`
		Valor float64 `json:"valor"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.ConverterGrandezas(req.Tipo, req.Valor)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleWifiString(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		SSID    string `json:"ssid"`
		Senha   string `json:"senha"`
		TipoSeg string `json:"tipoSeg"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.GerarStringWiFi(req.SSID, req.Senha, req.TipoSeg)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, map[string]string{"string": res})
}

func handleGerarSenha(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Tamanho    int  `json:"tamanho"`
		Maiusculas bool `json:"maiusculas"`
		Minusculas bool `json:"minusculas"`
		Numeros    bool `json:"numeros"`
		Simbolos   bool `json:"simbolos"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	res, err := tools.GerarSenha(req.Tamanho, req.Maiusculas, req.Minusculas, req.Numeros, req.Simbolos)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, map[string]string{"senha": res})
}

// --- SERVER_API ---

func handleDNS(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Hostname string `json:"hostname"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	ctx, cancel := contextWithTimeout(r, 20*time.Second)
	defer cancel()
	res, err := tools.TesteDNS(ctx, req.Hostname)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleSSL(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Host string `json:"host"`
		Port int    `json:"port"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	ctx, cancel := contextWithTimeout(r, 20*time.Second)
	defer cancel()
	res, err := tools.ValidarCertificadoSSL(ctx, req.Host, req.Port)
	if err != nil {
		fail(w, http.StatusBadGateway, err.Error())
		return
	}
	ok(w, res)
}

func handleLatencia(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	var req struct {
		Host       string `json:"host"`
		Port       int    `json:"port"`
		Tentativas int    `json:"tentativas"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	ctx, cancel := contextWithTimeout(r, 20*time.Second)
	defer cancel()
	res, err := tools.TestarLatenciaTCP(ctx, req.Host, req.Port, req.Tentativas)
	if err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, res)
}

func handleIPOrigem(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		fail(w, http.StatusMethodNotAllowed, "use GET")
		return
	}
	res := tools.IPOrigemDaRequisicao(r.RemoteAddr, trustedForwardedFor(r))
	ok(w, res)
}

func handleWakeOnLAN(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		fail(w, http.StatusMethodNotAllowed, "use POST")
		return
	}
	if !strings.EqualFold(os.Getenv("NETZONIA_ALLOW_WOL"), "true") {
		fail(w, http.StatusForbidden, "Wake-on-LAN está desativado neste servidor; habilite somente em implantação autorizada na rede local")
		return
	}
	var req struct {
		Mac       string `json:"mac"`
		Broadcast string `json:"broadcast"`
	}
	if !decodeJSON(w, r, &req) {
		return
	}
	if err := tools.WakeOnLAN(req.Mac, req.Broadcast); err != nil {
		fail(w, http.StatusBadRequest, err.Error())
		return
	}
	ok(w, map[string]string{"mensagem": "Magic packet enviado. Só acorda o equipamento se o servidor estiver na mesma LAN/VLAN roteada do alvo."})
}
