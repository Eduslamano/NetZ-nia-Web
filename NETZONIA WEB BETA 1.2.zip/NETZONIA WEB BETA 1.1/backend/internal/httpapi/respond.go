package httpapi

import (
	"encoding/json"
	"log"
	"net/http"
)

type envelope struct {
	OK    bool   `json:"ok"`
	Data  any    `json:"data,omitempty"`
	Error string `json:"error,omitempty"`
}

func writeJSON(w http.ResponseWriter, status int, body envelope) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(body); err != nil {
		log.Printf("falha ao serializar resposta: %v", err)
	}
}

// ok escreve uma resposta de sucesso padronizada.
func ok(w http.ResponseWriter, data any) {
	writeJSON(w, http.StatusOK, envelope{OK: true, Data: data})
}

// fail escreve um erro padronizado. A mensagem exposta ao cliente nunca deve
// conter detalhes internos (stack, paths, versões) — apenas o texto de
// validação/negócio já pensado para o usuário final nas funções de tools/.
func fail(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, envelope{OK: false, Error: msg})
}
