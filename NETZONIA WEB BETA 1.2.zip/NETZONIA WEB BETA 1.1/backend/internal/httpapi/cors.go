package httpapi

import (
	"net/http"
	"os"
	"strings"
)

// corsMiddleware aplica CORS a partir da variável de ambiente
// NETZONIA_CORS_ORIGINS (lista separada por vírgula). Em desenvolvimento,
// sem a variável definida, libera localhost em portas comuns de Vite.
// Nunca usa "*" quando NETZONIA_ENV=production sem origens explícitas —
// nesse caso nenhuma origem é liberada, para não silenciosamente abrir CORS.
func corsMiddleware(next http.Handler) http.Handler {
	allowed := allowedOrigins()
	isProd := strings.EqualFold(os.Getenv("NETZONIA_ENV"), "production")

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		if origin != "" && originAllowed(origin, allowed, isProd) {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Vary", "Origin")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func allowedOrigins() []string {
	raw := strings.TrimSpace(os.Getenv("NETZONIA_CORS_ORIGINS"))
	if raw == "" {
		return nil
	}
	parts := strings.Split(raw, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func originAllowed(origin string, allowed []string, isProd bool) bool {
	for _, a := range allowed {
		if a == origin {
			return true
		}
	}
	if len(allowed) > 0 {
		return false
	}
	if isProd {
		// Produção sem NETZONIA_CORS_ORIGINS configurada: nenhuma origem
		// liberada. É melhor falhar explicitamente do que abrir CORS geral.
		return false
	}
	// Desenvolvimento sem configuração explícita: localhost/127.0.0.1 em
	// qualquer porta (cobre o dev server padrão e portas alternativas do Vite).
	return strings.HasPrefix(origin, "http://localhost:") ||
		strings.HasPrefix(origin, "http://127.0.0.1:")
}
