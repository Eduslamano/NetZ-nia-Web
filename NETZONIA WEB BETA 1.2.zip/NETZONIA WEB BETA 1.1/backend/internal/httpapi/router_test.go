package httpapi

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestHealth(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, esperado 200", rec.Code)
	}
	var body envelope
	if err := json.NewDecoder(rec.Body).Decode(&body); err != nil {
		t.Fatalf("resposta não é JSON válido: %v", err)
	}
	if !body.OK {
		t.Error("esperava ok=true")
	}
}

func TestVLSMEndpoint_Sucesso(t *testing.T) {
	payload := `{"bloco":"192.168.0.0/24","hosts":[10,20]}`
	req := httptest.NewRequest(http.MethodPost, "/api/tools/vlsm", strings.NewReader(payload))
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, corpo = %s", rec.Code, rec.Body.String())
	}
	var body envelope
	if err := json.NewDecoder(rec.Body).Decode(&body); err != nil {
		t.Fatalf("resposta não é JSON válido: %v", err)
	}
	if !body.OK {
		t.Errorf("esperava ok=true, erro=%s", body.Error)
	}
}

func TestVLSMEndpoint_EntradaInvalida(t *testing.T) {
	payload := `{"bloco":"nao-e-cidr","hosts":[10]}`
	req := httptest.NewRequest(http.MethodPost, "/api/tools/vlsm", strings.NewReader(payload))
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, esperado 400", rec.Code)
	}
	var body envelope
	_ = json.NewDecoder(rec.Body).Decode(&body)
	if body.OK {
		t.Error("esperava ok=false para bloco CIDR inválido")
	}
}

func TestVLSMEndpoint_MetodoErrado(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/tools/vlsm", nil)
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusMethodNotAllowed {
		t.Fatalf("status = %d, esperado 405", rec.Code)
	}
}

func TestSenhaEndpoint(t *testing.T) {
	payload := `{"tamanho":16,"maiusculas":true,"minusculas":true,"numeros":true,"simbolos":false}`
	req := httptest.NewRequest(http.MethodPost, "/api/tools/senha", strings.NewReader(payload))
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, corpo = %s", rec.Code, rec.Body.String())
	}
}

func TestEndpointsDeCalculoPrioritarios(t *testing.T) {
	tests := []struct {
		name    string
		path    string
		payload string
	}{
		{"orçamento óptico", "/api/tools/orcamento-optico", `{"potencia":3,"distanciaKm":5,"attPorKm":0.35,"splitters":[15.5]}`},
		{"CFTV", "/api/tools/cftv", `{"resolucao":"1080p","fps":15,"cameras":8,"dias":30,"codec":"h265"}`},
		{"conversor", "/api/tools/conversor-telecom", `{"tipo":"dbm_mw","valor":0}`},
		{"string Wi-Fi", "/api/tools/wifi-string", `{"ssid":"Rede Teste","senha":"senha123","tipoSeg":"WPA"}`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest(http.MethodPost, tt.path, strings.NewReader(tt.payload))
			rec := httptest.NewRecorder()
			NewRouter().ServeHTTP(rec, req)
			if rec.Code != http.StatusOK {
				t.Fatalf("status = %d, corpo = %s", rec.Code, rec.Body.String())
			}
		})
	}
}

func TestEndpointsDeRedeBloqueiamDestinoPrivado(t *testing.T) {
	tests := []struct {
		path       string
		payload    string
		wantStatus int
	}{
		{"/api/tools/ssl", `{"host":"127.0.0.1","port":443}`, http.StatusBadGateway},
		{"/api/tools/latencia", `{"host":"192.168.1.1","port":443,"tentativas":1}`, http.StatusBadRequest},
	}
	for _, tt := range tests {
		req := httptest.NewRequest(http.MethodPost, tt.path, strings.NewReader(tt.payload))
		rec := httptest.NewRecorder()
		NewRouter().ServeHTTP(rec, req)
		if rec.Code != tt.wantStatus {
			t.Fatalf("%s: status = %d, esperado %d", tt.path, rec.Code, tt.wantStatus)
		}
	}
}

func TestJSONRejeitaCampoDesconhecidoECorpoGrande(t *testing.T) {
	req := httptest.NewRequest(http.MethodPost, "/api/tools/vlsm", strings.NewReader(`{"bloco":"10.0.0.0/24","hosts":[10],"extra":true}`))
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("campo desconhecido: status = %d", rec.Code)
	}

	large := `{"bloco":"` + strings.Repeat("a", maxBodyBytes+1) + `","hosts":[10]}`
	req = httptest.NewRequest(http.MethodPost, "/api/tools/vlsm", strings.NewReader(large))
	req.RemoteAddr = "203.0.113.77:1000"
	rec = httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("corpo grande: status = %d", rec.Code)
	}
}

func TestCORS_OrigemNaoListadaEmProducao(t *testing.T) {
	t.Setenv("NETZONIA_ENV", "production")
	t.Setenv("NETZONIA_CORS_ORIGINS", "")
	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	req.Header.Set("Origin", "https://exemplo-nao-autorizado.com")
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Header().Get("Access-Control-Allow-Origin") != "" {
		t.Error("produção sem allowlist não deveria liberar CORS para origem arbitrária")
	}
}

func TestCORS_OrigemListadaLiberada(t *testing.T) {
	t.Setenv("NETZONIA_ENV", "production")
	t.Setenv("NETZONIA_CORS_ORIGINS", "https://netzonia.exemplo.com")
	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	req.Header.Set("Origin", "https://netzonia.exemplo.com")
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Header().Get("Access-Control-Allow-Origin") != "https://netzonia.exemplo.com" {
		t.Error("origem explicitamente listada deveria ser liberada")
	}
}

func TestWakeOnLANDesativadoPorPadrao(t *testing.T) {
	t.Setenv("NETZONIA_ALLOW_WOL", "false")
	payload := `{"mac":"AA:BB:CC:DD:EE:FF","broadcast":"255.255.255.255"}`
	req := httptest.NewRequest(http.MethodPost, "/api/tools/wol", strings.NewReader(payload))
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("status = %d, esperado 403", rec.Code)
	}
}

func TestIPOrigemIgnoraForwardedForSemProxyConfiavel(t *testing.T) {
	t.Setenv("NETZONIA_TRUST_PROXY", "false")
	req := httptest.NewRequest(http.MethodGet, "/api/tools/ip-origem", nil)
	req.RemoteAddr = "203.0.113.5:1234"
	req.Header.Set("X-Forwarded-For", "198.51.100.8")
	rec := httptest.NewRecorder()
	NewRouter().ServeHTTP(rec, req)
	if !strings.Contains(rec.Body.String(), "203.0.113.5") {
		t.Fatalf("resposta deveria usar RemoteAddr, corpo = %s", rec.Body.String())
	}
}

func TestClientIPUsaForwardedForSomenteComProxyConfiavel(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	req.RemoteAddr = "203.0.113.5:1234"
	req.Header.Set("X-Forwarded-For", "198.51.100.8, 10.0.0.2")
	t.Setenv("NETZONIA_TRUST_PROXY", "false")
	if got := requestClientIP(req); got != "203.0.113.5" {
		t.Fatalf("sem proxy confiável: %q", got)
	}
	t.Setenv("NETZONIA_TRUST_PROXY", "true")
	if got := requestClientIP(req); got != "198.51.100.8" {
		t.Fatalf("com proxy confiável: %q", got)
	}
}

func TestClientIPRejeitaForwardedForInvalido(t *testing.T) {
	t.Setenv("NETZONIA_TRUST_PROXY", "true")
	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	req.RemoteAddr = "203.0.113.5:1234"
	req.Header.Set("X-Forwarded-For", "texto-invalido")
	if got := requestClientIP(req); got != "203.0.113.5" {
		t.Fatalf("deveria usar RemoteAddr; recebeu %q", got)
	}
}
