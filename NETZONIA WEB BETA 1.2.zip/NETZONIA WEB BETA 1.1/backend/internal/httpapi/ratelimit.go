package httpapi

import (
	"net/http"
	"sync"
	"time"
)

type rateEntry struct {
	window time.Time
	count  int
}

var requestRates = struct {
	sync.Mutex
	entries map[string]rateEntry
}{entries: make(map[string]rateEntry)}

const requestsPerMinute = 120

func rateLimitMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host := requestClientIP(r)
		now := time.Now()
		requestRates.Lock()
		entry := requestRates.entries[host]
		if entry.window.IsZero() || now.Sub(entry.window) >= time.Minute {
			entry = rateEntry{window: now}
		}
		entry.count++
		requestRates.entries[host] = entry
		blocked := entry.count > requestsPerMinute
		if len(requestRates.entries) > 10000 {
			for key, candidate := range requestRates.entries {
				if now.Sub(candidate.window) > 2*time.Minute {
					delete(requestRates.entries, key)
				}
			}
		}
		requestRates.Unlock()
		if blocked {
			w.Header().Set("Retry-After", "60")
			fail(w, http.StatusTooManyRequests, "limite de requisições excedido")
			return
		}
		next.ServeHTTP(w, r)
	})
}
