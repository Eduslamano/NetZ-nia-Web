module netzonia-web/backend

go 1.22
