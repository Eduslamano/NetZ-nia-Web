//go:build !windows

package main

import (
	"errors"
	"os"
	"os/exec"
	"runtime"
)

func dpapiEncrypt(data []byte) ([]byte, error) {
	return nil, errors.New("cofre seguro de credenciais ainda não implementado nesta plataforma")
}
func dpapiDecrypt(data []byte) ([]byte, error) {
	return nil, errors.New("cofre seguro de credenciais ainda não implementado nesta plataforma")
}
func systemBeep() {
	if runtime.GOOS == "darwin" {
		_ = exec.Command("afplay", "/System/Library/Sounds/Tink.aiff").Start()
		return
	}
	// O comando é inteiramente estático e não recebe entrada externa.
	_ = exec.Command("sh", "-c", "printf \\a").Start()
}
func (a *App) SolicitarElevacaoUAC() error {
	exe, err := os.Executable()
	if err != nil || exe == "" {
		return errors.New("não foi possível determinar o executável")
	}
	if runtime.GOOS == "darwin" {
		// O caminho do executável é passado em argv e quoted form é aplicado pelo
		// próprio AppleScript, evitando interpolação em código/shell.
		return exec.Command("osascript",
			"-e", "on run argv",
			"-e", "do shell script (quoted form of item 1 of argv) with administrator privileges",
			"-e", "end run",
			exe,
		).Start()
	}
	return exec.Command("pkexec", exe).Start()
}
