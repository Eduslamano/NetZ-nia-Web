package main

import "testing"

func TestSanitizeNomeArquivo(t *testing.T) {
	got := sanitizeNomeArquivo(`Cliente: Loja/A?*<>|`)
	if got == `Cliente: Loja/A?*<>|` {
		t.Fatalf("sanitizeNomeArquivo não alterou caracteres inválidos: %q", got)
	}
	if got == "" {
		t.Fatal("sanitizeNomeArquivo não deve esvaziar um nome válido")
	}
}
