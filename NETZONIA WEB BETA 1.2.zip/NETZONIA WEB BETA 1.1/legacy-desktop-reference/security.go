package main

import (
	"errors"
	"fmt"
	"math"
	"net"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

// hostnamePattern aceita hostnames no padrão RFC 1123 (letras, dígitos,
// hífen, ponto entre rótulos). Não aceita espaços, barras ou metacaracteres.
var hostnamePattern = regexp.MustCompile(`^[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,62}(?:\.[a-zA-Z0-9][a-zA-Z0-9\-]{0,62})*)?$`)
var oidPattern = regexp.MustCompile(`^(?:\.?[0-9]+)(?:\.[0-9]+)*$`)
var profilePattern = regexp.MustCompile(`^[\p{L}\p{N} _.-]{1,64}$`)
var placeIDPattern = regexp.MustCompile(`^[a-zA-Z0-9_.-]{1,256}$`)

func validateHost(host string) error {
	host = strings.TrimSpace(host)
	if host == "" {
		return errors.New("host vazio")
	}
	if len(host) > 253 || strings.HasPrefix(host, "-") {
		return errors.New("host inválido")
	}
	if ip := net.ParseIP(host); ip != nil {
		return nil
	}
	if hostnamePattern.MatchString(host) {
		return nil
	}
	return errors.New("host inválido — use um endereço IP ou hostname válido")
}

func validatePort(port int, defaultPort int) (int, error) {
	if port == 0 && defaultPort > 0 {
		port = defaultPort
	}
	if port < 1 || port > 65535 {
		return 0, errors.New("porta inválida: use um valor entre 1 e 65535")
	}
	return port, nil
}

func validateBoundedText(name, value string, minRunes, maxRunes int, allowNewline bool) (string, error) {
	value = strings.TrimSpace(value)
	n := len([]rune(value))
	if n < minRunes {
		return "", fmt.Errorf("%s obrigatório", name)
	}
	if n > maxRunes {
		return "", fmt.Errorf("%s excede o tamanho máximo de %d caracteres", name, maxRunes)
	}
	for _, r := range value {
		if unicode.IsControl(r) && !(allowNewline && (r == '\n' || r == '\r' || r == '\t')) {
			return "", fmt.Errorf("%s contém caracteres de controle inválidos", name)
		}
	}
	return value, nil
}

func validateSNMPCommunity(community string) (string, error) {
	// A community é passada como argumento de processo, nunca como shell. Ainda
	// limitamos comprimento/controles e bloqueamos prefixo de flag para impedir
	// argument injection no snmpget.
	value, err := validateBoundedText("community SNMP", community, 1, 128, false)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(value, "-") {
		return "", errors.New("community SNMP inválida")
	}
	return value, nil
}

func validateOID(oid string) (string, error) {
	oid = strings.TrimSpace(oid)
	if oid == "" {
		oid = "1.3.6.1.2.1.1.3.0"
	}
	if len(oid) > 256 || !oidPattern.MatchString(oid) {
		return "", errors.New("OID SNMP inválido")
	}
	if strings.HasPrefix(oid, "-") {
		return "", errors.New("OID SNMP inválido")
	}
	return oid, nil
}

func validatePPPoEProfile(profile string) (string, error) {
	profile = strings.TrimSpace(profile)
	if profile == "" {
		profile = "NetZonia_Temp"
	}
	if !profilePattern.MatchString(profile) || strings.Contains(profile, "..") || strings.ContainsAny(profile, "[]\r\n") {
		return "", errors.New("nome do perfil PPPoE inválido")
	}
	return profile, nil
}

func validateIPv4Mask(maskText string) (net.IPMask, error) {
	ip := net.ParseIP(strings.TrimSpace(maskText))
	if ip == nil || ip.To4() == nil {
		return nil, errors.New("máscara IPv4 inválida")
	}
	b := ip.To4()
	mask := net.IPMask([]byte{b[0], b[1], b[2], b[3]})
	ones, bits := mask.Size()
	if bits != 32 || ones < 0 {
		return nil, errors.New("máscara IPv4 deve ser contígua (ex.: 255.255.255.0)")
	}
	return mask, nil
}

func validateFinite(name string, value float64, min, max float64) error {
	if math.IsNaN(value) || math.IsInf(value, 0) {
		return fmt.Errorf("%s deve ser um número finito", name)
	}
	if value < min || value > max {
		return fmt.Errorf("%s fora do intervalo permitido (%s a %s)", name,
			strconv.FormatFloat(min, 'f', -1, 64), strconv.FormatFloat(max, 'f', -1, 64))
	}
	return nil
}

func validatePlaceID(placeID string) error {
	if !placeIDPattern.MatchString(strings.TrimSpace(placeID)) {
		return errors.New("placeId inválido")
	}
	return nil
}
