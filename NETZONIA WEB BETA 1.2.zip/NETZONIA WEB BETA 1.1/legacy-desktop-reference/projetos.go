package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// -----------------------------------------------------------------------------
// MAPA 3D — PERSISTÊNCIA DE PROJETO POR LOCAL
//
// Cada local pesquisado no Google Places (#/local) vira um arquivo JSON em
// disco, identificado pelo placeId. Isso cumpre a exigência de segurança já
// documentada: o JavaScript da webview nunca grava arquivo diretamente — só
// o Go toca no disco. Consumido pelo frontend via:
//   frontend/src/lib/wails-bridge.js → salvarProjetoLocal / carregarProjetoLocal / listarProjetosLocais
//   frontend/src/mapa3d/mapa3dView.js (salvar/carregar ao abrir #/mapa3d/:placeId)
//   frontend/src/views/placeSearchView.js (lista de "Projetos salvos")
// -----------------------------------------------------------------------------

// ProjetoLocal é o registro salvo em disco para um local pesquisado.
type ProjetoLocal struct {
	PlaceID   string  `json:"placeId"`
	Endereco  string  `json:"endereco"`
	Lat       float64 `json:"lat"`
	Lng       float64 `json:"lng"`
	DadosJSON string  `json:"dadosJSON"` // snapshot serializado do mapa3dView (nodes + cables)
}

// ProjetoLocalResumo é a versão enxuta usada na listagem (sem o snapshot
// completo, que pode ser grande).
type ProjetoLocalResumo struct {
	PlaceID  string  `json:"placeId"`
	Endereco string  `json:"endereco"`
	Lat      float64 `json:"lat"`
	Lng      float64 `json:"lng"`
}

var placeIDSanitizer = regexp.MustCompile(`[^a-zA-Z0-9_\-.]`)

// projetosDir devolve (e cria se preciso) a pasta onde os projetos por
// local ficam salvos: <diretório de config do usuário>/netzonia/projetos.
func projetosDir() (string, error) {
	base, err := os.UserConfigDir()
	if err != nil || strings.TrimSpace(base) == "" {
		return "", fmt.Errorf("não foi possível localizar a pasta de configuração do usuário")
	}
	dir := filepath.Join(base, "netzonia", "projetos")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", fmt.Errorf("não foi possível preparar a pasta de projetos: %w", err)
	}
	return dir, nil
}

// arquivoDoProjeto sanitiza o placeId (vindo do Google Places) para um
// nome de arquivo seguro, evitando qualquer tentativa de path traversal.
func arquivoDoProjeto(dir, placeID string) string {
	seguro := placeIDSanitizer.ReplaceAllString(placeID, "_")
	if seguro == "" {
		seguro = "local"
	}
	return filepath.Join(dir, seguro+".json")
}

// SalvarProjetoLocal grava (ou sobrescreve) o snapshot do Mapa 3D vinculado
// a um local. Exposto ao frontend via Wails.
func (a *App) SalvarProjetoLocal(placeID, endereco string, lat, lng float64, dadosJSON string) (bool, error) {
	placeID = strings.TrimSpace(placeID)
	if err := validatePlaceID(placeID); err != nil {
		return false, err
	}
	if math.IsNaN(lat) || math.IsInf(lat, 0) || lat < -90 || lat > 90 || math.IsNaN(lng) || math.IsInf(lng, 0) || lng < -180 || lng > 180 {
		return false, fmt.Errorf("coordenadas inválidas")
	}
	if len([]rune(endereco)) > 2048 {
		return false, fmt.Errorf("endereço excede o tamanho máximo")
	}
	if len(dadosJSON) > 10*1024*1024 {
		return false, fmt.Errorf("projeto excede o limite de 10 MiB")
	}
	var probe any
	if err := json.Unmarshal([]byte(dadosJSON), &probe); err != nil {
		return false, fmt.Errorf("dados do projeto não contêm JSON válido: %w", err)
	}
	dir, err := projetosDir()
	if err != nil {
		return false, err
	}

	registro := ProjetoLocal{PlaceID: placeID, Endereco: endereco, Lat: lat, Lng: lng, DadosJSON: dadosJSON}
	bruto, err := json.Marshal(registro)
	if err != nil {
		return false, fmt.Errorf("falha ao serializar o projeto: %w", err)
	}

	caminho := arquivoDoProjeto(dir, placeID)
	if err := atomicWriteFile(caminho, bruto, 0o600); err != nil {
		return false, fmt.Errorf("falha ao gravar o projeto em disco: %w", err)
	}
	return true, nil
}

// CarregarProjetoLocal devolve o snapshot (campo DadosJSON) salvo para um
// placeId, ou string vazia se não houver projeto salvo para esse local.
func (a *App) CarregarProjetoLocal(placeID string) (string, error) {
	placeID = strings.TrimSpace(placeID)
	if err := validatePlaceID(placeID); err != nil {
		return "", err
	}
	dir, err := projetosDir()
	if err != nil {
		return "", err
	}
	caminho := arquivoDoProjeto(dir, placeID)

	info, statErr := os.Stat(caminho)
	if statErr == nil && info.Size() > 12*1024*1024 {
		return "", fmt.Errorf("projeto salvo excede o tamanho permitido")
	}
	bruto, err := os.ReadFile(caminho)
	if os.IsNotExist(err) {
		return "", nil // nenhum projeto salvo ainda para este local — não é erro
	}
	if err != nil {
		return "", fmt.Errorf("falha ao ler o projeto salvo: %w", err)
	}

	var registro ProjetoLocal
	if err := json.Unmarshal(bruto, &registro); err != nil {
		return "", fmt.Errorf("projeto salvo está corrompido: %w", err)
	}
	return registro.DadosJSON, nil
}

// ListarProjetosLocais devolve o resumo de todos os locais com projeto
// salvo, para a tela de busca (#/local) mostrar "Projetos salvos".
func (a *App) ListarProjetosLocais() ([]ProjetoLocalResumo, error) {
	dir, err := projetosDir()
	if err != nil {
		return nil, err
	}

	entradas, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("falha ao listar projetos salvos: %w", err)
	}

	resultado := make([]ProjetoLocalResumo, 0, len(entradas))
	for _, entrada := range entradas {
		if entrada.IsDir() || filepath.Ext(entrada.Name()) != ".json" {
			continue
		}
		if info, err := entrada.Info(); err != nil || info.Size() > 12*1024*1024 {
			continue
		}
		bruto, err := os.ReadFile(filepath.Join(dir, entrada.Name()))
		if err != nil {
			continue
		}
		var registro ProjetoLocal
		if err := json.Unmarshal(bruto, &registro); err != nil {
			continue
		}
		resultado = append(resultado, ProjetoLocalResumo{
			PlaceID:  registro.PlaceID,
			Endereco: registro.Endereco,
			Lat:      registro.Lat,
			Lng:      registro.Lng,
		})
	}
	return resultado, nil
}
