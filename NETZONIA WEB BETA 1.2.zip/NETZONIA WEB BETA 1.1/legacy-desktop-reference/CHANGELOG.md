## P20 — Hardening de Produção — 14/09/2026
- Persistência de projetos 3D e credenciais protegidas passou a usar gravação temporária, flush e rename para reduzir corrupção por encerramento anormal.
- Inicialização remove somente temporários PPPoE do próprio Netzônia com mais de 24 horas.
- Falhas de inicialização do Wails passam a gerar diagnóstico local sanitizado.
- Adicionado preflight não bloqueante do diretório persistente do usuário.
- Build frontend no Wails alterado para `npm ci`, preservando o lockfile.
- Metadados de produto/versionamento foram preenchidos no `wails.json` para preparação da distribuição.
- 31 funcionalidades e código do Mapa 3D preservados; nenhuma lógica funcional foi redesenhada.


## 3.2 - P15 final (2026-09-08)
- Corrigidos Ping Sonoro, PPPoE, Gerenciador de Dispositivos e listagem/configuração de interfaces.
- Funções 15–31 passaram a alimentar o relatório de sessão.
- VLSM ganhou validação de capacidade do bloco.
- Servidor LAN passou a validar bind/porta antes de anunciar estado ativo.
- Credenciais usam nome de arquivo derivado por hash e DPAPI no Windows.
- SSH passou a validar chave do host por TOFU; gerador de senhas usa seleção criptográfica sem viés de módulo.
- Documentação atualizada para 31 funcionalidades.

# Integração P15 — módulos 15–31

- Integração frontend completa dos módulos adicionados em `novos_modulos.go`.
- Novos cards 15–31 na tela inicial.
- Ponte Wails/JavaScript adicionada para VLSM, orçamento óptico, CFTV, conversor telecom, SSH, Wake-on-LAN, ping sonoro, PPPoE, servidor LAN, string Wi-Fi, SNMP, SSL, gerador de senhas, atalhos Windows, configuração de IP, IPv6 e credenciais seguras.
- Formulários parametrizados e painéis especiais para ping sonoro, servidor LAN, configuração IP e credenciais.
- Renderização de resultados para os novos módulos.
- CSS ampliado para selects, senhas e checkboxes.
- Frontend recompilado com sucesso.

# Changelog

O projeto ainda não possui numeração formal de releases. Este histórico registra o ciclo acadêmico/técnico conhecido.

## P1–P8
Correções críticas e de integração: detecção EMI por segmento, consistência de remoção rack/cabos/portas, separação de mocks de produção, geocodificação via Go, correções de descoberta de dispositivos, validações de build/ferramentas de rede, revisão de bindings e resiliência das dependências cartográficas.

## P9
Tratamento de erros e logs: mensagens amigáveis, sanitização, UTF-8, rotação e controle de repetição.

## P10
Ampliação de testes automatizados Go para segurança, logs, geocodificação, orçamento, dispositivos/ARP e EMI.

## P11
Documentação e preparação final acadêmica. Nenhuma lógica funcional, teste ou dependência foi alterada nesta etapa.

## P12
Ajustes funcionais e visuais no Mapa 3D (`frontend/src/mapa3d/`), a pedido do usuário, a partir de feedback sobre a aparência e usabilidade do módulo:
- **Correção de bug**: o sombreamento das faces dos equipamentos (`scene3d.js` → `_shade`) subtraía um valor fixo de cada canal RGB para escurecer, o que zerava (virava preto puro) cores de base já escuras — como o rack aberto e alguns switches. Trocado por escala multiplicativa, que preserva a cor original em qualquer face.
- Piso/grade padrão da cena ampliado de 20 m para 34 m de lado.
- Modo tela cheia na view do Mapa 3D (botão na barra de ferramentas + botão de saída sempre visível sobre o canvas, além do Esc padrão do navegador).
- Campo de busca na biblioteca de equipamentos/cabos: filtra por nome ou categoria e mostra os resultados já com a ação de colocar/usar.
- Preview "fantasma": ao selecionar um item, uma silhueta semi-transparente do formato/tamanho real do equipamento acompanha o cursor sobre a planta antes do clique, com contorno verde (posição válida) ou vermelho (ex.: em cima de parede, sem rack próximo).
- Reforço visual dos modelos: LEDs de status em switches e roteadores, roteador com 4 antenas (antes 2), cabos com efeito de volume (dupla camada de traço) e conectores nas pontas no estilo plugue RJ45.
- Novo item no catálogo de equipamentos: **Switch 24p (2 fileiras)** — chassis escuro com 2 fileiras de 12 jaques RJ45 metálicos, desenho dedicado (`shape: "switch-2row"`), baseado em foto de referência enviada pelo usuário.

Nenhuma mudança nesta etapa tocou o backend Go.

## P13
Correção do encaixe de equipamentos de parede (`mountingType: "wall"`), reportado pelo usuário: ao adicionar Access Point (parede) e itens similares, eles eram posicionados soltos no chão (altura 0) exatamente no ponto clicado, sem nenhum encaixe na parede — pareciam "atravessar" a parede em vez de ficar fixados nela.
- `nearestWallPoint` (antes declarada mas nunca chamada em lugar nenhum do fluxo de colocação) agora é usada de fato: ao posicionar um item de parede, o sistema busca o ponto mais próximo numa parede desenhada manualmente **ou numa aresta do contorno do prédio carregado do local** (antes só as paredes manuais eram consideradas — quem usava só a busca de endereço/OpenStreetMap nunca tinha onde encaixar).
- O item é deslocado pra fora da parede (no sentido de onde o usuário clicou) pela metade da sua profundidade, então fica "colado" na face da parede em vez de cravado atravessando-a.
- Cada tipo de equipamento de parede ganhou uma altura de montagem típica (`alturaParede`) no catálogo — ex.: tomada a 0,3 m, AP de parede a 2,2 m, mini-rack de parede a 1,6 m — em vez de todos caírem no chão (altura 0).
- Se não houver nenhuma parede/contorno por perto, a colocação é recusada com aviso, em vez de posicionar o item solto no meio do ambiente.
- O preview "fantasma" (P12) foi atualizado pra mostrar a mesma posição de encaixe antes do clique.

Limitação conhecida: o item ainda é desenhado como caixa alinhada aos eixos X/Z do mundo, sem girar pra acompanhar o ângulo da parede quando ela é diagonal — a posição/altura ficam corretas, mas a orientação visual do "corpo" do equipamento não rotaciona ainda.

## P18 — UX, acabamento, responsividade e consistência (2026-09-14)
- Navegação de cada funcionalidade agora retorna para sua categoria de origem, em vez de voltar sempre à página inicial.
- Menu lateral mantém o contexto ativo ao navegar dentro de uma funcionalidade e também nas rotas do Planejador (`#/local` e `#/mapa3d`).
- Menu lateral recebeu gerenciamento de foco, ciclo de Tab e restauração de foco ao fechar.
- Modal de saída recebeu foco inicial, contenção de foco, restauração ao cancelar/fechar, ARIA descritiva e textos de ação mais claros.
- Toasts receberam semântica de acessibilidade e visual específico para avisos (`warn`).
- Responsividade refinada para janelas estreitas: formulários, botões, modal, cabeçalho, filtros e notificações.
- Removida a restrição `user-scalable=no` da viewport.
- Botões em operações assíncronas agora expõem `aria-busy` durante execução.
- Linguagem da entrada do Planejador 3D revisada para apresentação comercial, removendo referências internas a versões/fases anteriores.
- Nenhum arquivo Go, contrato Wails, definição das 31 funcionalidades ou código/CSS do Mapa 3D foi alterado.

### Ajuste visual pós-validação da P18 — cartões de resultado
- Corrigido o comportamento de textos longos nos cartões de estatística (`stat-grid`), observado na função 13 — IP Externo + Geolocalização.
- Valores extensos agora reduzem a tipografia de forma controlada e quebram linha dentro do próprio card, sem ultrapassar seus limites.
- O ajuste foi aplicado ao componente compartilhado de resultados, cobrindo também outros campos potencialmente longos como URL do Servidor LAN, emissor/subject SSL, endereços IPv6 e mensagens do Conversor Telecom.
- Nenhuma lógica das 31 funcionalidades, backend Go, contrato Wails ou módulo Mapa 3D foi alterada.

## P19 — Release Candidate RC1 — 14/09/2026
- Auditoria final de regressão estrutural sobre a base aprovada da P18.
- Confirmadas 31 funcionalidades, bridge frontend e bindings Wails.
- Mapa 3D preservado sem alteração de lógica.
- Frontend recompilado com sucesso; `npm audit` sem vulnerabilidades reportadas.
- Criado `MANIFESTO_SHA256_P19.txt` para congelamento de integridade do RC1.
- Nenhum código de produção foi alterado nesta prioridade.

## P21 — Empacotamento e Instalador
- Adicionado projeto de instalador Windows com Inno Setup 6 em `installer/`.
- Adicionado script `COMPILAR_INSTALADOR.bat` para geração do Setup no Windows.
- Instalação x64 em Program Files, atalhos, registro no Windows e desinstalador.
- Dados do usuário não são removidos pelo desinstalador.
- Aviso preventivo caso o WebView2 Runtime não seja localizado.
- Nenhuma das 31 funcionalidades, bridge Wails ou lógica do módulo 3D foi alterada nesta prioridade.

## 1.0.0 — P22 Release Oficial — 14/09/2026
- Consolidação da primeira release estável do Netzônia para Windows x64.
- 31 funcionalidades preservadas e congeladas a partir da P21 validada.
- Planejador/Mapa 3D preservado sem alteração funcional na P22.
- Metadados de produto promovidos de 0.9.0 para 1.0.0.
- Instalador Inno Setup promovido para Netzonia-Setup-1.0.0.exe.
- Auditoria final de catálogo, frontend, 3D, empacotamento e integridade.
- Documentação histórica P15–P22 consolidada.
