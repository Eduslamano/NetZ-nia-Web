package main

import "testing"

func TestCruzaZonaRiscoSegmentoAtravessaComPontasFora(t *testing.T) {
	pontos := []PontoCabo{{X: 0, Z: 0}, {X: 10, Z: 0}}
	zonas := []ZonaRisco{{X: 5, Z: 0, Raio: 1}}

	if !cruzaZonaRisco(pontos, zonas) {
		t.Fatal("esperava alerta EMI quando o segmento atravessa a zona com as duas pontas fora")
	}
}

func TestCruzaZonaRiscoSegmentoPassaFora(t *testing.T) {
	pontos := []PontoCabo{{X: 0, Z: 0}, {X: 10, Z: 0}}
	zonas := []ZonaRisco{{X: 5, Z: 2.01, Raio: 2}}

	if cruzaZonaRisco(pontos, zonas) {
		t.Fatal("não esperava alerta EMI quando o segmento passa fora do raio")
	}
}

func TestCruzaZonaRiscoUsaRaioPadrao(t *testing.T) {
	pontos := []PontoCabo{{X: 0, Z: 0}, {X: 10, Z: 0}}
	zonas := []ZonaRisco{{X: 5, Z: 1.1, Raio: 0}}

	if !cruzaZonaRisco(pontos, zonas) {
		t.Fatal("esperava uso do raio EMI padrão de 1.2m")
	}
}

func TestCruzaZonaRiscoPontoUnico(t *testing.T) {
	pontos := []PontoCabo{{X: 1, Z: 1}}
	zonas := []ZonaRisco{{X: 1.5, Z: 1, Raio: 0.6}}

	if !cruzaZonaRisco(pontos, zonas) {
		t.Fatal("esperava detectar ponto único dentro da zona EMI")
	}
}
