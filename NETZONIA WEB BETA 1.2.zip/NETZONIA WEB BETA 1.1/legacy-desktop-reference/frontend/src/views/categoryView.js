// ---------------------------------------------------------------------
// categoryView.js — tela de UMA categoria: cabeçalho da categoria +
// grade das ferramentas que pertencem a ela (antigas e novas juntas,
// na ordem numérica original).
// ---------------------------------------------------------------------

import { el, clear } from "../lib/dom.js";
import { CATEGORIES } from "../data/categories.js";
import { toolsByCategory } from "../data/tools.js";
import { renderFeatureCard } from "../components/featureCard.js";
import { icons } from "../data/icons.js";

export function renderCategoryView(container, categoryId) {
  clear(container);

  const category = CATEGORIES[categoryId];

  if (!category) {
    container.appendChild(
      el("div", { class: "view" }, [
        el("a", { href: "#/", class: "feature-back" }, [el("span", { html: icons.back }), "Voltar ao início"]),
        el("div", { class: "state-msg error", text: "Categoria não encontrada." }),
      ])
    );
    return () => {};
  }

  const tools = toolsByCategory(categoryId);

  const view = el("div", { class: "view" }, [
    el("a", { href: "#/", class: "feature-back" }, [el("span", { html: icons.back }), "Voltar ao início"]),
    el("div", { class: `category-header ${category.tone}` }, [
      el("div", { class: "category-header-icon", html: category.icon }),
      el("div", {}, [
        el("h1", { class: "view-title", text: category.label }),
        el("p", { class: "view-subtitle", text: category.description }),
      ]),
    ]),
    el(
      "div",
      { class: "tool-grid" },
      tools.length ? tools.map((t) => renderFeatureCard(t)) : [el("div", { class: "state-msg info", text: "Nenhuma ferramenta cadastrada nesta categoria ainda." })]
    ),
  ]);

  container.appendChild(view);
  return () => {};
}
