// ---------------------------------------------------------------------
// placeSearchView.js — tela "Buscar Local" (#/local).
//
// Fluxo (conforme especificado):
//   1) Usuário digita endereço/prédio → busca por Nominatim (OpenStreetMap),
//      com debounce, e mostra sugestões numa lista abaixo do campo
//   2) Clica numa sugestão → mapa (Leaflet) centraliza, marcador aparece
//   3) Painel lateral mostra os dados do local + lista de projetos já
//      salvos para locais anteriores
//   4) "Gerar estrutura 3D" → #/mapa3d/:placeId (carrega o projeto salvo
//      daquele local, se existir, ou começa um novo)
//
// Sem chave de API, sem billing — só precisa de internet no momento do
// uso (igual antes, com o Google Maps). Ver frontend/src/config/osmMap.js
// para a política de uso do Nominatim.
// ---------------------------------------------------------------------

import { el, clear } from "../lib/dom.js";
import { showToast } from "../components/toast.js";
import * as bridge from "../lib/wails-bridge.js";
import { loadLeaflet, searchAddress } from "../config/osmMap.js";
import { setPendingPlace } from "../mapa3d/placeContextStore.js";
import { metrosPorGrau, paraCoordLocal } from "../mapa3d/buildingFootprint.js";

function goTo(path) {
  window.location.hash = path;
}

function debounce(fn, ms) {
  let t = null;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

export function renderPlaceSearchView(container) {
  clear(container);

  let selectedPlace = null; // { placeId, nome, endereco, lat, lng, manualFootprint? }
  let desenhandoContorno = false;
  let contornoPontos = []; // [{lat,lng}]
  let contornoLayer = null; // L.Polyline/Polygon de rascunho
  let mapInstance = null;
  let marker = null;
  let savedProjects = [];
  let searchToken = 0; // evita que uma resposta antiga sobrescreva uma busca mais nova

  const view = el("div", { class: "view local-search-view" }, [
    el("a", { href: "#/", class: "feature-back" }, "← Voltar às funcionalidades"),
    el("h1", { class: "view-title", text: "Buscar Local" }),
    el("p", {
      class: "view-subtitle",
      text: "Busque o endereço ou prédio, selecione no mapa e gere o cenário 3D de infraestrutura daquele local.",
    }),
    el("a", { href: "#/mapa3d", class: "local-skip-link" }, "Prefere não buscar endereço? Ir direto pro Construtor Manual →"),
  ]);
  container.appendChild(view);

  // ---- busca ---------------------------------------------------------------
  const searchWrap = el("div", { class: "local-search-row" });
  const searchInput = el("input", {
    type: "text",
    class: "local-search-input",
    placeholder: "Digite um endereço — ex.: Av. Paulista, 1000, São Paulo",
    autocomplete: "off",
  });
  const suggestList = el("div", { class: "local-suggest-list" });
  searchWrap.appendChild(searchInput);
  searchWrap.appendChild(suggestList);
  view.appendChild(searchWrap);

  const attribution = el("p", {
    class: "local-attribution",
    text: "Busca de endereço e mapa por OpenStreetMap — sem custo, sem chave de API.",
  });
  view.appendChild(attribution);

  const mapEl = el("div", { class: "local-map" });
  const sidePanel = el("div", { class: "local-sidepanel" });
  view.appendChild(el("div", { class: "local-search-body" }, [mapEl, sidePanel]));

  function clearSuggestions() {
    clear(suggestList);
    suggestList.style.display = "none";
  }

  function renderSuggestions(results) {
    clear(suggestList);
    if (results.length === 0) {
      suggestList.style.display = "none";
      return;
    }
    results.forEach((place) => {
      const item = el("button", { type: "button", class: "local-suggest-item" }, [
        el("strong", { text: place.nome }),
        el("span", { text: place.endereco }),
      ]);
      item.addEventListener("click", () => selectPlace(place));
      suggestList.appendChild(item);
    });
    suggestList.style.display = "block";
  }

  function mensagemErroEndereco(err) {
    const raw = String(err?.message || err || "").trim();
    const msg = raw.toLowerCase();

    if (msg.includes("sem conexão com a internet")) {
      return "Sem conexão com a internet. Conecte-se a uma rede e tente novamente.";
    }
    if (msg.includes("demorou mais que o esperado") || msg.includes("tempo limite")) {
      return "A consulta de endereço demorou mais que o esperado. Verifique sua conexão e tente novamente.";
    }
    if (msg.includes("temporariamente ocupado")) {
      return "O serviço de endereços está temporariamente ocupado. Aguarde alguns segundos e tente novamente.";
    }
    if (msg.includes("temporariamente indisponível")) {
      return "O serviço de endereços está temporariamente indisponível. Tente novamente em instantes.";
    }

    // Nunca repassa mensagens cruas do backend/WebView para a interface,
    // evitando expor URL, query string, DNS, IP ou detalhes do sistema.
    return "Não foi possível buscar o endereço. Verifique sua conexão com a internet e tente novamente.";
  }

  const runSearch = debounce(async (query) => {
    const token = ++searchToken;
    if (query.trim().length < 3) {
      clearSuggestions();
      return;
    }
    try {
      const results = await searchAddress(query);
      if (token !== searchToken) return; // resposta obsoleta — ignora
      renderSuggestions(results);
    } catch (err) {
      if (token !== searchToken) return;
      clearSuggestions();
      showToast(mensagemErroEndereco(err), "error");
    }
  }, 500);

  searchInput.addEventListener("input", (e) => runSearch(e.target.value));
  searchInput.addEventListener("blur", () => setTimeout(clearSuggestions, 150));

  // -----------------------------------------------------------------
  // Desenhar contorno do prédio à mão — usado quando o OpenStreetMap não
  // tem o prédio mapeado (comum em cidades menores). O usuário marca os
  // cantos direto sobre o mapa real (rua/imagem), em vez de depender só
  // da Overpass API.
  // -----------------------------------------------------------------
  function iniciarDesenhoContorno() {
    desenhandoContorno = true;
    contornoPontos = [];
    if (contornoLayer) {
      contornoLayer.remove();
      contornoLayer = null;
    }
    showToast("Clique no mapa pra marcar cada canto do prédio. Mínimo de 3 pontos.", "info", 5000);
    renderSidePanel();
  }

  function redesenharContornoLayer() {
    if (!mapInstance || !window.L) return;
    if (contornoLayer) {
      contornoLayer.remove();
      contornoLayer = null;
    }
    if (contornoPontos.length < 2) return;
    const latlngs = contornoPontos.map((p) => [p.lat, p.lng]);
    contornoLayer =
      contornoPontos.length >= 3
        ? window.L.polygon(latlngs, { color: "#22D3C5", weight: 2, fillOpacity: 0.15 }).addTo(mapInstance)
        : window.L.polyline(latlngs, { color: "#22D3C5", weight: 2, dashArray: "6 6" }).addTo(mapInstance);
  }

  function concluirDesenhoContorno() {
    if (contornoPontos.length < 3 || !selectedPlace) return;
    const escala = metrosPorGrau(selectedPlace.lat);
    const origem = { lat: selectedPlace.lat, lng: selectedPlace.lng };
    const footprint = contornoPontos.map((p) => paraCoordLocal(p.lat, p.lng, origem, escala));
    selectedPlace = { ...selectedPlace, manualFootprint: { footprint, height: 9 } };
    desenhandoContorno = false;
    contornoPontos = [];
    showToast("Contorno salvo — será usado ao gerar a estrutura 3D.", "success");
    renderSidePanel();
  }

  function cancelarDesenhoContorno() {
    desenhandoContorno = false;
    contornoPontos = [];
    if (contornoLayer) {
      contornoLayer.remove();
      contornoLayer = null;
    }
    renderSidePanel();
  }

  function selectPlace(place) {
    selectedPlace = place;
    clearSuggestions();
    searchInput.value = place.endereco;

    if (mapInstance) {
      mapInstance.setView([place.lat, place.lng], 18);
      if (marker) marker.remove();
      marker = window.L.marker([place.lat, place.lng]).addTo(mapInstance).bindPopup(place.nome);
    }
    renderSidePanel();
  }

  // ---- painel lateral --------------------------------------------------------
  function renderSidePanel() {
    clear(sidePanel);
    sidePanel.appendChild(el("div", { class: "panel-section-title", text: "Local selecionado" }));

    if (!selectedPlace) {
      sidePanel.appendChild(el("div", { class: "state-msg info", text: "Busque e selecione um endereço acima." }));
    } else {
      sidePanel.appendChild(
        el("div", { class: "local-place-card" }, [
          el("strong", { text: selectedPlace.nome }),
          el("span", { text: selectedPlace.endereco }),
          el("span", { class: "mono-cell", text: `${selectedPlace.lat.toFixed(5)}, ${selectedPlace.lng.toFixed(5)}` }),
        ])
      );

      const genBtn = el("button", { type: "button", class: "btn btn-primary", style: "width:100%;margin-top:12px" }, "Gerar estrutura 3D →");
      genBtn.addEventListener("click", () => {
        setPendingPlace(selectedPlace);
        goTo(`#/mapa3d/${encodeURIComponent(selectedPlace.placeId)}`);
      });
      sidePanel.appendChild(genBtn);

      if (selectedPlace.manualFootprint) {
        sidePanel.appendChild(
          el("div", { class: "state-msg success", text: `Contorno traçado à mão (${selectedPlace.manualFootprint.footprint.length} pontos) — será usado em vez da busca automática.` })
        );
      }

      if (!desenhandoContorno) {
        const drawBtn = el(
          "button",
          { type: "button", class: "btn btn-ghost", style: "width:100%;margin-top:8px" },
          selectedPlace.manualFootprint ? "Redesenhar contorno do prédio" : "Não achou o prédio? Desenhar contorno no mapa →"
        );
        drawBtn.addEventListener("click", iniciarDesenhoContorno);
        sidePanel.appendChild(drawBtn);
      } else {
        sidePanel.appendChild(
          el("div", { class: "state-msg info", text: `Clique no mapa pra marcar cada canto do prédio (${contornoPontos.length} ponto${contornoPontos.length === 1 ? "" : "s"}).` })
        );
        const concluirBtn = el("button", { type: "button", class: "btn btn-primary", style: "width:100%;margin-top:8px", disabled: contornoPontos.length < 3 }, "Concluir contorno");
        concluirBtn.addEventListener("click", concluirDesenhoContorno);
        const cancelarBtn = el("button", { type: "button", class: "btn btn-ghost", style: "width:100%;margin-top:6px" }, "Cancelar");
        cancelarBtn.addEventListener("click", cancelarDesenhoContorno);
        sidePanel.appendChild(concluirBtn);
        sidePanel.appendChild(cancelarBtn);
      }
    }

    sidePanel.appendChild(el("div", { class: "panel-section-title", text: "Projetos salvos" }));
    if (savedProjects.length === 0) {
      sidePanel.appendChild(el("div", { class: "state-msg info", text: "Nenhum projeto salvo ainda." }));
    } else {
      savedProjects.forEach((p) => {
        const row = el("div", { class: "mapa3d-row" }, [
          el("div", { class: "mapa3d-row-text" }, [
            el("strong", { text: p.endereco || p.placeId }),
            el("span", { class: "mapa3d-row-sub", text: p.placeId }),
          ]),
          el("button", { type: "button", class: "btn btn-sm btn-ghost" }, "Abrir"),
        ]);
        row.lastChild.addEventListener("click", () => goTo(`#/mapa3d/${encodeURIComponent(p.placeId)}`));
        sidePanel.appendChild(row);
      });
    }
  }

  async function loadSavedProjects() {
    try {
      savedProjects = (await bridge.listarProjetosLocais()) || [];
    } catch {
      savedProjects = [];
    }
    renderSidePanel();
  }

  renderSidePanel();
  loadSavedProjects();

  // ---- mapa (Leaflet) ---------------------------------------------------------
  loadLeaflet()
    .then((L) => {
      mapInstance = L.map(mapEl, { zoomControl: true }).setView([-1.4557, -54.7852], 12); // fallback inicial: Santarém/PA
      // Tiles via CARTO (voyager) em vez de tile.openstreetmap.org: os
      // servidores brutos do OSM bloqueiam hotlinking de apps de terceiros, e a
      // CARTO passou a exigir chave nos endpoints legados de rastertiles (mudança
      // recente deles) — trocamos pro World Street Map da Esri, que continua
      // servindo tiles sem chave/cadastro pra uso de baixo volume como este.
      const baseLayer = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 19,
        attribution:
          "Tiles &copy; Esri &mdash; Esri, HERE, Garmin, FAO, NOAA, USGS, &copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors, and the GIS User Community",
      });

      let tileWarningShown = false;
      baseLayer.on("tileerror", () => {
        if (tileWarningShown) return;
        tileWarningShown = true;
        showToast(
          "O mapa-base está indisponível no momento. A interface continua aberta, mas os tiles dependem de internet.",
          "warning",
          7000
        );
      });
      baseLayer.addTo(mapInstance);

      mapInstance.on("click", async (e) => {
        const { lat, lng } = e.latlng;

        if (desenhandoContorno) {
          contornoPontos.push({ lat, lng });
          redesenharContornoLayer();
          renderSidePanel();
          return;
        }

        // clique direto no mapa também seleciona um ponto (geocodificação
        // reversa via Nominatim, feita pelo Go — ver geocodificacao.go),
        // sem precisar digitar
        try {
          const place = await bridge.geocodificarReverso(lat, lng);
          selectPlace(place);
        } catch {
          selectPlace({ placeId: `ponto_${lat.toFixed(5)}_${lng.toFixed(5)}`, nome: "Ponto no mapa", endereco: `${lat.toFixed(5)}, ${lng.toFixed(5)}`, lat, lng });
        }
      });

      if (selectedPlace) {
        mapInstance.setView([selectedPlace.lat, selectedPlace.lng], 18);
        marker = L.marker([selectedPlace.lat, selectedPlace.lng]).addTo(mapInstance);
      }
    })
    .catch((err) => {
      showToast("Não foi possível carregar o mapa. Verifique sua conexão com a internet e tente novamente.", "error", 7000);
    });

  return () => {
    if (mapInstance) {
      mapInstance.remove();
      mapInstance = null;
    }
  };
}
