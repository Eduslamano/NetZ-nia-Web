// ---------------------------------------------------------------------
// plannerView.js — tela de ENTRADA do módulo Planejador / Mapa 3D.
//
// NOTA DE INTEGRAÇÃO: o placeholder original do frontend da Enolla
// chamava um método inexistente no backend (`AbrirPlanejador3D`) e não
// abria o Planejador real. Esta versão foi reescrita para não
// reimplementar nada do módulo — ela só oferece a porta de entrada
// visual (estilo Enolla) para as DUAS rotas reais e funcionais já
// existentes no NETZONIA_3.2_P15_FINAL:
//   • #/local   → busca de endereço, importa contorno automaticamente
//   • #/mapa3d  → Construtor Manual, sem precisar de endereço
// Nenhuma lógica, tela ou dado do Planejador 3D foi recriado aqui.
// ---------------------------------------------------------------------

import { el, clear } from "../lib/dom.js";
import { PLANNER } from "../data/categories.js";
import { icons } from "../data/icons.js";

export function renderPlannerView(container) {
  clear(container);

  const view = el("div", { class: "feature-view" }, [
    el("a", { href: "#/", class: "feature-back" }, [el("span", { html: icons.back }), "Voltar ao início"]),
    el("div", { class: "feature-header" }, [
      el("div", { class: "feature-icon-badge tone-violet", html: PLANNER.icon }),
      el("div", { class: "feature-heading" }, [
        el("div", { class: "feature-eyebrow tone-violet", text: "Planejamento visual de infraestrutura" }),
        el("h1", { class: "feature-title", text: PLANNER.title }),
        el("p", { class: "feature-desc", text: PLANNER.description }),
      ]),
    ]),
    el("div", { class: "feature-panel" }, [
      el("div", { class: "panel-section-title", text: "Como você quer começar?" }),
      el("p", {
        class: "field-hint",
        style: "margin-bottom:16px;display:block",
        text: "Escolha entre localizar um endereço para iniciar o planejamento ou abrir diretamente o construtor manual. Racks, cabeamento, zonas EMI e orçamento permanecem disponíveis nos dois fluxos.",
      }),
      el("div", { class: "field-row" }, [
        el("a", { href: "#/local", class: "btn btn-primary" }, "Buscar endereço/prédio →"),
        el("a", { href: "#/mapa3d", class: "btn btn-ghost" }, "Começar sem endereço (Construtor Manual) →"),
      ]),
    ]),
  ]);

  container.appendChild(view);
  return () => {};
}
