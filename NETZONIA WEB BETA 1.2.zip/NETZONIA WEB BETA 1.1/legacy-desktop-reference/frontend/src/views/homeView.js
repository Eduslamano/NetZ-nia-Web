// ---------------------------------------------------------------------
// homeView.js — página inicial.
//
// Comportamento padrão (sem busca e sem filtro): grade com as 5
// categorias + o banner de destaque do Planejador 3D — a ideia é que a
// tela inicial nunca liste as ferramentas todas juntas, só as portas de
// entrada.
//
// Com busca e/ou filtro de categoria ativos (cabeçalho): a home passa a
// mostrar os resultados filtrados — texto livre, uma categoria
// específica, ou os dois combinados (busca só dentro daquela
// categoria). É o mesmo par de controles do cabeçalho, então a
// navegação por cards e a busca continuam redundantes uma com a outra.
// ---------------------------------------------------------------------

import { el, clear } from "../lib/dom.js";
import { CATEGORIES, CATEGORY_ORDER } from "../data/categories.js";
import { searchTools } from "../data/tools.js";
import { renderCategoryCard } from "../components/categoryCard.js";
import { renderPlannerBanner } from "../components/plannerBanner.js";
import { renderFeatureCard } from "../components/featureCard.js";
import { icons } from "../data/icons.js";

function renderCategoriesSection() {
  return el("div", {}, [
    el(
      "div",
      { class: "category-grid" },
      CATEGORY_ORDER.map((id) => renderCategoryCard(CATEGORIES[id]))
    ),
    renderPlannerBanner(),
  ]);
}

function renderSearchResultsSection(query, categoryId, results) {
  if (results.length === 0) {
    return el("div", { class: "empty-state" }, [
      el("div", { html: icons.search, style: "opacity:.5" }),
      el("p", {}, [
        "Nenhuma ferramenta encontrada",
        query ? [" para ", el("strong", { text: `"${query}"` })] : "",
        categoryId !== "all" ? [" em ", el("strong", { text: CATEGORIES[categoryId]?.label || categoryId })] : "",
        ".",
      ].flat()),
    ]);
  }

  return el("div", { class: "tool-grid" }, results.map((t) => renderFeatureCard(t)));
}

export function renderHomeView(container, { query = "", categoryId = "all" } = {}) {
  clear(container);

  const filtering = query.trim().length > 0 || categoryId !== "all";
  const results = filtering ? searchTools(query, categoryId) : [];

  let subtitle = "Escolha uma categoria para ver as ferramentas do toolkit de rede.";
  if (filtering) {
    const parts = [`${results.length} ferramenta(s) encontrada(s)`];
    if (categoryId !== "all") parts.push(`em ${CATEGORIES[categoryId]?.label || categoryId}`);
    if (query.trim()) parts.push(`para "${query.trim()}"`);
    subtitle = parts.join(" ") + ".";
  }

  const view = el("div", { class: "view" }, [
    el("h1", { class: "view-title", text: filtering ? "Resultados da busca" : "NetZônia" }),
    el("p", { class: "view-subtitle", text: subtitle }),
    filtering ? renderSearchResultsSection(query.trim(), categoryId, results) : renderCategoriesSection(),
  ]);

  container.appendChild(view);
  return () => {};
}
