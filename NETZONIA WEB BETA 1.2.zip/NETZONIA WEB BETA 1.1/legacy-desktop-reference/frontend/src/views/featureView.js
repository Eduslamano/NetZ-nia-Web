// ---------------------------------------------------------------------
// featureView.js — página de detalhe de UMA funcionalidade.
//
// É um "motor" único: o layout (cabeçalho, painel de entrada, área de
// resultado) é o mesmo para as funcionalidades disponíveis; o que muda é:
//   1) o tipo de painel de entrada (instant / host-input / watchdog / report / form e painéis especiais)
//   2) como o resultado retornado pelo backend é desenhado (RESULT_RENDERERS)
// ---------------------------------------------------------------------

import { el, clear, qs } from "../lib/dom.js";
import { getFeatureById } from "../data/features.js";
import { CATEGORIES } from "../data/categories.js";
import { icons } from "../data/icons.js";
import * as bridge from "../lib/wails-bridge.js";
import { showToast } from "../components/toast.js";
import {
  buildTable,
  buildStatGrid,
  buildBadge,
  buildBarRow,
  buildConsoleBox,
  buildLoadingRow,
  buildStateMsg,
} from "../components/resultBuilders.js";
import { fmtMs, fmtMbps, fmtBytesMB, classificarVelocidade, classificarLatencia, fmtTime } from "../lib/format.js";

// Mensagens de carregamento contextuais (operações mais longas do backend)
const LOADING_MESSAGES = {
  velocidade: "Medindo download e upload — isso pode levar alguns segundos...",
  dispositivos: "Enviando pings para popular a tabela ARP e identificar dispositivos...",
  reparar: "Executando etapas de reparo (flush DNS, renovação de IP, reset do Winsock)...",
  wifi: "Escaneando redes Wi-Fi ao alcance...",
  traceroute: "Rastreando o caminho até o destino, hop a hop...",
  portas: "Testando portas TCP comuns no host informado...",
  mtu: "Testando tamanhos de pacote para descobrir o MTU máximo...",
};

export function renderFeatureView(container, featureId) {
  const feature = getFeatureById(featureId);
  clear(container);

  if (!feature) {
    container.appendChild(
      el("div", { class: "feature-view" }, [
        el("a", { href: "#/", class: "feature-back" }, [el("span", { html: icons.back }), "Voltar"]),
        buildStateMsg("Funcionalidade não encontrada.", "error"),
      ])
    );
    return () => {};
  }

  const category = CATEGORIES[feature.category];

  const resultsHolder = el("div", { class: "feature-panel" }, [
    el("div", { class: "panel-section-title", text: "Resultado" }),
    buildStateMsg("Execute a funcionalidade acima para ver os resultados aqui.", "info"),
  ]);

  const view = el("div", { class: "feature-view" }, [
    el("a", { href: `#/categoria/${feature.category}`, class: "feature-back" }, [
      el("span", { html: icons.back }),
      `Voltar para ${category.shortLabel || category.label}`,
    ]),
    el("div", { class: "feature-header" }, [
      el("div", { class: `feature-icon-badge ${category.tone}`, html: feature.icon }),
      el("div", { class: "feature-heading" }, [
        el("div", { class: `feature-eyebrow ${category.tone}`, text: category.label }),
        el("h1", { class: "feature-title", text: `${String(feature.number).padStart(2, "0")} · ${feature.title}` }),
        el("p", { class: "feature-desc", text: feature.description }),
      ]),
    ]),
  ]);

  const inputPanel = el("div", { class: "feature-panel" });
  view.appendChild(inputPanel);
  view.appendChild(resultsHolder);
  container.appendChild(view);

  let cleanup = () => {};

  if (feature.type === "instant") {
    cleanup = mountInstantPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "host-input") {
    cleanup = mountHostInputPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "watchdog") {
    cleanup = mountWatchdogPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "report") {
    cleanup = mountReportPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "form") {
    cleanup = mountFormPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "ping-sound") {
    cleanup = mountPingSoundPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "lan-server") {
    cleanup = mountLANServerPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "ip-config") {
    cleanup = mountIPConfigPanel(inputPanel, resultsHolder, feature);
  } else if (feature.type === "credentials") {
    cleanup = mountCredentialsPanel(inputPanel, resultsHolder, feature);
  }

  return cleanup;
}

// =======================================================================
// PAINEL: instant (um botão, sem parâmetros)
// =======================================================================
function mountInstantPanel(inputPanel, resultsHolder, feature) {
  const runBtn = el("button", { class: "btn btn-primary", type: "button" }, "Executar");
  inputPanel.appendChild(
    el("div", { class: "field-row" }, [
      el("div", { class: "field", style: "flex:1 1 auto" }, [
        el("label", { text: "Sem parâmetros" }),
        el("span", { class: "field-hint", text: "Esta funcionalidade roda direto sobre a rede atual." }),
      ]),
      runBtn,
    ])
  );

  const run = async () => {
    setBusy(runBtn, true, "Executando...");
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
    resultsHolder.appendChild(buildLoadingRow(LOADING_MESSAGES[feature.id] || "Executando..."));

    try {
      const data = await bridge[feature.bridgeFn]();
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(renderResult(feature.id, data));
    } catch (err) {
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(buildStateMsg(`Falha ao executar: ${err?.message || err}`, "error"));
    } finally {
      setBusy(runBtn, false, "Executar");
    }
  };

  runBtn.addEventListener("click", run);
  return () => runBtn.removeEventListener("click", run);
}

// =======================================================================
// PAINEL: host-input (campo de texto + botão)
// =======================================================================
function mountHostInputPanel(inputPanel, resultsHolder, feature) {
  const input = el("input", {
    type: "text",
    id: `input-${feature.id}`,
    placeholder: feature.inputPlaceholder || "",
    value: feature.defaultHost || "",
  });
  const runBtn = el("button", { class: "btn btn-primary", type: "button" }, "Executar");

  inputPanel.appendChild(
    el("div", { class: "field-row" }, [
      el("div", { class: "field" }, [
        el("label", { for: `input-${feature.id}`, text: feature.inputLabel || "Host" }),
        input,
      ]),
      runBtn,
    ])
  );

  const run = async () => {
    const host = input.value.trim();
    if (feature.inputRequired && !host) {
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(buildStateMsg("Informe um host/destino válido antes de executar.", "warn"));
      input.focus();
      return;
    }

    setBusy(runBtn, true, "Executando...");
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
    resultsHolder.appendChild(buildLoadingRow(LOADING_MESSAGES[feature.id] || `Executando para "${host || "padrão"}"...`));

    try {
      const data = await bridge[feature.bridgeFn](host);
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(renderResult(feature.id, data));
    } catch (err) {
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(buildStateMsg(`Falha ao executar: ${err?.message || err}`, "error"));
    } finally {
      setBusy(runBtn, false, "Executar");
    }
  };

  runBtn.addEventListener("click", run);
  const onEnter = (e) => {
    if (e.key === "Enter") run();
  };
  input.addEventListener("keydown", onEnter);

  return () => {
    runBtn.removeEventListener("click", run);
    input.removeEventListener("keydown", onEnter);
  };
}

// =======================================================================
// PAINEL: watchdog (monitor contínuo, iniciar/parar + eventos)
// =======================================================================
function mountWatchdogPanel(inputPanel, resultsHolder, feature) {
  const hostInput = el("input", { type: "text", value: feature.defaultHost || "", placeholder: feature.inputPlaceholder });
  const intervalInput = el("input", { type: "number", value: "5", min: "1" });
  const limitInput = el("input", { type: "number", value: "60", min: "0" });

  const startBtn = el("button", { class: "btn btn-primary", type: "button" }, "Iniciar monitor");
  const stopBtn = el("button", { class: "btn btn-danger", type: "button", disabled: true }, "Parar");

  inputPanel.appendChild(
    el("div", { class: "field-row" }, [
      el("div", { class: "field" }, [el("label", { text: feature.inputLabel }), hostInput]),
      el("div", { class: "field", style: "flex:0 1 140px" }, [el("label", { text: "Intervalo (s)" }), intervalInput]),
      el("div", { class: "field", style: "flex:0 1 160px" }, [
        el("label", { text: "Verificações (0=infinito)" }),
        limitInput,
      ]),
      startBtn,
      stopBtn,
    ])
  );

  clear(resultsHolder);
  resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Monitor" }));

  const statsHolder = el("div", {});
  const logList = el("div", { class: "watchdog-log" });
  resultsHolder.appendChild(statsHolder);
  resultsHolder.appendChild(el("div", { style: "height:16px" }));
  resultsHolder.appendChild(logList);
  statsHolder.appendChild(buildStateMsg("Configure o host e clique em “Iniciar monitor”.", "info"));

  let unsubscribe = null;
  let running = false;

  const renderStats = (payload) => {
    clear(statsHolder);
    statsHolder.appendChild(
      buildStatGrid([
        { label: "Uptime", value: `${payload.uptime.toFixed(1)}%`, tone: payload.uptime > 97 ? "good" : payload.uptime > 90 ? "warn" : "bad" },
        { label: "Verificações", value: String(payload.total) },
        { label: "Quedas", value: String(payload.quedas), tone: payload.quedas > 0 ? "bad" : "good" },
        { label: "Última latência", value: payload.ok ? fmtMs(payload.latenciaMs) : "—", tone: payload.ok ? "good" : "bad" },
      ])
    );
  };

  const pushLogRow = (payload) => {
    const row = el("div", { class: "watchdog-log-row" }, [
      el("span", { class: `pulse-dot ${payload.ok ? "" : "down"}` }),
      el("span", { text: fmtTime(new Date(payload.timestamp)) }),
      el("span", {
        text: payload.ok ? `OK · ${fmtMs(payload.latenciaMs)}` : "QUEDA — host inacessível",
        style: `margin-left:auto;color:${payload.ok ? "var(--status-good)" : "var(--status-bad)"};font-weight:700`,
      }),
    ]);
    logList.insertBefore(row, logList.firstChild);
    while (logList.children.length > 60) logList.removeChild(logList.lastChild);
  };

  const stop = async () => {
    if (!running) return;
    running = false;
    await bridge.pararWatchdog();
    if (unsubscribe) unsubscribe();
    unsubscribe = null;
    startBtn.disabled = false;
    stopBtn.disabled = true;
    hostInput.disabled = false;
    intervalInput.disabled = false;
    limitInput.disabled = false;
    startBtn.textContent = "Iniciar monitor";
  };

  const start = async () => {
    const host = hostInput.value.trim() || feature.defaultHost;
    const intervalSec = Math.max(1, Number(intervalInput.value) || 5);
    const limite = Math.max(0, Number(limitInput.value) || 0);

    clear(statsHolder);
    clear(logList);
    statsHolder.appendChild(buildLoadingRow(`Conectando ao monitor para ${host}...`));

    running = true;
    startBtn.disabled = true;
    stopBtn.disabled = false;
    hostInput.disabled = true;
    intervalInput.disabled = true;
    limitInput.disabled = true;

    unsubscribe = bridge.onWatchdogTick((payload) => {
      renderStats(payload);
      pushLogRow(payload);
    });

    try {
      await bridge.iniciarWatchdog(host, intervalSec, limite);
    } catch (err) {
      showToast(`Erro ao iniciar o monitor: ${err?.message || err}`, "error");
      stop();
    }
  };

  startBtn.addEventListener("click", start);
  stopBtn.addEventListener("click", stop);

  return () => {
    startBtn.removeEventListener("click", start);
    stopBtn.removeEventListener("click", stop);
    if (running) stop();
  };
}

// =======================================================================
// PAINEL: form — formulário declarativo usado pelos módulos 15–28
// =======================================================================
function mountFormPanel(inputPanel, resultsHolder, feature) {
  const controls = new Map();
  const row = el("div", { class: "field-row" });

  for (const field of feature.fields || []) {
    const id = `input-${feature.id}-${field.key}`;
    const wrap = el("div", { class: `field${field.type === "checkbox" ? " field-check" : ""}` });
    let control;

    if (field.type === "select") {
      control = el("select", { id });
      for (const [value, label] of field.options || []) {
        const option = el("option", { value, text: label });
        if (String(value) === String(field.value ?? "")) option.selected = true;
        control.appendChild(option);
      }
    } else if (field.type === "checkbox") {
      control = el("input", { id, type: "checkbox" });
      control.checked = field.value !== false;
    } else {
      control = el("input", {
        id,
        type: field.type === "password" ? "password" : field.type === "number" ? "number" : "text",
        placeholder: field.placeholder || "",
        value: field.value ?? "",
        min: field.min,
        max: field.max,
        step: field.step,
      });
    }

    wrap.appendChild(el("label", { for: id, text: field.label || field.key }));
    wrap.appendChild(control);
    if (field.hint) wrap.appendChild(el("span", { class: "field-hint", text: field.hint }));
    row.appendChild(wrap);
    controls.set(field.key, { field, control });
  }

  const runBtn = el("button", { class: "btn btn-primary", type: "button" }, feature.buttonLabel || "Executar");
  row.appendChild(runBtn);
  inputPanel.appendChild(row);

  const parseValue = (field, control) => {
    if (field.type === "checkbox") return Boolean(control.checked);
    const raw = String(control.value ?? "").trim();
    if (field.parser === "int") return Number.parseInt(raw || "0", 10);
    if (field.parser === "number") return Number(raw || 0);
    if (field.parser === "csv-int") return raw ? raw.split(/[,;\s]+/).filter(Boolean).map((v) => Number.parseInt(v, 10)).filter(Number.isFinite) : [];
    if (field.parser === "csv-float") return raw ? raw.split(/[,;]+/).map((v) => Number(String(v).trim().replace(",", "."))).filter(Number.isFinite) : [];
    return raw;
  };

  const run = async () => {
    const args = [];
    for (const { field, control } of controls.values()) {
      const raw = field.type === "checkbox" ? control.checked : String(control.value ?? "").trim();
      if (field.required && (raw === "" || raw === false)) {
        clear(resultsHolder);
        resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
        resultsHolder.appendChild(buildStateMsg(`Preencha o campo “${field.label}”.`, "warn"));
        control.focus();
        return;
      }
      args.push(parseValue(field, control));
    }

    setBusy(runBtn, true, "Executando...");
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
    resultsHolder.appendChild(buildLoadingRow(LOADING_MESSAGES[feature.id] || "Executando módulo..."));
    try {
      const fn = bridge[feature.bridgeFn];
      if (typeof fn !== "function") throw new Error(`Integração ausente: ${feature.bridgeFn}`);
      const data = await fn(...args);
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      if (data == null && feature.successMessage) {
        resultsHolder.appendChild(buildStateMsg(feature.successMessage, "success"));
      } else {
        resultsHolder.appendChild(renderResult(feature.id, data));
      }
    } catch (err) {
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" }));
      resultsHolder.appendChild(buildStateMsg(`Falha ao executar: ${err?.message || err}`, "error"));
    } finally {
      setBusy(runBtn, false, feature.buttonLabel || "Executar");
    }
  };

  runBtn.addEventListener("click", run);
  return () => runBtn.removeEventListener("click", run);
}

// =======================================================================
// PAINEL: ping sonoro — iniciar/parar + eventos do backend
// =======================================================================
function mountPingSoundPanel(inputPanel, resultsHolder) {
  const hostInput = el("input", { type: "text", value: "8.8.8.8", placeholder: "Host ou IP" });
  const intervalInput = el("input", { type: "number", value: "1", min: "1" });
  const startBtn = el("button", { class: "btn btn-primary", type: "button" }, "Iniciar");
  const stopBtn = el("button", { class: "btn btn-danger", type: "button", disabled: true }, "Parar");
  inputPanel.appendChild(el("div", { class: "field-row" }, [
    el("div", { class: "field" }, [el("label", { text: "Host" }), hostInput]),
    el("div", { class: "field", style: "flex:0 1 150px" }, [el("label", { text: "Intervalo (s)" }), intervalInput]),
    startBtn, stopBtn,
  ]));

  let unsubscribe = null;
  let running = false;
  const showTick = (payload) => {
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Ping sonoro" }));
    resultsHolder.appendChild(buildStatGrid([
      { label: "Host", value: payload.host || hostInput.value },
      { label: "Status", value: payload.ok ? "Respondendo" : "Sem resposta", tone: payload.ok ? "good" : "bad" },
      { label: "Latência", value: payload.ok && payload.latenciaMs != null ? fmtMs(payload.latenciaMs) : "—" },
      { label: "Última verificação", value: payload.timestamp ? fmtTime(new Date(payload.timestamp)) : "—" },
    ]));
  };
  const stop = async () => {
    if (!running) return;
    running = false;
    try { await bridge.pararPingSonoro(); } catch { /* já será encerrado ao sair */ }
    if (unsubscribe) unsubscribe();
    unsubscribe = null;
    startBtn.disabled = false;
    stopBtn.disabled = true;
    hostInput.disabled = false;
    intervalInput.disabled = false;
  };
  const start = async () => {
    const host = hostInput.value.trim();
    if (!host) return hostInput.focus();
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Ping sonoro" }));
    resultsHolder.appendChild(buildLoadingRow(`Iniciando monitor para ${host}...`));
    unsubscribe = bridge.onPingSonoroTick(showTick);
    try {
      await bridge.iniciarPingSonoro(host, Math.max(1, Number.parseInt(intervalInput.value || "1", 10)));
      running = true;
      startBtn.disabled = true;
      stopBtn.disabled = false;
      hostInput.disabled = true;
      intervalInput.disabled = true;
    } catch (err) {
      if (unsubscribe) unsubscribe();
      unsubscribe = null;
      clear(resultsHolder);
      resultsHolder.appendChild(buildStateMsg(`Falha ao iniciar: ${err?.message || err}`, "error"));
    }
  };
  startBtn.addEventListener("click", start);
  stopBtn.addEventListener("click", stop);
  return () => { startBtn.removeEventListener("click", start); stopBtn.removeEventListener("click", stop); if (running) void stop(); };
}

// =======================================================================
// PAINEL: servidor LAN — iniciar/parar
// =======================================================================
function mountLANServerPanel(inputPanel, resultsHolder) {
  const portInput = el("input", { type: "number", value: "8080", min: "1", max: "65535" });
  const startBtn = el("button", { class: "btn btn-primary", type: "button" }, "Iniciar servidor");
  const stopBtn = el("button", { class: "btn btn-danger", type: "button", disabled: true }, "Parar servidor");
  inputPanel.appendChild(el("div", { class: "field-row" }, [
    el("div", { class: "field", style: "flex:0 1 220px" }, [el("label", { text: "Porta" }), portInput]), startBtn, stopBtn,
  ]));
  let running = false;
  const start = async () => {
    setBusy(startBtn, true, "Iniciando...");
    try {
      const data = await bridge.iniciarServidorLAN(Number.parseInt(portInput.value || "8080", 10));
      running = Boolean(data?.ativo);
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Servidor LAN" }));
      resultsHolder.appendChild(renderResult("servidor-lan", data));
      stopBtn.disabled = !running;
      portInput.disabled = running;
    } catch (err) {
      clear(resultsHolder); resultsHolder.appendChild(buildStateMsg(`Falha ao iniciar: ${err?.message || err}`, "error"));
    } finally { setBusy(startBtn, false, "Iniciar servidor"); startBtn.disabled = running; }
  };
  const stop = async () => {
    try { await bridge.pararServidorLAN(); } finally {
      running = false; startBtn.disabled = false; stopBtn.disabled = true; portInput.disabled = false;
      clear(resultsHolder); resultsHolder.appendChild(buildStateMsg("Servidor LAN parado.", "info"));
    }
  };
  startBtn.addEventListener("click", start); stopBtn.addEventListener("click", stop);
  return () => { startBtn.removeEventListener("click", start); stopBtn.removeEventListener("click", stop); if (running) void bridge.pararServidorLAN(); };
}

// =======================================================================
// PAINEL: configuração rápida de IP
// =======================================================================
function mountIPConfigPanel(inputPanel, resultsHolder) {
  const ifaceSelect = el("select", {});
  const ipInput = el("input", { type: "text", placeholder: "192.168.1.50" });
  const maskInput = el("input", { type: "text", placeholder: "255.255.255.0" });
  const gatewayInput = el("input", { type: "text", placeholder: "192.168.1.1" });
  const dhcpInput = el("input", { type: "checkbox" });
  const refreshBtn = el("button", { class: "btn btn-ghost", type: "button" }, "Atualizar interfaces");
  const applyBtn = el("button", { class: "btn btn-primary", type: "button" }, "Aplicar configuração");
  const dhcpField = el("div", { class: "field field-check" }, [el("label", { text: "Usar DHCP" }), dhcpInput]);
  inputPanel.appendChild(el("div", { class: "field-row" }, [
    el("div", { class: "field" }, [el("label", { text: "Interface" }), ifaceSelect]),
    refreshBtn, dhcpField,
    el("div", { class: "field" }, [el("label", { text: "IPv4" }), ipInput]),
    el("div", { class: "field" }, [el("label", { text: "Máscara" }), maskInput]),
    el("div", { class: "field" }, [el("label", { text: "Gateway" }), gatewayInput]),
    applyBtn,
  ]));
  const toggleStatic = () => { const off = dhcpInput.checked; ipInput.disabled = off; maskInput.disabled = off; gatewayInput.disabled = off; };
  dhcpInput.addEventListener("change", toggleStatic);
  const loadIfaces = async () => {
    setBusy(refreshBtn, true, "Carregando...");
    try {
      const list = await bridge.listarInterfacesRede(); clear(ifaceSelect);
      for (const item of list || []) ifaceSelect.appendChild(el("option", { value: item.nome, text: `${item.nome}${item.status ? ` · ${item.status}` : ""}` }));
      if (!(list || []).length) ifaceSelect.appendChild(el("option", { value: "", text: "Nenhuma interface encontrada" }));
    } catch (err) { showToast(`Falha ao listar interfaces: ${err?.message || err}`, "error"); }
    finally { setBusy(refreshBtn, false, "Atualizar interfaces"); }
  };
  const apply = async () => {
    const iface = ifaceSelect.value;
    if (!iface) return showToast("Selecione uma interface de rede.", "error");
    setBusy(applyBtn, true, "Aplicando...");
    try {
      const data = await bridge.configurarIP(iface, ipInput.value.trim(), maskInput.value.trim(), gatewayInput.value.trim(), dhcpInput.checked);
      clear(resultsHolder); resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Resultado" })); resultsHolder.appendChild(renderResult("config-ip", data));
    } catch (err) { clear(resultsHolder); resultsHolder.appendChild(buildStateMsg(`Falha: ${err?.message || err}`, "error")); }
    finally { setBusy(applyBtn, false, "Aplicar configuração"); }
  };
  refreshBtn.addEventListener("click", loadIfaces); applyBtn.addEventListener("click", apply); void loadIfaces();
  return () => { refreshBtn.removeEventListener("click", loadIfaces); applyBtn.removeEventListener("click", apply); dhcpInput.removeEventListener("change", toggleStatic); };
}

// =======================================================================
// PAINEL: credenciais seguras — salvar/carregar com DPAPI no Windows
// =======================================================================
function mountCredentialsPanel(inputPanel, resultsHolder) {
  const nameInput = el("input", { type: "text", placeholder: "ex.: roteador-escritorio" });
  const valueInput = el("input", { type: "password", placeholder: "Valor sensível" });
  const saveBtn = el("button", { class: "btn btn-primary", type: "button" }, "Salvar");
  const loadBtn = el("button", { class: "btn btn-ghost", type: "button" }, "Carregar");
  inputPanel.appendChild(el("div", { class: "field-row" }, [
    el("div", { class: "field" }, [el("label", { text: "Nome da credencial" }), nameInput]),
    el("div", { class: "field" }, [el("label", { text: "Valor" }), valueInput]), saveBtn, loadBtn,
  ]));
  const save = async () => {
    const nome = nameInput.value.trim(); if (!nome || !valueInput.value) return showToast("Informe nome e valor.", "error");
    setBusy(saveBtn, true, "Salvando...");
    try { const ok = await bridge.salvarCredencialSegura(nome, valueInput.value); clear(resultsHolder); resultsHolder.appendChild(buildStateMsg(ok ? "Credencial salva com proteção do sistema." : "A credencial não foi salva.", ok ? "success" : "warn")); valueInput.value = ""; }
    catch (err) { clear(resultsHolder); resultsHolder.appendChild(buildStateMsg(`Falha ao salvar: ${err?.message || err}`, "error")); }
    finally { setBusy(saveBtn, false, "Salvar"); }
  };
  const load = async () => {
    const nome = nameInput.value.trim(); if (!nome) return showToast("Informe o nome da credencial.", "error");
    setBusy(loadBtn, true, "Carregando...");
    try { const value = await bridge.carregarCredencialSegura(nome); clear(resultsHolder); resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Valor recuperado" })); resultsHolder.appendChild(value ? buildConsoleBox(value) : buildStateMsg("Credencial não encontrada.", "info")); }
    catch (err) { clear(resultsHolder); resultsHolder.appendChild(buildStateMsg(`Falha ao carregar: ${err?.message || err}`, "error")); }
    finally { setBusy(loadBtn, false, "Carregar"); }
  };
  saveBtn.addEventListener("click", save); loadBtn.addEventListener("click", load);
  return () => { saveBtn.removeEventListener("click", save); loadBtn.removeEventListener("click", load); };
}

// =======================================================================
// PAINEL: report (gerar + salvar relatório TXT)
// =======================================================================
function mountReportPanel(inputPanel, resultsHolder, feature) {
  const genBtn = el("button", { class: "btn btn-primary", type: "button" }, "Gerar relatório");
  const saveBtn = el("button", { class: "btn btn-ghost", type: "button", disabled: true }, [
    el("span", { html: icons.save }),
    " Salvar como...",
  ]);

  inputPanel.appendChild(
    el("div", { class: "field-row" }, [
      el("div", { class: "field", style: "flex:1 1 auto" }, [
        el("label", { text: "Pré-visualização" }),
        el("span", {
          class: "field-hint",
          text: "Reúne tudo o que foi executado nesta sessão. Gere para conferir antes de salvar no disco.",
        }),
      ]),
      genBtn,
      saveBtn,
    ])
  );

  clear(resultsHolder);
  resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Conteúdo do relatório" }));
  resultsHolder.appendChild(buildStateMsg("Clique em “Gerar relatório” para ver a pré-visualização.", "info"));

  const generate = async () => {
    setBusy(genBtn, true, "Gerando...");
    clear(resultsHolder);
    resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Conteúdo do relatório" }));
    resultsHolder.appendChild(buildLoadingRow("Compilando resultados da sessão..."));
    try {
      const text = await bridge.gerarRelatorioTXT();
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Conteúdo do relatório" }));
      resultsHolder.appendChild(buildConsoleBox(text));
      saveBtn.disabled = false;
    } catch (err) {
      clear(resultsHolder);
      resultsHolder.appendChild(el("div", { class: "panel-section-title", text: "Conteúdo do relatório" }));
      resultsHolder.appendChild(buildStateMsg(`Falha ao gerar relatório: ${err?.message || err}`, "error"));
    } finally {
      setBusy(genBtn, false, "Gerar relatório");
    }
  };

  const save = async () => {
    setBusy(saveBtn, true, "Salvando...");
    try {
      const result = await bridge.salvarRelatorioComo();
      if (result && result.saved) {
        showToast(`Relatório salvo em: ${result.path}`, "success", 6000);
      } else {
        showToast("Nenhum arquivo foi salvo.", "info");
      }
    } catch (err) {
      showToast(`Erro ao salvar: ${err?.message || err}`, "error");
    } finally {
      setBusy(saveBtn, false, [el("span", { html: icons.save }), " Salvar como..."]);
    }
  };

  genBtn.addEventListener("click", generate);
  saveBtn.addEventListener("click", save);
  return () => {
    genBtn.removeEventListener("click", generate);
    saveBtn.removeEventListener("click", save);
  };
}

// =======================================================================
// Utilitário: alterna estado de "ocupado" de um botão
// =======================================================================
function setBusy(btn, busy, label) {
  btn.disabled = busy;
  btn.setAttribute("aria-busy", busy ? "true" : "false");
  clear(btn);
  if (Array.isArray(label)) {
    label.forEach((n) => btn.appendChild(typeof n === "string" ? document.createTextNode(n) : n));
  } else {
    btn.appendChild(document.createTextNode(label));
  }
}

// =======================================================================
// RESULT RENDERERS — como desenhar o retorno de cada funcionalidade
// =======================================================================
function renderResult(featureId, data) {
  const renderer = RESULT_RENDERERS[featureId];
  if (renderer) return renderer(data);
  if (data == null) return buildStateMsg("Operação concluída com sucesso.", "success");
  if (typeof data === "string" || typeof data === "number" || typeof data === "boolean") return buildConsoleBox(String(data));
  return buildConsoleBox(JSON.stringify(data, null, 2));
}

const RESULT_RENDERERS = {
  velocidade: (data) => {
    const dl = classificarVelocidade(data.download.mbps);
    const ul = classificarVelocidade(data.upload.mbps);
    return el("div", {}, [
      buildStatGrid([
        {
          label: "Download",
          value: fmtMbps(data.download.mbps),
          tone: dl.tone,
          sub: `${fmtBytesMB(data.download.bytes)} em ${data.download.seconds.toFixed(1)}s`,
        },
        {
          label: "Upload",
          value: fmtMbps(data.upload.mbps),
          tone: ul.tone,
          sub: `${fmtBytesMB(data.upload.bytes)} em ${data.upload.seconds.toFixed(1)}s`,
        },
      ]),
      el("div", { style: "height:14px" }),
      el("div", { class: "field-row" }, [buildBadge(`Download: ${dl.label}`, dl.tone), buildBadge(`Upload: ${ul.label}`, ul.tone)]),
    ]);
  },

  dispositivos: (data) =>
    el("div", {}, [
      buildStateMsg(`Sub-rede detectada: ${data.subnet} · ${data.devices.length} dispositivo(s) encontrado(s).`, "info"),
      el("div", { style: "height:14px" }),
      buildTable(
        [
          { key: "ip", label: "IP" },
          { key: "mac", label: "MAC" },
          { key: "fabricante", label: "Fabricante" },
          { key: "hostname", label: "Hostname" },
          { key: "tipo", label: "Tipo" },
        ],
        data.devices,
        { monoKeys: ["ip", "mac"] }
      ),
    ]),

  roteador: (data) =>
    el("div", {}, [
      buildStateMsg(
        data.opened
          ? `Gateway detectado em ${data.gateway}. ${data.message}`
          : `Gateway detectado em ${data.gateway}, mas não foi possível abrir o navegador: ${data.message}`,
        data.opened ? "success" : "error"
      ),
    ]),

  reparar: (data) =>
    el("div", {}, [
      !data.isAdmin
        ? buildStateMsg("Sem privilégios de administrador — algumas etapas podem falhar.", "warn")
        : buildStateMsg("Executado com privilégios de administrador.", "success"),
      el("div", { style: "height:14px" }),
      buildTable(
        [
          { key: "desc", label: "Etapa" },
          { key: "output", label: "Saída" },
          { key: "ok", label: "Status", render: (ok) => buildBadge(ok ? "OK" : "Falhou", ok ? "good" : "bad") },
        ],
        data.steps
      ),
    ]),

  wifi: (data) => {
    const ch24Entries = Object.entries(data.ch24 || {});
    const ch5Entries = Object.entries(data.ch5 || {});
    const maxCount = Math.max(1, ...ch24Entries.map(([, n]) => n), ...ch5Entries.map(([, n]) => n));

    return el("div", {}, [
      buildTable(
        [
          { key: "ssid", label: "SSID" },
          { key: "banda", label: "Banda" },
          { key: "canal", label: "Canal" },
          { key: "sinal", label: "Sinal" },
        ],
        data.redes
      ),
      el("div", { style: "height:20px" }),
      el("div", { class: "panel-section-title", text: "Ocupação — 2.4 GHz" }),
      ...ch24Entries.map(([canal, n]) => buildBarRow(`Canal ${canal}`, n / maxCount, `${n} rede(s)`)),
      data.recomendacao24 ? buildStateMsg(`Recomendado 2.4 GHz: ${data.recomendacao24}`, "success") : null,
      el("div", { style: "height:16px" }),
      el("div", { class: "panel-section-title", text: "Ocupação — 5 GHz" }),
      ...ch5Entries.map(([canal, n]) => buildBarRow(`Canal ${canal}`, n / maxCount, `${n} rede(s)`)),
      data.recomendacao5 ? buildStateMsg(`Recomendado 5 GHz: ${data.recomendacao5}`, "success") : null,
    ]);
  },

  latencia: (list) =>
    buildTable(
      [
        { key: "nome", label: "Destino" },
        { key: "host", label: "Host" },
        { key: "min", label: "Mín.", render: fmtMs },
        { key: "avg", label: "Média", render: (v) => `${fmtMs(v)} · ${classificarLatencia(v).label}` },
        { key: "max", label: "Máx.", render: fmtMs },
        { key: "jitter", label: "Jitter", render: (v) => `${v.toFixed(1)} ms` },
      ],
      list,
      { monoKeys: ["host"] }
    ),

  traceroute: (data) =>
    el("div", {}, [
      buildStateMsg(`Traceroute até ${data.host} — ${data.hops.length} hop(s).`, "info"),
      el("div", { style: "height:14px" }),
      buildTable(
        [
          { key: "numero", label: "Hop" },
          { key: "ip", label: "IP" },
          { key: "hostname", label: "Hostname", render: (v) => v || "—" },
          {
            key: "latenciaMs",
            label: "Latência",
            render: (v) => (v == null ? buildBadge("Timeout", "bad") : `${fmtMs(v)}`),
          },
        ],
        data.hops,
        { monoKeys: ["ip"] }
      ),
    ]),

  portas: (data) =>
    el("div", {}, [
      buildStatGrid([
        { label: "Portas testadas", value: String(data.testadas) },
        { label: "Portas abertas", value: String(data.abertas.length), tone: data.abertas.length ? "warn" : "good" },
      ]),
      el("div", { style: "height:14px" }),
      data.abertas.length
        ? buildTable(
            [
              { key: "porta", label: "Porta" },
              { key: "servico", label: "Serviço" },
              { key: "status", label: "Status", render: () => buildBadge("Aberta", "warn") },
            ],
            data.abertas
          )
        : buildStateMsg("Nenhuma porta aberta detectada.", "success"),
    ]),

  adaptador: (data) =>
    el("div", {}, [
      buildConsoleBox(data.raw),
      el("div", { style: "height:14px" }),
      el("div", { class: "panel-section-title", text: "Link Wi-Fi ativo" }),
      el(
        "ul",
        { style: "display:flex;flex-direction:column;gap:6px" },
        (data.linkInfo || []).map((line) => el("li", { class: "mono-cell", text: line }))
      ),
    ]),

  dns: (data) =>
    el("div", {}, [
      buildStateMsg(`Resolvendo: ${data.hostname}`, "info"),
      el("div", { style: "height:14px" }),
      buildTable(
        [
          { key: "servidor", label: "Servidor" },
          { key: "ipServidor", label: "IP do servidor" },
          { key: "tempoMs", label: "Tempo", render: (v) => fmtMs(v) },
          { key: "resultado", label: "Resultado" },
        ],
        data.resultados,
        { monoKeys: ["ipServidor", "resultado"] }
      ),
    ]),

  "ip-externo": (data) =>
    buildStatGrid([
      { label: "IP Externo", value: data.ip },
      { label: "Cidade", value: data.city || "—" },
      { label: "Estado", value: data.region || "—" },
      { label: "País", value: data.country || "—" },
      { label: "ISP / Org.", value: data.org || "—" },
      { label: "Fuso Horário", value: data.timezone || "—" },
    ]),

  mtu: (data) =>
    el("div", {}, [
      buildStatGrid([
        { label: "MTU máximo detectado", value: `${data.mtuMax} bytes`, tone: data.mtuMax >= 1492 ? "good" : "warn" },
        { label: "Tipo de link", value: data.tipoLink },
      ]),
      el("div", { style: "height:14px" }),
      buildTable(
        [
          { key: "tamanho", label: "Tamanho (bytes)" },
          { key: "status", label: "Status" },
          { key: "ok", label: "", render: (ok) => buildBadge(ok ? "OK" : "Falhou", ok ? "good" : "bad") },
        ],
        data.resultados
      ),
      data.fragmentacao
        ? buildStateMsg("Fragmentação detectada — pode causar lentidão em algumas aplicações.", "warn")
        : null,
    ]),

  vlsm: (rows) => buildTable([
    { key: "rede", label: "Rede" }, { key: "mascara", label: "Máscara" }, { key: "broadcast", label: "Broadcast" },
    { key: "hosts", label: "Endereços" }, { key: "hostsUsaveis", label: "Hosts utilizáveis" },
  ], rows || [], { monoKeys: ["rede", "mascara", "broadcast"] }),

  "orcamento-optico": (data) => el("div", {}, [buildStatGrid([
    { label: "Nível recebido", value: `${Number(data.nivelRecebido).toFixed(2)} dBm`, tone: data.ok ? "good" : "bad" },
    { label: "Atenuação total", value: `${Number(data.atenuacaoTotal).toFixed(2)} dB` },
  ]), el("div", { style: "height:14px" }), buildStateMsg(data.mensagem, data.ok ? "success" : "error")]),

  cftv: (data) => el("div", {}, [buildStatGrid([
    { label: "Banda estimada", value: `${Number(data.bandaMbps).toFixed(1)} Mbps` },
    { label: "Armazenamento", value: `${Number(data.storageTB).toFixed(2)} TB` },
  ]), el("div", { style: "height:14px" }), buildStateMsg(data.mensagem, "info")]),

  "conversor-telecom": (data) => buildStatGrid([
    { label: "Entrada", value: String(data.entrada) }, { label: "Saída", value: `${Number(data.saida).toFixed(4)} ${data.unidade}` }, { label: "Conversão", value: data.mensagem },
  ]),

  ssh: (data) => el("div", {}, [buildStatGrid([{ label: "Exit code", value: String(data.exitCode), tone: data.exitCode === 0 ? "good" : "warn" }]),
    el("div", { style: "height:14px" }), el("div", { class: "panel-section-title", text: "STDOUT" }), buildConsoleBox(data.stdout || "(sem saída)"),
    data.stderr ? el("div", {}, [el("div", { style: "height:14px" }), el("div", { class: "panel-section-title", text: "STDERR" }), buildConsoleBox(data.stderr)]) : null]),

  pppoe: (data) => buildStateMsg(`${data.mensagem}${data.codigo ? ` · Código ${data.codigo}` : ""}`, data.sucesso ? "success" : "error"),
  "servidor-lan": (data) => el("div", {}, [buildStatGrid([{ label: "Status", value: data.ativo ? "Ativo" : "Inativo", tone: data.ativo ? "good" : "warn" }, { label: "URL", value: data.url || "—" }, { label: "Porta", value: String(data.porta || "—") }]), data.aviso ? buildStateMsg(data.aviso, "info") : null]),
  "wifi-string": (data) => buildConsoleBox(String(data || "")),
  snmp: (data) => buildConsoleBox(String(data || "")),
  ssl: (data) => el("div", {}, [buildStatGrid([
    { label: "Host", value: data.host }, { label: "Dias restantes", value: String(data.diasRestantes), tone: data.ok ? "good" : "bad" },
    { label: "Emissor", value: data.emissor || "—" }, { label: "Subject", value: data.subject || "—" },
  ]), ...(data.alertas || []).map((a) => buildStateMsg(a, "warn")), ...(data.ok ? [buildStateMsg("Certificado sem alertas detectados.", "success")] : [])]),
  "senha-segura": (data) => buildConsoleBox(String(data || "")),
  "config-ip": (data) => buildStateMsg(data.mensagem || (data.sucesso ? "Configuração aplicada." : "Não foi possível aplicar a configuração."), data.sucesso ? "success" : "error"),
  ipv6: (data) => el("div", {}, [buildStatGrid([
    { label: "IPv6 global", value: data.ipv6Global || "Não detectado" },
    { label: "Conectividade", value: data.conectividade ? "OK" : "Não", tone: data.conectividade ? "good" : "warn" },
    { label: "DNS IPv6", value: data.dnsv6 ? "OK" : "Não", tone: data.dnsv6 ? "good" : "warn" },
  ]), el("div", { style: "height:14px" }), buildStateMsg(data.mensagem, data.conectividade ? "success" : "info")]),
};
