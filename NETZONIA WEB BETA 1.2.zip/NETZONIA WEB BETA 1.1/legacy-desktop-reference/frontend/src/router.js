// ---------------------------------------------------------------------
// router.js — roteador minimalista baseado em hash.
// Fusão P15 + frontend da Enolla: junta a navegação por categorias da
// Enolla com as rotas funcionais reais do P15 (funcionalidade, mapa3d,
// local) — nenhuma rota funcional do P15 foi removida.
//
// Rotas suportadas:
//   #/                          → home (categorias + planejador, ou busca)
//   #/categoria/:id             → ferramentas de uma categoria
//   #/funcionalidade/:id        → detalhe de uma das 31 funcionalidades
//   #/planejador-3d             → tela de entrada do Planejador / Mapa 3D
//   #/local                     → busca de endereço (Planejador 3D real, P15)
//   #/mapa3d/:placeId?          → Planejador / Mapa 3D real (P15), com ou sem local
//
// Cada view pode devolver uma função de limpeza (remover listeners,
// parar o watchdog, etc.), chamada automaticamente antes de trocar de
// rota — evita vazamento de memória / eventos duplicados do Wails.
// ---------------------------------------------------------------------

import { qs } from "./lib/dom.js";
import { renderHomeView } from "./views/homeView.js";
import { renderCategoryView } from "./views/categoryView.js";
import { renderFeatureView } from "./views/featureView.js";
import { renderPlannerView } from "./views/plannerView.js";
import { renderMapa3DView } from "./mapa3d/mapa3dView.js";
import { renderPlaceSearchView } from "./views/placeSearchView.js";
import { PLANNER } from "./data/categories.js";

let currentCleanup = null;
const searchState = { query: "", categoryId: "all" };

function parseHash() {
  const hash = window.location.hash || "#/";
  const path = hash.replace(/^#/, "");
  const parts = path.split("/").filter(Boolean);

  if (parts.length === 0) return { name: "home" };
  if (parts[0] === "categoria" && parts[1]) return { name: "categoria", id: decodeURIComponent(parts[1]) };
  if (parts[0] === "funcionalidade" && parts[1]) return { name: "feature", id: decodeURIComponent(parts[1]) };
  if (parts[0] === "local") return { name: "local" };
  if (parts[0] === "mapa3d") return { name: "mapa3d", placeId: parts[1] ? decodeURIComponent(parts[1]) : null };
  if (parts[0] === PLANNER.id) return { name: "planner" };
  return { name: "not-found" };
}

function resetHeaderInputs() {
  const searchInput = qs("#search-input");
  const categoryFilter = qs("#category-filter");
  if (searchInput) searchInput.value = "";
  if (categoryFilter) categoryFilter.value = "all";
}

function render() {
  const container = qs("#app-main");
  if (typeof currentCleanup === "function") {
    currentCleanup();
    currentCleanup = null;
  }

  const route = parseHash();
  container.scrollTop = 0;

  if (route.name === "feature") {
    resetHeaderInputs();
    currentCleanup = renderFeatureView(container, route.id);
    return;
  }

  if (route.name === "categoria") {
    resetHeaderInputs();
    currentCleanup = renderCategoryView(container, route.id);
    return;
  }

  if (route.name === "planner") {
    resetHeaderInputs();
    currentCleanup = renderPlannerView(container);
    return;
  }

  if (route.name === "mapa3d") {
    resetHeaderInputs();
    currentCleanup = renderMapa3DView(container, route.placeId);
    return;
  }

  if (route.name === "local") {
    resetHeaderInputs();
    currentCleanup = renderPlaceSearchView(container);
    return;
  }

  // home (ou rota desconhecida cai na home)
  const searchInput = qs("#search-input");
  const categoryFilter = qs("#category-filter");
  if (searchInput) searchInput.value = searchState.query;
  if (categoryFilter) categoryFilter.value = searchState.categoryId;
  currentCleanup = renderHomeView(container, { query: searchState.query, categoryId: searchState.categoryId });
}

export function initRouter() {
  window.addEventListener("hashchange", render);
  if (!window.location.hash) window.location.hash = "#/";
  render();
}

export function navigate(path) {
  window.location.hash = path;
}

function applySearchState() {
  const route = parseHash();
  if (route.name !== "home") {
    navigate("#/");
  } else {
    render();
  }
}

/** Chamado pelo cabeçalho sempre que o texto de busca muda. */
export function setSearchQuery(query) {
  searchState.query = query;
  applySearchState();
}

/** Chamado pelo seletor de categoria ao lado da busca. */
export function setSearchCategory(categoryId) {
  searchState.categoryId = categoryId || "all";
  applySearchState();
}
