// ---------------------------------------------------------------------
// icons.js — ícones de linha (stroke, 24x24, currentColor) desenhados à
// mão para os 14 cartões. Mesmo estilo em todos: mantém a identidade
// visual coesa sem depender de bibliotecas externas (offline-first).
// ---------------------------------------------------------------------

const wrap = (paths) =>
  `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">${paths}</svg>`;

const S = 'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';

export const icons = {
  speed: wrap(`
    <path d="M12 13.5 16 9" ${S}/>
    <path d="M4.5 19a8.5 8.5 0 1 1 15 0" ${S}/>
    <path d="M7 19H4.5M19.5 19H17" ${S}/>
  `),
  devices: wrap(`
    <rect x="3" y="4" width="14" height="10" rx="1.5" ${S}/>
    <path d="M7 20h6M10 14v6" ${S}/>
    <rect x="17" y="9" width="4" height="7" rx="1" ${S}/>
  `),
  router: wrap(`
    <rect x="3" y="10" width="18" height="7" rx="1.5" ${S}/>
    <path d="M7 10V7a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3" ${S}/>
    <circle cx="8" cy="13.5" r="0.9" fill="currentColor"/>
    <circle cx="12" cy="13.5" r="0.9" fill="currentColor"/>
  `),
  repair: wrap(`
    <path d="M14.5 3.5 20.5 9.5 9.5 20.5 3.5 14.5Z" ${S}/>
    <path d="M13 6 18 11" ${S}/>
  `),
  wifi: wrap(`
    <path d="M4 9.5a12 12 0 0 1 16 0" ${S}/>
    <path d="M7 13a7.5 7.5 0 0 1 10 0" ${S}/>
    <path d="M10 16.5a3 3 0 0 1 4 0" ${S}/>
    <circle cx="12" cy="19.3" r="1" fill="currentColor"/>
  `),
  latency: wrap(`
    <circle cx="12" cy="12" r="8.5" ${S}/>
    <path d="M12 7.5V12l3 2" ${S}/>
  `),
  report: wrap(`
    <path d="M7 3.5h7l4 4V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1Z" ${S}/>
    <path d="M14 3.5V8h4" ${S}/>
    <path d="M9 12.5h6M9 15.5h6M9 18h3.5" ${S}/>
  `),
  traceroute: wrap(`
    <circle cx="4.5" cy="6" r="1.6" ${S}/>
    <circle cx="19.5" cy="18" r="1.6" ${S}/>
    <path d="M6 6.6C9 8 8 11 11 12s3 4 8.5 5.2" ${S}/>
  `),
  ports: wrap(`
    <rect x="3.5" y="6" width="17" height="12" rx="1.5" ${S}/>
    <path d="M8 10v4M12 10v4M16 10v4" ${S}/>
  `),
  adapter: wrap(`
    <rect x="3" y="6" width="18" height="9" rx="1.5" ${S}/>
    <path d="M7 19h10M9 15v4M15 15v4" ${S}/>
  `),
  dns: wrap(`
    <ellipse cx="12" cy="6" rx="8" ry="3" ${S}/>
    <path d="M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6" ${S}/>
    <path d="M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" ${S}/>
  `),
  watchdog: wrap(`
    <circle cx="12" cy="12" r="8.5" ${S}/>
    <path d="M8.5 12.5 11 15l4.5-6" ${S}/>
  `),
  geo: wrap(`
    <path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21Z" ${S}/>
    <circle cx="12" cy="9.5" r="2.3" ${S}/>
  `),
  mtu: wrap(`
    <path d="M3.5 12h4.5l1.5-4 3 8 1.5-4H20.5" ${S}/>
  `),
  search: wrap(`
    <circle cx="11" cy="11" r="7" ${S}/>
    <path d="M21 21 16.65 16.65" ${S}/>
  `),
  back: wrap(`<path d="M15 5 8 12l7 7" ${S}/>`),
  save: wrap(`
    <path d="M5 4.5h11L20 8.5V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1Z" ${S}/>
    <path d="M8 4.5V9h7V4.5" ${S}/>
    <path d="M8 14h8" ${S}/>
  `),
  info: wrap(`
    <circle cx="12" cy="12" r="9" ${S}/>
    <path d="M12 11v5.5M12 8v.01" ${S}/>
  `),

  // ---- categorias (ícones um pouco mais "cheios", para os cards grandes da home) ----
  catDiagnostico: wrap(`
    <path d="M3.5 12.5h4l2-6 3 11 2-8 1.5 3h4.5" ${S}/>
  `),
  catDispositivos: wrap(`
    <rect x="3.5" y="4" width="17" height="6" rx="1.4" ${S}/>
    <rect x="3.5" y="14" width="17" height="6" rx="1.4" ${S}/>
    <circle cx="7" cy="7" r="0.8" fill="currentColor"/>
    <circle cx="7" cy="17" r="0.8" fill="currentColor"/>
  `),
  catWifiInfra: wrap(`
    <path d="M12 3.5v4" ${S}/>
    <path d="M7.5 8.5a6.5 6.5 0 0 1 9 0" ${S}/>
    <path d="M4.5 11.5a10.5 10.5 0 0 1 15 0" ${S}/>
    <path d="M9 20.5 12 14l3 6.5" ${S}/>
  `),
  catMonitoramento: wrap(`
    <path d="M2.5 12.5c2-4.5 5-6.8 9.5-6.8s7.5 2.3 9.5 6.8c-2 4.5-5 6.8-9.5 6.8s-7.5-2.3-9.5-6.8Z" ${S}/>
    <circle cx="12" cy="12.5" r="2.6" ${S}/>
  `),
  catFerramentas: wrap(`
    <path d="M14.5 4.5a4 4 0 0 0-5.4 4.7L4 14.3v3.2h3.2l5.1-5.1a4 4 0 0 0 4.7-5.4l-2.6 2.6-2-.5-.5-2Z" ${S}/>
  `),
  catPlanejador: wrap(`
    <path d="M12 3.5 20 7v10l-8 3.5-8-3.5V7Z" ${S}/>
    <path d="M12 3.5v17M4 7l8 3.5 8-3.5" ${S}/>
  `),

  // ---- novas ferramentas ----
  ipv6: wrap(`
    <path d="M9 3.5 3.5 6.75v6.5L9 16.5l5.5-3.25v-6.5Z" ${S}/>
    <path d="M16.5 12.5h4M18 10.5v4" ${S}/>
    <path d="M9 20.5h6" ${S}/>
  `),
  wol: wrap(`
    <path d="M13 3 5.5 13.5H11L10 21l8-11h-5.5Z" ${S}/>
  `),
  ssh: wrap(`
    <rect x="3" y="4.5" width="18" height="15" rx="1.6" ${S}/>
    <path d="M6.5 9.5 10 12.5 6.5 15.5" ${S}/>
    <path d="M12.5 15.5h5" ${S}/>
  `),
  snmp: wrap(`
    <circle cx="5.5" cy="6" r="1.6" ${S}/>
    <circle cx="5.5" cy="18" r="1.6" ${S}/>
    <circle cx="18.5" cy="12" r="1.6" ${S}/>
    <path d="M7 6h5a3 3 0 0 1 3 3v0M7 18h5a3 3 0 0 0 3-3v0" ${S}/>
  `),
  ipConfig: wrap(`
    <path d="M4 7h9M4 12h16M4 17h9" ${S}/>
    <circle cx="16" cy="7" r="2" ${S}/>
    <circle cx="16" cy="17" r="2" ${S}/>
  `),
  vlsm: wrap(`
    <rect x="3.5" y="3.5" width="17" height="17" rx="1.4" ${S}/>
    <path d="M12 3.5v17M3.5 9h8.5M3.5 15h8.5" ${S}/>
  `),
  gpon: wrap(`
    <path d="M3.5 19 12 5l8.5 14" ${S}/>
    <path d="M8 13h8" ${S}/>
  `),
  cftv: wrap(`
    <path d="M3.5 8.5h11v7h-11Z" ${S}/>
    <path d="M14.5 10.5 20.5 8v8l-6-2.5Z" ${S}/>
    <circle cx="9" cy="12" r="2" ${S}/>
  `),
  wifiString: wrap(`
    <rect x="3.5" y="3.5" width="6" height="6" rx="1" ${S}/>
    <rect x="14.5" y="3.5" width="6" height="6" rx="1" ${S}/>
    <rect x="3.5" y="14.5" width="6" height="6" rx="1" ${S}/>
    <path d="M14.5 15.5h2.5v2.5h-2.5ZM19 15.5h1.5M14.5 20h1.5M17.5 20h3v-2" ${S}/>
  `),
  pingSonoro: wrap(`
    <path d="M4 10.5v3h3l4.5 3.8V6.7L7 10.5Z" ${S}/>
    <path d="M16 9a4.2 4.2 0 0 1 0 6M18.7 6.5a8 8 0 0 1 0 11" ${S}/>
  `),
  pppoe: wrap(`
    <path d="M8 9.5V6a2 2 0 0 1 2-2h1M16 14.5V18a2 2 0 0 1-2 2h-1" ${S}/>
    <rect x="4" y="9.5" width="6" height="5" rx="1.2" ${S}/>
    <rect x="14" y="9.5" width="6" height="5" rx="1.2" ${S}/>
    <path d="M10 12h4" ${S}/>
  `),
  serverLan: wrap(`
    <rect x="4" y="4" width="16" height="6.5" rx="1.4" ${S}/>
    <rect x="4" y="13.5" width="16" height="6.5" rx="1.4" ${S}/>
    <circle cx="7.5" cy="7.25" r="0.8" fill="currentColor"/>
    <circle cx="7.5" cy="16.75" r="0.8" fill="currentColor"/>
    <path d="M12 10.5v3" ${S}/>
  `),
  ssl: wrap(`
    <rect x="5" y="10.5" width="14" height="9" rx="1.6" ${S}/>
    <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" ${S}/>
    <path d="M12 14.2v2.2" ${S}/>
  `),
  convert: wrap(`
    <path d="M6 7h11.5M14.5 3.5 17.5 7l-3 3.5" ${S}/>
    <path d="M18 17H6.5M9.5 13.5 6.5 17l3 3.5" ${S}/>
  `),
  password: wrap(`
    <circle cx="8" cy="14.5" r="4" ${S}/>
    <path d="M11.3 11.7 19.5 3.5M16.5 6.5l2 2M19 4l1.5 1.5" ${S}/>
  `),
  shortcuts: wrap(`
    <rect x="2.5" y="6" width="19" height="12" rx="1.8" ${S}/>
    <path d="M6.5 10v0M9.5 10v0M12.5 10v0M15.5 10v0M6.5 14h11" ${S}/>
  `),
  home: wrap(`
    <path d="M4 11.5 12 4l8 7.5" ${S}/>
    <path d="M6 10v9.5h12V10" ${S}/>
  `),
  chevronRight: wrap(`<path d="M9 5.5 15.5 12 9 18.5" ${S}/>`),
  plugOff: wrap(`
    <path d="M9 3.5v4M15 3.5v4" ${S}/>
    <path d="M7 7.5h10v3.5a5 5 0 0 1-10 0Z" ${S}/>
    <path d="M12 15.5V20" ${S}/>
    <path d="M3.5 3.5 20.5 20.5" ${S}/>
  `),
  pulse: wrap(`
    <circle cx="12" cy="12" r="9" ${S}/>
    <path d="M8 12h2l1.5-3 2 6 1.5-3h1" ${S}/>
  `),
};
