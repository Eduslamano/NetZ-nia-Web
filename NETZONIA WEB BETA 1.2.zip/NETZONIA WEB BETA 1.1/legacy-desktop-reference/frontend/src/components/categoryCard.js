// ---------------------------------------------------------------------
// categoryCard.js — um dos 6 cartões grandes da home (um por categoria).
// ---------------------------------------------------------------------

import { el } from "../lib/dom.js";
import { icons } from "../data/icons.js";
import { countByCategory } from "../data/tools.js";

export function renderCategoryCard(category) {
  const total = countByCategory(category.id);

  return el(
    "a",
    {
      href: `#/categoria/${category.id}`,
      class: `category-card ${category.tone}`,
      "aria-label": `${category.label} — ${total} ferramentas`,
    },
    [
      el("div", { class: "category-card-icon", html: category.icon }),
      el("div", { class: "category-card-body" }, [
        el("h2", { class: "category-card-title", text: category.label }),
        el("p", { class: "category-card-desc", text: category.description }),
      ]),
      el("div", { class: "category-card-footer" }, [
        el("span", { class: "category-card-count", text: `${total} ferramenta${total === 1 ? "" : "s"}` }),
        el("span", { class: "category-card-open" }, [el("span", { text: "Abrir" }), el("span", { html: icons.chevronRight })]),
      ]),
    ]
  );
}
