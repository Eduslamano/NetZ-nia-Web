// ---------------------------------------------------------------------
// plannerBanner.js — faixa de destaque do Planejador / Mapa 3D.
// É deliberadamente diferente dos cartões de categoria (largura total,
// gradiente violeta próprio) porque o módulo pediu para manter
// destaque visual separado das 6 categorias de ferramentas.
// ---------------------------------------------------------------------

import { el } from "../lib/dom.js";
import { icons } from "../data/icons.js";
import { PLANNER } from "../data/categories.js";

export function renderPlannerBanner() {
  return el("a", { href: `#/${PLANNER.id}`, class: "planner-banner", "aria-label": PLANNER.title }, [
    el("div", { class: "planner-banner-icon", html: PLANNER.icon }),
    el("div", { class: "planner-banner-body" }, [
      el("span", { class: "planner-banner-eyebrow", text: "Módulo especial" }),
      el("h2", { class: "planner-banner-title", text: PLANNER.title }),
      el("p", { class: "planner-banner-desc", text: PLANNER.description }),
    ]),
    el("span", { class: "planner-banner-cta" }, [el("span", { text: "Abrir" }), el("span", { html: icons.chevronRight })]),
  ]);
}
