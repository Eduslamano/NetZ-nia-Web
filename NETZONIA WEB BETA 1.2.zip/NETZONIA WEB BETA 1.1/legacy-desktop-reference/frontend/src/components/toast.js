// ---------------------------------------------------------------------
// toast.js — notificações rápidas no canto da tela.
// Evita notificações idênticas simultâneas para não duplicar feedback
// quando duas dependências falham pelo mesmo motivo (ex.: internet offline).
// ---------------------------------------------------------------------

import { qs, el } from "../lib/dom.js";

/**
 * @param {string} message
 * @param {"info"|"success"|"error"|"warn"|"warning"} type
 * @param {number} duration - ms antes de sumir sozinho
 */
export function showToast(message, type = "info", duration = 4200) {
  const root = qs("#toast-root");
  if (!root) return;

  const normalizedMessage = String(message || "").trim();
  if (!normalizedMessage) return;

  const normalizedType = type === "warning" ? "warn" : type;
  const duplicate = Array.from(root.children).some(
    (node) => node.dataset?.toastMessage === normalizedMessage && node.dataset?.toastType === normalizedType
  );
  if (duplicate) return;

  const node = el("div", {
    class: `toast ${normalizedType}`,
    role: normalizedType === "error" ? "alert" : "status",
    "aria-atomic": "true",
    tabindex: "0",
  }, [
    el("span", { text: normalizedMessage }),
  ]);
  node.dataset.toastMessage = normalizedMessage;
  node.dataset.toastType = normalizedType;

  root.appendChild(node);

  let removed = false;
  const remove = () => {
    if (removed) return;
    removed = true;
    node.classList.add("leaving");
    setTimeout(() => node.remove(), 180);
  };

  const timer = setTimeout(remove, duration);
  node.addEventListener("click", () => {
    clearTimeout(timer);
    remove();
  });
}
