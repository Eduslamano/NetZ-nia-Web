// ---------------------------------------------------------------------
// sideMenu.js — gaveta lateral com as categorias, aberta pelo botão de
// menu hambúrguer no canto superior esquerdo do cabeçalho.
//
// Substitui a barra de navegação inferior: mesmo conjunto de atalhos
// (Início + 5 categorias + Planejador), agora dentro de um painel que
// desliza a partir da esquerda, com overlay escurecido atrás.
// ---------------------------------------------------------------------

import { el, qs, clear } from "../lib/dom.js";
import { icons } from "../data/icons.js";
import { CATEGORIES, CATEGORY_ORDER, PLANNER } from "../data/categories.js";
import { getFeatureById } from "../data/features.js";

function currentRouteInfo() {
  const hash = window.location.hash || "#/";
  const parts = hash.replace(/^#\//, "").split("/").filter(Boolean);
  if (parts.length === 0) return { name: "home" };
  if (parts[0] === "categoria" && parts[1]) return { name: "categoria", id: parts[1] };
  if (parts[0] === PLANNER.id || parts[0] === "local" || parts[0] === "mapa3d") return { name: "planejador" };
  if (parts[0] === "funcionalidade" && parts[1]) {
    const feature = getFeatureById(parts[1]);
    return { name: "funcionalidade", id: parts[1], categoryId: feature?.category || null };
  }
  return { name: "home" };
}

function buildItem({ href, icon, label, isActive, onNavigate }) {
  return el(
    "a",
    {
      href,
      class: `side-menu-item${isActive ? " active" : ""}`,
      onClick: onNavigate,
    },
    [el("span", { class: "side-menu-icon", html: icon }), el("span", { class: "side-menu-label", text: label })]
  );
}

export function mountSideMenu() {
  const root = qs("#side-menu-root");
  const menuBtn = qs("#menu-btn");
  if (!root || !menuBtn) return;

  let isOpen = false;
  let lastFocused = null;
  let activePanel = null;

  function focusableElements(container) {
    return Array.from(container.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    ));
  }

  function close({ restoreFocus = true } = {}) {
    if (!isOpen) return;
    isOpen = false;
    activePanel = null;
    clear(root);
    menuBtn.setAttribute("aria-expanded", "false");
    if (restoreFocus && lastFocused && typeof lastFocused.focus === "function") {
      lastFocused.focus();
    }
    lastFocused = null;
  }

  function renderPanelContent(panel) {
    const route = currentRouteInfo();
    clear(panel);

    const header = el("div", { class: "side-menu-header" }, [
      el("span", { class: "side-menu-title", text: "Categorias" }),
      el("button", { class: "side-menu-close", type: "button", "aria-label": "Fechar menu", text: "✕", onClick: close }),
    ]);

    const closeForNavigation = () => close({ restoreFocus: false });
    const items = [
      buildItem({ href: "#/", icon: icons.home, label: "Início", isActive: route.name === "home", onNavigate: closeForNavigation }),
      ...CATEGORY_ORDER.map((catId) => {
        const cat = CATEGORIES[catId];
        return buildItem({
          href: `#/categoria/${catId}`,
          icon: cat.icon,
          label: cat.label,
          isActive: (route.name === "categoria" && route.id === catId) || (route.name === "funcionalidade" && route.categoryId === catId),
          onNavigate: closeForNavigation,
        });
      }),
      buildItem({
        href: `#/${PLANNER.id}`,
        icon: PLANNER.icon,
        label: PLANNER.title,
        isActive: route.name === "planejador",
        onNavigate: closeForNavigation,
      }),
    ];

    panel.appendChild(header);
    panel.appendChild(el("nav", { class: "side-menu-list", "aria-label": "Categorias" }, items));
  }

  function open() {
    if (isOpen) return;
    isOpen = true;
    lastFocused = document.activeElement;
    menuBtn.setAttribute("aria-expanded", "true");

    const panel = el("div", { class: "side-menu-panel", role: "dialog", "aria-modal": "true", "aria-label": "Menu de categorias", tabindex: "-1" });
    activePanel = panel;
    renderPanelContent(panel);

    const overlay = el(
      "div",
      {
        class: "side-menu-overlay",
        onClick: (e) => {
          if (e.target === overlay) close();
        },
      },
      [panel]
    );

    clear(root);
    root.appendChild(overlay);

    // força o navegador a aplicar o estado inicial antes de animar a entrada
    requestAnimationFrame(() => {
      overlay.classList.add("is-open");
      const first = focusableElements(panel)[0];
      (first || panel).focus();
    });
  }

  menuBtn.addEventListener("click", () => (isOpen ? close() : open()));

  document.addEventListener("keydown", (e) => {
    if (!isOpen) return;
    if (e.key === "Escape") {
      e.preventDefault();
      close();
      return;
    }
    if (e.key === "Tab" && activePanel) {
      const focusables = focusableElements(activePanel);
      if (!focusables.length) {
        e.preventDefault();
        activePanel.focus();
        return;
      }
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  // mantém o item ativo em dia caso a rota mude com o menu aberto
  window.addEventListener("hashchange", () => {
    if (isOpen) close({ restoreFocus: false });
  });
}
