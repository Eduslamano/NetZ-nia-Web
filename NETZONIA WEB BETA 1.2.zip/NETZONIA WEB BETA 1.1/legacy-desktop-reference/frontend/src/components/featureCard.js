// ---------------------------------------------------------------------
// featureCard.js — um cartão de ferramenta (usado dentro das telas de
// categoria). Ferramentas novas (ainda sem backend) ganham um selo
// discreto "Aguardando backend" — nunca escondido, nunca disfarçado.
// ---------------------------------------------------------------------

import { el } from "../lib/dom.js";
import { CATEGORIES } from "../data/categories.js";
import { isPending } from "../data/tools.js";

export function renderFeatureCard(feature) {
  const category = CATEGORIES[feature.category];
  const numberLabel = String(feature.number).padStart(2, "0");
  const pending = isPending(feature);

  return el(
    "a",
    {
      href: `#/funcionalidade/${feature.id}`,
      class: `feature-card ${category.tone}`,
      "data-feature-id": feature.id,
      "aria-label": `${feature.title} — ${feature.subtitle}`,
    },
    [
      el("div", { class: "card-top" }, [
        el("div", { class: "card-icon", html: feature.icon }),
        el("span", { class: "card-number", text: `Nº ${numberLabel}` }),
      ]),
      el("div", { class: "card-body" }, [
        el("div", { class: "card-title", text: feature.title }),
        el("div", { class: "card-desc", text: feature.subtitle }),
      ]),
      el("div", { class: "card-footer" }, [
        el("span", { class: "card-tag", text: category.label }),
        pending ? el("span", { class: "card-pending-pill", text: "Aguardando backend" }) : null,
      ]),
    ]
  );
}
