// ---------------------------------------------------------------------
// exitModal.js — modal "Deseja salvar relatório antes de sair?"
//
// Fluxo:
//   [Sim] → chama App.SalvarRelatorioComo() no Go, que abre o diálogo
//           nativo "Salvar como" (runtime.SaveFileDialog) e grava o
//           arquivo. O caminho retornado é exibido em um toast, e só
//           então a aplicação fecha.
//   [Não] → fecha a aplicação imediatamente, sem salvar nada.
//
// Por que a escolha do local do arquivo não é feita em JS puro:
// a webview do Wails roda o frontend como conteúdo web comum, sem
// acesso ao sistema de arquivos do usuário — nem `<input type="file">`
// nem APIs de disco funcionam para *salvar* fora da pasta de downloads
// do navegador. A forma correta e seguRA é o Go abrir o diálogo nativo
// do SO e escrever o arquivo, devolvendo só o caminho final ao JS.
// ---------------------------------------------------------------------

import { el, qs, clear } from "../lib/dom.js";
import { icons } from "../data/icons.js";
import { salvarRelatorioComo, sairDaAplicacao } from "../lib/wails-bridge.js";
import { showToast } from "./toast.js";

export function openExitModal() {
  const root = qs("#modal-root");
  clear(root);

  let busy = false;
  const previouslyFocused = document.activeElement;
  let overlay = null;

  const focusableElements = (container) => Array.from(container.querySelectorAll(
    'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
  ));

  const cleanup = () => {
    document.removeEventListener("keydown", onKeydown);
  };

  const closeModal = ({ restoreFocus = true } = {}) => {
    cleanup();
    clear(root);
    if (restoreFocus && previouslyFocused && typeof previouslyFocused.focus === "function") {
      previouslyFocused.focus();
    }
  };

  const handleNao = () => {
    if (busy) return;
    closeModal({ restoreFocus: false });
    sairDaAplicacao();
  };

  const handleSim = async () => {
    if (busy) return;
    busy = true;
    simBtn.disabled = true;
    naoBtn.disabled = true;
    simBtn.textContent = "Salvando...";

    try {
      const result = await salvarRelatorioComo();
      if (result && result.saved) {
        showToast(`Relatório salvo em: ${result.path}`, "success", 6000);
      } else {
        showToast("Salvamento cancelado — nenhum arquivo foi criado.", "info");
      }
    } catch (err) {
      showToast(`Não foi possível salvar o relatório: ${err?.message || err}`, "error", 6000);
    } finally {
      closeModal({ restoreFocus: false });
      sairDaAplicacao();
    }
  };

  const simBtn = el("button", { class: "btn btn-primary", type: "button", onClick: handleSim }, "Sim, salvar e sair");
  const naoBtn = el("button", { class: "btn btn-ghost", type: "button", onClick: handleNao }, "Sair sem salvar");

  const modalCard = el("div", { class: "modal-card", role: "dialog", "aria-modal": "true", "aria-labelledby": "exit-modal-title", "aria-describedby": "exit-modal-desc", tabindex: "-1" }, [
    el("div", { class: "modal-icon", html: icons.save }),
    el("h2", { class: "modal-title", id: "exit-modal-title", text: "Deseja salvar o relatório antes de sair?" }),
    el("p", {
      class: "modal-text",
      id: "exit-modal-desc",
      text: "O relatório reúne o que foi executado nesta sessão do NetZônia. Você pode escolher onde salvá-lo ou sair sem criar o arquivo.",
    }),
    el("div", { class: "modal-actions" }, [naoBtn, simBtn]),
  ]);

  overlay = el(
    "div",
    {
      class: "modal-overlay",
      onClick: (e) => {
        if (e.target === overlay && !busy) closeModal();
      },
    },
    [modalCard]
  );

  function onKeydown(e) {
    if (e.key === "Escape" && !busy) {
      e.preventDefault();
      closeModal();
      return;
    }
    if (e.key !== "Tab") return;

    const focusables = focusableElements(modalCard);
    if (!focusables.length) {
      e.preventDefault();
      modalCard.focus();
      return;
    }
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  document.addEventListener("keydown", onKeydown);
  root.appendChild(overlay);
  requestAnimationFrame(() => simBtn.focus());
}
