// ---------------------------------------------------------------------
// resultBuilders.js — peças reutilizáveis para montar os resultados de
// cada funcionalidade (tabela, cartões de estatística, badges, barras
// de ocupação, console de saída bruta).
// ---------------------------------------------------------------------

import { el } from "../lib/dom.js";

/** Tabela genérica. columns: [{key, label}], rows: [{key: value}] */
export function buildTable(columns, rows, { monoKeys = [] } = {}) {
  if (!rows || rows.length === 0) {
    return el("div", { class: "state-msg info" }, "Nenhum resultado para exibir.");
  }

  const thead = el(
    "thead",
    {},
    el(
      "tr",
      {},
      columns.map((c) => el("th", { text: c.label }))
    )
  );

  const tbody = el(
    "tbody",
    {},
    rows.map((row) =>
      el(
        "tr",
        {},
        columns.map((c) => {
          const raw = row[c.key];
          const value = c.render ? c.render(raw, row) : raw ?? "—";
          if (value instanceof Node) return el("td", {}, value);
          return el("td", { class: monoKeys.includes(c.key) ? "mono-cell" : "" }, String(value));
        })
      )
    )
  );

  return el("div", { class: "result-table-wrap" }, el("table", { class: "result-table" }, [thead, tbody]));
}

/** Cartões de estatística. items: [{label, value, sub, tone}] */
export function buildStatGrid(items) {
  return el(
    "div",
    { class: "stat-grid" },
    items.map((item) => {
      const valueText = String(item.value ?? "—");
      const lengthClass = valueText.length > 30
        ? "is-very-long"
        : valueText.length > 18
          ? "is-long"
          : "";

      return el("div", { class: "stat-card" }, [
        el("div", { class: "stat-label", text: item.label }),
        el("div", { class: `stat-value ${item.tone || ""} ${lengthClass}`.trim(), text: valueText }),
        item.sub ? el("div", { class: "stat-sub", text: item.sub }) : null,
      ]);
    })
  );
}

/** Badge de status (bom/atenção/ruim/neutro). */
export function buildBadge(label, tone = "neutral") {
  return el("span", { class: `badge badge-${tone}`, text: label });
}

/** Linha de barra de ocupação (usada em canais Wi-Fi e hops de traceroute). */
export function buildBarRow(label, ratio, countLabel) {
  return el("div", { class: "bar-row" }, [
    el("span", { class: "bar-label", text: label }),
    el("div", { class: "bar-track" }, el("div", { class: "bar-fill", style: `width:${Math.round(ratio * 100)}%` })),
    el("span", { class: "bar-count", text: countLabel }),
  ]);
}

/** Bloco de saída bruta (estilo terminal). */
export function buildConsoleBox(text) {
  return el("pre", { class: "console-box", text });
}

/** Linha de estado de carregamento com spinner. */
export function buildLoadingRow(message) {
  return el("div", { class: "loading-row" }, [el("div", { class: "spinner" }), el("span", { text: message })]);
}

/** Mensagem de estado (info / erro / sucesso / aviso). */
export function buildStateMsg(message, tone = "info") {
  return el("div", { class: `state-msg ${tone}`, text: message });
}
