// ---------------------------------------------------------------------
// main.js — ponto de entrada. Liga o cabeçalho (busca, filtro de
// categoria, sair, selo de conexão), monta o menu lateral (Enolla) e
// inicializa o roteador. Fusão P15 + Enolla.
// ---------------------------------------------------------------------

import { qs, el } from "./lib/dom.js";
import { initRouter, setSearchQuery, setSearchCategory } from "./router.js";
import { openExitModal } from "./components/exitModal.js";
import { mountSideMenu } from "./components/sideMenu.js";
import { CATEGORIES, CATEGORY_ORDER } from "./data/categories.js";
import { bridgeStatus, isBackendConnected } from "./lib/wails-bridge.js";

function populateCategoryFilter() {
  const select = qs("#category-filter");
  if (!select) return;
  CATEGORY_ORDER.forEach((id) => {
    select.appendChild(el("option", { value: id }, CATEGORIES[id].shortLabel));
  });
}

function bindHeader() {
  const searchInput = qs("#search-input");
  const categoryFilter = qs("#category-filter");
  const exitBtn = qs("#exit-btn");

  searchInput.addEventListener("input", (e) => setSearchQuery(e.target.value));
  categoryFilter.addEventListener("change", (e) => setSearchCategory(e.target.value));

  exitBtn.addEventListener("click", () => openExitModal());

  // Atalho: "/" foca a busca (comum em toolkits/painéis técnicos)
  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && document.activeElement !== searchInput) {
      e.preventDefault();
      searchInput.focus();
    }
    if (e.key === "Escape" && document.activeElement === searchInput) {
      searchInput.blur();
    }
  });
}

function renderConnectivityBadge() {
  const badge = qs("#connectivity-badge");
  if (!badge) return;
  const label = badge.querySelector("[data-label]");
  if (isBackendConnected()) {
    badge.classList.add("online");
    label.textContent = "Backend conectado";
  } else {
    badge.classList.remove("online");
    label.textContent = "Pré-visualização (sem backend)";
  }
}

function logBridgeStatus() {
  if (bridgeStatus.connected) return;

  if (bridgeStatus.mocksEnabled) {
    // eslint-disable-next-line no-console
    console.warn(
      "%c[NetZônia] Pré-visualização em MODO MOCK — resultados são simulados e não representam medições reais.",
      "color:#8a5a00;font-weight:bold;"
    );
    return;
  }

  // eslint-disable-next-line no-console
  console.info(
    "%c[NetZônia] Backend Wails indisponível — dados simulados estão desativados. Use ?mock=1 somente para desenvolvimento.",
    "color:#0E4A43;font-weight:bold;"
  );
}

function bootstrap() {
  populateCategoryFilter();
  bindHeader();
  renderConnectivityBadge();
  mountSideMenu();
  initRouter();
  logBridgeStatus();
}

document.addEventListener("DOMContentLoaded", bootstrap);
