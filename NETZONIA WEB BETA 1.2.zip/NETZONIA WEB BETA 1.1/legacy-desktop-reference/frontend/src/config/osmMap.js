// ---------------------------------------------------------------------
// osmMap.js — carregamento sob demanda do Leaflet + busca de endereço
// via Nominatim (OpenStreetMap).
//
// O módulo de mapas é "offline-tolerante", mas não totalmente offline:
//   - a aplicação principal continua local;
//   - Leaflet é carregado sob demanda de CDNs públicos, com fallback;
//   - Nominatim é acessado pelo backend Go (rate-limit + timeout + UA);
//   - os tiles do mapa e o Overpass dependem de internet no momento do uso.
//
// A estratégia de múltiplos CDNs evita que uma indisponibilidade isolada
// do UNPKG derrube a tela inteira de mapas. Se todos falharem, a tela
// informa o problema sem afetar as 14 ferramentas de rede do Netzônia.
// ---------------------------------------------------------------------

import * as bridge from "../lib/wails-bridge.js";

const LEAFLET_VERSION = "1.9.4";
const LOAD_TIMEOUT_MS = 9000;

const LEAFLET_SOURCES = [
  {
    nome: "UNPKG",
    css: `https://unpkg.com/leaflet@${LEAFLET_VERSION}/dist/leaflet.css`,
    js: `https://unpkg.com/leaflet@${LEAFLET_VERSION}/dist/leaflet.js`,
    img: `https://unpkg.com/leaflet@${LEAFLET_VERSION}/dist/images/`,
  },
  {
    nome: "jsDelivr",
    css: `https://cdn.jsdelivr.net/npm/leaflet@${LEAFLET_VERSION}/dist/leaflet.css`,
    js: `https://cdn.jsdelivr.net/npm/leaflet@${LEAFLET_VERSION}/dist/leaflet.js`,
    img: `https://cdn.jsdelivr.net/npm/leaflet@${LEAFLET_VERSION}/dist/images/`,
  },
];

let loadingPromise = null;

function removeLeafletAssets() {
  document.querySelectorAll("[data-netzonia-leaflet]").forEach((node) => node.remove());
}

function loadLeafletSource(source) {
  return new Promise((resolve, reject) => {
    removeLeafletAssets();

    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = source.css;
    link.setAttribute("data-netzonia-leaflet", source.nome);
    document.head.appendChild(link);

    const script = document.createElement("script");
    script.src = source.js;
    script.async = true;
    script.setAttribute("data-netzonia-leaflet", source.nome);

    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(value);
    };

    const timer = setTimeout(() => {
      script.remove();
      link.remove();
      finish(reject, new Error(`${source.nome} excedeu o tempo de carregamento.`));
    }, LOAD_TIMEOUT_MS);

    script.onload = () => {
      const L = window.L;
      if (!L) {
        script.remove();
        link.remove();
        finish(reject, new Error(`${source.nome} carregou, mas o Leaflet não foi inicializado.`));
        return;
      }

      // Os ícones padrão usam caminhos relativos ao CSS. Como a biblioteca
      // está sendo carregada por CDN, fixamos explicitamente o mesmo provedor
      // que conseguiu carregar o Leaflet.
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: source.img + "marker-icon-2x.png",
        iconUrl: source.img + "marker-icon.png",
        shadowUrl: source.img + "marker-shadow.png",
      });
      finish(resolve, L);
    };

    script.onerror = () => {
      script.remove();
      link.remove();
      finish(reject, new Error(`Falha ao carregar Leaflet via ${source.nome}.`));
    };

    document.head.appendChild(script);
  });
}

/** Injeta CSS + JS do Leaflet, tentando provedores alternativos em sequência. */
export function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (loadingPromise) return loadingPromise;

  loadingPromise = (async () => {
    const erros = [];
    for (const source of LEAFLET_SOURCES) {
      try {
        return await loadLeafletSource(source);
      } catch (err) {
        erros.push(err?.message || String(err));
      }
    }

    removeLeafletAssets();
    console.warn("[NetZônia] Leaflet indisponível nos provedores configurados:", erros);
    throw new Error("Não foi possível carregar o mapa. Verifique sua conexão com a internet e tente novamente.");
  })().catch((err) => {
    loadingPromise = null;
    throw err;
  });

  return loadingPromise;
}

/**
 * Busca endereços/lugares via Nominatim. A requisição em si (header,
 * rate-limit de ~1/s, timeout) é feita pelo Go — ver geocodificacao.go.
 * @param {string} query
 * @returns {Promise<Array<{placeId:string, nome:string, endereco:string, lat:number, lng:number}>>}
 */
export async function searchAddress(query) {
  const q = query.trim();
  if (q.length < 3) return [];
  return bridge.buscarEndereco(q);
}
