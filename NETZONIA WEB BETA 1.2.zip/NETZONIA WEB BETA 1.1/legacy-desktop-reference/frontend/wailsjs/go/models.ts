export namespace main {
	
	export class AdapterResult {
	    raw: string;
	    linkInfo: string[];
	
	    static createFrom(source: any = {}) {
	        return new AdapterResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.raw = source["raw"];
	        this.linkInfo = source["linkInfo"];
	    }
	}
	export class CFTVResult {
	    bandaMbps: number;
	    storageTB: number;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new CFTVResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.bandaMbps = source["bandaMbps"];
	        this.storageTB = source["storageTB"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class CaboInfo {
	    id: string;
	    categoria: string;
	    limiteM: number;
	
	    static createFrom(source: any = {}) {
	        return new CaboInfo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.id = source["id"];
	        this.categoria = source["categoria"];
	        this.limiteM = source["limiteM"];
	    }
	}
	export class ConversaoResult {
	    entrada: number;
	    saida: number;
	    unidade: string;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new ConversaoResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.entrada = source["entrada"];
	        this.saida = source["saida"];
	        this.unidade = source["unidade"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class DNSItem {
	    servidor: string;
	    ipServidor: string;
	    tempoMs: number;
	    resultado: string;
	
	    static createFrom(source: any = {}) {
	        return new DNSItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.servidor = source["servidor"];
	        this.ipServidor = source["ipServidor"];
	        this.tempoMs = source["tempoMs"];
	        this.resultado = source["resultado"];
	    }
	}
	export class DNSResult {
	    hostname: string;
	    resultados: DNSItem[];
	
	    static createFrom(source: any = {}) {
	        return new DNSResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.hostname = source["hostname"];
	        this.resultados = this.convertValues(source["resultados"], DNSItem);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class Device {
	    ip: string;
	    mac: string;
	    fabricante: string;
	    hostname: string;
	    tipo: string;
	
	    static createFrom(source: any = {}) {
	        return new Device(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.ip = source["ip"];
	        this.mac = source["mac"];
	        this.fabricante = source["fabricante"];
	        this.hostname = source["hostname"];
	        this.tipo = source["tipo"];
	    }
	}
	export class DevicesResult {
	    subnet: string;
	    devices: Device[];
	
	    static createFrom(source: any = {}) {
	        return new DevicesResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.subnet = source["subnet"];
	        this.devices = this.convertValues(source["devices"], Device);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class EnderecoResultado {
	    placeId: string;
	    nome: string;
	    endereco: string;
	    lat: number;
	    lng: number;
	
	    static createFrom(source: any = {}) {
	        return new EnderecoResultado(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.placeId = source["placeId"];
	        this.nome = source["nome"];
	        this.endereco = source["endereco"];
	        this.lat = source["lat"];
	        this.lng = source["lng"];
	    }
	}
	export class IPConfigResult {
	    sucesso: boolean;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new IPConfigResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.sucesso = source["sucesso"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class IPInfo {
	    ip: string;
	    city: string;
	    region: string;
	    country: string;
	    org: string;
	    timezone: string;
	
	    static createFrom(source: any = {}) {
	        return new IPInfo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.ip = source["ip"];
	        this.city = source["city"];
	        this.region = source["region"];
	        this.country = source["country"];
	        this.org = source["org"];
	        this.timezone = source["timezone"];
	    }
	}
	export class IPv6Result {
	    ipv6Global: string;
	    conectividade: boolean;
	    dnsv6: boolean;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new IPv6Result(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.ipv6Global = source["ipv6Global"];
	        this.conectividade = source["conectividade"];
	        this.dnsv6 = source["dnsv6"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class InterfaceRede {
	    nome: string;
	    status: string;
	
	    static createFrom(source: any = {}) {
	        return new InterfaceRede(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.nome = source["nome"];
	        this.status = source["status"];
	    }
	}
	export class ItemOrcamento {
	    material: string;
	    quantidade: number;
	    unidade: string;
	
	    static createFrom(source: any = {}) {
	        return new ItemOrcamento(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.material = source["material"];
	        this.quantidade = source["quantidade"];
	        this.unidade = source["unidade"];
	    }
	}
	export class LANServerStatus {
	    url: string;
	    ativo: boolean;
	    porta: number;
	    aviso: string;
	
	    static createFrom(source: any = {}) {
	        return new LANServerStatus(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.url = source["url"];
	        this.ativo = source["ativo"];
	        this.porta = source["porta"];
	        this.aviso = source["aviso"];
	    }
	}
	export class LatencyResult {
	    host: string;
	    nome: string;
	    amostras: number[];
	    min: number;
	    max: number;
	    avg: number;
	    jitter: number;
	
	    static createFrom(source: any = {}) {
	        return new LatencyResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.host = source["host"];
	        this.nome = source["nome"];
	        this.amostras = source["amostras"];
	        this.min = source["min"];
	        this.max = source["max"];
	        this.avg = source["avg"];
	        this.jitter = source["jitter"];
	    }
	}
	export class MTUItem {
	    tamanho: number;
	    status: string;
	    ok: boolean;
	
	    static createFrom(source: any = {}) {
	        return new MTUItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.tamanho = source["tamanho"];
	        this.status = source["status"];
	        this.ok = source["ok"];
	    }
	}
	export class MTUResult {
	    host: string;
	    resultados: MTUItem[];
	    mtuMax: number;
	    tipoLink: string;
	    fragmentacao: boolean;
	
	    static createFrom(source: any = {}) {
	        return new MTUResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.host = source["host"];
	        this.resultados = this.convertValues(source["resultados"], MTUItem);
	        this.mtuMax = source["mtuMax"];
	        this.tipoLink = source["tipoLink"];
	        this.fragmentacao = source["fragmentacao"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class OpenPort {
	    porta: number;
	    servico: string;
	
	    static createFrom(source: any = {}) {
	        return new OpenPort(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.porta = source["porta"];
	        this.servico = source["servico"];
	    }
	}
	export class OrcamentoOpticoResult {
	    nivelRecebido: number;
	    atenuacaoTotal: number;
	    ok: boolean;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new OrcamentoOpticoResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.nivelRecebido = source["nivelRecebido"];
	        this.atenuacaoTotal = source["atenuacaoTotal"];
	        this.ok = source["ok"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class PPPoEResult {
	    sucesso: boolean;
	    mensagem: string;
	    codigo: number;
	
	    static createFrom(source: any = {}) {
	        return new PPPoEResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.sucesso = source["sucesso"];
	        this.mensagem = source["mensagem"];
	        this.codigo = source["codigo"];
	    }
	}
	export class PontoCabo {
	    x: number;
	    y: number;
	    z: number;
	
	    static createFrom(source: any = {}) {
	        return new PontoCabo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.x = source["x"];
	        this.y = source["y"];
	        this.z = source["z"];
	    }
	}
	export class PortScanResult {
	    host: string;
	    testadas: number;
	    abertas: OpenPort[];
	
	    static createFrom(source: any = {}) {
	        return new PortScanResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.host = source["host"];
	        this.testadas = source["testadas"];
	        this.abertas = this.convertValues(source["abertas"], OpenPort);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class ProjetoLocalResumo {
	    placeId: string;
	    endereco: string;
	    lat: number;
	    lng: number;
	
	    static createFrom(source: any = {}) {
	        return new ProjetoLocalResumo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.placeId = source["placeId"];
	        this.endereco = source["endereco"];
	        this.lat = source["lat"];
	        this.lng = source["lng"];
	    }
	}
	export class RepairStep {
	    desc: string;
	    ok: boolean;
	    output: string;
	
	    static createFrom(source: any = {}) {
	        return new RepairStep(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.desc = source["desc"];
	        this.ok = source["ok"];
	        this.output = source["output"];
	    }
	}
	export class RepairResult {
	    isAdmin: boolean;
	    steps: RepairStep[];
	
	    static createFrom(source: any = {}) {
	        return new RepairResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.isAdmin = source["isAdmin"];
	        this.steps = this.convertValues(source["steps"], RepairStep);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	
	export class ResultadoCabo {
	    distanciaM: number;
	    tipo: string;
	    excedeLimite: boolean;
	    pontoConsolidacaoSugerido: boolean;
	    alertaEMI: boolean;
	    emiAtenuado: boolean;
	    mensagem: string;
	
	    static createFrom(source: any = {}) {
	        return new ResultadoCabo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.distanciaM = source["distanciaM"];
	        this.tipo = source["tipo"];
	        this.excedeLimite = source["excedeLimite"];
	        this.pontoConsolidacaoSugerido = source["pontoConsolidacaoSugerido"];
	        this.alertaEMI = source["alertaEMI"];
	        this.emiAtenuado = source["emiAtenuado"];
	        this.mensagem = source["mensagem"];
	    }
	}
	export class RouterResult {
	    gateway: string;
	    opened: boolean;
	    message: string;
	
	    static createFrom(source: any = {}) {
	        return new RouterResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.gateway = source["gateway"];
	        this.opened = source["opened"];
	        this.message = source["message"];
	    }
	}
	export class SSHResult {
	    stdout: string;
	    stderr: string;
	    exitCode: number;
	
	    static createFrom(source: any = {}) {
	        return new SSHResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.stdout = source["stdout"];
	        this.stderr = source["stderr"];
	        this.exitCode = source["exitCode"];
	    }
	}
	export class SSLResult {
	    host: string;
	    diasRestantes: number;
	    emissor: string;
	    subject: string;
	    alertas: string[];
	    ok: boolean;
	
	    static createFrom(source: any = {}) {
	        return new SSLResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.host = source["host"];
	        this.diasRestantes = source["diasRestantes"];
	        this.emissor = source["emissor"];
	        this.subject = source["subject"];
	        this.alertas = source["alertas"];
	        this.ok = source["ok"];
	    }
	}
	export class SaveReportResult {
	    saved: boolean;
	    path: string;
	
	    static createFrom(source: any = {}) {
	        return new SaveReportResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.saved = source["saved"];
	        this.path = source["path"];
	    }
	}
	export class SpeedPart {
	    mbps: number;
	    bytes: number;
	    seconds: number;
	
	    static createFrom(source: any = {}) {
	        return new SpeedPart(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.mbps = source["mbps"];
	        this.bytes = source["bytes"];
	        this.seconds = source["seconds"];
	    }
	}
	export class SpeedResult {
	    download: SpeedPart;
	    upload: SpeedPart;
	
	    static createFrom(source: any = {}) {
	        return new SpeedResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.download = this.convertValues(source["download"], SpeedPart);
	        this.upload = this.convertValues(source["upload"], SpeedPart);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class SubnetVLSM {
	    rede: string;
	    mascara: string;
	    broadcast: string;
	    hosts: number;
	    hostsUsaveis: number;
	
	    static createFrom(source: any = {}) {
	        return new SubnetVLSM(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.rede = source["rede"];
	        this.mascara = source["mascara"];
	        this.broadcast = source["broadcast"];
	        this.hosts = source["hosts"];
	        this.hostsUsaveis = source["hostsUsaveis"];
	    }
	}
	export class TraceHop {
	    numero: number;
	    ip: string;
	    hostname: string;
	    latenciaMs?: number;
	
	    static createFrom(source: any = {}) {
	        return new TraceHop(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.numero = source["numero"];
	        this.ip = source["ip"];
	        this.hostname = source["hostname"];
	        this.latenciaMs = source["latenciaMs"];
	    }
	}
	export class TraceResult {
	    host: string;
	    hops: TraceHop[];
	
	    static createFrom(source: any = {}) {
	        return new TraceResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.host = source["host"];
	        this.hops = this.convertValues(source["hops"], TraceHop);
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class WatchdogStart {
	    started: boolean;
	
	    static createFrom(source: any = {}) {
	        return new WatchdogStart(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.started = source["started"];
	    }
	}
	export class WifiNetwork {
	    ssid: string;
	    sinal: string;
	    canal: string;
	    banda: string;
	
	    static createFrom(source: any = {}) {
	        return new WifiNetwork(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.ssid = source["ssid"];
	        this.sinal = source["sinal"];
	        this.canal = source["canal"];
	        this.banda = source["banda"];
	    }
	}
	export class WifiResult {
	    redes: WifiNetwork[];
	    ch24: Record<string, number>;
	    ch5: Record<string, number>;
	    recomendacao24: string;
	    recomendacao5: string;
	
	    static createFrom(source: any = {}) {
	        return new WifiResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.redes = this.convertValues(source["redes"], WifiNetwork);
	        this.ch24 = source["ch24"];
	        this.ch5 = source["ch5"];
	        this.recomendacao24 = source["recomendacao24"];
	        this.recomendacao5 = source["recomendacao5"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class ZonaRisco {
	    x: number;
	    y: number;
	    z: number;
	    raio: number;
	
	    static createFrom(source: any = {}) {
	        return new ZonaRisco(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.x = source["x"];
	        this.y = source["y"];
	        this.z = source["z"];
	        this.raio = source["raio"];
	    }
	}

}

