// ---------------------------------------------------------------------
// build.js — "build" deste frontend é só uma cópia de arquivos.
//
// Como não há bundler e os módulos ES nativos já são suportados pela
// webview do Wails, este script apenas copia index.html, src/ e assets/ para
// dist/, que é o diretório apontado por "frontend:dir" + "assetsDir"
// no wails.json (veja README.md).
//
// Uso: `npm run build` (chamado automaticamente pelo `wails build`
// via "frontend:build" no wails.json).
// ---------------------------------------------------------------------

import { cpSync, rmSync, existsSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const distDir = join(__dirname, "dist");

if (existsSync(distDir)) rmSync(distDir, { recursive: true, force: true });
mkdirSync(distDir, { recursive: true });

cpSync(join(__dirname, "index.html"), join(distDir, "index.html"));
cpSync(join(__dirname, "src"), join(distDir, "src"), { recursive: true });
cpSync(join(__dirname, "assets"), join(distDir, "assets"), { recursive: true });

// eslint-disable-next-line no-console
console.log("[NetZônia] Build concluído em ./dist");
