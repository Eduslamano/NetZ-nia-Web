# NetZônia — Frontend (Wails + Vanilla JS)

Frontend do toolkit de rede **NetZônia**, pronto para ser integrado a um
backend Go via [Wails v2](https://wails.io). O núcleo da interface não usa
bundler e os recursos visuais principais são locais. O módulo de mapas, porém,
depende de internet para geocodificação, tiles e consulta de edifícios; o
Leaflet é carregado sob demanda com fallback entre CDNs públicos.

## Estrutura de pastas

```
frontend/
├── index.html                  # shell da aplicação (header + <main> + modal/toast roots)
├── package.json                # só o script `build` (copia arquivos p/ dist/)
├── build.js                    # build "zero-dependência": copia index.html/src/assets → dist/
├── assets/
│   └── logo-netzonia.png       # logo fornecida (branca, fundo transparente)
└── src/
    ├── main.js                 # bootstrap: liga header (busca/sair) + inicia o router
    ├── router.js                # roteador por hash (#/  e  #/funcionalidade/:id)
    ├── lib/
    │   ├── wails-bridge.js      # ⭐ ÚNICO ponto de contato com window.go/window.runtime
    │   ├── dom.js                # helpers de criação de elementos (el, qs, qsa, clear...)
    │   └── format.js             # formatação de ms/Mbps/% e classificação de qualidade
    ├── data/
    │   ├── features.js           # config das 14 funcionalidades (fonte única de verdade)
    │   └── icons.js               # ícones SVG inline (sem dependência externa)
    ├── components/
    │   ├── featureCard.js         # cartão da grade inicial
    │   ├── exitModal.js            # modal "salvar relatório antes de sair?"
    │   ├── toast.js                 # notificações (ex.: "relatório salvo em...")
    │   └── resultBuilders.js        # tabela/stat-grid/badge/barra/console genéricos
    └── views/
        ├── homeView.js               # página inicial (título + grid de cards)
        └── featureView.js             # motor de detalhe (1 view genérica p/ as 14 features)
```

### Por que essa organização

- **`lib/wails-bridge.js` é a única porta de entrada para o Go.** Nenhum
  outro arquivo toca em `window.go` ou `window.runtime` diretamente. Isso
  significa que, para plugar o backend real, **só este arquivo precisa
  de atenção** — o resto da UI já está pronto.
- **`data/features.js` é a fonte única de verdade.** A home e a tela de
  detalhe são geradas a partir dessa lista. Adicionar uma 15ª ferramenta
  no futuro não exige tocar em HTML solto — só um novo item na lista +
  (se o formato do resultado for novo) uma entrada em `RESULT_RENDERERS`
  dentro de `featureView.js`.
- **`featureView.js` é um motor, não 14 arquivos repetidos.** O layout
  (cabeçalho, painel de entrada, área de resultado) é o mesmo para todas
  as funcionalidades; muda só o tipo de painel (`instant`, `host-input`,
  `watchdog`, `report`) e o "desenhista" do resultado.

## Como isso conecta com o `main.go` fornecido

Cada função pública do `wails-bridge.js` foi nomeada e modelada em cima
do comportamento real das funções do toolkit em `main.go`:

| Frontend (`wails-bridge.js`) | Espelha (`main.go`)                          | Método Go esperado (a expor via `wails.Bind`) |
|---|---|---|
| `testarVelocidade()`   | `testarVelocidade()`                | `App.TestarVelocidade()` |
| `listarDispositivos()` | `listarDispositivos()`              | `App.ListarDispositivos()` |
| `acessarRoteador()`    | `acessarRoteador()`                 | `App.AcessarRoteador()` |
| `repararConexao()`     | `repararConexao()`                  | `App.RepararConexao()` |
| `analisarWifi()`       | `analisarWifi()` / `parseWifi()`    | `App.AnalisarWifi()` |
| `testarLatencia(host)` | `testarLatencia()` / `testarLatenciaParaHost()` | `App.TestarLatencia(host string)` |
| `traceroute(host)`     | `tracerouteParaHost()`              | `App.Traceroute(host string)` |
| `scannerPortas(host)`  | `scanPortasHost()`                  | `App.ScannerPortas(host string)` |
| `infoAdaptador()`      | `infoAdaptador()`                   | `App.InfoAdaptador()` |
| `testeDNS(host)`       | `testeDNSParaHost()`                | `App.TesteDNS(hostname string)` |
| `iniciarWatchdog(...)` + eventos | `watchdogLoop()`           | `App.IniciarWatchdog(host string, intervalo int, limite int)` (emite eventos `watchdog:tick`) |
| `ipExterno()`          | `ipExterno()` / struct `IPInfo`     | `App.IPExterno()` |
| `testeMTU(host)`       | `testeMTUParaHost()`                | `App.TesteMTU(host string)` |
| `gerarRelatorioTXT()`  | `gerarRelatorioTXT()`               | `App.GerarRelatorioTXT()` (retorna o texto, sem gravar ainda) |
| `salvarRelatorioComo()`| `gerarRelatorioTXT()` (parte de I/O) | `App.SalvarRelatorioComo()` (usa `runtime.SaveFileDialog` + escreve o arquivo) |

Os formatos JSON exatos esperados por cada função (nomes de campo, tipos)
estão documentados em comentário logo acima de cada função em
`src/lib/wails-bridge.js`. Ajuste os `struct` do Go para retornar esses
campos (ou ajuste o `map*()` correspondente no bridge) — funciona nos
dois sentidos.

### Sobre o modal de saída e "salvar relatório onde eu quiser"

Por segurança, o Wails **não permite que o JavaScript da webview escreva
arquivos no disco livremente** — isso é proposital, a webview roda como
conteúdo semi-sandboxed, igual a uma aba de navegador comum. Não existe
`<input type="file">` nem API de disco no browser que resolva "salvar em
qualquer pasta que o usuário escolher" com segurança.

A forma correta (e é o que este frontend já assume) é:

1. O botão "Sim" do modal chama `App.SalvarRelatorioComo()` no Go.
2. O Go abre o diálogo nativo do SO com `runtime.SaveFileDialog(ctx, ...)`.
3. O Go escreve o arquivo no caminho escolhido (reaproveitando a lógica
   que já existe em `gerarRelatorioTXT()`).
4. O Go devolve `{ saved: true, path: "C:\...\relatorio.txt" }` ao JS.
5. O frontend mostra esse caminho num toast e só então fecha a janela
   (`window.runtime.Quit()`).

## Rodando sem o Wails (pré-visualização isolada do front)

Basta servir a pasta com qualquer servidor estático, por exemplo:

```bash
npx --yes serve frontend
# ou
python3 -m http.server --directory frontend 8080
```

Como `window.go` não existe fora do Wails, `wails-bridge.js` detecta isso
e usa dados simulados automaticamente (com um aviso no console), então
todas as 14 telas continuam navegáveis e visualmente completas mesmo sem
o Go rodando.

## Configuração sugerida no `wails.json` (raiz do projeto Go)

```jsonc
{
  "name": "netzonia",
  "outputfilename": "netzonia",
  "frontend:install": "npm install",
  "frontend:build": "npm run build",
  "frontend:dev:watcher": "",
  "frontend:dev:serverUrl": "auto",
  "wailsjsdir": "./frontend",
  "author": { "name": "" }
}
```

E no `main.go` (ou `app.go`), lembre de apontar os assets para
`frontend/dist` (gerado pelo `npm run build`) via `assetserver.Options{
Assets: os.DirFS("frontend/dist") }` — ou, se preferir pular o passo de
build, apontar direto para `frontend/` e remover o `npm run build` do
`frontend:build` (o app não usa nenhuma ferramenta que precise de bundling).
