package main

import (
	"net"
	"testing"
)

func mustCIDR(t *testing.T, cidr string) *net.IPNet {
	t.Helper()
	_, ipnet, err := net.ParseCIDR(cidr)
	if err != nil {
		t.Fatalf("ParseCIDR(%q): %v", cidr, err)
	}
	return ipnet
}

func TestIsUsableNeighborIPv4(t *testing.T) {
	ipnet := mustCIDR(t, "192.168.100.0/24")
	tests := []struct {
		ip   string
		want bool
	}{
		{"192.168.100.1", true},
		{"192.168.100.31", true},
		{"192.168.100.0", false},
		{"192.168.100.255", false},
		{"255.255.255.255", false},
		{"224.0.0.22", false},
		{"224.0.0.251", false},
		{"239.255.255.250", false},
		{"192.168.1.10", false},
		{"not-an-ip", false},
	}
	for _, tt := range tests {
		if got := isUsableNeighborIPv4(tt.ip, ipnet); got != tt.want {
			t.Errorf("isUsableNeighborIPv4(%q) = %v; want %v", tt.ip, got, tt.want)
		}
	}
}

func TestNormalizeARPType(t *testing.T) {
	tests := []struct {
		name string
		raw  string
		want string
	}{
		{"pt utf8 dinamico", "dinâmico", "Dinâmico"},
		{"pt utf8 estatico", "estático", "Estático"},
		{"en dynamic", "dynamic", "Dinâmico"},
		{"en static", "static", "Estático"},
		{"pt oem dinamico", string([]byte{'d', 'i', 'n', 0xa0, 'm', 'i', 'c', 'o'}), "Dinâmico"},
		{"pt oem estatico", string([]byte{'e', 's', 't', 0xa0, 't', 'i', 'c', 'o'}), "Estático"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := normalizeARPType(tt.raw); got != tt.want {
				t.Errorf("normalizeARPType(%q) = %q; want %q", tt.raw, got, tt.want)
			}
		})
	}
}
