# Roadmap

## Estado atual
Base P1–P10 estabilizada no Windows, com ferramentas de rede, Mapa 3D/planejador, persistência, orçamento, tratamento de erros/logs e testes Go selecionados. P11 organiza a documentação sem alterar o funcionamento. P12 traz correções e melhorias visuais/de usabilidade no Mapa 3D (ver CHANGELOG.md).

## Próximas evoluções
- Evolução do Mapa 3D pela equipe em branch/cópia posterior ao congelamento.
- Ampliar testes automatizados, especialmente frontend e integrações.
- Revisar bindings Wails após mudanças de métodos públicos.
- Testar em mais máquinas, adaptadores e redes.
- Decidir e formalizar política de suporte Linux/macOS.
- Padronizar diretórios de dados/logs se a equipe decidir fazê-lo, com migração segura.

## Visão futura
Instalador profissional, assinatura de código, versionamento/releases, licença definida, beta externo, suporte empresarial, possível expansão multiplataforma/mobile e modelo comercial. Esses itens não fazem parte da funcionalidade validada atual.
