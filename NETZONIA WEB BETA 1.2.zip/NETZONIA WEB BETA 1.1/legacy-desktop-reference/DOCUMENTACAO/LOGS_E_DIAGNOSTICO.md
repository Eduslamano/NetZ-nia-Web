# Logs e diagnóstico

O logger é inicializado no startup do Wails e fechado no shutdown. Falha no logger não impede a inicialização do aplicativo.

## Localização
No Windows: `%APPDATA%\Netzonia\logs\netzonia.log`.

## Níveis
`INFO`, `WARNING` e `ERROR`.

## Proteção
`sanitizeLogText` remove URLs, IPv4 e caminhos locais Windows/Unix, normaliza quebras de linha e limita o texto a 500 caracteres Unicode. O arquivo usa UTF-8 com BOM para leitura correta inclusive no Windows PowerShell 5.1.

## Repetição e tamanho
WARNING/ERROR idênticos são suprimidos dentro de uma janela de 10 segundos. Ao atingir aproximadamente 2 MiB, o arquivo é rotacionado para `.1`.

## Frontend
`RegistrarLog` permite à ponte JavaScript enviar falhas para o logger sem exibir o detalhe técnico ao usuário.

## Consulta
```powershell
Get-Content "$env:APPDATA\Netzonia\logs\netzonia.log" -Tail 30
```
