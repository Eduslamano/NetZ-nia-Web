# Segurança

## Implementado
- `validateHost` valida destinos usados por ferramentas de rede e rejeita caracteres/formatos perigosos.
- Testes automatizados cobrem hosts válidos e entradas com tentativa de injeção.
- Projetos sanitizam o identificador usado no nome do arquivo, reduzindo risco de path traversal.
- Orçamento sanitiza o nome sugerido do CSV.
- Logs removem URLs, IPv4 e caminhos locais antes de persistir detalhes.
- Arquivos de projeto/log/orçamento usam permissões restritivas quando suportadas pelo SO.
- Mocks de frontend não são fallback silencioso de produção.

## Privilégios
Algumas ações de reparo de rede precisam de privilégios administrativos. O aplicativo deve informar a necessidade em vez de assumir sucesso.

## Limites
Esses mecanismos reduzem riscos conhecidos, mas não significam que o software seja imune a falhas ou ataques. Scanner de portas e diagnósticos devem ser usados apenas em redes/alvos autorizados.
