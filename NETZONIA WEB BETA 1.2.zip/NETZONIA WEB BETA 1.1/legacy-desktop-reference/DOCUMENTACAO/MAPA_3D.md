# Mapa 3D

## Tecnologia atual
O módulo usa um motor próprio em **Canvas 2D** (`scene3d.js`) para criar uma visualização pseudo-3D. Não utiliza Three.js/WebGL nesta base.

## Recursos atuais
- Catálogo de racks e equipamentos de rede/energia.
- Equipamentos montáveis em rack e controle de unidades U.
- Portas padrão e ocupação associada aos cabos.
- Cabos UTP, blindados e fibra.
- Limite de 90 m para categorias metálicas na regra atual.
- Fibra tratada sem o limite metálico de 90 m e como imune a EMI.
- Zonas de risco EMI e detecção de cruzamento pelo segmento da rota.
- Remoção de rack com tratamento dos filhos/cabos relacionados.
- Persistência local de projetos.
- Geração/exportação de orçamento CSV.
- Busca de endereço, mapa e apoio por contorno externo quando online.
- Busca/filtro na própria biblioteca de equipamentos e cabos (por nome/categoria).
- Preview "fantasma" do equipamento seguindo o cursor antes de posicionar, com indicação visual de posição válida/inválida.
- Modo tela cheia, com botão de saída sempre visível.
- Equipamentos de parede (`mountingType: "wall"`) encaixam automaticamente na parede/contorno de prédio mais próximo, na altura de montagem típica de cada item, em vez de ficarem soltos no chão.

## Modelos visuais dos equipamentos
Cada tipo de equipamento tem uma dica visual (`shape`) usada pelo renderer (`scene3d.js` → `_drawShapeDetails`) para desenhar detalhes além da caixa colorida básica: trilhos de rack, fileira de portas, LEDs de status, antenas, etc. Alguns exemplos: `rack` (trilhos), `switch`/`patch-panel` (fileira de portas + LEDs), `switch-2row` (2 fileiras de jaques RJ45 metálicos, para o combo de 24 portas), `roteador` (4 antenas + LEDs), `ap-wifi` (antenas), `tomada` (moldura simples). Itens sem `shape` dedicado ficam como caixa lisa colorida.

## Orçamento
O frontend agrupa materiais/quantidades e o backend grava CSV com `;` e BOM UTF-8, deixando descrição detalhada, preço unitário e subtotal para preenchimento posterior.

## Limitações
A representação é um planejador visual, não um CAD/BIM ou simulador físico. Serviços cartográficos dependem de internet. Regras de cabeamento ajudam no planejamento, mas não substituem vistoria e projeto técnico profissional.

## Evoluções futuras possíveis
Modelagem 3D mais avançada, importação de plantas, cálculo inteligente de rotas/obstáculos, colaboração e recursos empresariais. Estes itens são roadmap, não funcionalidades atuais.
