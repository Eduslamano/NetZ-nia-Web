# Arquitetura do Netzônia

## Visão geral
O Netzônia separa apresentação e lógica. O frontend em HTML/CSS/JavaScript chama métodos Go através do runtime/bindings do Wails. O backend executa regras de negócio, comandos do sistema, I/O local e chamadas HTTP externas.

```mermaid
flowchart LR
 U[Usuário] --> F[Frontend HTML/CSS/JS]
 F --> W[Wails]
 W --> G[Backend Go]
 G --> OS[Sistema operacional / rede]
 G --> EXT[Serviços externos]
 G --> FS[Arquivos locais]
```

## Backend
`backend.go` concentra as ferramentas de rede; `security.go` valida destinos; `logging.go` registra diagnóstico; `geocodificacao.go` centraliza Nominatim; `projetos.go` persiste projetos; `orcamento.go` exporta CSV; `mapa3d.go` calcula rotas de cabo/EMI.

## Frontend
`frontend/src` contém views, componentes, ponte Wails e o planejador. O build é feito por `frontend/build.js` e gera `frontend/dist`.

## Comunicação Wails
Métodos públicos de `*App` são expostos ao frontend. A ponte `frontend/src/lib/wails-bridge.js` centraliza chamadas e tratamento de erros. Mocks só são permitidos explicitamente em pré-visualização com `?mock=1` e não substituem backend real ausente em produção.

## Persistência
Projetos locais são JSON sob o diretório de configuração do usuário em `netzonia/projetos`. O orçamento é salvo via diálogo nativo em CSV. Logs ficam em `Netzonia/logs`.

## Mapa 3D
O renderizador atual é um motor próprio em Canvas 2D com projeção visual pseudo-3D. O catálogo e as regras de racks, portas, cabos e EMI ficam no frontend, com cálculo de cabo também disponível no backend.

## Serviços externos
Nominatim, Leaflet por CDN, Overpass, tiles Esri, Cloudflare Speed, ipify, ipapi.co e ipwho.is aparecem na base atual. A indisponibilidade desses serviços deve degradar apenas os recursos dependentes deles.

## Testes
A suíte Go cobre regras críticas selecionadas. O frontend ainda não possui suíte automatizada própria.
