# Funcionalidades atuais

| Função | Entrada | Resultado / finalidade | Dependências e limitações |
|---|---|---|---|
| Testar Velocidade | nenhuma | download/upload | internet e Cloudflare Speed |
| Listar Dispositivos | rede local | IP/MAC/hostname/fabricante quando disponível | ARP/vizinhança local; respostas variam |
| Acessar Roteador | nenhuma | detecta gateway e abre painel | configuração local |
| Reparar Conexão | nenhuma | executa etapas de reparo | pode exigir administrador; varia por SO |
| Analisar Wi‑Fi | nenhuma | rede/AP, canal, sinal e recomendações | adaptador e utilitários do SO |
| Testar Latência | host | latência e jitter | host válido e conectividade |
| Gerar Relatório | dados acumulados | relatório TXT | dados obtidos durante uso |
| Traceroute | host | saltos até o destino | ICMP/rede/firewalls |
| Scanner de Portas | host | portas abertas dentre o conjunto testado | firewalls e política de rede |
| Info Adaptador | nenhuma | informações das interfaces | utilitários do SO |
| Teste DNS | hostname | consultas em servidores DNS | internet/rede e DNS |
| Watchdog | host/intervalo | monitoramento periódico | conectividade; roda até ser parado |
| IP Externo | nenhuma | IP público e geolocalização aproximada | ipify + provedores de geolocalização |
| Teste MTU | host | estimativa de MTU útil | comportamento de ping/fragmentação |
| Calculadora VLSM | bloco IPv4 + hosts | sub-redes, máscaras, broadcast e capacidade | valida capacidade total do bloco |
| Orçamento Óptico GPON/FTTH | potência, distância, atenuação, splitters | nível recebido e atenuação total | estimativa; limite de referência atual -27 dBm |
| Banda CFTV | resolução, FPS, câmeras, retenção, codec | banda e armazenamento estimados | estimativa dependente do bitrate real |
| Conversor Telecom | tipo + valor | dBm↔mW e Mbps↔MB/s | cálculo local |
| Terminal SSH | host, porta, usuário, senha, comando | saída e código remoto | TOFU para chave do host; inclui compatibilidade legada |
| Wake-on-LAN | MAC + broadcast | envio de Magic Packet | equipamento precisa suportar/configurar WoL |
| Ping Sonoro | host + intervalo | monitor contínuo com latência e alerta | execução oculta no Windows |
| Teste PPPoE | usuário, senha, perfil | resultado/código de discagem | Windows; requer ambiente PPPoE real |
| Servidor LAN | porta | servidor HTTP local + download de 100 MB | Firewall pode solicitar permissão |
| Gerador String Wi-Fi | SSID, senha, segurança | string WIFI para QR Code | senha não é registrada no relatório |
| Consulta SNMP | host, community, OID | resposta SNMP | requer snmpget/Net-SNMP ou cmdlet compatível |
| Validador SSL | host + porta | validade, emissor, subject e alertas | valida cadeia/hostname após inspeção TLS |
| Gerador de Senhas | tamanho + conjuntos | senha aleatória criptográfica | seleção sem viés de módulo |
| Atalhos do Windows | ferramenta | abre painéis administrativos | Windows |
| Configuração Rápida de IP | interface + DHCP/IPv4 | altera configuração de rede | Windows e privilégios administrativos |
| Prontidão IPv6 | nenhuma | IPv6 global, conectividade e DNS | depende da rede/provedor |
| Credenciais Seguras | nome + valor | salva/carrega valor protegido | DPAPI no Windows; outras plataformas não declaradas seguras |

## Mapa 3D / planejador
Permite construir uma representação visual de infraestrutura, inserir racks/equipamentos, ocupar unidades U, criar cabos entre portas, acompanhar ocupação de portas, trabalhar com cabos metálicos/blindados/fibra, sinalizar zonas EMI, salvar projetos locais e gerar orçamento CSV. Cabos metálicos usam limite de 90 m na regra atual; fibra é tratada separadamente e como imune a EMI. A detecção EMI considera a distância do segmento de cabo à zona de risco. A biblioteca de equipamentos tem busca/filtro por nome, mostra um preview do item antes de posicionar na planta, e a view pode ser aberta em tela cheia (com botão de saída sempre visível).

A busca de local pode usar geocodificação/mapa e contornos externos. O construtor manual continua sendo a alternativa quando esses serviços não estão disponíveis.

## Erros
Entradas de host são validadas. Erros técnicos são tratados pela ponte para não serem despejados diretamente ao usuário; detalhes de diagnóstico podem ser enviados ao logger.
