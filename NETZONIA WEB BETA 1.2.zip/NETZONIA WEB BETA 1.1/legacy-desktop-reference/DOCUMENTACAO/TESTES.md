# Testes

## Automatizados
Execute `go test ./...`.

- `backend_devices_test.go`: filtra IPv4 vizinho utilizável e normaliza tipo ARP.
- `geocodificacao_test.go`: mensagens amigáveis para DNS/timeout/erro genérico sem vazamento técnico.
- `logging_test.go`: sanitização de dados, UTF-8/truncamento e supressão de repetição.
- `mapa3d_emi_test.go`: cruzamento EMI por segmento, caso fora, raio padrão e ponto único.
- `orcamento_test.go`: sanitização do nome de arquivo.
- `security_test.go`: hosts válidos e bloqueio de entradas inválidas/tentativas de injeção.

Execute também `go vet ./...` para análise estática Go.

## Frontend
Nesta base não existe suíte automatizada JavaScript. O build `npm run build` e testes manuais continuam necessários.

## Checklist manual recomendado
Abrir o executável; testar as 14 ferramentas; testar entradas inválidas; testar operação sem internet; testar Mapa 3D manual; criar/remover rack/equipamentos/cabos; verificar portas/U; testar EMI; salvar/carregar projeto; exportar CSV; verificar log; testar busca de endereço online/offline.

## Resultado da base P1–P10
Segundo a validação realizada pela equipe antes da P11, `go test ./...` passou e `go vet ./...` terminou sem apontamentos no Windows. A P11 não modifica os testes nem o código funcional.
