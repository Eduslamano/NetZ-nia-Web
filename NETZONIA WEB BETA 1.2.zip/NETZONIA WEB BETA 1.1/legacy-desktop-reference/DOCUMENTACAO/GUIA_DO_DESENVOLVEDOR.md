# Guia do desenvolvedor

## Organização
Backend Go na raiz; frontend em `frontend/src`; build frontend em `frontend/dist`; bindings Wails em `frontend/wailsjs`; testes Go em `*_test.go`.

## Fluxo
UI → `wails-bridge.js` → método público `App` → lógica Go/OS/serviço → resultado → UI.

## Antes de alterar
Crie branch/cópia, preserve uma versão estável e limite cada mudança ao problema em questão.

## Validação mínima
```powershell
go test ./...
go vet ./...
wails build
```
E execute testes manuais da área alterada.

## Bindings
Métodos públicos adicionados ao `App` exigem regeneração/revisão dos bindings Wails. Nesta base, `RegistrarLog` existe no Go e é usado diretamente pela ponte via `window.go`, mas não aparece nos arquivos gerados `frontend/wailsjs/go/main/App.js/.d.ts`; isso deve ser revisado antes de depender desses módulos gerados.

## Frontend
Mocks só devem ser usados explicitamente em pré-visualização (`?mock=1`). Não transformar mocks em fallback de produção.

## Compatibilidade
Evite tratar todo sistema não-Windows como Linux. Se a expansão multiplataforma for priorizada, separe implementações por SO e teste cada plataforma real.
