# Pontos para revisão futura

Estes itens foram observados durante a auditoria da P11 e **não foram corrigidos**, pois a P11 não pode alterar código funcional.

1. `logAppError` existe em `logging.go`, mas não foi encontrada chamada em outros arquivos Go. O frontend usa `RegistrarLog`, portanto o logger continua funcional.
2. Há capitalização diferente entre `Netzonia/logs` e `netzonia/projetos`. No Windows isso tende a não diferenciar diretório por caixa, mas em sistemas case-sensitive pode gerar duas árvores.
3. `RegistrarLog` é método público de `*App` e é chamado por `wails-bridge.js`, porém não consta nos bindings gerados `frontend/wailsjs/go/main/App.js/.d.ts` presentes no ZIP. A ponte atual usa `window.go.main.App` diretamente, mas os bindings devem ser regenerados/revisados numa etapa técnica futura.
4. Não existe suíte automatizada JavaScript nesta base.
5. Não há implementação `darwin` dedicada; caminhos não-Windows usam lógica pensada principalmente para Linux em diversas funções. O teste experimental em macOS não equivale a suporte funcional completo.
6. O caminho Linux de reparo depende de utilitários como `resolvectl`/`nmcli`, cuja presença varia por distribuição.
7. IP externo/geolocalização depende de provedores públicos de terceiros; indisponibilidade/limites estão fora do controle do projeto.
8. O `README.md` original ainda era o template padrão Wails; foi substituído na P11 por documentação real do projeto.

Nenhum desses itens foi alterado na P11.
