# Guia do usuário

1. Abra o Netzônia pelo executável gerado pelo Wails.
2. Na tela principal, escolha uma ferramenta de diagnóstico ou o Mapa 3D.
3. Nas ferramentas com destino, informe host/IP válido e execute. Leia o resultado apresentado; falhas devem aparecer em linguagem amigável.
4. Para Mapa 3D, use Buscar Local quando houver internet ou entre diretamente no Construtor Manual.
5. Use o campo de busca da biblioteca para achar um equipamento/cabo rápido, ou navegue pelas categorias. Ao selecionar um item, uma silhueta acompanha o cursor mostrando onde ele vai encaixar antes do clique. Adicione racks/equipamentos, organize itens montáveis e crie conexões por cabo. Observe avisos de distância, portas e EMI.
6. Use o botão de tela cheia na barra de ferramentas para trabalhar com mais espaço; o botão de saída fica sempre visível no canto do canvas.
7. Salve o projeto local quando aplicável e carregue-o posteriormente pela lista de projetos.
8. Gere o orçamento para exportar os materiais/quantidades em CSV.
9. Gere relatório TXT das operações de rede quando necessário.

Algumas ações de reparo podem exigir execução com privilégios de administrador. Serviços de mapa e consultas externas podem ficar indisponíveis sem internet, mas isso não deve derrubar o aplicativo.
