# Dependências externas

## Serviços identificados
- Cloudflare Speed (`speed.cloudflare.com`): teste de velocidade.
- Nominatim/OpenStreetMap: busca e geocodificação reversa via Go.
- Leaflet 1.9.4: carregado sob demanda por UNPKG com fallback jsDelivr.
- Esri World Street Map: tiles do mapa.
- Overpass API: consulta de contorno/edificação.
- ipify: descoberta do IP público.
- ipapi.co: geolocalização de IP.
- ipwho.is: fallback de geolocalização.

## Sem internet
Busca de endereço, tiles, Overpass, teste de velocidade, IP externo/geolocalização e outros diagnósticos que dependam de destinos externos podem ficar indisponíveis. O frontend deve exibir mensagens amigáveis e manter o restante da aplicação utilizável.

## Offline/local
O construtor manual, regras do Mapa 3D, projetos locais, orçamento e operações estritamente locais não dependem dos serviços cartográficos para existir, embora determinadas ferramentas de rede ainda dependam da rede/sistema operacional.

## Disponibilidade
São serviços de terceiros; o projeto não controla disponibilidade, limites ou mudanças desses provedores.
