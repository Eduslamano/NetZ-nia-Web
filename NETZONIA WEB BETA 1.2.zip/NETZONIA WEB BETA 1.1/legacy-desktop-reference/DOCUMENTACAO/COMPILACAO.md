# Compilação

## Requisitos
- Go compatível com `go.mod` (base atual: 1.25).
- Node.js e npm.
- Wails CLI v2.
- Windows: WebView2 disponível.

## Validação
Na raiz:
```powershell
go test ./...
go vet ./...
```

## Frontend
```powershell
cd frontend
npm.cmd run build
cd ..
```
O `wails build` também executa o build configurado do frontend.

## Executável Windows
```powershell
wails build
```
Saída esperada: `build/bin/netzonia.exe`.

## Desenvolvimento
`wails dev` pode ser usado quando o ambiente estiver preparado. O frontend não depende de um servidor Vite próprio; `frontend:dev:serverUrl` está vazio no `wails.json`.

## Plataformas
Windows é a plataforma principal validada. Não assumir equivalência funcional de Linux/macOS: vários diagnósticos executam utilitários específicos do sistema e o caminho não-Windows atual não possui uma implementação macOS dedicada.
