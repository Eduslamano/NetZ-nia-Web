package main

import (
	"context"
	"errors"
	"net"
	"strings"
	"testing"
)

func TestErroNominatimAmigavelDNSNaoVazaDetalhes(t *testing.T) {
	err := &net.DNSError{Err: "no such host", Name: "nominatim.openstreetmap.org"}
	got := erroNominatimAmigavel(err)
	msg := got.Error()

	if !strings.Contains(strings.ToLower(msg), "sem conexão") {
		t.Fatalf("mensagem inesperada: %q", msg)
	}
	for _, detalhe := range []string{"no such host", "nominatim.openstreetmap.org"} {
		if strings.Contains(strings.ToLower(msg), strings.ToLower(detalhe)) {
			t.Fatalf("mensagem amigável vazou detalhe técnico %q: %q", detalhe, msg)
		}
	}
}

func TestErroNominatimAmigavelTimeout(t *testing.T) {
	got := erroNominatimAmigavel(context.DeadlineExceeded)
	if !strings.Contains(strings.ToLower(got.Error()), "demorou mais que o esperado") {
		t.Fatalf("mensagem de timeout inesperada: %q", got.Error())
	}
}

func TestErroNominatimAmigavelGenerico(t *testing.T) {
	got := erroNominatimAmigavel(errors.New("falha interna secreta"))
	if strings.Contains(got.Error(), "falha interna secreta") {
		t.Fatalf("erro genérico vazou detalhe interno: %q", got.Error())
	}
}
