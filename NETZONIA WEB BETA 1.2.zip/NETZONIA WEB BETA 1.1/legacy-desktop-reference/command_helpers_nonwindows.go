//go:build !windows

package main

import "os/exec"

func configureCommandNoWindow(cmd *exec.Cmd) {}
func decodeSystemOutput(data []byte) string  { return string(data) }
