package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

// -----------------------------------------------------------------------------
// GEOCODIFICAÇÃO (Nominatim / OpenStreetMap)
//
// Antes, a busca de endereço e o reverse geocoding do clique no mapa eram
// feitos direto no frontend (fetch), inclusive tentando setar o header
// User-Agent manualmente. Em um navegador/WebView, User-Agent é um header
// "forbidden" controlado pelo próprio navegador — o valor definido pelo
// JavaScript é ignorado silenciosamente. Como a política de uso do
// Nominatim exige um User-Agent identificável com contato, e limite de
// ~1 req/s, essas duas chamadas foram movidas para cá, onde o Go tem
// controle real do header, do timeout e do rate limit.
//
// O Overpass (footprint de prédios) e o Leaflet continuam no frontend —
// não há problema de header bloqueado nesses casos, e mover tudo para o
// Go sem necessidade fugiria do escopo desta correção.
// -----------------------------------------------------------------------------

const (
	nominatimSearchURL   = "https://nominatim.openstreetmap.org/search"
	nominatimReverseURL  = "https://nominatim.openstreetmap.org/reverse"
	nominatimUserAgent   = "Netzonia/1.0 (contato: suporte@netzonia.app)"
	nominatimMinInterval = 1100 * time.Millisecond
)

// EnderecoResultado é o formato já esperado pelo frontend (osmMap.js /
// placeSearchView.js): { placeId, nome, endereco, lat, lng }. Mantido
// idêntico ao que o fetch direto do frontend devolvia antes.
type EnderecoResultado struct {
	PlaceID  string  `json:"placeId"`
	Nome     string  `json:"nome"`
	Endereco string  `json:"endereco"`
	Lat      float64 `json:"lat"`
	Lng      float64 `json:"lng"`
}

type nominatimItem struct {
	OsmType     string `json:"osm_type"`
	OsmID       int64  `json:"osm_id"`
	DisplayName string `json:"display_name"`
	Lat         string `json:"lat"`
	Lon         string `json:"lon"`
}

var (
	nominatimMu          sync.Mutex
	nominatimLastRequest time.Time
	nominatimHTTPClient  = &http.Client{Timeout: 10 * time.Second}
)

// aguardaLimiteNominatim bloqueia até que ~1100ms tenham se passado desde a
// última requisição ao Nominatim, respeitando a política de uso (~1 req/s).
// Serializa também requisições concorrentes (busca + reverse), o que evita
// rajadas de cliques/digitação disparando chamadas em paralelo.
func aguardaLimiteNominatim() {
	nominatimMu.Lock()
	defer nominatimMu.Unlock()
	espera := nominatimMinInterval - time.Since(nominatimLastRequest)
	if espera > 0 {
		time.Sleep(espera)
	}
	nominatimLastRequest = time.Now()
}

// erroNominatimAmigavel converte falhas de transporte em mensagens seguras
// para a interface. O objetivo é não expor URLs, parâmetros HTTP, DNS interno
// ou mensagens cruas do sistema operacional ao usuário final.
func erroNominatimAmigavel(err error) error {
	if err == nil {
		return nil
	}

	if errors.Is(err, context.DeadlineExceeded) {
		return errors.New("A consulta de endereço demorou mais que o esperado. Verifique sua conexão e tente novamente.")
	}

	var dnsErr *net.DNSError
	if errors.As(err, &dnsErr) {
		return errors.New("Sem conexão com a internet. Conecte-se a uma rede e tente novamente.")
	}

	var netErr net.Error
	if errors.As(err, &netErr) {
		if netErr.Timeout() {
			return errors.New("A consulta de endereço demorou mais que o esperado. Verifique sua conexão e tente novamente.")
		}
		return errors.New("Não foi possível acessar o serviço de endereços. Verifique sua conexão com a internet e tente novamente.")
	}

	return errors.New("Não foi possível acessar o serviço de endereços. Verifique sua conexão com a internet e tente novamente.")
}

// nominatimRequest executa um GET identificado corretamente para o
// Nominatim, validando timeout e status HTTP antes de devolver o corpo cru.
func nominatimRequest(ctx context.Context, rawURL string) ([]byte, error) {
	aguardaLimiteNominatim()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return nil, errors.New("Não foi possível preparar a consulta de endereço.")
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", nominatimUserAgent)

	resp, err := nominatimHTTPClient.Do(req)
	if err != nil {
		return nil, erroNominatimAmigavel(err)
	}
	defer resp.Body.Close()

	if resp.StatusCode/100 != 2 {
		switch {
		case resp.StatusCode == http.StatusTooManyRequests:
			return nil, errors.New("O serviço de endereços está temporariamente ocupado. Aguarde alguns segundos e tente novamente.")
		case resp.StatusCode >= 500:
			return nil, errors.New("O serviço de endereços está temporariamente indisponível. Tente novamente em instantes.")
		default:
			return nil, errors.New("Não foi possível consultar o serviço de endereços no momento.")
		}
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, 2*1024*1024))
	if err != nil {
		return nil, errors.New("Não foi possível receber a resposta do serviço de endereços. Tente novamente.")
	}
	return body, nil
}

func primeiroSegmento(s string) string {
	if s == "" {
		return ""
	}
	if i := strings.Index(s, ","); i >= 0 {
		return s[:i]
	}
	return s
}

func parseCoordNominatim(s string, min, max float64) (float64, error) {
	v, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	if err != nil {
		return 0, errors.New("coordenada inválida retornada pelo serviço de endereços")
	}
	if err := validateFinite("coordenada", v, min, max); err != nil {
		return 0, err
	}
	return v, nil
}

// BuscarEndereco busca endereços/lugares via Nominatim (geocodificação
// direta). Usado pela tela "Buscar Local" (#/local) ao digitar um endereço.
// Mesma validação de tamanho mínimo (3 chars) que existia no frontend.
func (a *App) BuscarEndereco(query string) ([]EnderecoResultado, error) {
	q := strings.TrimSpace(query)
	if len([]rune(q)) < 3 {
		return []EnderecoResultado{}, nil
	}
	if len([]rune(q)) > 512 {
		return nil, errors.New("endereço de busca excede o tamanho máximo")
	}

	params := url.Values{}
	params.Set("format", "jsonv2")
	params.Set("addressdetails", "0")
	params.Set("limit", "6")
	params.Set("q", q)
	reqURL := nominatimSearchURL + "?" + params.Encode()

	if a.ctx == nil {
		return nil, errors.New("aplicação ainda não inicializada")
	}
	ctx, cancel := context.WithTimeout(a.ctx, 12*time.Second)
	defer cancel()

	body, err := nominatimRequest(ctx, reqURL)
	if err != nil {
		return nil, err
	}

	var items []nominatimItem
	if err := json.Unmarshal(body, &items); err != nil {
		return nil, errors.New("O serviço de endereços retornou uma resposta inválida. Tente novamente.")
	}

	resultados := make([]EnderecoResultado, 0, len(items))
	for _, item := range items {
		lat, err := parseCoordNominatim(item.Lat, -90, 90)
		if err != nil {
			continue
		}
		lng, err := parseCoordNominatim(item.Lon, -180, 180)
		if err != nil {
			continue
		}
		resultados = append(resultados, EnderecoResultado{
			PlaceID: fmt.Sprintf("osm_%s_%d", item.OsmType, item.OsmID), Nome: primeiroSegmento(item.DisplayName), Endereco: item.DisplayName, Lat: lat, Lng: lng,
		})
	}
	return resultados, nil
}

// GeocodificarReverso resolve um par lat/lng para um endereço (Nominatim
// reverse). Usado quando o usuário clica diretamente no mapa em
// placeSearchView.js.
func (a *App) GeocodificarReverso(lat, lng float64) (EnderecoResultado, error) {
	if err := validateFinite("latitude", lat, -90, 90); err != nil {
		return EnderecoResultado{}, err
	}
	if err := validateFinite("longitude", lng, -180, 180); err != nil {
		return EnderecoResultado{}, err
	}
	params := url.Values{}
	params.Set("format", "jsonv2")
	params.Set("lat", fmt.Sprintf("%f", lat))
	params.Set("lon", fmt.Sprintf("%f", lng))
	reqURL := nominatimReverseURL + "?" + params.Encode()

	if a.ctx == nil {
		return EnderecoResultado{}, errors.New("aplicação ainda não inicializada")
	}
	ctx, cancel := context.WithTimeout(a.ctx, 12*time.Second)
	defer cancel()

	body, err := nominatimRequest(ctx, reqURL)
	if err != nil {
		return EnderecoResultado{}, err
	}

	var item nominatimItem
	if err := json.Unmarshal(body, &item); err != nil {
		return EnderecoResultado{}, errors.New("O serviço de endereços retornou uma resposta inválida. Tente novamente.")
	}

	nome := primeiroSegmento(item.DisplayName)
	if nome == "" {
		nome = "Local selecionado"
	}
	endereco := item.DisplayName
	if endereco == "" {
		endereco = fmt.Sprintf("%.5f, %.5f", lat, lng)
	}

	return EnderecoResultado{
		PlaceID:  fmt.Sprintf("osm_%s_%d", item.OsmType, item.OsmID),
		Nome:     nome,
		Endereco: endereco,
		Lat:      lat,
		Lng:      lng,
	}, nil
}
