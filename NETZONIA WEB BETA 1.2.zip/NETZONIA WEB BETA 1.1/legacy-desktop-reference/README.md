# Netzônia 1.0.0 — Release Oficial

**Status:** versão estável Windows x64 consolidada na P22. As 31 funcionalidades e o Planejador/Mapa 3D foram congelados a partir da base P21 validada em Windows.

# Netzônia

Aplicação desktop para diagnóstico, administração, análise e planejamento de infraestrutura de redes. O projeto combina backend em Go, interface HTML/CSS/JavaScript e Wails v2 para integração desktop.

## Objetivo
Centralizar em uma única interface ferramentas que normalmente são usadas separadamente por técnicos de redes e acrescentar um planejador visual de infraestrutura.

## Funcionalidades atuais
- Teste de velocidade de download/upload.
- Descoberta de dispositivos da rede local.
- Acesso ao painel do roteador e reparo de conexão.
- Análise Wi‑Fi, latência/jitter, traceroute e scanner de portas.
- Informações de adaptadores, DNS, Watchdog, IP externo e MTU.
- Relatório TXT com registro das ferramentas executadas na sessão.
- VLSM, orçamento óptico GPON/FTTH, banda CFTV, conversões telecom, SSH, Wake-on-LAN, Ping Sonoro, PPPoE, servidor LAN, string Wi-Fi, SNMP, validação SSL, geração de senhas, atalhos Windows, configuração de IP, prontidão IPv6 e cofre de credenciais no Windows.
- Mapa 3D/planejador visual com racks, equipamentos, portas, unidades U, cabeamento, zonas EMI, projetos locais e orçamento CSV.
- Busca de endereço e mapa para apoiar o planejamento quando há internet.

## Arquitetura
`Frontend HTML/CSS/JS → ponte/bindings Wails → backend Go → sistema operacional/rede/serviços externos`.

O Mapa 3D atual usa um motor próprio de projeção em **Canvas 2D**; não é Three.js/WebGL.

## Tecnologias
Go 1.25 (conforme `go.mod`), Wails v2.15.0, HTML5, CSS3, JavaScript Vanilla e Node/npm para o build do frontend. No Windows, o Wails utiliza WebView2.

## Estrutura principal
- `backend.go`: ferramentas de rede.
- `mapa3d.go`: cálculo/validação de cabeamento e EMI.
- `projetos.go`: persistência de projetos locais.
- `orcamento.go`: exportação CSV.
- `geocodificacao.go`: Nominatim via backend.
- `logging.go`: logs e sanitização.
- `security.go`: validação de hosts.
- `frontend/`: interface e Mapa 3D.
- `*_test.go`: testes automatizados Go.
- `DOCUMENTACAO/`: documentação técnica e de uso.

## Compilação e validação
Na raiz do projeto:

```powershell
go test ./...
go vet ./...
wails build
```

O executável Windows é normalmente produzido em `build/bin/netzonia.exe`.

## Logs
No Windows, o log fica em `%APPDATA%\Netzonia\logs\netzonia.log`. O logger mascara URLs, IPv4 e caminhos locais e limita repetições de WARNING/ERROR idênticos.

## Online e offline
As ferramentas locais e o construtor manual não dependem integralmente do mapa. Busca de endereço, tiles, contornos externos e alguns diagnósticos que consultam serviços públicos dependem da internet. Consulte `DOCUMENTACAO/DEPENDENCIAS_EXTERNAS.md`.

## Segurança
Há validação de hosts antes de comandos de rede, sanitização de logs e permissões restritivas para arquivos locais. Algumas operações de reparo exigem privilégios administrativos.

## Plataformas
**Windows:** plataforma principal validada até o encerramento da P15.  
**Linux/macOS:** o código possui caminhos não-Windows e pode compilar em outros ambientes, mas as ferramentas de diagnóstico não devem ser declaradas como integralmente suportadas sem testes específicos por sistema.

## Testes
O projeto possui testes Go para segurança, logs, geocodificação, orçamento, dispositivos/ARP e EMI. Não há suíte automatizada de frontend nesta base.

## Roadmap
Aprimoramento do planejador 3D, ampliação de testes, empacotamento profissional, testes multiplataforma e preparação futura para uso empresarial/comercial. Recursos planejados não devem ser apresentados como implementados.

## Equipe
- Yuri Leal dos Santos — Backend, integração e testes.
- Saulo Pantoja — Backend e evolução do módulo Rede 3D.
- Enolla Coutinho — Frontend / Interface.
- Carlos Edu — Documentação e organização/publicação no GitHub.

## Contexto
Projeto acadêmico de Análise e Desenvolvimento de Sistemas em evolução para uma base tecnicamente mais madura.

## Licença
Licença ainda não definida pela equipe.
