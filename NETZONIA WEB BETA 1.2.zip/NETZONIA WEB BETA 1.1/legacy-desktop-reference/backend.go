package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// -----------------------------------------------------------------------------
// RELATÓRIO DA SESSÃO
// -----------------------------------------------------------------------------

var sessionReport = struct {
	sync.Mutex
	strings.Builder
}{}

func reportLog(format string, args ...any) {
	sessionReport.Lock()
	defer sessionReport.Unlock()
	if sessionReport.Len() == 0 {
		sessionReport.WriteString("NETZÔNIA - RELATÓRIO DE REDE\n")
		sessionReport.WriteString("Gerado em: " + time.Now().Format("02/01/2006 15:04:05") + "\n")
		sessionReport.WriteString(strings.Repeat("=", 56) + "\n\n")
	}
	sessionReport.WriteString(fmt.Sprintf(format, args...))
	sessionReport.WriteString("\n")
}

func reportText() string {
	sessionReport.Lock()
	defer sessionReport.Unlock()
	if sessionReport.Len() == 0 {
		return "NETZÔNIA - RELATÓRIO DE REDE\nGerado em: " + time.Now().Format("02/01/2006 15:04:05") + "\n\nNenhuma operação executada nesta sessão.\n"
	}
	return sessionReport.String()
}

// -----------------------------------------------------------------------------
// TIPOS QUE FORMAM O CONTRATO GO <-> FRONTEND
// -----------------------------------------------------------------------------

type SpeedPart struct {
	Mbps    float64 `json:"mbps"`
	Bytes   int64   `json:"bytes"`
	Seconds float64 `json:"seconds"`
}

type SpeedResult struct {
	Download SpeedPart `json:"download"`
	Upload   SpeedPart `json:"upload"`
}

type Device struct {
	IP         string `json:"ip"`
	MAC        string `json:"mac"`
	Fabricante string `json:"fabricante"`
	Hostname   string `json:"hostname"`
	Tipo       string `json:"tipo"`
}

type DevicesResult struct {
	Subnet  string   `json:"subnet"`
	Devices []Device `json:"devices"`
}

type RouterResult struct {
	Gateway string `json:"gateway"`
	Opened  bool   `json:"opened"`
	Message string `json:"message"`
}

type RepairStep struct {
	Desc   string `json:"desc"`
	OK     bool   `json:"ok"`
	Output string `json:"output"`
}

type RepairResult struct {
	IsAdmin bool         `json:"isAdmin"`
	Steps   []RepairStep `json:"steps"`
}

type WifiNetwork struct {
	SSID  string `json:"ssid"`
	Sinal string `json:"sinal"`
	Canal string `json:"canal"`
	Banda string `json:"banda"`
}

type WifiResult struct {
	Redes          []WifiNetwork  `json:"redes"`
	Ch24           map[string]int `json:"ch24"`
	Ch5            map[string]int `json:"ch5"`
	Recomendacao24 string         `json:"recomendacao24"`
	Recomendacao5  string         `json:"recomendacao5"`
}

type LatencyResult struct {
	Host     string    `json:"host"`
	Nome     string    `json:"nome"`
	Amostras []float64 `json:"amostras"`
	Min      float64   `json:"min"`
	Max      float64   `json:"max"`
	Avg      float64   `json:"avg"`
	Jitter   float64   `json:"jitter"`
}

type SaveReportResult struct {
	Saved bool   `json:"saved"`
	Path  string `json:"path"`
}

type TraceHop struct {
	Numero     int      `json:"numero"`
	IP         string   `json:"ip"`
	Hostname   string   `json:"hostname"`
	LatenciaMs *float64 `json:"latenciaMs"`
}

type TraceResult struct {
	Host string     `json:"host"`
	Hops []TraceHop `json:"hops"`
}

type OpenPort struct {
	Porta   int    `json:"porta"`
	Servico string `json:"servico"`
}

type PortScanResult struct {
	Host     string     `json:"host"`
	Testadas int        `json:"testadas"`
	Abertas  []OpenPort `json:"abertas"`
}

type AdapterResult struct {
	Raw      string   `json:"raw"`
	LinkInfo []string `json:"linkInfo"`
}

type DNSItem struct {
	Servidor   string `json:"servidor"`
	IPServidor string `json:"ipServidor"`
	TempoMs    int64  `json:"tempoMs"`
	Resultado  string `json:"resultado"`
}

type DNSResult struct {
	Hostname   string    `json:"hostname"`
	Resultados []DNSItem `json:"resultados"`
}

type WatchdogStart struct {
	Started bool `json:"started"`
}

type IPInfo struct {
	IP       string `json:"ip"`
	City     string `json:"city"`
	Region   string `json:"region"`
	Country  string `json:"country"`
	Org      string `json:"org"`
	Timezone string `json:"timezone"`
}

type MTUItem struct {
	Tamanho int    `json:"tamanho"`
	Status  string `json:"status"`
	OK      bool   `json:"ok"`
}

type MTUResult struct {
	Host         string    `json:"host"`
	Resultados   []MTUItem `json:"resultados"`
	MTUMax       int       `json:"mtuMax"`
	TipoLink     string    `json:"tipoLink"`
	Fragmentacao bool      `json:"fragmentacao"`
}

// -----------------------------------------------------------------------------
// 1) TESTE DE VELOCIDADE
// -----------------------------------------------------------------------------

type zeroReader struct{ remaining int64 }

func (z *zeroReader) Read(p []byte) (int, error) {
	if z.remaining <= 0 {
		return 0, io.EOF
	}
	if int64(len(p)) > z.remaining {
		p = p[:z.remaining]
	}
	clear(p)
	z.remaining -= int64(len(p))
	return len(p), nil
}

func (a *App) TestarVelocidade() (SpeedResult, error) {
	var result SpeedResult
	client := &http.Client{Timeout: 90 * time.Second}

	const dlBytes int64 = 25_000_000
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, fmt.Sprintf("https://speed.cloudflare.com/__down?bytes=%d", dlBytes), nil)
	if err != nil {
		return result, err
	}
	started := time.Now()
	resp, err := client.Do(req)
	if err != nil {
		return result, fmt.Errorf("falha no download de teste: %w", err)
	}
	if resp.Body != nil {
		defer resp.Body.Close()
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return result, fmt.Errorf("servidor de velocidade respondeu HTTP %d", resp.StatusCode)
	}
	n, err := io.Copy(io.Discard, resp.Body)
	if err != nil {
		return result, err
	}
	sec := time.Since(started).Seconds()
	result.Download = SpeedPart{Mbps: float64(n) * 8 / sec / 1e6, Bytes: n, Seconds: sec}

	const upBytes int64 = 10 * 1024 * 1024
	upCtx, upCancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer upCancel()
	upReq, err := http.NewRequestWithContext(upCtx, http.MethodPost, "https://speed.cloudflare.com/__up", &zeroReader{remaining: upBytes})
	if err != nil {
		return result, err
	}
	upReq.ContentLength = upBytes
	upReq.Header.Set("Content-Type", "application/octet-stream")
	started = time.Now()
	upResp, err := client.Do(upReq)
	if err != nil {
		return result, fmt.Errorf("falha no upload de teste: %w", err)
	}
	if upResp.Body != nil {
		defer upResp.Body.Close()
	}
	_, _ = io.Copy(io.Discard, upResp.Body)
	if upResp.StatusCode < 200 || upResp.StatusCode >= 300 {
		return result, fmt.Errorf("servidor de upload respondeu HTTP %d", upResp.StatusCode)
	}
	sec = time.Since(started).Seconds()
	result.Upload = SpeedPart{Mbps: float64(upBytes) * 8 / sec / 1e6, Bytes: upBytes, Seconds: sec}

	reportLog("[Velocidade] Download %.2f Mbps | Upload %.2f Mbps", result.Download.Mbps, result.Upload.Mbps)
	return result, nil
}

// -----------------------------------------------------------------------------
// UTILIDADES DE REDE
// -----------------------------------------------------------------------------

func detectLocalNetwork() (net.IP, *net.IPNet, error) {
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil, nil, err
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			ip, ipnet, err := net.ParseCIDR(addr.String())
			if err != nil || ip.To4() == nil {
				continue
			}
			if ip.IsLoopback() || ip.IsLinkLocalUnicast() {
				continue
			}
			return ip.To4(), ipnet, nil
		}
	}
	return nil, nil, errors.New("nenhuma interface IPv4 ativa encontrada")
}

func cidrString(ipnet *net.IPNet) string {
	ones, _ := ipnet.Mask.Size()
	return fmt.Sprintf("%s/%d", ipnet.IP.String(), ones)
}

func networkHosts(ipnet *net.IPNet, max int) ([]string, error) {
	ones, bits := ipnet.Mask.Size()
	if bits != 32 || ones < 24 {
		return nil, fmt.Errorf("rede %s muito grande para varredura automática nesta versão", cidrString(ipnet))
	}
	var hosts []string
	base := ipnet.IP.To4()
	if base == nil {
		return nil, errors.New("rede não IPv4")
	}
	// Para /24, /25 etc., enumera endereços válidos de host.
	total := 1 << uint(32-ones)
	if total > max+2 {
		total = max + 2
	}
	n := uint32(base[0])<<24 | uint32(base[1])<<16 | uint32(base[2])<<8 | uint32(base[3])
	for i := 1; i < total-1; i++ {
		v := n + uint32(i)
		hosts = append(hosts, fmt.Sprintf("%d.%d.%d.%d", byte(v>>24), byte(v>>16), byte(v>>8), byte(v)))
	}
	return hosts, nil
}

func runWithTimeout(timeout time.Duration, name string, args ...string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, name, args...)
	configureCommandNoWindow(cmd)
	return cmd.CombinedOutput()
}

func pingCommand(host string, count int, timeout time.Duration) *exec.Cmd {
	if runtime.GOOS == "windows" {
		ms := int(timeout.Milliseconds())
		return exec.Command("ping", "-n", strconv.Itoa(count), "-w", strconv.Itoa(ms), host)
	}
	sec := int(timeout.Seconds())
	if sec < 1 {
		sec = 1
	}
	return exec.Command("ping", "-c", strconv.Itoa(count), "-W", strconv.Itoa(sec), host)
}

var pingTimeRE = regexp.MustCompile(`(?i)(?:time|tempo)\s*[=<]\s*([0-9]+(?:[.,][0-9]+)?)\s*ms`)

func parsePingTimes(output string) []float64 {
	matches := pingTimeRE.FindAllStringSubmatch(output, -1)
	vals := make([]float64, 0, len(matches))
	for _, m := range matches {
		s := strings.ReplaceAll(m[1], ",", ".")
		v, err := strconv.ParseFloat(s, 64)
		if err == nil {
			if strings.Contains(strings.ToLower(m[0]), "<") && v == 1 {
				v = 0.5
			}
			vals = append(vals, v)
		}
	}
	return vals
}

func pingOnce(host string, timeout time.Duration) (float64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout+time.Second)
	defer cancel()
	cmd := pingCommand(host, 1, timeout)
	cmd = exec.CommandContext(ctx, cmd.Path, cmd.Args[1:]...)
	configureCommandNoWindow(cmd)
	out, err := cmd.CombinedOutput()
	vals := parsePingTimes(string(out))
	if len(vals) > 0 {
		return vals[0], nil
	}
	if err == nil {
		return 0, errors.New("host não retornou tempo de ping")
	}
	return 0, fmt.Errorf("host inacessível: %w", err)
}

func reverseName(ip string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 600*time.Millisecond)
	defer cancel()
	names, err := net.DefaultResolver.LookupAddr(ctx, ip)
	if err != nil || len(names) == 0 {
		return ""
	}
	return strings.TrimSuffix(names[0], ".")
}

var ouiDB = map[string]string{
	"00:50:56": "VMware", "00:0C:29": "VMware", "00:1A:11": "Google",
	"00:17:F2": "Apple", "3C:22:FB": "Apple", "DC:A6:32": "Raspberry Pi",
	"B8:27:EB": "Raspberry Pi", "50:3E:AA": "TP-Link", "B0:4E:26": "TP-Link",
	"EC:08:6B": "TP-Link", "00:1D:AA": "D-Link", "1C:7E:E5": "D-Link",
	"FC:FB:FB": "Cisco", "B4:FB:E4": "Cisco", "F8:1A:67": "Intelbras",
	"00:26:B9": "Dell", "18:03:73": "Dell", "00:1A:2B": "Samsung",
	"00:07:AB": "Samsung", "80:CE:62": "Huawei", "00:E0:FC": "Huawei",
	"00:15:5D": "Microsoft (Hyper-V)",
}

func vendorForMAC(mac string) string {
	mac = strings.ToUpper(strings.ReplaceAll(mac, "-", ":"))
	if len(mac) >= 8 {
		if v, ok := ouiDB[mac[:8]]; ok {
			return v
		}
	}
	return "Desconhecido"
}

// normalizeARPType evita que a saída localizada do arp.exe exponha texto em
// OEM/ANSI diretamente ao frontend. Em Windows PT-BR, por exemplo, "dinâmico"
// e "estático" podem chegar com bytes que não são UTF-8. Os prefixos ASCII são
// suficientes para classificar os dois estados sem depender da página de código.
func normalizeARPType(raw string) string {
	t := strings.ToLower(strings.TrimSpace(raw))
	switch {
	case strings.HasPrefix(t, "din"), strings.HasPrefix(t, "dyn"):
		return "Dinâmico"
	case strings.HasPrefix(t, "est"), strings.HasPrefix(t, "stat"):
		return "Estático"
	}

	clean := strings.TrimSpace(strings.ToValidUTF8(raw, ""))
	if clean == "" {
		return "Desconhecido"
	}
	return clean
}

// isUsableNeighborIPv4 mantém na lista apenas hosts IPv4 unicast da sub-rede
// local detectada. Isso remove rede/broadcast e entradas multicast que o Windows
// mantém na tabela ARP, mas que não representam dispositivos descobertos.
func isUsableNeighborIPv4(raw string, ipnet *net.IPNet) bool {
	ip := net.ParseIP(strings.TrimSpace(raw))
	if ip == nil || ip.To4() == nil {
		return false
	}
	ip = ip.To4()
	if ip.IsUnspecified() || ip.IsLoopback() || ip.IsMulticast() || ip.IsLinkLocalUnicast() {
		return false
	}
	if ipnet == nil || !ipnet.Contains(ip) {
		return false
	}

	network := ip.Mask(ipnet.Mask).To4()
	if network == nil {
		return false
	}
	broadcast := make(net.IP, net.IPv4len)
	for i := 0; i < net.IPv4len; i++ {
		broadcast[i] = network[i] | ^ipnet.Mask[i]
	}
	return !ip.Equal(network) && !ip.Equal(broadcast)
}

// -----------------------------------------------------------------------------
// 2) DISPOSITIVOS
// -----------------------------------------------------------------------------

func (a *App) ListarDispositivos() (DevicesResult, error) {
	var result DevicesResult
	_, ipnet, err := detectLocalNetwork()
	if err != nil {
		return result, err
	}
	result.Subnet = cidrString(ipnet)
	hosts, err := networkHosts(ipnet, 254)
	if err != nil {
		return result, err
	}

	sem := make(chan struct{}, 48)
	var wg sync.WaitGroup
	for _, host := range hosts {
		host := host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			cmd := pingCommand(host, 1, 350*time.Millisecond)
			ctx, cancel := context.WithTimeout(context.Background(), 900*time.Millisecond)
			defer cancel()
			probe := exec.CommandContext(ctx, cmd.Path, cmd.Args[1:]...)
			configureCommandNoWindow(probe)
			_ = probe.Run()
		}()
	}
	wg.Wait()

	devices := map[string]Device{}
	if runtime.GOOS == "windows" {
		arpCmd := exec.Command("arp", "-a")
		configureCommandNoWindow(arpCmd)
		out, err := arpCmd.CombinedOutput()
		if err != nil {
			return result, fmt.Errorf("arp -a: %w", err)
		}
		for _, line := range strings.Split(string(out), "\n") {
			f := strings.Fields(line)
			if len(f) < 3 || !isUsableNeighborIPv4(f[0], ipnet) {
				continue
			}
			if !strings.Contains(f[1], "-") && !strings.Contains(f[1], ":") {
				continue
			}
			typ := normalizeARPType(f[2])
			devices[f[0]] = Device{IP: f[0], MAC: f[1], Fabricante: vendorForMAC(f[1]), Tipo: typ}
		}
	} else {
		out, err := exec.Command("ip", "neigh", "show").CombinedOutput()
		if err != nil {
			return result, fmt.Errorf("ip neigh: %w", err)
		}
		for _, line := range strings.Split(string(out), "\n") {
			f := strings.Fields(line)
			if len(f) < 1 || !isUsableNeighborIPv4(f[0], ipnet) {
				continue
			}
			mac := ""
			for i := range f {
				if f[i] == "lladdr" && i+1 < len(f) {
					mac = f[i+1]
					break
				}
			}
			if mac == "" {
				continue
			}
			devices[f[0]] = Device{IP: f[0], MAC: mac, Fabricante: vendorForMAC(mac), Tipo: "Dinâmico"}
		}
	}

	list := make([]Device, 0, len(devices))
	for _, d := range devices {
		list = append(list, d)
	}
	sort.Slice(list, func(i, j int) bool { return bytesIPLess(list[i].IP, list[j].IP) })

	semNames := make(chan struct{}, 12)
	wg = sync.WaitGroup{}
	for i := range list {
		i := i
		wg.Add(1)
		go func() {
			defer wg.Done()
			semNames <- struct{}{}
			defer func() { <-semNames }()
			name := reverseName(list[i].IP)
			if name == "" {
				name = "[Desconhecido]"
			}
			list[i].Hostname = name
		}()
	}
	wg.Wait()
	result.Devices = list
	reportLog("[Dispositivos] Rede %s | %d dispositivo(s)", result.Subnet, len(list))
	return result, nil
}

func bytesIPLess(a, b string) bool {
	ia, ib := net.ParseIP(a).To4(), net.ParseIP(b).To4()
	if ia == nil || ib == nil {
		return a < b
	}
	for i := 0; i < 4; i++ {
		if ia[i] != ib[i] {
			return ia[i] < ib[i]
		}
	}
	return false
}

// -----------------------------------------------------------------------------
// 3) ROTEADOR
// -----------------------------------------------------------------------------

func defaultGateway() (string, error) {
	if runtime.GOOS == "windows" {
		routeCmd := exec.Command("route", "print", "0.0.0.0")
		configureCommandNoWindow(routeCmd)
		out, err := routeCmd.CombinedOutput()
		if err == nil {
			for _, line := range strings.Split(string(out), "\n") {
				f := strings.Fields(line)
				if len(f) >= 3 && f[0] == "0.0.0.0" && f[1] == "0.0.0.0" && net.ParseIP(f[2]) != nil {
					return f[2], nil
				}
			}
		}
		return "", errors.New("gateway padrão não encontrado")
	}
	out, err := exec.Command("ip", "route", "show", "default").CombinedOutput()
	if err != nil {
		return "", err
	}
	f := strings.Fields(string(out))
	for i := 0; i < len(f)-1; i++ {
		if f[i] == "via" && net.ParseIP(f[i+1]) != nil {
			return f[i+1], nil
		}
	}
	return "", errors.New("gateway padrão não encontrado")
}

func (a *App) AcessarRoteador() (RouterResult, error) {
	gw, err := defaultGateway()
	if err != nil {
		return RouterResult{}, err
	}
	url := "http://" + gw
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	} else {
		cmd = exec.Command("xdg-open", url)
	}
	err = cmd.Start()
	res := RouterResult{Gateway: gw, Opened: err == nil}
	if err != nil {
		res.Message = err.Error()
	} else {
		res.Message = "Painel aberto no navegador padrão."
	}
	reportLog("[Roteador] Gateway %s | aberto=%v", gw, res.Opened)
	return res, nil
}

// -----------------------------------------------------------------------------
// 4) REPARAR CONEXÃO
// -----------------------------------------------------------------------------

func adminStatus() bool {
	if runtime.GOOS == "windows" {
		fltmc := exec.Command("fltmc")
		configureCommandNoWindow(fltmc)
		if fltmc.Run() == nil {
			return true
		}
		netSession := exec.Command("net", "session")
		configureCommandNoWindow(netSession)
		return netSession.Run() == nil
	}
	// Evita syscall específico para manter o mesmo fonte compilável em Windows.
	out, err := exec.Command("id", "-u").Output()
	return err == nil && strings.TrimSpace(string(out)) == "0"
}

func commandStep(desc, cmd string, args ...string) RepairStep {
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	proc := exec.CommandContext(ctx, cmd, args...)
	configureCommandNoWindow(proc)
	out, err := proc.CombinedOutput()
	text := strings.TrimSpace(decodeSystemOutput(out))
	if ctx.Err() == context.DeadlineExceeded {
		err = errors.New("comando excedeu o tempo limite")
	}
	if len(text) > 500 {
		text = text[:500] + "..."
	}
	if text == "" && err != nil {
		text = err.Error()
	}
	return RepairStep{Desc: desc, OK: err == nil, Output: text}
}

func (a *App) RepararConexao() (RepairResult, error) {
	admin := adminStatus()
	res := RepairResult{IsAdmin: admin, Steps: []RepairStep{}}
	if !admin {
		return res, errors.New("a reparação de conexão exige privilégios de administrador/root")
	}
	if runtime.GOOS == "windows" {
		res.Steps = append(res.Steps,
			commandStep("Limpar cache DNS", "ipconfig", "/flushdns"),
			commandStep("Liberar IP atual", "ipconfig", "/release"),
			commandStep("Renovar IP via DHCP", "ipconfig", "/renew"),
			commandStep("Resetar Winsock", "netsh", "winsock", "reset"),
		)
	} else {
		// Em Linux, comandos variam por distribuição. Usamos os disponíveis sem
		// derrubar a interface inteira desnecessariamente.
		if _, err := exec.LookPath("resolvectl"); err == nil {
			res.Steps = append(res.Steps, commandStep("Limpar cache DNS", "resolvectl", "flush-caches"))
		} else {
			res.Steps = append(res.Steps, RepairStep{Desc: "Limpar cache DNS", OK: false, Output: "resolvectl não disponível"})
		}
		if _, err := exec.LookPath("nmcli"); err == nil {
			res.Steps = append(res.Steps, commandStep("Recarregar conexões NetworkManager", "nmcli", "connection", "reload"))
		} else {
			res.Steps = append(res.Steps, RepairStep{Desc: "Recarregar conexões", OK: false, Output: "nmcli não disponível"})
		}
	}
	reportLog("[Reparação] Sistema %s | etapas=%d", runtime.GOOS, len(res.Steps))
	return res, nil
}

// -----------------------------------------------------------------------------
// 5) WI-FI
// -----------------------------------------------------------------------------

func wifiBandFromChannel(ch int) string {
	if ch >= 1 && ch <= 14 {
		return "2.4 GHz"
	}
	if ch > 14 {
		return "5 GHz"
	}
	return ""
}

func parseWindowsWifi(out string) []WifiNetwork {
	var redes []WifiNetwork
	var ssid string
	var signal string
	scanner := bufio.NewScanner(strings.NewReader(out))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		low := strings.ToLower(line)
		if strings.HasPrefix(low, "ssid ") && !strings.HasPrefix(low, "bssid") {
			if p := strings.SplitN(line, ":", 2); len(p) == 2 {
				ssid = strings.TrimSpace(p[1])
				if ssid == "" {
					ssid = "[rede oculta]"
				}
			}
			continue
		}
		if strings.HasPrefix(low, "signal") || strings.HasPrefix(low, "sinal") {
			if p := strings.SplitN(line, ":", 2); len(p) == 2 {
				signal = strings.TrimSpace(p[1])
			}
		}
		if strings.HasPrefix(low, "channel") || strings.HasPrefix(low, "canal") {
			if p := strings.SplitN(line, ":", 2); len(p) == 2 {
				chs := strings.TrimSpace(p[1])
				ch, _ := strconv.Atoi(chs)
				redes = append(redes, WifiNetwork{SSID: ssid, Sinal: signal, Canal: chs, Banda: wifiBandFromChannel(ch)})
				signal = ""
			}
		}
	}
	return redes
}

func parseLinuxWifi(out string) []WifiNetwork {
	var redes []WifiNetwork
	for _, line := range strings.Split(strings.TrimSpace(out), "\n") {
		if strings.TrimSpace(line) == "" {
			continue
		}
		// nmcli -t escapa ':' como \:, então separar por ':' puro é imperfeito;
		// para a demo preservamos os quatro últimos campos via SplitN.
		parts := strings.Split(line, ":")
		if len(parts) < 4 {
			continue
		}
		freqStr := parts[len(parts)-1]
		chStr := parts[len(parts)-2]
		signal := parts[len(parts)-3]
		ssid := strings.Join(parts[:len(parts)-3], ":")
		ssid = strings.ReplaceAll(ssid, `\:`, `:`)
		if ssid == "" {
			ssid = "[rede oculta]"
		}
		freq, _ := strconv.Atoi(freqStr)
		band := "2.4 GHz"
		if freq >= 4900 {
			band = "5 GHz"
		}
		redes = append(redes, WifiNetwork{SSID: ssid, Sinal: signal + "%", Canal: chStr, Banda: band})
	}
	return redes
}

func recommendChannel(counts map[string]int, preferred []string) string {
	best, bestN := "", int(^uint(0)>>1)
	for _, ch := range preferred {
		n := counts[ch]
		if n == 0 {
			return "Canal " + ch + " (livre)"
		}
		if n < bestN {
			best, bestN = ch, n
		}
	}
	if best == "" {
		return ""
	}
	return "Canal " + best + " (menos congestionado)"
}

func (a *App) AnalisarWifi() (WifiResult, error) {
	var redes []WifiNetwork
	if runtime.GOOS == "windows" {
		wifiCmd := exec.Command("netsh", "wlan", "show", "networks", "mode=bssid")
		configureCommandNoWindow(wifiCmd)
		out, err := wifiCmd.CombinedOutput()
		if err != nil {
			return WifiResult{}, fmt.Errorf("netsh wlan: %w", err)
		}
		redes = parseWindowsWifi(string(out))
	} else {
		if _, err := exec.LookPath("nmcli"); err != nil {
			return WifiResult{}, errors.New("nmcli não está instalado; instale NetworkManager para análise Wi-Fi")
		}
		out, err := exec.Command("nmcli", "-t", "-f", "SSID,SIGNAL,CHAN,FREQ", "dev", "wifi", "list").CombinedOutput()
		if err != nil {
			return WifiResult{}, err
		}
		redes = parseLinuxWifi(string(out))
	}
	ch24 := map[string]int{}
	ch5 := map[string]int{}
	for _, r := range redes {
		if r.Banda == "2.4 GHz" {
			ch24[r.Canal]++
		} else if r.Banda == "5 GHz" {
			ch5[r.Canal]++
		}
	}
	res := WifiResult{Redes: redes, Ch24: ch24, Ch5: ch5, Recomendacao24: recommendChannel(ch24, []string{"1", "6", "11"}), Recomendacao5: recommendChannel(ch5, []string{"36", "40", "44", "48", "149", "153", "157", "161"})}
	reportLog("[Wi-Fi] %d AP/rede(s) detectado(s)", len(redes))
	return res, nil
}

// -----------------------------------------------------------------------------
// 6) LATÊNCIA
// -----------------------------------------------------------------------------

func calcLatency(name, host string) (LatencyResult, error) {
	cmd := pingCommand(host, 10, 2*time.Second)
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	cmd = exec.CommandContext(ctx, cmd.Path, cmd.Args[1:]...)
	configureCommandNoWindow(cmd)
	out, err := cmd.CombinedOutput()
	vals := parsePingTimes(string(out))
	if len(vals) == 0 {
		if err != nil {
			return LatencyResult{}, fmt.Errorf("ping %s: %w", host, err)
		}
		return LatencyResult{}, errors.New("nenhuma amostra de ping encontrada")
	}
	min, max, sum := vals[0], vals[0], 0.0
	for _, v := range vals {
		if v < min {
			min = v
		}
		if v > max {
			max = v
		}
		sum += v
	}
	avg := sum / float64(len(vals))
	jitter := 0.0
	if len(vals) > 1 {
		for i := 1; i < len(vals); i++ {
			d := vals[i] - vals[i-1]
			if d < 0 {
				d = -d
			}
			jitter += d
		}
		jitter /= float64(len(vals) - 1)
	}
	return LatencyResult{Host: host, Nome: name, Amostras: vals, Min: min, Max: max, Avg: avg, Jitter: jitter}, nil
}

func (a *App) TestarLatencia(host string) ([]LatencyResult, error) {
	var targets [][2]string
	if strings.TrimSpace(host) != "" {
		if err := validateHost(host); err != nil {
			return nil, err
		}
		targets = [][2]string{{host, host}}
	} else {
		gw, _ := defaultGateway()
		if gw != "" {
			targets = append(targets, [2]string{"Gateway", gw})
		}
		targets = append(targets, [2]string{"Google DNS", "8.8.8.8"}, [2]string{"Cloudflare", "1.1.1.1"})
	}
	out := make([]LatencyResult, 0, len(targets))
	for _, t := range targets {
		r, err := calcLatency(t[0], t[1])
		if err != nil {
			return nil, err
		}
		out = append(out, r)
		reportLog("[Latência] %s %s média %.1f ms jitter %.1f ms", r.Nome, r.Host, r.Avg, r.Jitter)
	}
	return out, nil
}

// -----------------------------------------------------------------------------
// 7) RELATÓRIO
// -----------------------------------------------------------------------------

func (a *App) GerarRelatorioTXT() string { return reportText() }

func (a *App) SalvarRelatorioComo() (SaveReportResult, error) {
	if a.ctx == nil {
		return SaveReportResult{}, errors.New("contexto do Wails ainda não inicializado")
	}
	defaultName := "relatorio_netzonia_" + time.Now().Format("20060102_150405") + ".txt"
	path, err := wailsruntime.SaveFileDialog(a.ctx, wailsruntime.SaveDialogOptions{Title: "Salvar relatório do Netzônia", DefaultFilename: defaultName, Filters: []wailsruntime.FileFilter{{DisplayName: "Arquivo de texto (*.txt)", Pattern: "*.txt"}}})
	if err != nil {
		return SaveReportResult{}, err
	}
	if path == "" {
		return SaveReportResult{Saved: false, Path: ""}, nil
	}
	if err := os.WriteFile(path, []byte(reportText()), 0o600); err != nil {
		return SaveReportResult{}, err
	}
	return SaveReportResult{Saved: true, Path: path}, nil
}

// -----------------------------------------------------------------------------
// 8) TRACEROUTE
// -----------------------------------------------------------------------------

var ipTokenRE = regexp.MustCompile(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)
var msTokenRE = regexp.MustCompile(`(?i)(?:<\s*)?([0-9]+(?:[.,][0-9]+)?)\s*ms`)

func parseTrace(out string) []TraceHop {
	var hops []TraceHop
	for _, line := range strings.Split(out, "\n") {
		f := strings.Fields(strings.TrimSpace(line))
		if len(f) < 2 {
			continue
		}
		n, err := strconv.Atoi(f[0])
		if err != nil || n <= 0 {
			continue
		}
		ip := "*"
		if m := ipTokenRE.FindString(line); m != "" {
			ip = m
		}
		var lat *float64
		if m := msTokenRE.FindStringSubmatch(line); len(m) > 1 {
			s := strings.ReplaceAll(m[1], ",", ".")
			v, _ := strconv.ParseFloat(s, 64)
			lat = &v
		}
		hostName := ""
		if ip != "*" {
			hostName = reverseName(ip)
		}
		hops = append(hops, TraceHop{Numero: n, IP: ip, Hostname: hostName, LatenciaMs: lat})
	}
	return hops
}

func (a *App) Traceroute(host string) (TraceResult, error) {
	host = strings.TrimSpace(host)
	if host == "" {
		return TraceResult{}, errors.New("destino obrigatório")
	}
	if err := validateHost(host); err != nil {
		return TraceResult{}, err
	}
	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.Command("tracert", "-d", "-w", "1000", "-h", "30", host)
	} else if p, err := exec.LookPath("traceroute"); err == nil {
		cmd = exec.Command(p, "-n", "-w", "1", "-m", "30", host)
	} else if p, err := exec.LookPath("tracepath"); err == nil {
		cmd = exec.Command(p, "-n", host)
	} else {
		return TraceResult{}, errors.New("traceroute/tracepath não está instalado")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)
	defer cancel()
	cmd = exec.CommandContext(ctx, cmd.Path, cmd.Args[1:]...)
	configureCommandNoWindow(cmd)
	out, err := cmd.CombinedOutput()
	if err != nil && len(out) == 0 {
		return TraceResult{}, err
	}
	hops := parseTrace(string(out))
	if len(hops) == 0 {
		return TraceResult{}, errors.New("nenhum hop pôde ser interpretado")
	}
	reportLog("[Traceroute] %s | %d hops", host, len(hops))
	return TraceResult{Host: host, Hops: hops}, nil
}

// -----------------------------------------------------------------------------
// 9) PORTAS TCP
// -----------------------------------------------------------------------------

var portNames = map[int]string{21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 9090: "Web", 11211: "Memcached", 27017: "MongoDB"}
var commonPorts = []int{21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 6379, 8080, 8443, 9090, 11211, 27017}

func (a *App) ScannerPortas(host string) (PortScanResult, error) {
	host = strings.TrimSpace(host)
	if host == "" {
		return PortScanResult{}, errors.New("host obrigatório")
	}
	if err := validateHost(host); err != nil {
		return PortScanResult{}, err
	}
	type item struct {
		p    int
		open bool
	}
	ch := make(chan item, len(commonPorts))
	sem := make(chan struct{}, 20)
	var wg sync.WaitGroup
	for _, p := range commonPorts {
		p := p
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			c, err := net.DialTimeout("tcp", net.JoinHostPort(host, strconv.Itoa(p)), 1200*time.Millisecond)
			if err == nil {
				c.Close()
				ch <- item{p, true}
			} else {
				ch <- item{p, false}
			}
		}()
	}
	wg.Wait()
	close(ch)
	var open []OpenPort
	for r := range ch {
		if r.open {
			open = append(open, OpenPort{Porta: r.p, Servico: portNames[r.p]})
		}
	}
	sort.Slice(open, func(i, j int) bool { return open[i].Porta < open[j].Porta })
	reportLog("[Portas] %s | %d abertas de %d", host, len(open), len(commonPorts))
	return PortScanResult{Host: host, Testadas: len(commonPorts), Abertas: open}, nil
}

// -----------------------------------------------------------------------------
// 10) ADAPTADORES
// -----------------------------------------------------------------------------

func (a *App) InfoAdaptador() (AdapterResult, error) {
	var res AdapterResult
	if runtime.GOOS == "windows" {
		// Força UTF-8 antes de executar utilitários localizados do Windows. Sem isso,
		// ipconfig/netsh podem escrever na página OEM (ex.: CP850) e o WebView
		// interpreta os bytes como UTF-8, produzindo textos como "Configura��o".
		cmdIP := exec.Command("ipconfig", "/all")
		configureCommandNoWindow(cmdIP)
		out, err := cmdIP.CombinedOutput()
		if err != nil {
			return res, err
		}
		res.Raw = decodeSystemOutput(out)
		cmdWi := exec.Command("netsh", "wlan", "show", "interfaces")
		configureCommandNoWindow(cmdWi)
		if wi, err := cmdWi.CombinedOutput(); err == nil {
			for _, line := range strings.Split(decodeSystemOutput(wi), "\n") {
				low := strings.ToLower(line)
				if strings.Contains(low, "ssid") || strings.Contains(low, "signal") || strings.Contains(low, "sinal") || strings.Contains(low, "rate") || strings.Contains(low, "velocidade") {
					t := strings.TrimSpace(line)
					if t != "" {
						res.LinkInfo = append(res.LinkInfo, t)
					}
				}
			}
		}
	} else {
		addr, err := exec.Command("ip", "addr", "show").CombinedOutput()
		if err != nil {
			return res, err
		}
		route, _ := exec.Command("ip", "route", "show").CombinedOutput()
		res.Raw = string(addr) + "\nRotas:\n" + string(route)
		if _, err := exec.LookPath("nmcli"); err == nil {
			if wi, err := exec.Command("nmcli", "-t", "-f", "GENERAL.DEVICE,GENERAL.CONNECTION,GENERAL.TYPE,GENERAL.STATE", "device", "show").CombinedOutput(); err == nil {
				for _, line := range strings.Split(strings.TrimSpace(string(wi)), "\n") {
					if line != "" {
						res.LinkInfo = append(res.LinkInfo, line)
					}
				}
			}
		}
	}
	reportLog("[Adaptadores] informações consultadas em %s", runtime.GOOS)
	return res, nil
}

// -----------------------------------------------------------------------------
// 11) DNS
// -----------------------------------------------------------------------------

func (a *App) TesteDNS(hostname string) (DNSResult, error) {
	hostname = strings.TrimSpace(hostname)
	if hostname == "" {
		hostname = "google.com"
	}
	if err := validateHost(hostname); err != nil {
		return DNSResult{}, err
	}
	servers := []struct{ name, ip string }{{"ISP Local (padrão)", ""}, {"Cloudflare", "1.1.1.1"}, {"Google", "8.8.8.8"}, {"OpenDNS", "208.67.222.222"}, {"Quad9", "9.9.9.9"}}
	res := DNSResult{Hostname: hostname}
	for _, s := range servers {
		resolver := net.DefaultResolver
		ipServer := "auto"
		if s.ip != "" {
			ipServer = s.ip
			d := net.Dialer{Timeout: 3 * time.Second}
			resolver = &net.Resolver{PreferGo: true, Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				return d.DialContext(ctx, network, net.JoinHostPort(s.ip, "53"))
			}}
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		start := time.Now()
		ips, err := resolver.LookupIPAddr(ctx, hostname)
		elapsed := time.Since(start).Milliseconds()
		cancel()
		item := DNSItem{Servidor: s.name, IPServidor: ipServer, TempoMs: elapsed}
		if err != nil {
			item.Resultado = "ERRO: " + err.Error()
		} else {
			parts := make([]string, 0, 3)
			for i, ip := range ips {
				if i >= 3 {
					break
				}
				parts = append(parts, ip.IP.String())
			}
			item.Resultado = strings.Join(parts, ", ")
		}
		res.Resultados = append(res.Resultados, item)
	}
	reportLog("[DNS] %s consultado em %d servidores", hostname, len(res.Resultados))
	return res, nil
}

// -----------------------------------------------------------------------------
// 12) WATCHDOG
// -----------------------------------------------------------------------------

func (a *App) IniciarWatchdog(host string, intervalSec int, limite int) (WatchdogStart, error) {
	host = strings.TrimSpace(host)
	if host == "" {
		host = "1.1.1.1"
	}
	if err := validateHost(host); err != nil {
		return WatchdogStart{}, err
	}
	if intervalSec < 1 || intervalSec > 3600 {
		return WatchdogStart{}, errors.New("intervalo deve estar entre 1 e 3600 segundos")
	}
	if limite < 0 || limite > 1000000 {
		return WatchdogStart{}, errors.New("limite de testes inválido")
	}
	if a.ctx == nil {
		return WatchdogStart{}, errors.New("aplicação ainda não inicializada")
	}
	a.watchdogMu.Lock()
	if a.watchdogCancel != nil {
		a.watchdogCancel()
	}
	ctx, cancel := context.WithCancel(context.Background())
	a.watchdogCancel = cancel
	a.watchdogMu.Unlock()
	go func() {
		total, quedas := 0, 0
		ticker := time.NewTicker(time.Duration(intervalSec) * time.Second)
		defer ticker.Stop()
		emit := func() bool {
			total++
			lat, err := pingOnce(host, 2*time.Second)
			ok := err == nil
			if !ok {
				quedas++
			}
			uptime := (1 - float64(quedas)/float64(total)) * 100
			payload := map[string]any{"timestamp": time.Now().Format(time.RFC3339Nano), "ok": ok, "latenciaMs": nil, "uptime": uptime, "total": total, "quedas": quedas, "host": host}
			if ok {
				payload["latenciaMs"] = lat
			}
			wailsruntime.EventsEmit(a.ctx, "watchdog:tick", payload)
			return limite > 0 && total >= limite
		}
		if emit() {
			return
		}
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				if emit() {
					return
				}
			}
		}
	}()
	reportLog("[Watchdog] iniciado para %s a cada %ds", host, intervalSec)
	return WatchdogStart{Started: true}, nil
}

func (a *App) PararWatchdog() {
	a.watchdogMu.Lock()
	defer a.watchdogMu.Unlock()
	if a.watchdogCancel != nil {
		a.watchdogCancel()
		a.watchdogCancel = nil
	}
	reportLog("[Watchdog] monitor interrompido")
}

// -----------------------------------------------------------------------------
// 13) IP EXTERNO
// -----------------------------------------------------------------------------

func fetchJSON(client *http.Client, endpoint string, target any) error {
	resp, err := client.Get(endpoint)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		return fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return json.NewDecoder(io.LimitReader(resp.Body, 2*1024*1024)).Decode(target)
}

func geolocateIP(client *http.Client, ip string) (IPInfo, error) {
	// Provedor principal. Os campos são mapeados explicitamente para não
	// depender de coincidência acidental entre nomes JSON e campos Go.
	var primary struct {
		IP       string `json:"ip"`
		City     string `json:"city"`
		Region   string `json:"region"`
		Country  string `json:"country_name"`
		Org      string `json:"org"`
		Timezone string `json:"timezone"`
		Error    bool   `json:"error"`
		Reason   string `json:"reason"`
	}
	if err := fetchJSON(client, "https://ipapi.co/"+url.PathEscape(ip)+"/json/", &primary); err == nil && !primary.Error {
		info := IPInfo{IP: ip, City: primary.City, Region: primary.Region, Country: primary.Country, Org: primary.Org, Timezone: primary.Timezone}
		if info.City != "" || info.Region != "" || info.Country != "" || info.Org != "" || info.Timezone != "" {
			return info, nil
		}
	}

	// Fallback sem chave. Isso evita que uma limitação temporária do ipapi.co
	// transforme a funcionalidade inteira em apenas um mostrador de IP.
	var fallback struct {
		Success bool   `json:"success"`
		Message string `json:"message"`
		City    string `json:"city"`
		Region  string `json:"region"`
		Country string `json:"country"`
		Conn    struct {
			ISP string `json:"isp"`
			Org string `json:"org"`
		} `json:"connection"`
		Timezone struct {
			ID string `json:"id"`
		} `json:"timezone"`
	}
	if err := fetchJSON(client, "https://ipwho.is/"+url.PathEscape(ip), &fallback); err != nil {
		return IPInfo{IP: ip}, fmt.Errorf("geolocalização indisponível: %w", err)
	}
	if !fallback.Success {
		return IPInfo{IP: ip}, fmt.Errorf("geolocalização indisponível: %s", fallback.Message)
	}
	org := fallback.Conn.Org
	if org == "" {
		org = fallback.Conn.ISP
	}
	return IPInfo{IP: ip, City: fallback.City, Region: fallback.Region, Country: fallback.Country, Org: org, Timezone: fallback.Timezone.ID}, nil
}

func (a *App) IPExterno() (IPInfo, error) {
	client := &http.Client{Timeout: 10 * time.Second}
	var pub struct {
		IP string `json:"ip"`
	}
	if err := fetchJSON(client, "https://api.ipify.org?format=json", &pub); err != nil {
		return IPInfo{}, fmt.Errorf("não foi possível obter o IP público: %w", err)
	}
	if net.ParseIP(pub.IP) == nil {
		return IPInfo{}, errors.New("IP público inválido")
	}
	info, err := geolocateIP(client, pub.IP)
	if err != nil {
		// O IP continua útil, mas o erro deixa claro ao frontend que os dados de
		// geolocalização não foram obtidos, em vez de exibir campos vazios como
		// se a operação tivesse sido totalmente bem-sucedida.
		return IPInfo{IP: pub.IP}, err
	}
	reportLog("[IP Externo] %s | %s/%s", info.IP, info.City, info.Country)
	return info, nil
}

// -----------------------------------------------------------------------------
// 14) MTU
// -----------------------------------------------------------------------------

func mtuPing(host string, payload int) (bool, error) {
	var args []string
	if runtime.GOOS == "windows" {
		args = []string{"-n", "1", "-w", "1800", "-f", "-l", strconv.Itoa(payload), host}
	} else {
		args = []string{"-c", "1", "-W", "2", "-M", "do", "-s", strconv.Itoa(payload), host}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	pingCmd := exec.CommandContext(ctx, "ping", args...)
	configureCommandNoWindow(pingCmd)
	out, err := pingCmd.CombinedOutput()
	text := strings.ToLower(strings.ToValidUTF8(string(out), ""))
	fragmentMarkers := []string{
		"fragment",
		"message too long",
		"packet needs to be fragmented",
		"needs to be fragmented",
		"precisa ser fragmentado",
		"precisa ser fragmentada",
	}
	for _, marker := range fragmentMarkers {
		if strings.Contains(text, marker) {
			return false, nil
		}
	}
	// Um ping bem-sucedido precisa trazer uma resposta real. Assim, timeout,
	// destino inalcançável e bloqueio de ICMP não são confundidos com MTU baixo.
	if err == nil && (strings.Contains(text, "ttl=") || strings.Contains(text, "ttl ")) {
		return true, nil
	}
	if err != nil {
		return false, fmt.Errorf("sonda MTU sem resposta (não é possível afirmar fragmentação): %w", err)
	}
	return false, errors.New("sonda MTU sem resposta reconhecível")
}

func mtuLinkType(mtu int) string {
	switch {
	case mtu >= 1500:
		return "Ethernet padrão (1500)"
	case mtu >= 1492:
		return "PPPoE — normal para links ADSL/fibra PPPoE"
	case mtu >= 1400:
		return "Possível VPN ou túnel"
	default:
		return "MTU baixo — verifique VPN/proxy/túnel"
	}
}

func (a *App) TesteMTU(host string) (MTUResult, error) {
	host = strings.TrimSpace(host)
	if host == "" {
		host = "8.8.8.8"
	}
	if err := validateHost(host); err != nil {
		return MTUResult{}, err
	}
	// Primeiro garante que o destino responde.
	if _, err := pingOnce(host, 2*time.Second); err != nil {
		return MTUResult{}, fmt.Errorf("destino não respondeu ao ping: %w", err)
	}
	low, high, best := 548, 1472, 0
	fragmented := false
	for low <= high {
		mid := (low + high) / 2
		ok, err := mtuPing(host, mid)
		if err != nil {
			return MTUResult{}, fmt.Errorf("falha ao medir MTU com pacote de %d bytes: %w", mid+28, err)
		}
		if ok {
			best = mid
			low = mid + 1
		} else {
			fragmented = true
			high = mid - 1
		}
	}
	if best == 0 {
		return MTUResult{}, errors.New("não foi possível determinar MTU")
	}
	mtu := best + 28
	probes := []int{1500, 1492, 1480, 1468, 1428, 1328, 1228}
	items := make([]MTUItem, 0, len(probes))
	for _, size := range probes {
		payload := size - 28
		ok, err := mtuPing(host, payload)
		status := "✓ sem fragmentação"
		if err != nil {
			status = "? sem resposta / inconclusivo"
			ok = false
		} else if !ok {
			status = "✗ fragmentação necessária"
		}
		items = append(items, MTUItem{Tamanho: size, Status: status, OK: ok})
	}
	res := MTUResult{Host: host, Resultados: items, MTUMax: mtu, TipoLink: mtuLinkType(mtu), Fragmentacao: fragmented}
	reportLog("[MTU] %s | máximo %d bytes", host, mtu)
	return res, nil
}
