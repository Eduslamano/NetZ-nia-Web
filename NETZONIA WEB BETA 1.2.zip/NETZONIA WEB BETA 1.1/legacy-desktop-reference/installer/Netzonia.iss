#define MyAppName "Netzônia"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Equipe Netzônia"
#define MyAppExeName "netzonia.exe"

[Setup]
AppId={{E2D77CF8-64D8-4A86-B2A3-C7C27C7F5D1B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Netzônia
DefaultGroupName=Netzônia
DisableProgramGroupPage=yes
OutputDir=output
OutputBaseFilename=Netzonia-Setup-{#MyAppVersion}
SetupIconFile=..\build\windows\icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes
CreateUninstallRegKey=yes
VersionInfoVersion=1.0.0.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=Instalador do Netzônia
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoCopyright=Copyright © 2026 Equipe Netzônia
MinVersion=10.0.17763

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"; GroupDescription: "Atalhos adicionais:"; Flags: unchecked

[Files]
Source: "..\build\bin\netzonia.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Netzônia"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#MyAppExeName}"
Name: "{commondesktop}\Netzônia"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Netzônia"; Flags: nowait postinstall skipifsilent

[Code]
function WebView2RuntimeLikelyPresent(): Boolean;
var
  Path: String;
begin
  Result := False;

  Path := ExpandConstant('{pf32}\Microsoft\EdgeWebView\Application');
  if DirExists(Path) then
  begin
    Result := True;
    Exit;
  end;

  Path := ExpandConstant('{localappdata}\Microsoft\EdgeWebView\Application');
  if DirExists(Path) then
  begin
    Result := True;
    Exit;
  end;
end;

function InitializeSetup(): Boolean;
var
  R: Integer;
begin
  Result := True;

  if not IsWin64 then
  begin
    MsgBox('O Netzônia requer Windows 64 bits.', mbCriticalError, MB_OK);
    Result := False;
    Exit;
  end;

  if not WebView2RuntimeLikelyPresent() then
  begin
    R := MsgBox(
      'O Microsoft Edge WebView2 Runtime não foi localizado.' + #13#10 + #13#10 +
      'O Netzônia utiliza WebView2 para exibir sua interface. Em instalações atuais do Windows 10/11 ele normalmente já está presente.' + #13#10 + #13#10 +
      'Você pode continuar a instalação, mas caso o Netzônia não abra, instale o Microsoft Edge WebView2 Runtime e execute o programa novamente.' + #13#10 + #13#10 +
      'Deseja continuar?',
      mbConfirmation, MB_YESNO);
    Result := (R = IDYES);
  end;
end;
