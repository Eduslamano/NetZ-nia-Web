@echo off
setlocal
cd /d "%~dp0"

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if not defined ISCC (
  echo.
  echo [ERRO] Inno Setup 6 nao foi encontrado neste computador.
  echo Instale o Inno Setup 6 e execute este arquivo novamente.
  echo Site oficial: https://jrsoftware.org/isdl.php
  echo.
  pause
  exit /b 1
)

if not exist "..\build\bin\netzonia.exe" (
  echo.
  echo [ERRO] build\bin\netzonia.exe nao foi encontrado.
  echo Execute "wails build" na raiz do projeto antes de compilar o instalador.
  echo.
  pause
  exit /b 2
)

echo [1/2] Compilando instalador do Netzonia...
"%ISCC%" "Netzonia.iss"
if errorlevel 1 (
  echo.
  echo [ERRO] A compilacao do instalador falhou.
  pause
  exit /b 3
)

echo.
echo [2/2] Concluido.
echo Instalador: %CD%\output\Netzonia-Setup-1.0.0.exe
start "" "%CD%\output"
pause
