NETZÔNIA — P21 EMPACOTAMENTO / INSTALADOR
=========================================

OBJETIVO
--------
Gerar um instalador profissional do Netzônia para Windows sem alterar as 31 funcionalidades,
o backend Wails ou o módulo de projeção/planejamento 3D.

ARQUIVOS
--------
Netzonia.iss               -> projeto do instalador Inno Setup 6
COMPILAR_INSTALADOR.bat    -> compilação automática no Windows
output/                     -> destino do instalador gerado

PRÉ-REQUISITOS PARA COMPILAR
----------------------------
1. Windows 10/11 64 bits.
2. O projeto P21 deve conter build\bin\netzonia.exe gerado e aprovado.
3. Inno Setup 6 instalado.

COMO GERAR
----------
1. Na raiz do projeto execute:
       wails build
2. Confirme que existe:
       build\bin\netzonia.exe
3. Abra a pasta installer.
4. Execute:
       COMPILAR_INSTALADOR.bat
5. O resultado será criado em:
       installer\output\Netzonia-Setup-0.9.0.exe

O QUE O INSTALADOR FAZ
----------------------
- Instala o Netzônia em Program Files\Netzônia.
- Cria entrada no Menu Iniciar.
- Oferece atalho opcional na Área de Trabalho.
- Registra o aplicativo no Windows e cria desinstalador.
- Preserva dados do usuário fora da pasta de instalação.
- Não força execução permanente como administrador.
- Não altera a lógica interna das 31 funcionalidades.
- Não altera o módulo 3D.
- Verifica arquitetura Windows x64.
- Avisa caso o WebView2 Runtime não seja encontrado nos diretórios usuais.

DADOS DO USUÁRIO
----------------
O desinstalador remove somente os arquivos instalados em Program Files.
Não há regra de exclusão de AppData, projetos, credenciais ou arquivos exportados do usuário.

VALIDAÇÃO DA P21
----------------
Depois de gerar o Setup, testar preferencialmente em outro Windows 64 bits:
1. Instalar.
2. Abrir pelo Menu Iniciar.
3. Confirmar Backend conectado.
4. Testar uma função de rede.
5. Testar Função 13.
6. Abrir o Planejador/Mapa 3D e carregar/salvar projeto.
7. Exportar CSV.
8. Fechar e abrir novamente.
9. Desinstalar pelo Windows.
10. Confirmar que o desinstalador não apagou projetos/dados pessoais.
