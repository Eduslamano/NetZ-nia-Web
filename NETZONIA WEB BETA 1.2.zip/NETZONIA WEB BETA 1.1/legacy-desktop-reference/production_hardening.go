package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const staleRuntimeTempAge = 24 * time.Hour

// atomicWriteFile grava estado persistente no mesmo diretório do destino e
// só o publica depois de flush bem-sucedido. Isso reduz a chance de arquivos
// internos parcialmente gravados após queda de energia/processo.
func atomicWriteFile(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}

	f, err := os.CreateTemp(dir, ".netzonia-write-*")
	if err != nil {
		return err
	}
	tempPath := f.Name()
	committed := false
	defer func() {
		_ = f.Close()
		if !committed {
			_ = os.Remove(tempPath)
		}
	}()

	if err := f.Chmod(perm); err != nil {
		return err
	}
	if _, err := f.Write(data); err != nil {
		return err
	}
	if err := f.Sync(); err != nil {
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	if err := os.Rename(tempPath, path); err != nil {
		return err
	}
	committed = true
	return nil
}

// prepareProductionRuntime realiza apenas manutenção segura e não bloqueante
// do ambiente local. Nenhuma funcionalidade de rede depende deste passo.
func prepareProductionRuntime() {
	cleanupStalePPPoETempFiles()
}

// cleanupStalePPPoETempFiles remove somente arquivos temporários com prefixo
// exclusivo do Netzônia que tenham sobrevivido a um encerramento anormal.
func cleanupStalePPPoETempFiles() {
	matches, err := filepath.Glob(filepath.Join(os.TempDir(), "netzonia-pppoe-*.pbk"))
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-staleRuntimeTempAge)
	for _, path := range matches {
		info, err := os.Stat(path)
		if err != nil || info.IsDir() || info.ModTime().After(cutoff) {
			continue
		}
		_ = os.Remove(path)
	}
}

// recordFatalRunError preserva uma pista mínima caso o Wails falhe antes de
// a interface conseguir iniciar. O texto passa pela mesma sanitização do log.
func recordFatalRunError(runErr error) {
	if runErr == nil {
		return
	}
	base, err := os.UserConfigDir()
	if err != nil || strings.TrimSpace(base) == "" {
		return
	}
	dir := filepath.Join(base, "Netzonia", "logs")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return
	}
	line := fmt.Sprintf("%s ERROR operacao=inicializacao detalhe=%s\n",
		time.Now().Format("2006-01-02 15:04:05"), sanitizeLogText(runErr.Error()))
	path := filepath.Join(dir, "netzonia_startup_error.log")
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(line)
	_ = f.Sync()
}

// ensureProductionStorageWritable é usado por testes/preflight para verificar
// se o diretório de configuração do usuário está disponível. Não cria fallback
// inseguro em diretórios temporários para dados persistentes.
func ensureProductionStorageWritable() error {
	base, err := os.UserConfigDir()
	if err != nil || strings.TrimSpace(base) == "" {
		return errors.New("diretório de configuração do usuário indisponível")
	}
	probeDir := filepath.Join(base, "Netzonia")
	if err := os.MkdirAll(probeDir, 0o700); err != nil {
		return fmt.Errorf("falha ao preparar diretório de configuração: %w", err)
	}
	return nil
}
