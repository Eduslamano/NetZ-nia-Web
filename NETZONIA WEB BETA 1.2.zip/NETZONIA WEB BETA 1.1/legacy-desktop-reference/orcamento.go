package main

import (
	"encoding/csv"
	"errors"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// -----------------------------------------------------------------------------
// ORÇAMENTO 3D
//
// O frontend (frontend/src/mapa3d/mapa3dView.js → gerarItensOrcamento) varre o
// grafo de cena, agrupa os equipamentos pelo nome do catálogo e soma o
// comprimento dos cabos por tipo. O Go só recebe esse array já pronto,
// abre o diálogo nativo de salvar do SO e grava a planilha.
//
// Formato: CSV (biblioteca padrão, sem dependência nova — funciona no
// build atual sem precisar rodar `go get`). Cada linha vem só com
// Material + Quantidade; Descrição Detalhada e Preço Unitário ficam em
// branco de propósito, pro cliente preencher depois, conforme o
// documento de especificação do Orçamento 3D.
//
// Upgrade futuro opcional: trocar por github.com/xuri/excelize/v2 pra
// gerar .xlsx com fórmula de subtotal (=Quantidade*Preço) já embutida.
// Isso exige rodar `go get github.com/xuri/excelize/v2` antes de
// buildar — não fiz essa troca agora porque não consigo baixar
// dependências novas neste ambiente pra garantir que compila.
// -----------------------------------------------------------------------------

// ItemOrcamento é uma linha do orçamento: a categoria do material e a
// quantidade exata de instâncias presentes na cena 3D.
type ItemOrcamento struct {
	Material   string  `json:"material"`
	Quantidade float64 `json:"quantidade"`
	Unidade    string  `json:"unidade"` // "un" (equipamento) ou "m" (cabo)
}

// ExportarOrcamento grava o CSV do orçamento e devolve o caminho salvo
// (string vazia se o usuário cancelar o diálogo — não é erro).
func (a *App) ExportarOrcamento(itens []ItemOrcamento, nomeProjeto string) (string, error) {
	if len(itens) == 0 {
		return "", errors.New("nenhum equipamento no mapa para gerar orçamento")
	}
	if len(itens) > 10000 {
		return "", errors.New("quantidade excessiva de itens no orçamento")
	}
	for _, item := range itens {
		if len([]rune(item.Material)) == 0 || len([]rune(item.Material)) > 512 {
			return "", errors.New("material do orçamento inválido")
		}
		if math.IsNaN(item.Quantidade) || math.IsInf(item.Quantidade, 0) || item.Quantidade < 0 || item.Quantidade > 1e9 {
			return "", errors.New("quantidade inválida no orçamento")
		}
		if len([]rune(item.Unidade)) > 32 {
			return "", errors.New("unidade do orçamento inválida")
		}
	}
	if a.ctx == nil {
		return "", errors.New("aplicação ainda não inicializada")
	}

	sugestao := "Orcamento_Netzonia.csv"
	if nome := strings.TrimSpace(nomeProjeto); nome != "" {
		sugestao = fmt.Sprintf("Orcamento_%s.csv", sanitizeNomeArquivo(nome))
	}

	caminho, err := wailsruntime.SaveFileDialog(a.ctx, wailsruntime.SaveDialogOptions{
		Title:           "Salvar orçamento",
		DefaultFilename: sugestao,
		Filters: []wailsruntime.FileFilter{
			{DisplayName: "Planilha CSV (*.csv)", Pattern: "*.csv"},
		},
	})
	if err != nil {
		return "", fmt.Errorf("falha ao abrir o diálogo de salvar: %w", err)
	}
	if caminho == "" {
		return "", nil // usuário cancelou
	}

	f, err := os.OpenFile(caminho, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return "", fmt.Errorf("falha ao criar o arquivo: %w", err)
	}
	defer f.Close()

	// BOM UTF-8 pra acentuação (ç, ã, é...) abrir certo direto no Excel
	if _, err := f.WriteString("\uFEFF"); err != nil {
		return "", fmt.Errorf("falha ao escrever o arquivo: %w", err)
	}

	w := csv.NewWriter(f)
	w.Comma = ';' // Excel em pt-BR espera ; como separador de campo por padrão

	_ = w.Write([]string{"Material", "Quantidade", "Unidade", "Descrição Detalhada", "Preço Unitário", "Subtotal"})
	for _, item := range itens {
		qtd := strconv.FormatFloat(item.Quantidade, 'f', -1, 64)
		_ = w.Write([]string{safeCSVCell(item.Material), qtd, safeCSVCell(item.Unidade), "", "", ""})
	}
	w.Flush()

	if err := w.Error(); err != nil {
		return "", fmt.Errorf("falha ao escrever o CSV: %w", err)
	}
	return caminho, nil
}

func sanitizeNomeArquivo(s string) string {
	return placeIDSanitizer.ReplaceAllString(s, "_")
}

// safeCSVCell neutraliza formula injection ao abrir CSV em Excel/LibreOffice.
func safeCSVCell(s string) string {
	t := strings.TrimLeft(s, " \t\r\n")
	if t != "" && strings.ContainsRune("=+-@", rune(t[0])) {
		return "'" + s
	}
	return s
}
