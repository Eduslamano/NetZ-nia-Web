package main

import (
	"strings"
	"testing"
	"time"
	"unicode/utf8"
)

func TestSanitizeLogTextMascaraDadosSensiveisEPreservaUTF8(t *testing.T) {
	entrada := `Netzônia conexão inválida em https://exemplo.com/api?q=1 IP 192.168.1.10 caminho C:\\Users\\Yuri\\segredo.txt`
	got := sanitizeLogText(entrada)

	if !utf8.ValidString(got) {
		t.Fatal("sanitizeLogText retornou texto UTF-8 inválido")
	}
	if !strings.Contains(got, "Netzônia") || !strings.Contains(got, "conexão inválida") {
		t.Fatalf("acentuação não foi preservada: %q", got)
	}
	for _, proibido := range []string{"https://exemplo.com", "192.168.1.10", `C:\\Users\\Yuri`} {
		if strings.Contains(got, proibido) {
			t.Fatalf("dado sensível não foi mascarado: %q", proibido)
		}
	}
	for _, marcador := range []string{"[URL_REMOVIDA]", "[IP_REMOVIDO]", "[CAMINHO_REMOVIDO]"} {
		if !strings.Contains(got, marcador) {
			t.Fatalf("marcador esperado ausente: %s em %q", marcador, got)
		}
	}
}

func TestSanitizeLogTextTruncaSemQuebrarRuneUTF8(t *testing.T) {
	entrada := strings.Repeat("á", 700)
	got := sanitizeLogText(entrada)
	if !utf8.ValidString(got) {
		t.Fatal("truncamento quebrou uma sequência UTF-8")
	}
	if utf8.RuneCountInString(got) != 501 { // 500 runes + reticências
		t.Fatalf("quantidade inesperada de runes após truncamento: %d", utf8.RuneCountInString(got))
	}
}

func TestShouldSuppressRepeatedLog(t *testing.T) {
	appLogRecent = make(map[string]time.Time)
	base := time.Unix(1000, 0)

	if shouldSuppressRepeatedLog("ERROR", "BuscarEndereco", "sem conexão", base) {
		t.Fatal("primeira ocorrência não deve ser suprimida")
	}
	if !shouldSuppressRepeatedLog("ERROR", "BuscarEndereco", "sem conexão", base.Add(2*time.Second)) {
		t.Fatal("repetição dentro da janela deveria ser suprimida")
	}
	if shouldSuppressRepeatedLog("ERROR", "BuscarEndereco", "sem conexão", base.Add(logRepeatWindow+time.Second)) {
		t.Fatal("ocorrência após a janela não deve ser suprimida")
	}
	if shouldSuppressRepeatedLog("INFO", "aplicacao", "iniciado", base.Add(2*time.Second)) {
		t.Fatal("INFO nunca deve ser suprimido")
	}
}
