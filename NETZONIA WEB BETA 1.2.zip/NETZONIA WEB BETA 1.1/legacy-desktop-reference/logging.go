package main

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

const (
	maxLogSize      int64 = 2 * 1024 * 1024 // 2 MiB
	logRepeatWindow       = 10 * time.Second
)

var (
	appLogMu     sync.Mutex
	appLogFile   *os.File
	appLogger    *log.Logger
	appLogRecent = make(map[string]time.Time)

	urlLogRE     = regexp.MustCompile(`(?i)https?://\S+`)
	ipv4LogRE    = regexp.MustCompile(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)
	winPathLogRE = regexp.MustCompile(`(?i)\b[A-Z]:\\[^\r\n]+`)
	unixHomeRE   = regexp.MustCompile(`/(?:Users|home)/[^/\s]+(?:/[^\s]*)?`)
)

// initAppLogger prepara um log local de diagnóstico. Falhas no logger nunca
// impedem a inicialização do Netzônia.
func initAppLogger() {
	appLogMu.Lock()
	defer appLogMu.Unlock()

	if appLogger != nil {
		return
	}

	baseDir, err := os.UserConfigDir()
	if err != nil || strings.TrimSpace(baseDir) == "" {
		return
	}

	logDir := filepath.Join(baseDir, "Netzonia", "logs")
	if err := os.MkdirAll(logDir, 0o700); err != nil {
		return
	}

	logPath := filepath.Join(logDir, "netzonia.log")
	rotateLogIfNeeded(logPath)
	ensureUTF8BOM(logPath)

	f, err := os.OpenFile(logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}

	appLogFile = f
	appLogger = log.New(f, "", log.Ldate|log.Ltime)
	appLogger.Printf("INFO operacao=aplicacao detalhe=%s", sanitizeLogText("Netzônia iniciado"))
}

// ensureUTF8BOM garante que leitores do Windows, inclusive Windows PowerShell
// 5.1, reconheçam o arquivo como UTF-8. Se já existir um log antigo sem BOM,
// ele é migrado preservando seu conteúdo.
func ensureUTF8BOM(path string) {
	const bom = "\xEF\xBB\xBF"

	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			_ = os.WriteFile(path, []byte(bom), 0o600)
		}
		return
	}
	if len(data) >= 3 && string(data[:3]) == bom {
		return
	}

	migrated := make([]byte, 0, len(data)+3)
	migrated = append(migrated, []byte(bom)...)
	migrated = append(migrated, data...)
	_ = os.WriteFile(path, migrated, 0o600)
}

func rotateLogIfNeeded(path string) {
	info, err := os.Stat(path)
	if err != nil || info.Size() < maxLogSize {
		return
	}
	_ = os.Remove(path + ".1")
	_ = os.Rename(path, path+".1")
}

func closeAppLogger() {
	appLogMu.Lock()
	defer appLogMu.Unlock()

	if appLogger != nil {
		appLogger.Printf("INFO operacao=aplicacao detalhe=%s", sanitizeLogText("Netzônia encerrado"))
	}
	if appLogFile != nil {
		_ = appLogFile.Close()
	}
	appLogFile = nil
	appLogger = nil
	appLogRecent = make(map[string]time.Time)
}

// sanitizeLogText reduz o risco de gravar no log URLs, IPs e caminhos locais.
// O log serve para diagnóstico do tipo de falha, não para armazenar dados da
// rede ou informações pessoais do computador.
func sanitizeLogText(value string) string {
	s := strings.TrimSpace(strings.ToValidUTF8(value, "�"))
	if s == "" {
		return "sem detalhes"
	}

	s = urlLogRE.ReplaceAllString(s, "[URL_REMOVIDA]")
	s = ipv4LogRE.ReplaceAllString(s, "[IP_REMOVIDO]")
	s = winPathLogRE.ReplaceAllString(s, "[CAMINHO_REMOVIDO]")
	s = unixHomeRE.ReplaceAllString(s, "[CAMINHO_REMOVIDO]")
	s = strings.NewReplacer("\r", " ", "\n", " ", "\t", " ").Replace(s)
	s = strings.Join(strings.Fields(s), " ")

	const maxRunes = 500
	if utf8.RuneCountInString(s) > maxRunes {
		r := []rune(s)
		s = string(r[:maxRunes]) + "…"
	}
	return s
}

func writeAppLog(level, operation, detail string) {
	appLogMu.Lock()
	defer appLogMu.Unlock()
	if appLogger == nil {
		return
	}

	level = strings.ToUpper(strings.TrimSpace(level))
	switch level {
	case "INFO", "WARNING", "ERROR":
	default:
		level = "INFO"
	}

	operation = sanitizeLogText(operation)
	detail = sanitizeLogText(detail)

	// Falhas automáticas podem ocorrer repetidamente enquanto o usuário digita
	// ou enquanto uma dependência externa está indisponível. Mantemos a primeira
	// ocorrência e suprimimos repetições idênticas por uma janela curta para o
	// arquivo continuar útil sem crescer com dezenas de linhas iguais.
	if shouldSuppressRepeatedLog(level, operation, detail, time.Now()) {
		return
	}

	appLogger.Printf("%s operacao=%s detalhe=%s", level, operation, detail)
}

// shouldSuppressRepeatedLog deve ser chamado com appLogMu já adquirido.
// INFO nunca é suprimido; WARNING/ERROR idênticos são limitados por janela.
func shouldSuppressRepeatedLog(level, operation, detail string, now time.Time) bool {
	if level != "ERROR" && level != "WARNING" {
		return false
	}

	key := level + "\x00" + operation + "\x00" + detail
	if last, ok := appLogRecent[key]; ok && now.Sub(last) < logRepeatWindow {
		return true
	}
	appLogRecent[key] = now

	for k, seen := range appLogRecent {
		if now.Sub(seen) > 5*logRepeatWindow {
			delete(appLogRecent, k)
		}
	}
	return false
}

func logAppError(operation string, err error) {
	if err == nil {
		return
	}
	writeAppLog("ERROR", operation, fmt.Sprintf("%T: %v", err, err))
}

// RegistrarLog é exposto ao frontend via Wails. Ele permite que a ponte JS
// registre falhas de chamadas sem exibir detalhes técnicos ao usuário.
func (a *App) RegistrarLog(nivel, operacao, detalhe string) {
	writeAppLog(nivel, operacao, detalhe)
}
