@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo NETZONIA 1.0.0 - GERACAO FINAL WINDOWS
echo ==========================================
echo.
echo [1/3] Build Wails 1.0.0...
wails build
if errorlevel 1 goto :errobuild

echo.
echo [2/3] Compilando instalador 1.0.0...
call "installer\COMPILAR_INSTALADOR.bat"
if errorlevel 1 goto :errosetup

echo.
echo [3/3] SHA-256...
certutil -hashfile "build\bin\netzonia.exe" SHA256
certutil -hashfile "installer\output\Netzonia-Setup-1.0.0.exe" SHA256

echo.
echo RELEASE 1.0.0 GERADA COM SUCESSO.
pause
exit /b 0
:errobuild
echo [ERRO] wails build falhou.
pause
exit /b 1
:errosetup
echo [ERRO] instalador 1.0.0 falhou.
pause
exit /b 2
