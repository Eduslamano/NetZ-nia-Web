package main

import "testing"

func TestValidateHostAceitaAlvosValidos(t *testing.T) {
	validos := []string{
		"8.8.8.8",
		"1.1.1.1",
		"localhost",
		"google.com",
		"sub.dominio-exemplo.com",
	}
	for _, host := range validos {
		if err := validateHost(host); err != nil {
			t.Errorf("validateHost(%q) retornou erro inesperado: %v", host, err)
		}
	}
}

func TestValidateHostBloqueiaEntradaInvalidaOuInjecao(t *testing.T) {
	invalidos := []string{
		"",
		"--help",
		"-n",
		"teste@@@",
		"google.com & whoami",
		"google.com;whoami",
		"google.com/path",
		"host com espaco",
	}
	for _, host := range invalidos {
		if err := validateHost(host); err == nil {
			t.Errorf("validateHost(%q) deveria rejeitar a entrada", host)
		}
	}
}
