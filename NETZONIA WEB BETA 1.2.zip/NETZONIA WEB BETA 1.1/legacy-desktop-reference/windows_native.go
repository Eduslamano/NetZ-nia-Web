//go:build windows

package main

import (
	"bytes"
	"fmt"
	"io"
	"os/exec"
	"syscall"
	"unsafe"

	"golang.org/x/text/encoding/charmap"
	"golang.org/x/text/transform"
)

type dataBlob struct {
	cbData uint32
	pbData *byte
}

var (
	crypt32                = syscall.NewLazyDLL("crypt32.dll")
	kernel32               = syscall.NewLazyDLL("kernel32.dll")
	user32                 = syscall.NewLazyDLL("user32.dll")
	procCryptProtectData   = crypt32.NewProc("CryptProtectData")
	procCryptUnprotectData = crypt32.NewProc("CryptUnprotectData")
	procLocalFree          = kernel32.NewProc("LocalFree")
	procMessageBeep        = user32.NewProc("MessageBeep")
)

const cryptProtectUIForbidden = 0x1

func bytesToBlob(data []byte) dataBlob {
	if len(data) == 0 {
		return dataBlob{}
	}

	return dataBlob{
		cbData: uint32(len(data)),
		pbData: &data[0],
	}
}

func blobToBytes(blob dataBlob) []byte {
	if blob.cbData == 0 || blob.pbData == nil {
		return []byte{}
	}

	data := unsafe.Slice(blob.pbData, int(blob.cbData))
	result := make([]byte, len(data))
	copy(result, data)

	return result
}

func dpapiEncrypt(data []byte) ([]byte, error) {
	input := bytesToBlob(data)
	var output dataBlob

	r1, _, err := procCryptProtectData.Call(
		uintptr(unsafe.Pointer(&input)),
		0,
		0,
		0,
		0,
		uintptr(cryptProtectUIForbidden),
		uintptr(unsafe.Pointer(&output)),
	)

	if r1 == 0 {
		return nil, fmt.Errorf("falha ao criptografar dados com DPAPI: %v", err)
	}

	defer procLocalFree.Call(uintptr(unsafe.Pointer(output.pbData)))

	return blobToBytes(output), nil
}

func dpapiDecrypt(data []byte) ([]byte, error) {
	input := bytesToBlob(data)
	var output dataBlob

	r1, _, err := procCryptUnprotectData.Call(
		uintptr(unsafe.Pointer(&input)),
		0,
		0,
		0,
		0,
		uintptr(cryptProtectUIForbidden),
		uintptr(unsafe.Pointer(&output)),
	)

	if r1 == 0 {
		return nil, fmt.Errorf("falha ao descriptografar dados com DPAPI: %v", err)
	}

	defer procLocalFree.Call(uintptr(unsafe.Pointer(output.pbData)))

	return blobToBytes(output), nil
}

func systemBeep() {
	procMessageBeep.Call(0xFFFFFFFF)
}

func configureCommandNoWindow(cmd *exec.Cmd) {
	if cmd == nil {
		return
	}
	// HideWindow sozinho pode ainda permitir que alguns executáveis de console
	// (como ping.exe) criem uma janela visível durante a execução quando o
	// Netzônia é compilado como aplicação GUI. CREATE_NO_WINDOW impede a criação
	// da janela de console do processo filho; HideWindow permanece como camada
	// adicional para utilitários que respeitam STARTUPINFO.
	const createNoWindow = 0x08000000
	cmd.SysProcAttr = &syscall.SysProcAttr{
		HideWindow:    true,
		CreationFlags: createNoWindow,
	}
}

func decodeSystemOutput(data []byte) string {
	if len(data) == 0 {
		return ""
	}
	r := transform.NewReader(bytes.NewReader(data), charmap.CodePage850.NewDecoder())
	decoded, err := io.ReadAll(r)
	if err == nil {
		return string(decoded)
	}
	return string(data)
}
