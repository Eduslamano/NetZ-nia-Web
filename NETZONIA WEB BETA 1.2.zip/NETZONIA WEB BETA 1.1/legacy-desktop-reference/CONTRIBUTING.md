# Contribuindo com o Netzônia

1. Trabalhe a partir da base/branch indicada pela equipe.
2. Faça uma mudança por objetivo e evite refatorações não relacionadas.
3. Não altere dependências sem decisão da equipe.
4. Para mudanças Go, execute `gofmt`, `go test ./...` e `go vet ./...`.
5. Para mudanças frontend, execute `npm run build` e teste a funcionalidade no Wails.
6. Para mudanças em métodos públicos do `App`, regenere/revise bindings.
7. Documente limitações e não declare suporte sem teste real.
8. Não publique dados de rede, logs pessoais, credenciais ou arquivos locais de usuários.

Pull requests/commits devem explicar problema, mudança, arquivos afetados e testes executados.
