package main

import (
	"fmt"
	"math"
)

// -----------------------------------------------------------------------------
// MAPA 3D — MOTOR DE VALIDAÇÃO DE INFRAESTRUTURA
//
// Espelha, no lado Go, as mesmas regras já documentadas em
// Equipamentos_Rede_Netzonia.txt e no PDF de arquitetura (ABNT NBR 14565 /
// EIA-TIA): limite de 90m no enlace permanente e alerta de EMI quando um
// cabo metálico cruza uma "Zona de Risco".
//
// Consumido pelo frontend via frontend/src/lib/wails-bridge.js →
// calcularCabo(pontos, tipo, zonas), chamado sempre que o usuário conecta
// dois equipamentos no Mapa 3D (frontend/src/mapa3d/mapa3dView.js).
// -----------------------------------------------------------------------------

// LimiteCanalMetalicoM é o limite de distância do canal para cabeamento
// metálico (90m de enlace permanente + 10m de patch cords = 100m de canal;
// aqui validamos o trecho desenhado no mapa contra o enlace permanente).
const LimiteCanalMetalicoM = 90.0

// RaioZonaRiscoPadraoM é o raio (em metros) usado quando uma Zona de Risco
// EMI não especifica um raio próprio.
const RaioZonaRiscoPadraoM = 1.2

// PontoCabo é um ponto 3D (metros) de um trecho de cabo já roteado de forma
// ortogonal pelo frontend (sem diagonais atravessando paredes/piso).
type PontoCabo struct {
	X float64 `json:"x"`
	Y float64 `json:"y"`
	Z float64 `json:"z"`
}

// CaboInfo descreve o meio físico escolhido no frontend
// (frontend/src/mapa3d/equipmentCatalog.js → CABLE_TYPES). Categoria
// controla a regra de validação:
//
//	"nao-blindado" → limite estrito de 90m; EMI gera alerta forte
//	"blindado"     → mesmo limite de 90m; a blindagem ATENUA o alerta de EMI
//	"fibra"        → imune a EMI; sem limite de 90m (LimiteM = 0)
type CaboInfo struct {
	ID        string  `json:"id"`
	Categoria string  `json:"categoria"`
	LimiteM   float64 `json:"limiteM"` // 0 = sem limite
}

// ZonaRisco representa um marcador de EMI (poço de elevador, motor, gerador)
// desenhado no mapa.
type ZonaRisco struct {
	X    float64 `json:"x"`
	Y    float64 `json:"y"`
	Z    float64 `json:"z"`
	Raio float64 `json:"raio"`
}

// ResultadoCabo é devolvido ao frontend após a validação de um cabo.
type ResultadoCabo struct {
	DistanciaM                float64 `json:"distanciaM"`
	Tipo                      string  `json:"tipo"`
	ExcedeLimite              bool    `json:"excedeLimite"`
	PontoConsolidacaoSugerido bool    `json:"pontoConsolidacaoSugerido"`
	AlertaEMI                 bool    `json:"alertaEMI"`
	EmiAtenuado               bool    `json:"emiAtenuado"` // true quando a blindagem já reduz o impacto do alerta
	Mensagem                  string  `json:"mensagem"`
}

// distanciaManhattan soma a distância entre pontos consecutivos do trajeto
// (Geometria do Táxi) — o roteamento de cabos é sempre ortogonal, então o
// comprimento físico real do cabo é a soma dos módulos, não a distância
// euclidiana direta entre origem e destino.
func distanciaManhattan(pontos []PontoCabo) float64 {
	soma := 0.0
	for i := 1; i < len(pontos); i++ {
		soma += math.Abs(pontos[i].X-pontos[i-1].X) +
			math.Abs(pontos[i].Y-pontos[i-1].Y) +
			math.Abs(pontos[i].Z-pontos[i-1].Z)
	}
	return soma
}

// distanciaPontoSegmentoXZ calcula a menor distância, em planta (plano XZ),
// entre uma Zona de Risco e um segmento de cabo. O eixo Y não participa da
// validação de EMI porque a zona é tratada como uma área circular em planta.
func distanciaPontoSegmentoXZ(zona ZonaRisco, a, b PontoCabo) float64 {
	abX := b.X - a.X
	abZ := b.Z - a.Z
	comprimentoQuadrado := abX*abX + abZ*abZ

	// Segmento degenerado: os dois pontos ocupam a mesma posição em planta.
	if comprimentoQuadrado == 0 {
		dx := zona.X - a.X
		dz := zona.Z - a.Z
		return math.Sqrt(dx*dx + dz*dz)
	}

	// Projeta o centro da zona sobre o segmento e limita a projeção ao
	// intervalo [0,1], garantindo que a menor distância também considere
	// corretamente as extremidades do trecho.
	t := ((zona.X-a.X)*abX + (zona.Z-a.Z)*abZ) / comprimentoQuadrado
	if t < 0 {
		t = 0
	} else if t > 1 {
		t = 1
	}

	maisProximoX := a.X + t*abX
	maisProximoZ := a.Z + t*abZ
	dx := zona.X - maisProximoX
	dz := zona.Z - maisProximoZ

	return math.Sqrt(dx*dx + dz*dz)
}

// cruzaZonaRisco verifica, em planta (plano XZ), se qualquer segmento do
// trajeto atravessa ou passa dentro do raio de alguma Zona de Risco EMI.
// Isso evita o falso negativo da implementação anterior, que verificava
// somente os pontos do trajeto e podia ignorar uma zona localizada no meio
// de dois pontos consecutivos.
func cruzaZonaRisco(pontos []PontoCabo, zonas []ZonaRisco) bool {
	if len(pontos) == 0 || len(zonas) == 0 {
		return false
	}

	for _, zona := range zonas {
		raio := zona.Raio
		if raio <= 0 {
			raio = RaioZonaRiscoPadraoM
		}

		// Um único ponto não forma segmento, mas ainda pode estar dentro da zona.
		if len(pontos) == 1 {
			if distanciaPontoSegmentoXZ(zona, pontos[0], pontos[0]) <= raio {
				return true
			}
			continue
		}

		for i := 1; i < len(pontos); i++ {
			if distanciaPontoSegmentoXZ(zona, pontos[i-1], pontos[i]) <= raio {
				return true
			}
		}
	}

	return false
}

func arredonda1(v float64) float64 {
	return math.Round(v*10) / 10
}

// CalcularCabo é o método exposto ao frontend via Wails (window.go.main.App.CalcularCabo).
// cabo.Categoria: "nao-blindado" | "blindado" | "fibra".
func (a *App) CalcularCabo(pontos []PontoCabo, cabo CaboInfo, zonas []ZonaRisco) ResultadoCabo {
	distancia := arredonda1(distanciaManhattan(pontos))

	resultado := ResultadoCabo{
		DistanciaM: distancia,
		Tipo:       cabo.ID,
	}

	switch cabo.Categoria {
	case "fibra":
		resultado.Mensagem = fmt.Sprintf(
			"Trajeto de fibra óptica: %.1fm — imune a EMI e sem limite de 90m (o orçamento óptico/atenuação é validado separadamente).",
			distancia,
		)

	case "blindado":
		limite := cabo.LimiteM
		if limite <= 0 {
			limite = LimiteCanalMetalicoM
		}
		resultado.ExcedeLimite = distancia > limite
		if resultado.ExcedeLimite {
			resultado.PontoConsolidacaoSugerido = true
			resultado.Mensagem = fmt.Sprintf(
				"Trajeto de %.1fm excede o limite de %.0fm do enlace permanente (ABNT NBR 14565 / EIA-TIA). Insira um Ponto de Consolidação (CP).",
				distancia, limite,
			)
		}

		if cruzaZonaRisco(pontos, zonas) {
			resultado.AlertaEMI = true
			resultado.EmiAtenuado = true
			if resultado.Mensagem != "" {
				resultado.Mensagem += " "
			}
			resultado.Mensagem += "O cabo cruza uma Zona de Risco EMI, mas a blindagem já atenua o impacto — mantenha o aterramento da malha correto nas duas pontas."
		}

		if resultado.Mensagem == "" {
			resultado.Mensagem = "Trajeto dentro dos limites da norma."
		}

	case "nao-blindado":
		limite := cabo.LimiteM
		if limite <= 0 {
			limite = LimiteCanalMetalicoM
		}
		resultado.ExcedeLimite = distancia > limite
		if resultado.ExcedeLimite {
			resultado.PontoConsolidacaoSugerido = true
			resultado.Mensagem = fmt.Sprintf(
				"Trajeto de %.1fm excede o limite de %.0fm do enlace permanente (ABNT NBR 14565 / EIA-TIA). Insira um Ponto de Consolidação (CP).",
				distancia, limite,
			)
		}

		if cruzaZonaRisco(pontos, zonas) {
			resultado.AlertaEMI = true
			if resultado.Mensagem != "" {
				resultado.Mensagem += " "
			}
			resultado.Mensagem += "O cabo cruza uma Zona de Risco EMI — recomenda-se cabo blindado (F/UTP ou S/FTP) com aterramento adequado."
		}

		if resultado.Mensagem == "" {
			resultado.Mensagem = "Trajeto dentro dos limites da norma."
		}

	default:
		// categoria desconhecida: não deveria acontecer (o frontend só envia
		// valores do catálogo), mas em vez de tratar silenciosamente como
		// "não blindado", sinaliza no resultado em vez de assumir a norma mais permissiva
		resultado.Mensagem = fmt.Sprintf("Categoria de cabo desconhecida (%q) — validação não pôde ser aplicada com segurança. Verifique o catálogo.", cabo.Categoria)
		resultado.ExcedeLimite = true // conservador: força o usuário a revisar em vez de deixar passar batido
	}

	return resultado
}
