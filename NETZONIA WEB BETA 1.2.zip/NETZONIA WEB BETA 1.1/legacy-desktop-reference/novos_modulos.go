package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"math"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	wailsruntime "github.com/wailsapp/wails/v2/pkg/runtime"
	"golang.org/x/crypto/ssh"
)

// ---------------------------------------------------------------------------
// 15) CALCULADORA VLSM
// ---------------------------------------------------------------------------

type SubnetVLSM struct {
	Rede         string `json:"rede"`
	Mascara      string `json:"mascara"`
	Broadcast    string `json:"broadcast"`
	Hosts        int    `json:"hosts"`
	HostsUsaveis int    `json:"hostsUsaveis"`
}

func (a *App) CalcularVLSM(bloco string, hosts []int) ([]SubnetVLSM, error) {
	_, ipnet, err := net.ParseCIDR(strings.TrimSpace(bloco))
	if err != nil {
		return nil, fmt.Errorf("bloco inválido: %w", err)
	}
	if ipnet.IP.To4() == nil {
		return nil, errors.New("apenas IPv4 suportado")
	}
	if len(hosts) == 0 {
		return nil, errors.New("informe ao menos uma quantidade de hosts")
	}
	if len(hosts) > 512 {
		return nil, errors.New("quantidade excessiva de sub-redes solicitadas")
	}

	hostsOrdenados := append([]int(nil), hosts...)
	for _, h := range hostsOrdenados {
		if h < 1 {
			return nil, errors.New("quantidade de hosts deve ser maior que zero")
		}
		// Uma sub-rede IPv4 não pode exigir mais que 2^32 endereços; o limite
		// também impede overflow em h+2 e shifts dependentes da arquitetura.
		if int64(h) > int64(^uint32(0))-2 {
			return nil, errors.New("quantidade de hosts excede a capacidade do IPv4")
		}
	}
	sort.Slice(hostsOrdenados, func(i, j int) bool { return hostsOrdenados[i] > hostsOrdenados[j] })

	base := ipnet.IP.To4()
	_, blocoPrefix := ipnet.Mask.Size()
	if blocoPrefix != 32 {
		return nil, errors.New("máscara IPv4 inválida")
	}
	var resultados []SubnetVLSM

	for _, h := range hostsOrdenados {
		needed := uint64(h) + 2
		bits := uint(0)
		for (uint64(1)<<bits) < needed && bits < 32 {
			bits++
		}
		if bits > 32 || (uint64(1)<<bits) < needed {
			return nil, errors.New("quantidade de hosts excede a capacidade de uma sub-rede IPv4")
		}
		prefix := 32 - int(bits)
		mask := net.CIDRMask(prefix, 32)
		if len(mask) != 4 {
			return nil, errors.New("não foi possível calcular uma máscara IPv4 válida")
		}
		network := make(net.IP, 4)
		copy(network, base)
		for i := 0; i < 4; i++ {
			network[i] &= mask[i]
		}
		broadcast := make(net.IP, 4)
		copy(broadcast, network)
		for i := 0; i < 4; i++ {
			broadcast[i] |= ^mask[i]
		}
		if !ipnet.Contains(network) || !ipnet.Contains(broadcast) {
			return nil, fmt.Errorf("o bloco %s não possui espaço suficiente para todas as sub-redes solicitadas", bloco)
		}
		total := uint64(1) << bits
		if total > uint64(^uint(0)>>1) {
			return nil, errors.New("sub-rede calculada excede a capacidade numérica desta plataforma")
		}
		resultados = append(resultados, SubnetVLSM{
			Rede:         network.String() + "/" + strconv.Itoa(prefix),
			Mascara:      fmt.Sprintf("%d.%d.%d.%d", mask[0], mask[1], mask[2], mask[3]),
			Broadcast:    broadcast.String(),
			Hosts:        int(total),
			HostsUsaveis: int(total) - 2,
		})

		base = make(net.IP, 4)
		copy(base, broadcast)
		carry := true
		for i := 3; i >= 0 && carry; i-- {
			if base[i] < 255 {
				base[i]++
				carry = false
			} else {
				base[i] = 0
			}
		}
		if carry && len(resultados) < len(hostsOrdenados) {
			return nil, fmt.Errorf("o bloco %s não possui espaço suficiente para todas as sub-redes solicitadas", bloco)
		}
	}
	reportLog("[VLSM] bloco %s | %d sub-rede(s) calculada(s)", bloco, len(resultados))
	return resultados, nil
}

// ---------------------------------------------------------------------------
// 16) CALCULADORA DE ORÇAMENTO ÓPTICO (GPON/FTTH)
// ---------------------------------------------------------------------------

type OrcamentoOpticoResult struct {
	NivelRecebido  float64 `json:"nivelRecebido"`
	AtenuacaoTotal float64 `json:"atenuacaoTotal"`
	OK             bool    `json:"ok"`
	Mensagem       string  `json:"mensagem"`
}

func (a *App) CalcularOrcamentoOptico(potencia float64, distanciaKm float64, attPorKm float64, splitters []float64) (OrcamentoOpticoResult, error) {
	if err := validateFinite("potência", potencia, -100, 100); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if err := validateFinite("distância", distanciaKm, 0, 1000); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if err := validateFinite("atenuação por km", attPorKm, 0, 100); err != nil {
		return OrcamentoOpticoResult{}, err
	}
	if len(splitters) > 128 {
		return OrcamentoOpticoResult{}, errors.New("quantidade excessiva de splitters")
	}
	attTotal := distanciaKm * attPorKm
	for _, loss := range splitters {
		if err := validateFinite("atenuação de splitter", loss, 0, 100); err != nil {
			return OrcamentoOpticoResult{}, err
		}
		attTotal += loss
	}
	nivel := potencia - attTotal
	ok := nivel >= -27.0
	msg := fmt.Sprintf("Nível recebido: %.2f dBm (atenuação total: %.2f dB)", nivel, attTotal)
	if !ok {
		msg += " — ABAIXO DO LIMITE MÍNIMO DE -27 dBm!"
	}
	reportLog("[GPON/FTTH] distância %.2f km | atenuação total %.2f dB | nível %.2f dBm", distanciaKm, attTotal, nivel)
	return OrcamentoOpticoResult{NivelRecebido: nivel, AtenuacaoTotal: attTotal, OK: ok, Mensagem: msg}, nil
}

// ---------------------------------------------------------------------------
// 17) CALCULADORA DE BANDA CFTV
// ---------------------------------------------------------------------------

type CFTVResult struct {
	BandaMbps float64 `json:"bandaMbps"`
	StorageTB float64 `json:"storageTB"`
	Mensagem  string  `json:"mensagem"`
}

func (a *App) CalcularBandaCFTV(resolucao string, fps int, cameras int, dias int, codec string) (CFTVResult, error) {
	mbpsPorCam := map[string]float64{"720p": 1.0, "1080p": 2.0, "2mp": 2.0, "3mp": 3.5, "4mp": 4.0, "5mp": 5.0, "4k": 8.0, "8mp": 8.0}
	base, ok := mbpsPorCam[strings.ToLower(strings.TrimSpace(resolucao))]
	if !ok {
		return CFTVResult{}, errors.New("resolução CFTV não suportada")
	}
	if fps < 1 || fps > 240 {
		return CFTVResult{}, errors.New("FPS deve estar entre 1 e 240")
	}
	if cameras < 1 || cameras > 10000 {
		return CFTVResult{}, errors.New("quantidade de câmeras inválida")
	}
	if dias < 1 || dias > 3650 {
		return CFTVResult{}, errors.New("quantidade de dias inválida")
	}
	codec = strings.ToLower(strings.TrimSpace(codec))
	if codec != "" && codec != "h264" && codec != "h265" && codec != "hevc" {
		return CFTVResult{}, errors.New("codec não suportado")
	}
	base *= float64(fps) / 15.0
	if codec == "h265" || codec == "hevc" {
		base *= 0.6
	}
	bandaTotal := base * float64(cameras)
	storageTB := (bandaTotal / 8.0) * 3600.0 * 24.0 * float64(dias) / (1024.0 * 1024.0)
	reportLog("[CFTV] %d câmera(s) | %.1f Mbps | %.2f TB", cameras, bandaTotal, storageTB)
	return CFTVResult{BandaMbps: bandaTotal, StorageTB: storageTB, Mensagem: fmt.Sprintf("Banda estimada: %.1f Mbps | Armazenamento: %.2f TB (%d dias)", bandaTotal, storageTB, dias)}, nil
}

// ---------------------------------------------------------------------------
// 18) CONVERSOR DE GRANDEZAS TELECOM
// ---------------------------------------------------------------------------

type ConversaoResult struct {
	Entrada  float64 `json:"entrada"`
	Saida    float64 `json:"saida"`
	Unidade  string  `json:"unidade"`
	Mensagem string  `json:"mensagem"`
}

func (a *App) ConverterGrandezas(tipo string, valor float64) (ConversaoResult, error) {
	if math.IsNaN(valor) || math.IsInf(valor, 0) {
		return ConversaoResult{}, errors.New("valor deve ser um número finito")
	}
	tipo = strings.ToLower(strings.TrimSpace(tipo))
	if tipo == "mw_dbm" && valor <= 0 {
		return ConversaoResult{}, errors.New("mW deve ser maior que zero para conversão em dBm")
	}
	if (tipo == "mbps_mbs" || tipo == "mbs_mbps") && valor < 0 {
		return ConversaoResult{}, errors.New("taxa de transferência não pode ser negativa")
	}
	switch tipo {
	case "dbm_mw":
		mw := math.Pow(10, valor/10.0)
		if math.IsInf(mw, 0) {
			return ConversaoResult{}, errors.New("resultado fora do intervalo numérico")
		}
		res := ConversaoResult{Entrada: valor, Saida: mw, Unidade: "mW", Mensagem: fmt.Sprintf("%.2f dBm = %.4f mW", valor, mw)}
		reportLog("[Conversor Telecom] %s", res.Mensagem)
		return res, nil
	case "mw_dbm":
		dbm := 10 * math.Log10(valor)
		res := ConversaoResult{Entrada: valor, Saida: dbm, Unidade: "dBm", Mensagem: fmt.Sprintf("%.4f mW = %.2f dBm", valor, dbm)}
		reportLog("[Conversor Telecom] %s", res.Mensagem)
		return res, nil
	case "mbps_mbs":
		mbs := valor / 8.0
		res := ConversaoResult{Entrada: valor, Saida: mbs, Unidade: "MB/s", Mensagem: fmt.Sprintf("%.2f Mbps = %.2f MB/s", valor, mbs)}
		reportLog("[Conversor Telecom] %s", res.Mensagem)
		return res, nil
	case "mbs_mbps":
		mbps := valor * 8.0
		if math.IsInf(mbps, 0) {
			return ConversaoResult{}, errors.New("resultado fora do intervalo numérico")
		}
		res := ConversaoResult{Entrada: valor, Saida: mbps, Unidade: "Mbps", Mensagem: fmt.Sprintf("%.2f MB/s = %.2f Mbps", valor, mbps)}
		reportLog("[Conversor Telecom] %s", res.Mensagem)
		return res, nil
	default:
		return ConversaoResult{}, errors.New("tipo de conversão desconhecido: use dbm_mw, mw_dbm, mbps_mbs ou mbs_mbps")
	}
}

var sshKnownHostsMu sync.Mutex

func netzoniaSSHHostKeyCallback(target string) ssh.HostKeyCallback {
	return func(_ string, _ net.Addr, key ssh.PublicKey) error {
		fingerprint := ssh.FingerprintSHA256(key)
		base, err := os.UserConfigDir()
		if err != nil || strings.TrimSpace(base) == "" {
			return fmt.Errorf("não foi possível localizar a pasta de configuração para validar a chave SSH")
		}
		dir := filepath.Join(base, "Netzonia")
		if err := os.MkdirAll(dir, 0o700); err != nil {
			return err
		}
		path := filepath.Join(dir, "ssh_known_hosts.txt")
		sshKnownHostsMu.Lock()
		defer sshKnownHostsMu.Unlock()
		data, readErr := os.ReadFile(path)
		if readErr != nil && !os.IsNotExist(readErr) {
			return fmt.Errorf("não foi possível ler o arquivo de hosts SSH conhecidos: %w", readErr)
		}
		for lineNo, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			if line == "" {
				continue
			}
			parts := strings.SplitN(line, "\t", 2)
			if len(parts) != 2 || strings.TrimSpace(parts[0]) == "" || strings.TrimSpace(parts[1]) == "" {
				return fmt.Errorf("arquivo de hosts SSH conhecidos está corrompido na linha %d", lineNo+1)
			}
			if parts[0] != target {
				continue
			}
			if parts[1] != fingerprint {
				return errors.New("a chave do servidor SSH mudou; conexão bloqueada por segurança")
			}
			return nil
		}
		f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
		if err != nil {
			return err
		}
		defer f.Close()
		if _, err = fmt.Fprintf(f, "%s\t%s\n", target, fingerprint); err != nil {
			return err
		}
		return f.Sync()
	}
}

// ---------------------------------------------------------------------------
// 19) TERMINAL SSH (cifras legadas para equip. antigos)
// ---------------------------------------------------------------------------

type SSHResult struct {
	Stdout   string `json:"stdout"`
	Stderr   string `json:"stderr"`
	ExitCode int    `json:"exitCode"`
}

type cappedWriter struct {
	buf strings.Builder
	max int
}

func (w *cappedWriter) Write(p []byte) (int, error) {
	if w.buf.Len() < w.max {
		remaining := w.max - w.buf.Len()
		if remaining > len(p) {
			remaining = len(p)
		}
		_, _ = w.buf.Write(p[:remaining])
	}
	return len(p), nil
}
func (w *cappedWriter) String() string { return w.buf.String() }

func (a *App) ExecutarSSH(host, user, pass, cmd string, port int) (SSHResult, error) {
	var err error
	port, err = validatePort(port, 22)
	if err != nil {
		return SSHResult{}, err
	}
	host = strings.TrimSpace(host)
	if err := validateHost(host); err != nil {
		return SSHResult{}, err
	}
	user, err = validateBoundedText("usuário SSH", user, 1, 128, false)
	if err != nil {
		return SSHResult{}, err
	}
	if len([]rune(pass)) > 4096 {
		return SSHResult{}, errors.New("senha SSH excede o tamanho máximo")
	}
	cmd, err = validateBoundedText("comando SSH", cmd, 1, 16384, true)
	if err != nil {
		return SSHResult{}, err
	}

	config := &ssh.ClientConfig{
		User: user, Auth: []ssh.AuthMethod{ssh.Password(pass)},
		HostKeyCallback: netzoniaSSHHostKeyCallback(net.JoinHostPort(host, strconv.Itoa(port))), Timeout: 15 * time.Second,
		Config: ssh.Config{
			// Algoritmos legados permanecem por compatibilidade com equipamentos antigos.
			// Eles são risco residual documentado na P17 e devem ser removidos/opt-in numa versão futura.
			KeyExchanges: []string{"curve25519-sha256", "curve25519-sha256@libssh.org", "ecdh-sha2-nistp256", "ecdh-sha2-nistp384", "ecdh-sha2-nistp521", "diffie-hellman-group14-sha1", "diffie-hellman-group1-sha1"},
			Ciphers:      []string{"aes128-gcm@openssh.com", "aes256-gcm@openssh.com", "aes128-ctr", "aes192-ctr", "aes256-ctr", "aes128-cbc", "aes192-cbc", "aes256-cbc", "3des-cbc"},
		},
	}
	client, err := ssh.Dial("tcp", net.JoinHostPort(host, strconv.Itoa(port)), config)
	if err != nil {
		reportLog("[SSH] falha ao conectar em %s:%d", host, port)
		return SSHResult{}, fmt.Errorf("falha na conexão SSH: %w", err)
	}
	defer client.Close()
	session, err := client.NewSession()
	if err != nil {
		return SSHResult{}, fmt.Errorf("falha ao criar sessão: %w", err)
	}
	defer session.Close()
	stdout, err := session.StdoutPipe()
	if err != nil {
		return SSHResult{}, fmt.Errorf("falha ao preparar stdout SSH: %w", err)
	}
	stderr, err := session.StderrPipe()
	if err != nil {
		return SSHResult{}, fmt.Errorf("falha ao preparar stderr SSH: %w", err)
	}
	if err := session.Start(cmd); err != nil {
		return SSHResult{}, fmt.Errorf("falha ao iniciar comando: %w", err)
	}
	var outW = &cappedWriter{max: 512 * 1024}
	var errW = &cappedWriter{max: 64 * 1024}
	var copyWG sync.WaitGroup
	copyWG.Add(2)
	go func() { defer copyWG.Done(); _, _ = io.Copy(outW, stdout) }()
	go func() { defer copyWG.Done(); _, _ = io.Copy(errW, stderr) }()
	waitCh := make(chan error, 1)
	go func() { waitCh <- session.Wait() }()
	var waitErr error
	select {
	case waitErr = <-waitCh:
	case <-time.After(90 * time.Second):
		_ = session.Close()
		_ = client.Close()
		<-waitCh
		copyWG.Wait()
		return SSHResult{}, errors.New("comando SSH excedeu o tempo limite de 90 segundos")
	}
	copyWG.Wait()
	exitCode := 0
	if waitErr != nil {
		if exitErr, ok := waitErr.(*ssh.ExitError); ok {
			exitCode = exitErr.ExitStatus()
		} else {
			return SSHResult{}, fmt.Errorf("falha durante execução SSH: %w", waitErr)
		}
	}
	reportLog("[SSH] comando remoto executado em %s:%d | exit=%d", host, port, exitCode)
	return SSHResult{Stdout: outW.String(), Stderr: errW.String(), ExitCode: exitCode}, nil
}

// ---------------------------------------------------------------------------
// 20) WAKE-ON-LAN
// ---------------------------------------------------------------------------

func (a *App) WakeOnLAN(macAddr, broadcast string) error {
	mac, err := net.ParseMAC(strings.TrimSpace(macAddr))
	if err != nil || len(mac) != 6 {
		return errors.New("MAC inválido: informe um endereço de 6 bytes")
	}
	broadcast = strings.TrimSpace(broadcast)
	if broadcast == "" {
		broadcast = "255.255.255.255:9"
	}
	host, portText, err := net.SplitHostPort(broadcast)
	if err != nil {
		if strings.Count(broadcast, ":") == 0 {
			host = broadcast
			portText = "9"
		} else {
			return errors.New("broadcast inválido; use IP:porta")
		}
	}
	if err := validateHost(host); err != nil {
		return fmt.Errorf("broadcast inválido: %w", err)
	}
	port64, err := strconv.ParseInt(portText, 10, 32)
	if err != nil {
		return errors.New("porta de broadcast inválida")
	}
	port, err := validatePort(int(port64), 9)
	if err != nil {
		return err
	}
	packet := make([]byte, 6+16*6)
	for i := 0; i < 6; i++ {
		packet[i] = 0xFF
	}
	for i := 0; i < 16; i++ {
		copy(packet[6+i*6:], mac)
	}
	addr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		return fmt.Errorf("broadcast inválido: %w", err)
	}
	conn, err := net.DialUDP("udp", nil, addr)
	if err != nil {
		return err
	}
	defer conn.Close()
	_ = conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
	_, err = conn.Write(packet)
	if err == nil {
		reportLog("[Wake-on-LAN] Magic Packet enviado")
	}
	return err
}

// ---------------------------------------------------------------------------
// 21) PING SONORO (modo alinhamento)
// ---------------------------------------------------------------------------

func (a *App) IniciarPingSonoro(host string, intervaloSec int) error {
	host = strings.TrimSpace(host)
	if host == "" {
		return errors.New("host obrigatório")
	}
	if err := validateHost(host); err != nil {
		return err
	}
	if intervaloSec < 1 || intervaloSec > 3600 {
		return errors.New("intervalo deve estar entre 1 e 3600 segundos")
	}
	if a.ctx == nil {
		return errors.New("aplicação ainda não inicializada")
	}

	a.pingMu.Lock()
	if a.pingCancel != nil {
		a.pingCancel()
	}
	ctx, cancel := context.WithCancel(context.Background())
	a.pingCancel = cancel
	a.pingMu.Unlock()

	reportLog("[Ping Sonoro] iniciado para %s a cada %ds", host, intervaloSec)
	go func() {
		ticker := time.NewTicker(time.Duration(intervaloSec) * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				lat, err := pingOnce(host, 2*time.Second)
				ok := err == nil
				payload := map[string]any{
					"host":       host,
					"ok":         ok,
					"latenciaMs": nil,
					"timestamp":  time.Now().Format(time.RFC3339Nano),
				}
				if ok {
					payload["latenciaMs"] = lat
					systemBeep()
				}
				wailsruntime.EventsEmit(a.ctx, "ping:sonoro:tick", payload)
			}
		}
	}()
	return nil
}

func (a *App) PararPingSonoro() {
	a.pingMu.Lock()
	defer a.pingMu.Unlock()
	if a.pingCancel != nil {
		a.pingCancel()
		a.pingCancel = nil
		reportLog("[Ping Sonoro] monitor interrompido")
	}
}

// ---------------------------------------------------------------------------
// 22) TESTADOR DE PPPoE LOCAL
// ---------------------------------------------------------------------------

type PPPoEResult struct {
	Sucesso  bool   `json:"sucesso"`
	Mensagem string `json:"mensagem"`
	Codigo   int    `json:"codigo"`
}

func (a *App) TestarPPPoE(usuario, senha, perfil string) (PPPoEResult, error) {
	if runtime.GOOS != "windows" {
		return PPPoEResult{}, errors.New("PPPoE local apenas disponível no Windows")
	}
	var err error
	perfil, err = validatePPPoEProfile(perfil)
	if err != nil {
		return PPPoEResult{}, err
	}
	usuario, err = validateBoundedText("usuário PPPoE", usuario, 1, 256, false)
	if err != nil {
		return PPPoEResult{}, err
	}
	if len([]rune(senha)) == 0 || len([]rune(senha)) > 1024 {
		return PPPoEResult{}, errors.New("senha PPPoE inválida")
	}
	for _, r := range senha {
		if r == '\r' || r == '\n' || r == 0 {
			return PPPoEResult{}, errors.New("senha PPPoE contém caracteres de controle inválidos")
		}
	}
	f, err := os.CreateTemp("", "netzonia-pppoe-*.pbk")
	if err != nil {
		return PPPoEResult{}, fmt.Errorf("não foi possível criar perfil PPPoE temporário: %w", err)
	}
	pbkPath := f.Name()
	defer os.Remove(pbkPath)
	defer f.Close()
	_ = f.Chmod(0o600)
	pbkContent := fmt.Sprintf("[%s]\nMEDIA=rastd\nPort=VPN2-0\nDevice=WAN Miniport (PPPOE)\nPHONE_NUMBER=\n", perfil)
	if _, err = f.WriteString(pbkContent); err != nil {
		return PPPoEResult{}, fmt.Errorf("não foi possível gravar perfil PPPoE temporário: %w", err)
	}
	if err = f.Sync(); err != nil {
		return PPPoEResult{}, fmt.Errorf("não foi possível finalizar perfil PPPoE temporário: %w", err)
	}
	_ = f.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	cmdPPPoE := exec.CommandContext(ctx, "rasdial", perfil, usuario, senha, "/phonebook:"+pbkPath)
	configureCommandNoWindow(cmdPPPoE)
	out, runErr := cmdPPPoE.CombinedOutput()
	output := decodeSystemOutput(out)
	if ctx.Err() == context.DeadlineExceeded {
		return PPPoEResult{Sucesso: false, Mensagem: "Tempo limite excedido ao testar PPPoE"}, nil
	}
	if runErr == nil && (strings.Contains(output, "Successfully connected") || strings.Contains(output, "Conectado com sucesso")) {
		discCtx, discCancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer discCancel()
		disc := exec.CommandContext(discCtx, "rasdial", perfil, "/disconnect", "/phonebook:"+pbkPath)
		configureCommandNoWindow(disc)
		_ = disc.Run()
		reportLog("[PPPoE] teste concluído | sucesso=true | código=0")
		return PPPoEResult{Sucesso: true, Mensagem: "Discagem PPPoE bem-sucedida", Codigo: 0}, nil
	}
	codigo := 0
	msg := strings.TrimSpace(output)
	if len(msg) > 4096 {
		msg = msg[:4096] + "…"
	}
	switch {
	case strings.Contains(output, "691") || strings.Contains(output, "Access denied"):
		codigo, msg = 691, "Erro 691: Credenciais inválidas (usuário ou senha incorretos)"
	case strings.Contains(output, "678") || strings.Contains(output, "No answer"):
		codigo, msg = 678, "Erro 678: Sem resposta do concentrador (verifique o link físico)"
	case strings.Contains(output, "680"):
		codigo, msg = 680, "Erro 680: Sem sinal de discagem"
	case strings.Contains(output, "777"):
		codigo, msg = 777, "Erro 777: O modem está ocupado ou fora de área"
	case strings.Contains(output, "623"):
		codigo, msg = 623, "Erro 623: Perfil/entrada PPPoE não encontrado no Windows"
	}
	if msg == "" && runErr != nil {
		msg = "Falha ao testar PPPoE"
	}
	reportLog("[PPPoE] teste concluído | sucesso=false | código=%d", codigo)
	return PPPoEResult{Sucesso: false, Mensagem: msg, Codigo: codigo}, nil
}

// ---------------------------------------------------------------------------
// 23) SERVIDOR LAN (teste de banda local)
// ---------------------------------------------------------------------------

type LANServerStatus struct {
	URL   string `json:"url"`
	Ativo bool   `json:"ativo"`
	Porta int    `json:"porta"`
	Aviso string `json:"aviso"`
}

var lanServer struct {
	mu     sync.Mutex
	server *http.Server
	porta  int
}

func setLANHeaders(w http.ResponseWriter) {
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Frame-Options", "DENY")
}

func (a *App) IniciarServidorLAN(porta int) (LANServerStatus, error) {
	var err error
	porta, err = validatePort(porta, 8080)
	if err != nil {
		return LANServerStatus{}, err
	}
	lanServer.mu.Lock()
	defer lanServer.mu.Unlock()
	if lanServer.server != nil {
		return LANServerStatus{Aviso: "Servidor já está ativo", Ativo: true, Porta: lanServer.porta}, nil
	}
	ip, _, err := detectLocalNetwork()
	if err != nil {
		return LANServerStatus{}, err
	}
	sem := make(chan struct{}, 4)
	mux := http.NewServeMux()
	mux.HandleFunc("/lan-download", func(w http.ResponseWriter, r *http.Request) {
		setLANHeaders(w)
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			w.Header().Set("Allow", "GET, HEAD")
			http.Error(w, "método não permitido", http.StatusMethodNotAllowed)
			return
		}
		select {
		case sem <- struct{}{}:
			defer func() { <-sem }()
		default:
			http.Error(w, "servidor ocupado", http.StatusServiceUnavailable)
			return
		}
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Content-Length", "104857600")
		if r.Method == http.MethodHead {
			return
		}
		zero := make([]byte, 65536)
		for i := 0; i < 1600; i++ {
			if _, err := w.Write(zero); err != nil {
				return
			}
		}
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		setLANHeaders(w)
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			w.Header().Set("Allow", "GET, HEAD")
			http.Error(w, "método não permitido", http.StatusMethodNotAllowed)
			return
		}
		if r.Method == http.MethodGet {
			_, _ = w.Write([]byte("NetZônia LAN Server OK"))
		}
	})
	addr := fmt.Sprintf("0.0.0.0:%d", porta)
	listener, err := net.Listen("tcp", addr)
	if err != nil {
		return LANServerStatus{}, fmt.Errorf("não foi possível abrir a porta %d: %w", porta, err)
	}
	server := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 120 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16 * 1024}
	lanServer.server = server
	lanServer.porta = porta
	go func() {
		if err := server.Serve(listener); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logAppError("ServidorLAN", err)
		}
	}()
	reportLog("[Servidor LAN] iniciado em %s:%d", ip.String(), porta)
	return LANServerStatus{URL: fmt.Sprintf("http://%s:%d", ip.String(), porta), Ativo: true, Porta: porta, Aviso: "Servidor iniciado. Se o Windows Firewall solicitar permissão, permita apenas em redes privadas."}, nil
}

func (a *App) PararServidorLAN() {
	lanServer.mu.Lock()
	server := lanServer.server
	lanServer.server = nil
	lanServer.porta = 0
	lanServer.mu.Unlock()
	if server != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if err := server.Shutdown(ctx); err != nil {
			_ = server.Close()
		}
		reportLog("[Servidor LAN] servidor interrompido")
	}
}

// ---------------------------------------------------------------------------
// 24) GERADOR DE STRING WI-FI (padrão QR Code)
// ---------------------------------------------------------------------------

func (a *App) GerarStringWiFi(ssid, senha, tipoSeg string) (string, error) {
	if ssid == "" {
		return "", errors.New("SSID obrigatório")
	}
	if tipoSeg == "" {
		tipoSeg = "WPA"
	}
	if senha == "" {
		reportLog("[Wi-Fi String] string gerada para rede aberta")
		return fmt.Sprintf("WIFI:T:nopass;S:%s;;", escapeWiFi(ssid)), nil
	}
	reportLog("[Wi-Fi String] string gerada com segurança %s", tipoSeg)
	return fmt.Sprintf("WIFI:T:%s;S:%s;P:%s;;", tipoSeg, escapeWiFi(ssid), escapeWiFi(senha)), nil
}

func escapeWiFi(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `;`, `\;`)
	s = strings.ReplaceAll(s, `:`, `\:`)
	s = strings.ReplaceAll(s, `,`, `\,`)
	return s
}

// ---------------------------------------------------------------------------
// 25) CONSULTA SNMP RÁPIDA (via snmpget externo)
// ---------------------------------------------------------------------------

func (a *App) ConsultaSNMP(host, community, oid string) (string, error) {
	host = strings.TrimSpace(host)
	if err := validateHost(host); err != nil {
		return "", err
	}
	var err error
	community, err = validateSNMPCommunity(community)
	if err != nil {
		return "", err
	}
	oid, err = validateOID(oid)
	if err != nil {
		return "", err
	}
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
	defer cancel()
	var out []byte
	if runtime.GOOS == "windows" {
		cmdSNMP := exec.CommandContext(ctx, "snmpget", "-v2c", "-c", community, host, oid)
		configureCommandNoWindow(cmdSNMP)
		out, err = cmdSNMP.CombinedOutput()
		if err != nil && !strings.Contains(strings.ToLower(decodeSystemOutput(out)), "timeout") {
			// Script fixo; valores do usuário são argumentos separados ($args), não interpolados no código PowerShell.
			script := `& { param($c,$h,$o) if (-not (Get-Command Invoke-SnmpGet -ErrorAction SilentlyContinue)) { throw 'Invoke-SnmpGet indisponivel' }; Invoke-SnmpGet -Community $c -Version V2c -Target $h -OID $o }`
			cmdPS := exec.CommandContext(ctx, "powershell", "-NoProfile", "-NonInteractive", "-Command", script, community, host, oid)
			configureCommandNoWindow(cmdPS)
			out, err = cmdPS.CombinedOutput()
		}
	} else {
		out, err = exec.CommandContext(ctx, "snmpget", "-v2c", "-c", community, host, oid).CombinedOutput()
	}
	if ctx.Err() == context.DeadlineExceeded {
		return "", errors.New("consulta SNMP excedeu o tempo limite")
	}
	if err != nil {
		reportLog("[SNMP] falha na consulta do OID %s", oid)
		msg := strings.TrimSpace(decodeSystemOutput(out))
		if len(msg) > 4096 {
			msg = msg[:4096] + "…"
		}
		low := strings.ToLower(err.Error() + " " + msg)
		if strings.Contains(low, "executable file not found") || strings.Contains(low, "invoke-snmpget indisponivel") || strings.Contains(low, "not recognized") {
			return "", errors.New("ferramenta SNMP não encontrada no sistema; instale snmpget/Net-SNMP ou um cmdlet SNMP compatível")
		}
		return "", fmt.Errorf("SNMP falhou: %w | saída: %s", err, msg)
	}
	result := strings.TrimSpace(decodeSystemOutput(out))
	if len(result) > 1024*1024 {
		return "", errors.New("resposta SNMP excede o limite permitido")
	}
	reportLog("[SNMP] consulta concluída para OID %s", oid)
	return result, nil
}

// ---------------------------------------------------------------------------
// 26) VALIDADOR DE CERTIFICADO SSL
// ---------------------------------------------------------------------------

type SSLResult struct {
	Host          string   `json:"host"`
	DiasRestantes int      `json:"diasRestantes"`
	Emissor       string   `json:"emissor"`
	Subject       string   `json:"subject"`
	Alertas       []string `json:"alertas"`
	OK            bool     `json:"ok"`
}

func (a *App) ValidarCertificadoSSL(host string, port int) (SSLResult, error) {
	host = strings.TrimSpace(host)
	if err := validateHost(host); err != nil {
		return SSLResult{}, err
	}
	var err error
	port, err = validatePort(port, 443)
	if err != nil {
		return SSLResult{}, err
	}
	conn, err := tls.DialWithDialer(&net.Dialer{Timeout: 10 * time.Second}, "tcp", net.JoinHostPort(host, strconv.Itoa(port)), &tls.Config{InsecureSkipVerify: true, ServerName: host}) //nolint:gosec -- coleta o certificado; confiança é verificada manualmente abaixo.
	if err != nil {
		return SSLResult{}, fmt.Errorf("falha TLS: %w", err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(15 * time.Second))
	state := conn.ConnectionState()
	if len(state.PeerCertificates) == 0 {
		return SSLResult{}, errors.New("servidor não apresentou certificado")
	}
	cert := state.PeerCertificates[0]
	dias := int(time.Until(cert.NotAfter).Hours() / 24)
	alertas := []string{}
	intermediates := x509.NewCertPool()
	for _, c := range state.PeerCertificates[1:] {
		intermediates.AddCert(c)
	}
	if _, err := cert.Verify(x509.VerifyOptions{DNSName: host, Intermediates: intermediates}); err != nil {
		alertas = append(alertas, "Falha na validação da cadeia/hostname do certificado")
	}
	if dias < 0 {
		alertas = append(alertas, "CERTIFICADO EXPIRADO")
	} else if dias < 30 {
		alertas = append(alertas, fmt.Sprintf("Certificado expira em %d dias", dias))
	}
	reportLog("[SSL] %s:%d | dias restantes=%d | alertas=%d", host, port, dias, len(alertas))
	return SSLResult{Host: host, DiasRestantes: dias, Emissor: cert.Issuer.CommonName, Subject: cert.Subject.CommonName, Alertas: alertas, OK: len(alertas) == 0}, nil
}

func containsSAN(cert *x509.Certificate, host string) bool {
	for _, san := range cert.DNSNames {
		if san == host || (strings.HasPrefix(san, "*.") && strings.HasSuffix(host, san[1:])) {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------------------
// 27) GERADOR DE SENHAS SEGURAS
// ---------------------------------------------------------------------------

func (a *App) GerarSenha(tamanho int, maiusculas, minusculas, numeros, simbolos bool) (string, error) {
	if tamanho < 4 || tamanho > 128 {
		return "", errors.New("tamanho deve ser entre 4 e 128")
	}
	var chars string
	if maiusculas {
		chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	}
	if minusculas {
		chars += "abcdefghijklmnopqrstuvwxyz"
	}
	if numeros {
		chars += "0123456789"
	}
	if simbolos {
		chars += "!@#$%^&*()-_=+[]{}|;:,.<>?"
	}
	if chars == "" {
		return "", errors.New("pelo menos um tipo de caractere deve ser selecionado")
	}

	n := big.NewInt(int64(len(chars)))
	result := make([]byte, tamanho)
	for i := 0; i < tamanho; i++ {
		v, err := rand.Int(rand.Reader, n)
		if err != nil {
			return "", fmt.Errorf("falha ao gerar aleatoriedade: %w", err)
		}
		result[i] = chars[v.Int64()]
	}
	reportLog("[Senha] senha segura gerada com %d caracteres", tamanho)
	return string(result), nil
}

// ---------------------------------------------------------------------------
// 28) ATALHOS DO SISTEMA
// ---------------------------------------------------------------------------

func (a *App) AbrirAtalhoSistema(atalho string) error {
	if runtime.GOOS != "windows" {
		return errors.New("atalhos do sistema apenas disponíveis no Windows")
	}
	var cmd *exec.Cmd
	switch atalho {
	case "ncpa.cpl":
		cmd = exec.Command("control.exe", "ncpa.cpl")
	case "appwiz.cpl":
		cmd = exec.Command("control.exe", "appwiz.cpl")
	case "inetcpl.cpl":
		cmd = exec.Command("control.exe", "inetcpl.cpl")
	case "firewall.cpl":
		cmd = exec.Command("control.exe", "firewall.cpl")
	case "sysdm.cpl":
		cmd = exec.Command("control.exe", "sysdm.cpl")
	case "devmgmt.msc":
		cmd = exec.Command("cmd.exe", "/C", "start", "", "devmgmt.msc")
		configureCommandNoWindow(cmd)
	default:
		return fmt.Errorf("atalho desconhecido: %s", atalho)
	}
	err := cmd.Start()
	if err == nil {
		reportLog("[Atalho Windows] %s aberto", atalho)
	} else {
		reportLog("[Atalho Windows] falha ao abrir %s", atalho)
	}
	return err
}

// ---------------------------------------------------------------------------
// 29) CONFIGURAÇÃO RÁPIDA DE IP
// ---------------------------------------------------------------------------

type InterfaceRede struct {
	Nome   string `json:"nome"`
	Status string `json:"status"`
}

type IPConfigResult struct {
	Sucesso  bool   `json:"sucesso"`
	Mensagem string `json:"mensagem"`
}

func (a *App) ListarInterfacesRede() ([]InterfaceRede, error) {
	if runtime.GOOS != "windows" {
		return nil, errors.New("listagem de interfaces apenas no Windows nesta versão")
	}
	items, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("falha ao listar interfaces: %w", err)
	}
	ifaces := make([]InterfaceRede, 0, len(items))
	for _, item := range items {
		name := strings.TrimSpace(item.Name)
		if name == "" {
			continue
		}
		status := "inativo"
		if item.Flags&net.FlagUp != 0 {
			status = "ativo"
		}
		ifaces = append(ifaces, InterfaceRede{Nome: name, Status: status})
	}
	reportLog("[Configuração IP] %d interface(s) listada(s)", len(ifaces))
	return ifaces, nil
}

func (a *App) ConfigurarIP(iface, ip, mascara, gateway string, dhcp bool) (IPConfigResult, error) {
	if runtime.GOOS != "windows" {
		return IPConfigResult{}, errors.New("configuração de IP apenas no Windows nesta versão")
	}
	iface = strings.TrimSpace(iface)
	if iface == "" {
		return IPConfigResult{Sucesso: false, Mensagem: "Selecione uma interface de rede válida"}, nil
	}
	if len([]rune(iface)) > 256 {
		return IPConfigResult{Sucesso: false, Mensagem: "Nome da interface excede o tamanho permitido"}, nil
	}
	found := false
	if items, err := net.Interfaces(); err == nil {
		for _, item := range items {
			if item.Name == iface {
				found = true
				break
			}
		}
	} else {
		return IPConfigResult{}, fmt.Errorf("falha ao validar interface de rede: %w", err)
	}
	if !found {
		return IPConfigResult{Sucesso: false, Mensagem: "Interface de rede não encontrada: " + iface}, nil
	}
	var parsedIP net.IP
	var mask net.IPMask
	gateway = strings.TrimSpace(gateway)
	ip = strings.TrimSpace(ip)
	mascara = strings.TrimSpace(mascara)
	if !dhcp {
		parsedIP = net.ParseIP(ip)
		if parsedIP == nil || parsedIP.To4() == nil {
			return IPConfigResult{Sucesso: false, Mensagem: "IPv4 inválido"}, nil
		}
		var err error
		mask, err = validateIPv4Mask(mascara)
		if err != nil {
			return IPConfigResult{Sucesso: false, Mensagem: err.Error()}, nil
		}
		if gateway != "" {
			g := net.ParseIP(gateway)
			if g == nil || g.To4() == nil {
				return IPConfigResult{Sucesso: false, Mensagem: "Gateway IPv4 inválido"}, nil
			}
			network := parsedIP.To4().Mask(mask)
			if !(&net.IPNet{IP: network, Mask: mask}).Contains(g.To4()) {
				return IPConfigResult{Sucesso: false, Mensagem: "Gateway deve pertencer à mesma sub-rede do IPv4 informado"}, nil
			}
		}
	}
	if !adminStatus() {
		return IPConfigResult{Sucesso: false, Mensagem: "Privilégios de administrador necessários. Clique em 'Elevar' para reiniciar como admin."}, nil
	}
	runNetsh := func(args ...string) (string, error) {
		ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		cmd := exec.CommandContext(ctx, "netsh", args...)
		configureCommandNoWindow(cmd)
		out, err := cmd.CombinedOutput()
		if ctx.Err() == context.DeadlineExceeded {
			return "", errors.New("netsh excedeu o tempo limite")
		}
		return strings.TrimSpace(decodeSystemOutput(out)), err
	}
	if dhcp {
		msg, err := runNetsh("interface", "ipv4", "set", "address", "name="+iface, "source=dhcp")
		if err != nil {
			return IPConfigResult{Sucesso: false, Mensagem: msg}, nil
		}
		if _, err = runNetsh("interface", "ipv4", "set", "dnsservers", "name="+iface, "source=dhcp"); err != nil {
			return IPConfigResult{Sucesso: false, Mensagem: "DHCP de endereço ativado, mas houve falha ao configurar DNS automaticamente"}, nil
		}
		reportLog("[Configuração IP] DHCP ativado em %s", iface)
		return IPConfigResult{Sucesso: true, Mensagem: "DHCP ativado em " + iface}, nil
	}
	args := []string{"interface", "ipv4", "set", "address", "name=" + iface, "static", parsedIP.To4().String(), mascara}
	if gateway != "" {
		args = append(args, gateway, "1")
	}
	msg, err := runNetsh(args...)
	if err != nil {
		return IPConfigResult{Sucesso: false, Mensagem: msg}, nil
	}
	reportLog("[Configuração IP] IPv4 estático configurado em %s", iface)
	return IPConfigResult{Sucesso: true, Mensagem: "IP estático configurado em " + iface}, nil
}

// ---------------------------------------------------------------------------
// 30) TESTE DE PRONTIDÃO IPv6
// ---------------------------------------------------------------------------

type IPv6Result struct {
	IPv6Global    string `json:"ipv6Global"`
	Conectividade bool   `json:"conectividade"`
	DNSv6         bool   `json:"dnsv6"`
	Mensagem      string `json:"mensagem"`
}

func (a *App) TestarProntidaoIPv6() (IPv6Result, error) {
	res := IPv6Result{Mensagem: "Analisando IPv6..."}

	ifaces, err := net.Interfaces()
	if err != nil {
		return res, err
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && ipnet.IP.To16() != nil && ipnet.IP.To4() == nil {
				if !ipnet.IP.IsLinkLocalUnicast() && !ipnet.IP.IsLoopback() {
					res.IPv6Global = ipnet.IP.String()
					break
				}
			}
		}
		if res.IPv6Global != "" {
			break
		}
	}

	conn, err := net.DialTimeout("tcp", "[2606:4700:4700::1111]:53", 5*time.Second)
	if err == nil {
		conn.Close()
		res.Conectividade = true
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	resolver := &net.Resolver{PreferGo: true}
	ips, err := resolver.LookupIPAddr(ctx, "ipv6.google.com")
	res.DNSv6 = err == nil && len(ips) > 0

	switch {
	case res.IPv6Global != "" && res.Conectividade:
		res.Mensagem = "IPv6 está ativo e funcional."
	case res.IPv6Global != "":
		res.Mensagem = "IPv6 local detectado, mas sem conectividade externa."
	default:
		res.Mensagem = "Nenhum endereço IPv6 global detectado."
	}
	reportLog("[IPv6] global=%v | conectividade=%v | DNSv6=%v", res.IPv6Global != "", res.Conectividade, res.DNSv6)
	return res, nil
}

// ---------------------------------------------------------------------------
// 31) CREDENCIAIS SEGURAS (DPAPI Windows / fallback outras plataformas)
// ---------------------------------------------------------------------------

func credentialFilePath(nome string) (string, error) {
	nome = strings.TrimSpace(nome)
	if nome == "" {
		return "", errors.New("nome da credencial obrigatório")
	}
	if len([]rune(nome)) > 128 {
		return "", errors.New("nome da credencial muito longo")
	}
	for _, r := range nome {
		if r < 32 {
			return "", errors.New("nome da credencial contém caracteres inválidos")
		}
	}
	base := os.Getenv("LOCALAPPDATA")
	if strings.TrimSpace(base) == "" {
		var err error
		base, err = os.UserConfigDir()
		if err != nil || strings.TrimSpace(base) == "" {
			return "", errors.New("não foi possível localizar uma pasta segura para credenciais")
		}
	}
	dir := filepath.Join(base, "NetZonia", "credentials")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	h := sha256.Sum256([]byte(nome))
	return filepath.Join(dir, hex.EncodeToString(h[:])+".enc"), nil
}

func (a *App) SalvarCredencialSegura(nome, valor string) (bool, error) {
	if len([]byte(valor)) > 1024*1024 {
		return false, errors.New("valor da credencial excede o limite de 1 MiB")
	}
	path, err := credentialFilePath(nome)
	if err != nil {
		return false, err
	}
	encrypted, err := dpapiEncrypt([]byte(valor))
	if err != nil {
		return false, fmt.Errorf("falha ao encriptar: %w", err)
	}
	if err := atomicWriteFile(path, encrypted, 0o600); err != nil {
		return false, err
	}
	reportLog("[Credenciais] credencial protegida salva")
	return true, nil
}

func (a *App) CarregarCredencialSegura(nome string) (string, error) {
	path, err := credentialFilePath(nome)
	if err != nil {
		return "", err
	}
	data, err := os.ReadFile(path)
	if len(data) > 2*1024*1024 {
		return "", errors.New("arquivo de credencial excede o tamanho esperado")
	}
	if os.IsNotExist(err) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	decrypted, err := dpapiDecrypt(data)
	if err != nil {
		return "", fmt.Errorf("falha ao decriptar: %w", err)
	}
	reportLog("[Credenciais] credencial protegida recuperada")
	return string(decrypted), nil
}
