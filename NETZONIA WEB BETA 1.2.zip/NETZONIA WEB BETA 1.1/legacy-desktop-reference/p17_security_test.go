package main

import (
	"math"
	"net"
	"strings"
	"testing"
)

func TestValidatePort(t *testing.T) {
	cases := []struct {
		in, def, want int
		ok            bool
	}{
		{0, 22, 22, true}, {1, 0, 1, true}, {65535, 0, 65535, true},
		{-1, 0, 0, false}, {65536, 0, 0, false}, {0, 0, 0, false},
	}
	for _, tc := range cases {
		got, err := validatePort(tc.in, tc.def)
		if tc.ok && (err != nil || got != tc.want) {
			t.Fatalf("validatePort(%d): got=%d err=%v", tc.in, got, err)
		}
		if !tc.ok && err == nil {
			t.Fatalf("validatePort(%d) deveria falhar", tc.in)
		}
	}
}

func TestSNMPValidationBlocksInjection(t *testing.T) {
	badCommunities := []string{"", "-c", "public\nwhoami", strings.Repeat("a", 129)}
	for _, v := range badCommunities {
		if _, err := validateSNMPCommunity(v); err == nil {
			t.Errorf("community %q deveria falhar", v)
		}
	}
	badOIDs := []string{"1.3.6;whoami", "$(whoami)", "-1.3.6", "1..3", strings.Repeat("1", 300)}
	for _, v := range badOIDs {
		if _, err := validateOID(v); err == nil {
			t.Errorf("OID %q deveria falhar", v)
		}
	}
	if _, err := validateSNMPCommunity("public"); err != nil {
		t.Fatal(err)
	}
	if _, err := validateOID("1.3.6.1.2.1.1.3.0"); err != nil {
		t.Fatal(err)
	}
}

func TestPPPoEProfileValidation(t *testing.T) {
	bad := []string{"abc\ndef", "[evil]", `..\\evil`, `a/b`, strings.Repeat("a", 65)}
	for _, v := range bad {
		if _, err := validatePPPoEProfile(v); err == nil {
			t.Errorf("perfil %q deveria falhar", v)
		}
	}
	for _, v := range []string{"NetZonia_Temp", "Minha Conexao-01", "perfil.teste"} {
		if _, err := validatePPPoEProfile(v); err != nil {
			t.Errorf("perfil válido %q: %v", v, err)
		}
	}
}

func TestIPv4MaskContiguous(t *testing.T) {
	for _, v := range []string{"255.255.255.0", "255.255.0.0", "255.255.255.252"} {
		if _, err := validateIPv4Mask(v); err != nil {
			t.Errorf("máscara válida %s: %v", v, err)
		}
	}
	for _, v := range []string{"255.0.255.0", "255.255.255.1", "abc"} {
		if _, err := validateIPv4Mask(v); err == nil {
			t.Errorf("máscara %s deveria falhar", v)
		}
	}
}

func TestVLSMAdversarialInputsDoNotPanic(t *testing.T) {
	a := &App{}
	bad := []struct {
		bloco string
		hosts []int
	}{
		{"x", []int{10}}, {"2001:db8::/64", []int{10}}, {"192.168.1.0/24", []int{-1}},
		{"192.168.1.0/24", []int{0}}, {"192.168.1.0/24", []int{1000000000}},
	}
	for _, tc := range bad {
		func() {
			defer func() {
				if r := recover(); r != nil {
					t.Fatalf("panic em %#v: %v", tc, r)
				}
			}()
			if _, err := a.CalcularVLSM(tc.bloco, tc.hosts); err == nil {
				t.Errorf("entrada %#v deveria retornar erro", tc)
			}
		}()
	}
}

func TestVLSMNormal(t *testing.T) {
	a := &App{}
	res, err := a.CalcularVLSM("192.168.10.0/24", []int{100, 50, 20})
	if err != nil {
		t.Fatal(err)
	}
	if len(res) != 3 {
		t.Fatalf("esperava 3 sub-redes, obteve %d", len(res))
	}
	for _, r := range res {
		if _, _, err := net.ParseCIDR(r.Rede); err != nil {
			t.Fatalf("rede inválida gerada: %s", r.Rede)
		}
	}
}

func TestCalculatorsRejectNonFiniteAndInvalidRanges(t *testing.T) {
	a := &App{}
	if _, err := a.CalcularOrcamentoOptico(1, math.NaN(), 0.35, nil); err == nil {
		t.Error("GPON deveria rejeitar NaN")
	}
	if _, err := a.CalcularBandaCFTV("1080p", 0, 1, 1, "h264"); err == nil {
		t.Error("CFTV deveria rejeitar FPS zero")
	}
	if _, err := a.ConverterGrandezas("mw_dbm", 0); err == nil {
		t.Error("mw_dbm deveria rejeitar zero")
	}
}

func TestSafeCSVCell(t *testing.T) {
	for _, s := range []string{"=CMD()", "+1+1", "-2+3", "@SUM(A1)"} {
		if got := safeCSVCell(s); !strings.HasPrefix(got, "'") {
			t.Errorf("%q não neutralizado: %q", s, got)
		}
	}
	if got := safeCSVCell("Cabo UTP"); got != "Cabo UTP" {
		t.Errorf("conteúdo normal alterado: %q", got)
	}
}

func TestPlaceIDValidation(t *testing.T) {
	for _, s := range []string{"osm_node_123", "ChIJ-abc.def"} {
		if err := validatePlaceID(s); err != nil {
			t.Errorf("placeID válido: %v", err)
		}
	}
	for _, s := range []string{"../segredo", "C:\\temp", "a/b", ""} {
		if err := validatePlaceID(s); err == nil {
			t.Errorf("placeID %q deveria falhar", s)
		}
	}
}

func FuzzValidateHostNoPanic(f *testing.F) {
	for _, s := range []string{"localhost", "1.1.1.1", ";whoami", strings.Repeat("a", 300)} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) { _ = validateHost(s) })
}

func FuzzValidateOIDNoPanic(f *testing.F) {
	for _, s := range []string{"1.3.6.1.2.1", "", "1..3", "$(id)"} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) { _, _ = validateOID(s) })
}
