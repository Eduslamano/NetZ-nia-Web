package main

import (
	"context"
	"sync"
)

// App é o objeto exposto pelo Wails ao frontend.
type App struct {
	ctx context.Context

	watchdogMu     sync.Mutex
	watchdogCancel context.CancelFunc

	pingMu     sync.Mutex
	pingCancel context.CancelFunc
}

func NewApp() *App {
	return &App{}
}

func (a *App) startup(ctx context.Context) {
	a.ctx = ctx
	initAppLogger()
	prepareProductionRuntime()
	if err := ensureProductionStorageWritable(); err != nil {
		logAppError("preflight armazenamento", err)
	}
}

func (a *App) shutdown(ctx context.Context) {
	a.watchdogMu.Lock()
	if a.watchdogCancel != nil {
		a.watchdogCancel()
		a.watchdogCancel = nil
	}
	a.watchdogMu.Unlock()
	a.pingMu.Lock()
	if a.pingCancel != nil {
		a.pingCancel()
		a.pingCancel = nil
	}
	a.pingMu.Unlock()
	a.PararServidorLAN()
	closeAppLogger()
}
