# Auditoria de migração — NETZÔNIA Desktop → NETZÔNIA Web

Auditoria real do código em `legacy-desktop-reference/` (não modificado), feita antes de qualquer
implementação na aplicação Web. Base: `backend.go`, `novos_modulos.go`, `orcamento.go`, `projetos.go`,
`geocodificacao.go`, `security.go`, `mapa3d.go`, `production_hardening.go`, `windows_native.go`,
`platform_stubs.go`, `command_helpers_nonwindows.go`, e os testes `*_test.go`.

## 1. Confirmação das 31 funções no código legado

Todas as 31 funções existem como métodos públicos `func (a *App) ...` (bindings Wails), confirmadas por
`grep` — nenhuma foi inferida por documentação. Localização real:

| # | Função | Método Go | Arquivo |
|---|---|---|---|
| 1 | Testar Velocidade | `TestarVelocidade` | backend.go:216 |
| 2 | Listar Dispositivos | `ListarDispositivos` | backend.go:466 |
| 3 | Acessar Painel do Roteador | `AcessarRoteador` | backend.go:613 |
| 4 | Reparar Conexão | `RepararConexao` | backend.go:675 |
| 5 | Analisar Canais Wi-Fi | `AnalisarWifi` | backend.go:801 |
| 6 | Testar Latência | `TestarLatencia(host)` | backend.go:878 |
| 7 | Gerar Relatório TXT | `GerarRelatorioTXT` / `SalvarRelatorioComo` | backend.go:908/910 |
| 8 | Traceroute Visual | `Traceroute(host)` | backend.go:965 |
| 9 | Scanner Portas TCP | `ScannerPortas(host)` | backend.go:1006 |
| 10 | Informações Adaptador | `InfoAdaptador` | backend.go:1054 |
| 11 | Teste DNS | `TesteDNS(hostname)` | backend.go:1105 |
| 12 | Watchdog | `IniciarWatchdog`/`PararWatchdog` | backend.go:1153/1214 |
| 13 | IP Externo + Geolocalização | `IPExterno` | backend.go:1289 |
| 14 | MTU | `TesteMTU(host)` | backend.go:1365 |
| 15 | VLSM | `CalcularVLSM(bloco, hosts)` | novos_modulos.go:43 |
| 16 | Orçamento Óptico GPON/FTTH | `CalcularOrcamentoOptico(...)` | novos_modulos.go:147 |
| 17 | Banda CFTV | `CalcularBandaCFTV(...)` | novos_modulos.go:187 |
| 18 | Conversor Telecom | `ConverterGrandezas(tipo, valor)` | novos_modulos.go:227 |
| 19 | Terminal SSH | `ExecutarSSH(...)` | novos_modulos.go:346 |
| 20 | Wake-on-LAN | `WakeOnLAN(mac, broadcast)` | novos_modulos.go:435 |
| 21 | Ping Sonoro | `IniciarPingSonoro`/`PararPingSonoro` | novos_modulos.go:492/543 |
| 22 | PPPoE | `TestarPPPoE(...)` | novos_modulos.go:563 |
| 23 | Servidor LAN | `IniciarServidorLAN`/`PararServidorLAN` | novos_modulos.go:665/740 |
| 24 | Gerador String Wi-Fi | `GerarStringWiFi(ssid, senha, tipoSeg)` | novos_modulos.go:760 |
| 25 | SNMP | `ConsultaSNMP(host, community, oid)` | novos_modulos.go:787 |
| 26 | SSL | `ValidarCertificadoSSL(host, port)` | novos_modulos.go:854 |
| 27 | Gerador Senhas | `GerarSenha(...)` | novos_modulos.go:906 |
| 28 | Atalhos Windows | `AbrirAtalhoSistema(atalho)` | novos_modulos.go:944 |
| 29 | Configuração Rápida IP | `ConfigurarIP(...)` | novos_modulos.go:1013 |
| 30 | Prontidão IPv6 | `TestarProntidaoIPv6` | novos_modulos.go:1112 |
| 31 | Credenciais Seguras | `SalvarCredencialSegura`/`CarregarCredencialSegura` | novos_modulos.go:1194/1213 |

O frontend legado (`frontend/src/data/features.js`, 489 linhas) já mapeia cada uma das 31 com `id`,
`number`, `type` de UI (`instant`, `host-input`, `form`, `watchdog`, `report`, `ping-sound`,
`lan-server`, `ip-config`, `credentials`) e `bridgeFn` (nome do binding Wails). Esse arquivo é uma boa
fonte para os formulários da Web, mas o `bridgeFn` precisa ser reapontado para chamadas HTTP à API Go —
não existe `window.go/wails` no navegador.

## 2. Classificação para a Web

| # | Função | Classe | Observação técnica real |
|---|---|---|---|
| 1 | Velocidade | `SERVER_API` | Mede a partir do servidor Go, não do link do usuário; UI deve deixar isso explícito |
| 2 | Dispositivos | `LOCAL_AGENT_REQUIRED` | Depende de ARP/sub-rede local da máquina do usuário |
| 3 | Painel do Roteador | `HYBRID` | Web pode abrir `http://<gateway>` informado pelo usuário; detecção automática do gateway é local |
| 4 | Reparar Conexão | `DESKTOP_ONLY` | Usa comandos nativos Windows (`netsh`, `ipconfig /release` etc., ver `windows_native.go`) |
| 5 | Wi-Fi (canais) | `LOCAL_AGENT_REQUIRED` | Depende de adaptador Wi-Fi local |
| 6 | Latência | `SERVER_API` | ICMP/echo a partir do servidor; explicitar ponto de medição |
| 7 | Relatório TXT | `WEB_NATIVE` | Puramente geração de texto a partir de dados já coletados |
| 8 | Traceroute | `SERVER_API` | A partir do servidor; agente futuro para perspectiva do cliente |
| 9 | Scanner de Portas | `SERVER_API` | Com limites fortes de host/porta/rate — ver seção 5 |
| 10 | Info Adaptador | `LOCAL_AGENT_REQUIRED` | WMI/registro Windows |
| 11 | Teste DNS | `SERVER_API` | Resolve a partir do servidor contra 5 resolvers fixos |
| 12 | Watchdog | `SERVER_API` (MVP) | Loop de ping por sessão; monitor persistente real é pós-MVP |
| 13 | IP Externo | `SERVER_API` | IP do servidor visto por fora não é o IP do usuário — **precisa alternativa client-side (ver seção 5)** |
| 14 | MTU | `SERVER_API` | A partir do servidor |
| 15 | VLSM | `WEB_NATIVE` | Cálculo puro — migração completa prioritária |
| 16 | Óptico GPON/FTTH | `WEB_NATIVE` | Cálculo puro |
| 17 | Banda CFTV | `WEB_NATIVE` | Cálculo puro |
| 18 | Conversor Telecom | `WEB_NATIVE` | Cálculo puro |
| 19 | SSH | `SERVER_API` | Backend autenticado; nunca credencial em texto no frontend |
| 20 | Wake-on-LAN | `HYBRID` | Pacote broadcast só tem efeito se o servidor estiver na mesma LAN do alvo |
| 21 | Ping Sonoro | `HYBRID` | Ping via servidor + áudio via Web Audio API no navegador |
| 22 | PPPoE | `DESKTOP_ONLY` | Usa RAS/`rasdial` do Windows (`windows_native.go`) |
| 23 | Servidor LAN | `DESKTOP_ONLY` (MVP) | Sobe servidor de arquivos na máquina local do usuário |
| 24 | Gerador String Wi-Fi | `WEB_NATIVE` | Cálculo puro |
| 25 | SNMP | `SERVER_API` | Depende de `snmpget` externo no host — ver seção 5 |
| 26 | SSL | `SERVER_API` | Handshake TLS a partir do servidor |
| 27 | Gerador de Senhas | `WEB_NATIVE` | Migrar para Web Crypto (`crypto.getRandomValues`), preservando o mesmo conjunto de caracteres |
| 28 | Atalhos Windows | `DESKTOP_ONLY` | Abre `control.exe`/`.cpl` do Windows |
| 29 | Configuração Rápida IP | `DESKTOP_ONLY` | Grava configuração de rede da máquina local |
| 30 | Prontidão IPv6 | `SERVER_API` | Testa a partir do servidor; IPv6 do cliente exige verificação no navegador |
| 31 | Credenciais Seguras | `SERVER_API` (redesenho) | Legado usa DPAPI (Windows only) — Web precisa de outro modelo, ver seção 5 |

## 3. Dependências Wails/Windows identificadas

- `windows_native.go` (133 linhas): comandos `netsh`, `rasdial`, `.cpl` — usados por Reparar Conexão,
  PPPoE, Atalhos, Configuração de IP. `platform_stubs.go` e `command_helpers_nonwindows.go` mostram que o
  próprio legado já teve o cuidado de isolar isso por build tag (`GOOS`), o que confirma que dá para
  reaproveitar a mesma separação na Web (essas funções simplesmente não têm implementação de servidor).
- `wailsruntime` (`github.com/wailsapp/wails/v2/pkg/runtime`) é importado em `novos_modulos.go` para
  eventos (`EventsEmit`, usado por Watchdog/Ping Sonoro) — na Web isso deve virar Server-Sent Events ou
  WebSocket, não polling arbitrário.
- `SalvarCredencialSegura`/`CarregarCredencialSegura` (novos_modulos.go:1194) usam armazenamento local do
  SO (indicado no relatório do legado como DPAPI/keyring) — não existe equivalente direto no navegador;
  a Web precisa de um modelo server-side com Auth (Supabase), não pode ser client-only.
- Projetos (`projetos.go`) hoje gravam JSON em disco local via `SalvarProjetoLocal`/`CarregarProjetoLocal`/
  `ListarProjetosLocais` — a Web reaproveita a mesma forma (chave = `placeID`, valor = JSON do projeto),
  mudando o adapter para `localStorage`/IndexedDB no MVP e Supabase depois.
- `IPExterno` (backend.go:1289) e `geocodificacao.go` (Nominatim) dependem de rede de saída do processo
  Go — no Desktop isso é a rede do usuário; no servidor Web será a rede do servidor. Para IP externo do
  **usuário**, a única forma correta na Web é o navegador chamar um serviço de IP diretamente (ou o
  próprio endpoint de request do servidor Web, que expõe o IP de quem chamou a API, não do processo).

## 4. Regras reaproveitáveis — validação (`security.go`)

`security.go` (134 linhas) contém validadores puros e testáveis, sem qualquer dependência de Wails:
`validateHost`, `validatePort`, `validateBoundedText`, `validateSNMPCommunity`, `validateOID`,
`validatePPPoEProfile`, `validateIPv4Mask`, `validateFinite`, `validatePlaceID`. Todos são portáveis 1:1
para o backend Go da Web (mesma linguagem, zero dependência de SO) e devem ser reaproveitados
literalmente para manter o mesmo padrão de segurança (bloqueio de argument injection, limites de
tamanho, regex RFC 1123 para host).

## 5. Pontos de atenção antes de implementar (não resolvidos ainda; não são decisão automática)

1. **IP Externo do usuário**: o legado roda no computador do usuário, então `IPExterno` reflete a rede
   dele. No servidor Web isso muda de significado — a UI precisa deixar claro que é o IP visto pelo
   servidor (para geolocalização de infraestrutura), e não fingir ser o IP do visitante.
2. **Scanner de Portas / SNMP**: dependem de rede alcançável a partir do servidor. Em produção, isso
   pode ser abusado para varredura de terceiros a partir da infraestrutura da Netzônia. A Fase D precisa
   de rate limiting, allowlist ou aviso explícito de "escopo autorizado" — não é uma função de cálculo
   puro como VLSM.
3. **SNMP depende de binário externo `snmpget`** no host do servidor Go — se o servidor de produção não
   tiver esse binário instalado, a função falha com erro claro (o próprio legado já trata isso). Isso
   precisa estar documentado como dependência operacional, não escondido.
4. **Credenciais Seguras**: o modelo DPAPI do Desktop não migra. Redesenho real (Auth por usuário via
   Supabase + segredo cifrado server-side) é maior que uma tradução de função e depende da Fase E
   (Supabase) estar pronta — por isso fica classificada `PREPARADO, AGUARDANDO SUPABASE` e não
   implementada como cofre funcional no MVP local.
5. **Watchdog/Ping Sonoro contínuos**: o legado usa eventos Wails (processo desktop de longa duração). Um
   servidor HTTP stateless não deve manter goroutines de monitoramento por usuário indefinidamente sem
   desenho de recursos (timeout, limite por sessão) — está escopado para o tempo de uma aba aberta no
   MVP, não um serviço 24/7.

## 6. Planejador 3D — regras confirmadas em `mapa3d.go` (235 linhas)

- Limite de **90 m** para cabeamento metálico (`LimiteCanalMetalicoM = 90.0`, linha 24), correspondente
  ao enlace permanente EIA/TIA (90 m + 10 m de patch cords = 100 m de canal).
- Fibra é imune ao limite de 90 m e a EMI (`LimiteM = 0` para tipo `"fibra"`).
- Cabo `"blindado"` mantém o mesmo limite de 90 m, mas **atenua** (não elimina) o alerta de EMI; cabo
  `"nao-blindado"` gera alerta forte.
- Detecção de EMI usa distância ponto-a-segmento no plano XZ (`distanciaPontoSegmentoXZ`, linha 88) e
  checa se o **trajeto cruza ou passa dentro do raio** da zona de risco (`cruzaZonaRisco`, linha 123) —
  ou seja, já considera o segmento inteiro, não só os pontos inicial/final (a fusão P15+Enolla registrada
  na memória do usuário indica que esse é justamente o ponto que havia sido identificado como pendência
  nº 1 de correção; nesta cópia do legado a lógica de segmento já está implementada).
- `CalcularCabo(pontos, cabo, zonas)` (linha 158) é a função central e é pura o suficiente para ser
  portada com testes (`mapa3d_emi_test.go`, 39 linhas, já existe no legado).
- Frontend 3D legado (`legacy-desktop-reference/frontend/src/mapa3d/*` e a cópia em
  `frontend/src/mapa3d/legacy-reference/*` já preparada no scaffold Web) usa Canvas/lógica própria — a
  migração para Three.js (Fase F) deve portar `CalcularCabo` e as regras de rack/porta como módulos JS
  puros e testáveis, independentes da cena 3D, conforme pedido no prompt mestre.

## 7. Estrutura Web já recebida como scaffold (não é trabalho já feito, é ponto de partida)

- `frontend/src/data/{tools,features,categories,icons}.js`: já mapeiam as 31 funções e suas categorias
  visuais — reaproveitável para o dashboard.
- `frontend/src/main.js`: 3 linhas, vazio — Fase B precisa construir a aplicação real.
- `backend/cmd/server/main.go`: apenas um `/api/health` fixo em `ServeMux`, CORS `*` fixo (não
  configurável por ambiente) — Fase B precisa de roteamento real, CORS por ambiente e as demais rotas.
- `supabase/`: só contém `README.md`, sem migrations/schema/RLS ainda — Fase E parte do zero.
- **Ambiente de execução desta sessão**: sem Go instalado por padrão (instalado `golang-go` 1.22.2 via
  apt neste container); os `go.mod` do projeto (novo e legado) declaram `go 1.25`, e não há acesso de
  rede ao proxy de módulos Go neste ambiente (fora da allowlist de rede) para baixar o toolchain 1.25.
  Para este trabalho, o `go.mod` do backend novo foi ajustado para `go 1.22` (compatível com o toolchain
  disponível aqui); a equipe deve compilar/testar novamente com Go 1.25+ real antes da entrega, conforme
  já alertado em `docs/RELATORIO_PREPARACAO_CLAUDE.md`.

## 8. Conclusão da Fase A

Nenhum arquivo de `legacy-desktop-reference/` foi alterado. As 31 funções foram confirmadas por leitura
direta do código (não por suposição). A matriz de classificação acima substitui/detalha
`docs/MATRIZ_31_FUNCOES.md` com a leitura real do código; `MATRIZ_31_FUNCOES_FINAL.md` (Fase H) vai
registrar o status de implementação real por função ao final do trabalho desta sessão.
