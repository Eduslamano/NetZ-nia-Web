# Testes

## Executados nesta entrega

```text
npm test       → 17 aprovados, 0 falhas
npm run build  → sucesso
npm audit      → 0 vulnerabilidades
node --check   → todos os arquivos JS sem erro de sintaxe
gofmt          → nenhum arquivo pendente
go test ./...  → sucesso em todos os pacotes
go vet ./...   → sucesso
go build       → sucesso com -buildvcs=false no diretório extraído do ZIP
```

Os testes cobrem CRUD/busca/renomeação/duplicação, timestamps, corrupção de armazenamento, debounce e
recuperação do autosave, fluxo crítico salvar/reabrir/relatório, serialização defensiva, piso, parede,
teto, rack/U sincronizado, portas explícitas, cabos, 90 m, EMI e fibra. No Go, cobrem cálculos,
endpoints, validação JSON, SSRF, CORS, proxy confiável, IP de origem, WOL opt-in e magic packet.

## Execução real dos serviços

Backend e Vite foram iniciados simultaneamente. Foram confirmados por HTTP real:

- HTML e módulos `main.js`/`planner3d.js` entregues pelo Vite;
- `/api/health` e CORS para `http://127.0.0.1:5173`;
- VLSM, GPON/FTTH, CFTV, Conversor, String Wi-Fi e Gerador de Senhas;
- WOL desativado por padrão retornando HTTP 403;
- IP de origem e endpoint DNS.

SSL e Latência rejeitaram a tentativa externa porque o sandbox não conseguiu acessar seu resolvedor
DNS (`network is unreachable`). As rotas, validações e bloqueio SSRF foram testados automaticamente,
mas a conexão pública real deve ser repetida em homologação com rede liberada.

## Limitações reais

- O navegador remoto tentou abrir `http://127.0.0.1:5173` e retornou `ERR_BLOCKED_BY_CLIENT`.
  Portanto **não houve validação visual WebGL**, nem verificação visual de console/renderização.
- Docker, Postgres e Supabase CLI não estão instalados; os Dockerfiles foram revisados, mas não
  executados. Auth/RLS permanecem preparados para validação na instância do Edu.
- O npm emite um aviso do ambiente sobre `http-proxy`; a auditoria encontrou 0 vulnerabilidades.

## Checklist manual obrigatório

1. iniciar backend e frontend;
2. criar projeto;
3. abrir ferramenta VLSM e executar;
4. confirmar resultado salvo no relatório;
5. abrir Planner;
6. adicionar rack, switch e roteador;
7. mover e rotacionar;
8. criar cabo ORIGEM → DESTINO;
9. confirmar portas ocupadas e validação;
10. aguardar indicador “Salvo”;
11. recarregar a página;
12. abrir o projeto e conferir restauração;
13. baixar relatório TXT;
14. testar desktop, tablet e teclado;
15. verificar o console do navegador durante todo o fluxo;
16. repetir Auth/RLS com duas empresas em Supabase real;
17. testar SSL e Latência com saída DNS/TCP liberada;
18. executar `docker compose up --build` em host com Docker.
