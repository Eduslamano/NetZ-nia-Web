# Guia Supabase para Carlos Edu

## Objetivo e estado atual

O código de Auth, os repositórios, as migrations e as políticas RLS estão **preparados**, mas não
foram validados contra uma instância real nesta entrega. Faça primeiro em um projeto de homologação,
nunca diretamente em produção.

## 1. Criar o projeto

1. Entre no painel do Supabase com a conta da equipe.
2. Crie um projeto novo e escolha a região mais próxima dos usuários.
3. Defina uma senha forte para o Postgres e guarde-a fora do Git.
4. Aguarde o status do projeto ficar saudável.

## 2. Obter URL e chave pública

No painel, abra **Project Settings → API** (ou a área equivalente da versão atual do painel):

- copie a **Project URL** para `VITE_SUPABASE_URL`;
- copie somente a chave pública **publishable** ou **anon** para `VITE_SUPABASE_ANON_KEY`.

Não use no frontend: `service_role`, senha do Postgres, JWT secret ou token pessoal.

## 3. Configurar o ambiente

Na pasta `frontend`, crie `.env.local` (esse arquivo é ignorado pelo Git):

```env
VITE_API_BASE_URL=http://localhost:8080
VITE_SUPABASE_ENABLED=true
VITE_SUPABASE_URL=https://SEU-PROJETO.supabase.co
VITE_SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA
```

Para o backend local, use as variáveis `NETZONIA_*` documentadas em `.env.example`. O backend Go
não precisa da `service_role` para o fluxo atual.

## 4. Executar migrations e policies

No **SQL Editor**, execute um arquivo por vez e exatamente nesta ordem:

1. `supabase/migrations/0001_init.sql`
2. `supabase/migrations/0002_phase2_projects.sql`
3. `supabase/migrations/0003_release_candidate_hardening.sql`
4. `supabase/policies/0001_rls_policies.sql`
5. `supabase/policies/0002_hardened_rls.sql`

O arquivo `0002_hardened_rls.sql` substitui as políticas iniciais por versões que evitam recursão em
`company_members`. Não inverta a ordem. Depois confirme no painel que RLS continua ativada em:
`profiles`, `companies`, `company_members`, `projects` e `project_data`.

## 5. Configurar Auth e criar o primeiro usuário

1. Em **Authentication → Providers**, mantenha Email/Password habilitado.
2. Para homologação, decida conscientemente se confirmação por e-mail ficará ativa.
3. Em **Authentication → Users**, crie o usuário de teste do Edu ou use o cadastro permitido pelo
   projeto Supabase.
4. Não insira manualmente empresa/membership antes do primeiro login.

## 6. Criar a primeira empresa e associação

1. Inicie backend e frontend.
2. Abra `#/conta` e entre com o primeiro usuário.
3. Informe o nome da empresa.
4. A tela chama `create_company_with_owner`, que cria de forma transacional:
   - o `profile` do usuário;
   - a `company`;
   - a associação em `company_members` com papel `owner`.
5. Confirme no Table Editor que as três linhas foram criadas.

Não crie a primeira associação usando inserts soltos: isso pode deixar empresa sem proprietário se
uma das operações falhar.

## 7. Testar login, logout e sessão

1. Entre com e-mail/senha corretos.
2. Recarregue a página e confirme que a sessão permanece.
3. Abra Projetos; não deve aparecer mensagem de empresa ausente.
4. Saia da conta e tente abrir `#/projetos`; a aplicação deve mostrar a tela de login.
5. Confira o console: não deve haver chave privada, senha ou token escrito em log.

## 8. Testar criação e persistência de projeto

1. Crie um projeto em **Meus Projetos**.
2. Renomeie, duplique e pesquise o projeto.
3. Abra o Planner, altere o ambiente, adicione equipamentos/rack/cabo e aguarde **Salvo**.
4. Recarregue, abra o mesmo projeto e confira a restauração.
5. Confirme no banco uma linha em `projects` e uma em `project_data` para o mesmo ID.

## 9. Testar isolamento entre empresas (obrigatório)

Crie duas contas e duas empresas independentes:

- Usuário A → Empresa A → Projeto A;
- Usuário B → Empresa B → Projeto B.

Valide com a chave pública, nunca com `service_role`:

1. A lista de A mostra Projeto A e não mostra Projeto B.
2. Copiar o UUID de Projeto B para uma requisição autenticada como A retorna zero linha/negação.
3. A não consegue alterar `projects` nem `project_data` de B.
4. A não consegue excluir projeto de B.
5. Repita B contra A.
6. Um membro comum pode editar projetos da própria empresa, mas somente owner/admin pode excluir.

Para teste avançado com Supabase CLI/psql, adapte os UUIDs em
`supabase/tests/rls_two_companies.sql`. Esse script usa `ROLLBACK` e não deve apontar para produção.

Só marque RLS como **validada** depois que todos esses casos passarem em instância real.

## 10. Erros comuns

| Sintoma | Causa provável | Correção |
|---|---|---|
| “Supabase ativado sem URL/chave” | `.env.local` incompleto | Preencher as variáveis Vite e reiniciar o Vite |
| Login funciona, mas Projetos não abre | usuário sem membership | Abrir Conta e criar empresa; verificar RPC e tabelas |
| “infinite recursion detected” | policy 0002 não aplicada | Executar `0002_hardened_rls.sql` após a policy 0001 |
| Projeto não salva | RLS, limite de 4 MiB ou migration ausente | Ver logs e aplicar migrations na ordem |
| Alteração não aparece | Vite manteve env antigo | Encerrar e iniciar `npm run dev` novamente |
| Usuário A vê dados de B | falha crítica de RLS | Suspender homologação e revisar policies |

## 11. Voltar ao modo local

No `.env.local`, altere apenas:

```env
VITE_SUPABASE_ENABLED=false
```

Reinicie o Vite. A aplicação voltará ao `LocalProjectRepository` e mostrará **MODO LOCAL** no topo.
Projetos locais e projetos Supabase são armazenamentos diferentes; desativar Supabase não copia nem
apaga dados da nuvem.

## 12. Checklist de conclusão do Edu

- [ ] migrations 0001, 0002 e 0003 executadas;
- [ ] policies 0001 e 0002 executadas;
- [ ] somente chave pública no frontend;
- [ ] login/logout/sessão testados;
- [ ] criação de empresa/owner testada;
- [ ] CRUD e persistência do projeto testados;
- [ ] isolamento A ↔ B testado com chave pública;
- [ ] backup e logs configurados;
- [ ] resultados registrados no relatório de homologação.
