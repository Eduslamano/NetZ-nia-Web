# Matriz inicial das 31 funções

| # | Função | Estratégia Web inicial |
|---|---|---|
|1|Testar Velocidade|Adaptar para Web/API; distinguir cliente x servidor|
|2|Listar Dispositivos|Agente local/Desktop futuro; não simular|
|3|Acessar Painel do Roteador|Web pode orientar/abrir gateway informado; detecção local exige agente|
|4|Reparar Conexão|Desktop/agente local|
|5|Analisar Canais Wi-Fi|Desktop/agente local; Web exibe dados coletados|
|6|Testar Latência|API servidor; deixar claro ponto de medição|
|7|Gerar Relatório TXT|Web direto + persistência de projeto|
|8|Traceroute|API servidor; agente para perspectiva do cliente|
|9|Scanner Portas TCP|Backend com autorização/limites; não varredura indiscriminada|
|10|Informações Adaptador|Desktop/agente local|
|11|Teste DNS|Backend Go/Web|
|12|Watchdog|Backend/worker futuro; MVP pode monitorar sessão|
|13|IP Externo + Geolocalização|Web/API adaptada|
|14|MTU|Agente/backend conforme alvo; documentar perspectiva|
|15|VLSM|Migrar integralmente|
|16|Orçamento GPON/FTTH|Migrar integralmente|
|17|Banda CFTV|Migrar integralmente|
|18|Conversor Telecom|Migrar integralmente|
|19|Terminal SSH|Backend autenticado e controlado; nunca segredo no frontend|
|20|Wake-on-LAN|Backend/agente na LAN|
|21|Ping Sonoro|Web UI + backend/agente; áudio no navegador|
|22|PPPoE|Desktop/agente local|
|23|Servidor LAN|Desktop/agente; Web pode ter alternativa de download hospedado|
|24|Gerador String Wi-Fi|Migrar integralmente|
|25|SNMP|Backend/agente com segredos protegidos|
|26|SSL|Backend Go/Web|
|27|Gerador Senhas|Migrar integralmente com Web Crypto|
|28|Atalhos Windows|Não faz sentido no site; manter Desktop|
|29|Configuração Rápida IP|Desktop/agente local|
|30|Prontidão IPv6|Web parcial + backend/agente para diagnóstico completo|
|31|Credenciais Seguras|Substituir DPAPI por Auth/segredos server-side; nunca expor service role|
