# Arquitetura Web

## Limites do produto

```text
Frontend Vite/JavaScript
  ├─ Projetos e modo local
  ├─ Ferramentas
  ├─ Planner Three.js
  └─ Relatórios
       │ HTTP/JSON
Backend Go
  ├─ validação e rate limit
  └─ ferramentas SERVER_API

Persistência selecionável
  ├─ LocalProjectRepository → localStorage
  └─ SupabaseProjectRepository → Auth + PostgreSQL/RLS
```

O Desktop Wails não foi transformado em Web. Recursos que exigem a máquina/rede do usuário permanecem
no Desktop ou na arquitetura futura do Netzônia Agent.

## Projeto

`Project` contém `id`, `companyId`, `ownerId`, nome, descrição, timestamps, `schemaVersion`,
`revision` e `data`. O campo `data` agrega `planner3d` e `toolResults`. O repositório é trocado
por composição; páginas não conhecem o mecanismo de armazenamento.

## Frontend

- `pages/`: dashboard, detalhe, projetos, Planner, relatórios e conta.
- `repositories/`: contrato e adapters local/Supabase.
- `state/projectSession.js`: projeto ativo e resultados de ferramenta.
- `mapa3d/`: modelo, regras puras, persistência e engine Three.js.
- `services/`: API, Supabase e autosave.

## Backend

`cmd/server` inicia `internal/httpapi`, que valida corpos, limita tamanho, aplica CORS, headers e
rate limit. As regras ficam em `internal/tools`; validadores em `internal/validation`.

Conexões SSL/latência bloqueiam IPs privados, loopback, link-local e multicast para reduzir SSRF.
Diagnóstico de LAN pertence ao Agent. Wake-on-LAN exige `NETZONIA_ALLOW_WOL=true`.

## Fluxo crítico

Criar projeto → abrir → executar ferramenta → salvar resultado → abrir Planner → adicionar/mover
equipamentos → criar cabo → autosave → recarregar → restaurar → gerar relatório.
