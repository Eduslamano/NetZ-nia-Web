# Checklist Release Candidate

Legenda: itens marcados foram comprovados por teste automatizado, build ou execução HTTP real. Itens
visuais permanecem desmarcados porque o navegador remoto bloqueou `localhost`.

- [x] Backend inicia
- [x] Frontend inicia
- [x] Frontend ↔ Backend funciona
- [ ] Dashboard funciona — bundle/HTTP aprovados; interação visual não validada
- [x] Projetos listam — repositório automatizado
- [x] Projeto cria — repositório automatizado
- [x] Projeto salva — fluxo crítico automatizado
- [x] Autosave funciona — debounce, estado e recuperação de erro testados
- [x] Projeto reabre — fluxo crítico automatizado
- [x] Projeto duplica — repositório automatizado
- [x] Projeto exclui — repositório automatizado; confirmação visual pendente
- [ ] Planner abre — módulo entregue por HTTP, mas abertura visual bloqueada
- [ ] Three.js renderiza — sem validação visual WebGL
- [x] Piso funciona — regra geométrica automatizada
- [x] Parede funciona — superfície, plano, limites, orientação e restauração testados
- [x] Teto funciona — plano, limites e restauração testados
- [x] Rack funciona — regra e sincronização testadas
- [x] U funciona — alocação/conflito/persistência testados
- [x] Equipamentos funcionam — modelo/persistência testados por código
- [x] Portas funcionam — seleção, ocupação e reconstrução testadas
- [x] Origem/Destino funciona — endpoints lógicos explícitos testados
- [x] Cabos funcionam — criação, remoção associada e restauração testadas
- [x] EMI funciona — segmento, blindagem e fibra testados
- [x] Persistência 3D funciona — fluxo salvar/reabrir automatizado
- [x] Relatório TXT funciona — conteúdo gerado e testado
- [ ] Impressão funciona — código preservado; diálogo do navegador não validado
- [ ] Ferramentas prioritárias funcionam — cálculos/HTTP aprovados; SSL/Latência externos bloqueados pela rede do sandbox
- [x] Supabase repository pronto — preparado, sem instância real
- [x] Migrations prontas — revisão estática, sem Postgres real
- [x] RLS pronta — preparada para validação A ↔ B, não validada em produção
- [x] Auth pronto — arquitetura preparada, sem login Supabase real
- [x] Guia Edu criado
- [x] go test passa
- [x] go vet passa
- [x] npm test passa
- [x] npm build passa
- [x] npm audit revisado — 0 vulnerabilidades
- [x] Sem secrets — varredura final sem chaves privadas ou tokens conhecidos
- [x] Deploy documentado
- [x] Relatório Enolla criado

## Evidência da limitação visual

O navegador remoto tentou abrir `http://127.0.0.1:5173` e retornou
`ERR_BLOCKED_BY_CLIENT`. Não foi usada automação alternativa para contornar a restrição e não se
declara renderização Three.js validada.
