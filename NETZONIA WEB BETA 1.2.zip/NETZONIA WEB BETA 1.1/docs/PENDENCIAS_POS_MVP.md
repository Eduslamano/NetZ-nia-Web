# Pendências pós-MVP

1. Executar e validar migrations/Auth/RLS em Supabase real.
2. Realizar teste visual/manual do Planner em Chrome/Edge com WebGL.
3. Substituir placeholders pelos modelos GLB finais do Blender.
4. Implementar histórico/versionamento avançado e conflito otimista no autosave Supabase.
5. Construir Netzônia Agent para LAN, Wi-Fi, adaptadores e operações de SO.
6. Avaliar scanner, SSH e SNMP somente após Auth, auditoria, allowlist e limites específicos.
7. Implementar streaming controlado para Watchdog/Ping Sonoro.
8. Homologar Docker em domínio HTTPS real, com observabilidade e backup.
9. Executar testes de acessibilidade com leitor de tela e dispositivos reais.

Esses itens não são marcados como funcionais na matriz final.
