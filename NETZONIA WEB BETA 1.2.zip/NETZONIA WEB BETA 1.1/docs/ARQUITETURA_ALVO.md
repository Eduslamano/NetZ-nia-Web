# Arquitetura alvo

Navegador -> Frontend Web (Vanilla JS/Vite + Three.js) -> API Go -> Supabase PostgreSQL/Auth/Storage.

O Desktop Wails 1.0 permanece preservado em `legacy-desktop-reference` como referência. Recursos dependentes da máquina local não devem ser falsificados no navegador; classificar como servidor, agente local futuro ou Desktop.

## 3D
Migrar gradualmente do Canvas pseudo-3D para Three.js. Preservar regras técnicas já existentes: catálogo, racks/U, endpoints reais, portas, Origem/Destino, 90 m, EMI, fibra, persistência e orçamento. Modelos GLB do Blender devem ser substituíveis sem alterar regras.
