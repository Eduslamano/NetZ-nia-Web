# Relatório de preparação

A cópia recebida do NETZÔNIA REDE 3D OFICIAL 1.0 foi preservada integralmente como referência em `legacy-desktop-reference/` (com remoção apenas de eventuais binários de build/saída de instalador da cópia de trabalho para reduzir ruído).

Foi criada uma estrutura Web separada com frontend Vite/Vanilla JS, backend Go API, diretório Supabase, documentação de arquitetura, matriz das 31 funções, critérios de aceite, divisão da equipe e Prompt Mestre para Claude Code.

Nenhuma das 31 funções do legado foi alterada nesta preparação. O objetivo é permitir que Claude Code faça auditoria e migração controlada, mantendo o Desktop como fonte de verdade.

## Validação
O `main.go` do scaffold foi formatado com gofmt. A tentativa de `go test ./...` não pôde concluir neste ambiente porque o `go.mod` alvo usa Go 1.25 e o runtime disponível tentou baixar o toolchain 1.25, mas este ambiente não possui acesso ao proxy do Go. Isso não é registrado como teste aprovado; deve ser executado na máquina da equipe com Go 1.25+.
