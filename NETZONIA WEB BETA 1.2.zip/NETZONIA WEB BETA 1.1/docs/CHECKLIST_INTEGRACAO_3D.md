# Checklist de integração 3D

Marcação baseada apenas em comparação, teste automatizado, build ou execução realmente concluída.

- [x] RC original preservada — mudanças limitadas ao Planner, teste e relatórios solicitados
- [x] Desktop legado preservado — hashes idênticos
- [x] Auditoria Saulo realizada
- [x] Merge seletivo realizado
- [x] Three.js compila
- [ ] Planner inicializa — localhost bloqueado no navegador remoto
- [x] Equipment funciona — modelo/persistência e visual procedural testados
- [x] Floor funciona — restrição automatizada preservada
- [x] Wall funciona — superfície, plano e orientação testados
- [x] Ceiling funciona — plano e limites testados
- [x] Rack funciona — estrutura lógica e visual testadas
- [x] Rack U funciona — alocação, conflito e persistência testados
- [x] Ports funcionam — ocupação e reconstrução testadas
- [x] Origem/Destino funciona — endpoints e portas explícitas testados
- [x] Cabos funcionam — criação, remoção e restauração testadas
- [x] EMI funciona — interseção e mitigação testadas
- [x] Persistência funciona — serialização e fluxo salvar/reabrir testados
- [x] Projetos antigos continuam compatíveis — schema não alterado e restauração preservada
- [x] Model fallback funciona — falha simulada de GLB mantém procedural
- [x] npm test aprovado — 19 testes
- [x] npm build aprovado
- [x] npm audit revisado — 0 vulnerabilidades
- [ ] go test aprovado — Go indisponível nesta sessão
- [ ] go vet aprovado — Go indisponível nesta sessão
- [x] Nenhum secret introduzido — varredura final do pacote
- [x] Supabase preservado — hashes idênticos
- [x] Relatórios preservados — conteúdo anterior mantido; relatórios novos adicionados
- [x] 31 funções preservadas — módulos fora do Planner idênticos
- [ ] Validação visual realizada — pendente no PC do Yuri

## Limitações do ambiente

- navegador remoto: `ERR_BLOCKED_BY_CLIENT` ao acessar localhost;
- Go: ausente; tentativa de instalação recusada pelas permissões do gerenciador de pacotes.

