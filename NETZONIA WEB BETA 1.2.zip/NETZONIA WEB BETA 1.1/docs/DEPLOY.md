# Deploy

## Homologação com Docker

```bash
docker compose up --build
```

- Web: porta 8081.
- API: porta 8080.
- Nginx encaminha `/api/` internamente para o serviço Go.
- Healthcheck: `GET /api/health`.

Antes de produção:

1. definir domínio HTTPS;
2. restringir `NETZONIA_CORS_ORIGINS`;
3. manter `NETZONIA_ALLOW_WOL=false` fora de servidor autorizado na LAN;
4. definir `NETZONIA_TRUST_PROXY=true` somente atrás de proxy controlado;
5. configurar variáveis Supabase no build do frontend;
6. executar testes Go e frontend;
7. testar RLS com duas empresas;
8. centralizar logs e backups do Postgres.

Kubernetes não é necessário para o MVP.

Para o roteiro completo de Release Candidate, smoke test e rollback, consulte
`docs/DEPLOY_HOMOLOGACAO.md`.
