# Supabase

## Modo local

`VITE_SUPABASE_ENABLED=false` usa `LocalProjectRepository`. Não requer credenciais.

## Ativação

1. Criar projeto Supabase.
2. Aplicar, em ordem, `migrations/0001_init.sql`, `migrations/0002_phase2_projects.sql` e
   `migrations/0003_release_candidate_hardening.sql`.
3. Aplicar `policies/0001_rls_policies.sql` e depois `policies/0002_hardened_rls.sql`.
4. Configurar no frontend:
   - `VITE_SUPABASE_ENABLED=true`
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Criar usuário no Supabase Auth, entrar e criar a primeira empresa pela tela Conta.

A função transacional `create_company_with_owner` cria perfil, empresa e membership `owner`.
O passo a passo operacional completo está em `docs/GUIA_SUPABASE_EDU.md`.

## Segurança

- Somente chave pública publishable/anon no frontend.
- Nunca expor `service_role`, senha do Postgres ou JWT privado.
- A policy endurecida usa funções `security definer` no schema `private` para consultar membership
  sem recursão RLS.
- Projetos não podem trocar `company_id` ou `created_by` após a criação.
- Usuário só lê empresas/projetos em que possui membership.
- Exclusão de projeto requer `owner` ou `admin`.
- `project_data` deve ser um objeto JSON e tem limite de 4 MiB, também validado pelo frontend.

## Estado de validação

SQL e adapters foram revisados e o frontend compila, mas nenhuma migration/policy foi executada contra
um Supabase real nesta entrega. Não marcar RLS/Auth como testado até executar os casos multiempresa:
usuário A não pode listar, ler, alterar ou excluir dados da empresa B.
