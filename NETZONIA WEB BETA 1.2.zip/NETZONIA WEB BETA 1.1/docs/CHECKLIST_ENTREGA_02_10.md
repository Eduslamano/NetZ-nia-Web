# Checklist de entrega — 02/10/2026 (histórico da Fase 1)

> Documento histórico. O checklist atual está em `CHECKLIST_ENTREGA.md`.

Conferido item a item contra `docs/CRITERIOS_ACEITE_MVP.md`. ✅ = verificado nesta sessão; ⚠️ = parcial;
❌ = não feito.

| # | Critério | Status | Nota |
|---|---|---|---|
| 1 | Abre por URL e é responsivo (mobile/tablet/desktop) | ⚠️ | CSS responsivo herdado presente; sem teste manual em dispositivo real nesta sessão (sem ferramenta de teste visual disponível) |
| 2 | Dashboard, categorias, busca e páginas de ferramentas sem Wails | ✅ | `frontend/src/main.js`, `pages/dashboard.js`, `pages/toolDetail.js` — testado com `npm run build` e servido via Vite dev, confirmado end-to-end com o backend |
| 3 | API Go com healthcheck, validação, erros JSON consistentes, CORS configurável | ✅ | `backend/internal/httpapi` — testes automatizados + CORS testado com origem real (dev e produção simulada) |
| 4 | Ferramentas Web puras prioritárias com resultados reais, não mocks | ✅ | VLSM, Orçamento Óptico, CFTV, Conversor Telecom, Wi-Fi String, Gerador de Senhas — todas com teste automatizado comparando valores conhecidos |
| 5 | Recursos impossíveis no navegador marcados como Desktop/Agente, sem botão falso | ✅ | `frontend/src/data/toolStatus.js` + telas de estado honesto em `toolDetail.js` |
| 6 | Projetos funcionam localmente sem Supabase | ⚠️ | `LocalProjectRepository` funcional e testável por leitura de código, mas **não há tela de UI ligada a ele ainda** (ver pendência 4) |
| 7 | Camada Supabase pronta (schema/migrations/RLS/adapters/.env.example), credenciais não obrigatórias | ✅ | `supabase/migrations/`, `supabase/policies/`, `repositories/`, `.env.example` — nunca executado contra banco real (documentado) |
| 8 | 3D abre e funciona; regras preservadas; Three.js/GLB preparado | ❌ | Não iniciado nesta sessão — maior pendência, ver `PENDENCIAS_POS_MVP.md` item 1 |
| 9 | Sem segredos hardcoded; entradas validadas; XSS evitado; logs não vazam credenciais | ✅ | Validadores portados de `security.go`; frontend usa `escapeHtml`/`textContent` em vez de interpolação direta; nenhum segredo no repositório; `.env.example` só com nomes vazios |
| 10 | npm build/test/audit e gofmt/go test/go vet executados e documentados | ✅ (Go em 1.22, não 1.25 — ver nota) | Resultados reais em `docs/RELATORIO_FINAL_NETZONIA_WEB_MVP.md` |

## Itens fora dos 10 critérios formais, também verificados

- [x] `legacy-desktop-reference/` não foi alterada (verificado por timestamp de arquivos antes de gerar
      este checklist — 0 arquivos modificados).
- [x] Nenhuma credencial real commitada (`.env.example` só tem nomes de variáveis vazios).
- [x] `go vet ./...` sem avisos.
- [x] `gofmt -l .` sem saída (tudo formatado).
- [x] `npm audit` → 0 vulnerabilidades.

## Bloqueadores reais para "pronto para produção" em 02/10

1. Planejador 3D inexistente como código (critério 8 reprovado).
2. Tela de projetos não ligada ao repositório local (critério 6 parcial).
3. Responsividade/acessibilidade sem validação humana (critério 1 parcial).
4. Ambiente Go da equipe precisa reconfirmar em 1.25+ (item de processo, não de lógica).
5. Deploy real nunca testado.

Nenhum desses bloqueadores foi escondido ou marcado como resolvido — todos estão também em
`docs/PENDENCIAS_POS_MVP.md`, com o motivo técnico específico de cada um.
