# Critérios de aceite MVP Web

1. Abre por URL e é responsivo em desktop/notebook/mobile.
2. Dashboard, categorias, busca e páginas de ferramentas funcionam sem Wails.
3. API Go possui healthcheck, validação, erros JSON consistentes e CORS configurável.
4. Ferramentas Web puras prioritárias funcionam com resultados reais, não mocks.
5. Recursos impossíveis no navegador são marcados claramente como Desktop/Agente futuro, sem botões falsos.
6. Projetos funcionam localmente mesmo sem Supabase.
7. Camada Supabase está pronta: schema/migrations/RLS/adapters/.env.example, mas credenciais não são obrigatórias.
8. 3D abre e funciona; preservar regras técnicas existentes e preparar Three.js/GLB.
9. Sem segredos hardcoded; entradas validadas; XSS evitado; logs não vazam credenciais.
10. npm build/test/audit e gofmt/go test/go vet devem ser executados e resultados documentados.
