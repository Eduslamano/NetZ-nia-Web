# Deploy de homologação

## Pré-requisitos

- Docker Engine com Compose v2; ou Node.js 20+ e Go 1.22+ para execução sem containers.
- Projeto Supabase de homologação somente se o modo nuvem for testado.
- HTTPS e um proxy controlado antes de qualquer exposição pública.

## Opção A — Docker Compose

Na raiz do projeto:

```bash
docker compose config
docker compose up --build -d
docker compose ps
curl -f http://localhost:8080/api/health
```

- Web/Nginx: `http://localhost:8081`.
- API: `http://localhost:8080`.
- Nginx encaminha `/api/` para o container Go.
- WOL permanece desligado.

O Compose fornecido é para homologação local. Antes de expor, configure HTTPS, firewall, backup e
observabilidade. Não invente nem fixe domínio no código.

## Opção B — execução sem Docker

Terminal 1:

```bash
cd backend
NETZONIA_ENV=development NETZONIA_ADDR=:8080 go run ./cmd/server
```

Terminal 2:

```bash
cd frontend
npm ci
npm run dev
```

Abra `http://127.0.0.1:5173`. Para teste consciente em outro dispositivo da LAN, execute
`npm run dev -- --host 0.0.0.0` e restrinja a porta no firewall.

## Variáveis obrigatórias/relevantes

| Variável | Serviço | Uso |
|---|---|---|
| `VITE_API_BASE_URL` | build frontend | URL da API; no Nginx Compose pode ficar vazia para mesma origem |
| `VITE_SUPABASE_ENABLED` | build frontend | `true` apenas quando Auth/RLS forem homologados |
| `VITE_SUPABASE_URL` | build frontend | URL pública do projeto Supabase |
| `VITE_SUPABASE_ANON_KEY` | build frontend | chave pública publishable/anon |
| `NETZONIA_ENV` | backend | use `production` fora do desenvolvimento |
| `NETZONIA_ADDR` | backend | endereço de escuta, padrão `:8080` |
| `NETZONIA_CORS_ORIGINS` | backend | origens HTTPS exatas, separadas por vírgula |
| `NETZONIA_TRUST_PROXY` | backend | `true` somente atrás de proxy controlado |
| `NETZONIA_ALLOW_WOL` | backend | mantenha `false`; habilite apenas em servidor autorizado na LAN |

Nunca use `service_role`, senha do banco ou JWT secret no build do frontend.

## Supabase

Siga `docs/GUIA_SUPABASE_EDU.md`. A ordem é migrations 0001 → 0002 → 0003 e policies 0001 → 0002.
Auth/RLS só podem ser marcados como validados após o teste com Usuário A/Empresa A e Usuário B/Empresa B.

## Smoke test após deploy

1. `GET /api/health` retorna HTTP 200 e `ok:true`.
2. A página inicial carrega sem erro.
3. Criar, renomear, pesquisar, duplicar e excluir um projeto de teste.
4. Executar VLSM e confirmar o resultado associado ao projeto.
5. Abrir Planner e testar piso, parede, teto, rack, U, portas e cabo.
6. Aguardar **Salvo**, recarregar e confirmar a restauração.
7. Gerar TXT e impressão.
8. Conferir console do navegador e logs dos containers.
9. Com Supabase: repetir isolamento multiempresa.

## Segurança operacional

- CORS de produção deve listar somente origens controladas.
- O proxy deve sobrescrever `X-Forwarded-For`; o Nginx desta entrega já faz isso.
- Não publique scanner, SSH ou SNMP sem Auth, autorização, auditoria e allowlist.
- Limite logs e nunca registre senhas, strings Wi-Fi ou credenciais.
- Configure backup do Postgres/Supabase e teste restauração.

## Rollback

1. Mantenha a imagem/ZIP anterior identificada.
2. Interrompa a RC e volte os containers para a versão anterior.
3. Não reverta migrations destrutivamente. A migration 0003 só adiciona constraints/índice; avalie a
   compatibilidade dos dados antes de qualquer rollback SQL.
4. Para contornar Supabase sem apagar dados, defina `VITE_SUPABASE_ENABLED=false`, reconstrua o
   frontend e use o modo local.

## Limitação desta entrega

O ambiente usado na Fase 3 não possuía Docker/Postgres e o navegador remoto bloqueou localhost. O
Compose foi revisado, mas precisa ser executado pela equipe em host apropriado. A validação visual
WebGL também permanece no checklist manual.
