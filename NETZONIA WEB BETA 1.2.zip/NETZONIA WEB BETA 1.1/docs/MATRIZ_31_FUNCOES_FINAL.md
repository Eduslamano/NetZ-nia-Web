# Matriz das 31 funções — Release Candidate

Status revisado na Fase 3. “Funcional” indica implementação e teste automatizado/HTTP quando
aplicável; não transforma recursos locais em funções falsas de navegador.

| Nº | Função | Desktop | Web | Tipo | Status | Implementação | Limitação / próxima evolução |
|---:|---|---|---|---|---|---|---|
| 1 | Testar Velocidade | Sim | Não | SERVER_API | PENDENTE | — | Definir protocolo de banda e origem da medição. |
| 2 | Listar Dispositivos | Sim | Não | LOCAL_AGENT | AGENT_NECESSARIO | — | ARP/LAN pelo futuro Agent autorizado. |
| 3 | Painel do Roteador | Sim | Sim | HYBRID | FUNCIONAL | UI abre gateway informado | Navegador não detecta gateway. |
| 4 | Reparar Conexão | Sim | Não | DESKTOP_ONLY | DESKTOP_ONLY | Desktop | Comandos Windows. |
| 5 | Canais Wi-Fi | Sim | Não | LOCAL_AGENT | AGENT_NECESSARIO | — | Adaptador local/análise passiva. |
| 6 | Latência | Sim | Sim | SERVER_API | FUNCIONAL | TCP connect no Go | Parte do servidor, não ICMP do usuário. |
| 7 | Relatório TXT | Sim | Sim | WEB_NATIVE | FUNCIONAL | `pages/reports.js` | PDF usa impressão do navegador. |
| 8 | Traceroute Visual | Sim | Não | SERVER_API | PENDENTE | — | Privilégios e perspectiva do servidor. |
| 9 | Scanner TCP | Sim | Não | SERVER_API | PENDENTE | — | Exige Auth, autorização, allowlist e rate limit específico. |
| 10 | Informações Adaptador | Sim | Não | LOCAL_AGENT | AGENT_NECESSARIO | — | Dados da máquina local. |
| 11 | Teste DNS | Sim | Sim | SERVER_API | FUNCIONAL | API Go | Mede resolvers a partir do servidor. |
| 12 | Watchdog | Sim | Não | HYBRID | PENDENTE | — | Precisa SSE/WebSocket e cotas. |
| 13 | IP Externo | Sim | Sim | SERVER_API | PARCIAL | IP visto pela API | Proxy confiável deve ser configurado; geolocalização não implementada. |
| 14 | MTU | Sim | Não | SERVER_API | PENDENTE | — | Socket/DF e perspectiva do servidor. |
| 15 | VLSM | Sim | Sim | WEB_NATIVE | FUNCIONAL | API Go testada na base | — |
| 16 | GPON/FTTH | Sim | Sim | WEB_NATIVE | FUNCIONAL | API Go testada na base | — |
| 17 | Banda CFTV | Sim | Sim | WEB_NATIVE | FUNCIONAL | API Go testada na base | Estimativa baseada na fórmula oficial. |
| 18 | Conversor Telecom | Sim | Sim | WEB_NATIVE | FUNCIONAL | API Go testada na base | — |
| 19 | Terminal SSH | Sim | Não | SERVER_API | PENDENTE | — | Cofre/Auth/auditoria antes de ativar. |
| 20 | Wake-on-LAN | Sim | Sim | HYBRID | PARCIAL | API Go | Desativado por padrão; servidor deve estar na LAN autorizada. |
| 21 | Ping Sonoro | Sim | Não | HYBRID | PENDENTE | — | Stream + Web Audio; Agent para perspectiva local. |
| 22 | PPPoE | Sim | Não | DESKTOP_ONLY | DESKTOP_ONLY | Desktop | Integração Windows/RAS. |
| 23 | Servidor LAN | Sim | Não | DESKTOP_ONLY | DESKTOP_ONLY | Desktop | Servidor na máquina do usuário. |
| 24 | String Wi-Fi | Sim | Sim | WEB_NATIVE | FUNCIONAL | API Go | Não realiza auditoria ofensiva. |
| 25 | SNMP | Sim | Não | SERVER_API | PENDENTE | — | Binário, Auth, rede autorizada e proteção de community. |
| 26 | SSL | Sim | Sim | SERVER_API | FUNCIONAL | API Go | Destinos privados bloqueados contra SSRF. |
| 27 | Gerador Senhas | Sim | Sim | WEB_NATIVE | FUNCIONAL | CSPRNG no Go | Resultado não é gravado em logs. |
| 28 | Atalhos Windows | Sim | Não | DESKTOP_ONLY | DESKTOP_ONLY | Desktop | Sem equivalente seguro no navegador. |
| 29 | Configuração IP | Sim | Não | DESKTOP_ONLY | DESKTOP_ONLY | Desktop | Exige privilégio local. |
| 30 | Prontidão IPv6 | Sim | Não | HYBRID | PENDENTE | — | Precisa teste client-side e/ou Agent. |
| 31 | Credenciais Seguras | Sim | Preparado | SERVER_API | PENDENTE | Auth/RLS preparados | Cofre cifrado não implementado. |

Contagem Web: **11 completas**, IP de origem e Wake-on-LAN parciais/controlados. Nenhuma
função dependente de SO/LAN foi simulada no navegador.
