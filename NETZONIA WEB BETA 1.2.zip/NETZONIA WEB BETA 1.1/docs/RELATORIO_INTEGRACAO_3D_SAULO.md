# Relatório de integração 3D — Saulo

## Antes

A RC já possuía motor Three.js modular, OrbitControls, TransformControls, raycasting, ambiente com
piso/quatro paredes/teto, racks/U, portas explícitas, cabos, EMI, persistência defensiva, GLTFLoader e
fallback. Os placeholders visuais de equipamentos eram caixas simples.

Baseline pré-integração:

- `npm test`: 17 aprovados, 0 falhas;
- `npm run build`: aprovado;
- `npm audit`: 0 vulnerabilidades;
- Go: não executado nesta sessão, pois o binário não estava instalado e o ambiente recusou a
  instalação pelo gerenciador de pacotes. A entrega anterior da RC registra a suíte Go aprovada.

## Depois

O `PlannerEngine` permanece como motor oficial. Um módulo visual separado passou a gerar:

- racks com estrutura, trilhos e volume selecionável;
- switches com 24 portas e LEDs;
- roteadores com antenas e indicador luminoso;
- access points circulares com anel de status;
- caixas com contorno para os demais equipamentos.

Trocar a representação não altera IDs, portas, conexões ou instalação. Quando um GLB está configurado,
ele substitui o procedural; se estiver ausente ou falhar, o procedural permanece.

## Arquivos modificados

- `frontend/src/mapa3d/engine/equipmentVisuals.js` — novo;
- `frontend/src/mapa3d/engine/plannerEngine.js`;
- `frontend/src/mapa3d/equipmentCatalog.js`;
- `frontend/src/mapa3d/modelLoader.js`;
- `frontend/test/planner.test.js`;
- saída `frontend/dist/` regenerada;
- relatórios e checklist desta integração.

## Melhorias incorporadas

- detalhes procedurais derivados dos modelos do Saulo;
- materiais metálicos, transparentes e emissivos;
- separação formal entre modelo lógico e visual;
- fallback de GLB transformado em função testável;
- verificação automatizada das dimensões e quantidade de detalhes.

## Bugs e riscos evitados

- nenhuma dependência em `window.THREE` ou Three.js r128;
- nenhum merge cego da pasta `mapa3d`;
- nenhum retorno à UI/persistência Wails antiga;
- pivôs adaptados ao centro, evitando afundar modelos no piso;
- fallback não derruba o Planner quando o GLB falha;
- ciclo de descarte existente continua liberando geometrias, materiais e texturas.

## Testes pós-integração

- `npm test`: 19 aprovados, 0 falhas;
- `npm run build`: aprovado;
- `node --check`: aprovado;
- testes anteriores de projeto, instalação, rack/U, portas, cabos, EMI e restauração preservados;
- novos testes de visuais procedurais e fallback GLB aprovados.

Os resultados finais de `npm audit` e das verificações de integridade constam no checklist de entrega.

## Limitações

O navegador remoto bloqueou `http://127.0.0.1:5173/` com `ERR_BLOCKED_BY_CLIENT`. Assim, a integração
foi implementada, testada por código e compilada, mas **não foi validada visualmente em WebGL**.
Também não foi possível reinstalar Go neste ambiente para repetir `go test`/`go vet`.

## Pendências

1. validar visualmente câmera, seleção, transformação e modelos no PC do Yuri;
2. observar console e uso de GPU/memória durante uma sessão longa;
3. inserir GLBs finais com escala, pivô e licença registrados;
4. decidir se servidores, ONU, câmera e nobreak receberão modelos procedurais próprios;
5. executar novamente a suíte Go em ambiente com Go 1.22+.

