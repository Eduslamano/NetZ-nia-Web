# Planner 3D

## Implementado

- Three.js com carregamento sob demanda, câmera em órbita, zoom, luz, piso, grade, quatro paredes e teto.
- Seleção por raycaster.
- `TransformControls` para mover e rotacionar.
- Placeholders profissionais para roteador, switch, ONU, AP, servidor, câmera, nobreak e racks.
- `GLTFLoader` integrado com fallback automático para placeholder se o `.glb` falhar ou não existir.
- Instalação lógica explícita: `floor`, `wall`, `ceiling` ou `rack`, separada do visual.
- Piso fixa a altura do equipamento; teto fixa o plano inferior; parede preserva `surfaceId`, prende
  o objeto ao plano, limita o movimento à superfície e mantém orientação coerente.
- Racks 24U/42U com slots, bloqueio de sobreposição e equipamentos acompanhando posição/rotação do rack.
- Portas lógicas tipadas, escolha explícita das portas e ocupação/liberação por cabo.
- Seleção explícita ORIGEM → DESTINO; rack não é endpoint.
- Cobre U/UTP, cobre blindado e fibra.
- Limite de 90 m para cobre; fibra sem esse limite.
- Detecção de EMI pela distância da zona ao segmento completo.
- Serialização e restauração dentro de `project.data.planner3d`.
- Autosave com debounce e indicadores de estado.

## Estrutura persistida

```text
planner3d
├─ environment
├─ equipment[]
├─ racks[]
├─ cables[]
└─ zones[]
```

O restaurador limita contagens, normaliza transforms/instalações, revalida slots e descarta entidades,
cabos, portas e IDs inválidos ou duplicados. Portas ocupadas são reconstruídas a partir dos cabos,
evitando confiar cegamente no JSON armazenado.

## Separação para o Saulo

- Lógica/regras: `src/mapa3d/{model,persistence,installationConstraints,rackManager,networkValidator}.js`.
- Renderização: `src/mapa3d/engine/plannerEngine.js`.
- Catálogo e referência futura de GLB: `src/mapa3d/equipmentCatalog.js` e `modelLoader.js`.

Modelos, materiais, iluminação e colisões podem evoluir sem alterar IDs, portas, instalação lógica,
cabeamento ou formato persistido.

## Limitações

- Modelos finais Blender/GLB não foram fornecidos; permanecem placeholders.
- Colisão é limitada aos limites do ambiente e às regras lógicas de rack.
- O navegador remoto voltou a bloquear `localhost` com `ERR_BLOCKED_BY_CLIENT`; portanto não houve
  validação visual WebGL nesta fase. As regras e o fluxo de restauração foram testados por código.
  Repetir o checklist manual de `docs/TESTES.md` em Chrome/Edge local.
