# Relatório final — Fase 3 Release Candidate

## 1. Base e escopo

A implementação foi feita diretamente sobre o ZIP oficial da Fase 2, preservando sua arquitetura e
o diretório `legacy-desktop-reference/`. Não houve reconstrução do projeto. O objetivo desta fase foi
fechar os fluxos de Projetos, tornar o Planner 3D persistente e coerente, fortalecer backend e
segurança, preparar Supabase e produzir documentação de homologação.

## 2. Auditoria inicial

- frontend: 7 testes aprovados, build e audit aprovados;
- backend: o único bloqueio era um teste de Wake-on-LAN que tentava emitir broadcast real e falhava
  com `network is unreachable`;
- ambiente: Node.js, npm, Go e Git disponíveis; Docker, Podman e PostgreSQL ausentes;
- navegador remoto: acesso a `http://127.0.0.1:5173` bloqueado com `ERR_BLOCKED_BY_CLIENT`.

O teste WOL foi tornado determinístico: agora valida os 102 bytes do magic packet sem depender da
rede. O envio real continua protegido por configuração e aceita apenas broadcast privado ou global.

## 3. Projetos e persistência

- feedback de erro e estado de carregamento nas ações de Projetos;
- cache do projeto ativo atualizado após renomeação;
- validação de nome, estrutura e limite de 4 MiB antes da gravação Supabase;
- autosave testado quanto a debounce, última versão e recuperação após falha;
- fluxo automatizado cria, equipa, cabeia, salva, reabre e restaura o mesmo projeto;
- armazenamento local corrompido é tratado sem derrubar a aplicação.

## 4. Planner 3D

- ambiente dimensionável com piso, quatro paredes e teto;
- restrições puras para piso, parede, teto e rack, evitando flutuação e atravessamento;
- equipamentos em rack preservam `rackId`/`rackU` e acompanham movimento e rotação;
- seleção explícita do equipamento e da porta nas duas extremidades do cabo;
- portas ocupadas, IDs inválidos e cabos inconsistentes são rejeitados;
- restauração defensiva normaliza transformações, entidades, racks, zonas e cabos;
- carregamento GLB opcional com placeholder seguro em caso de ausência ou falha;
- descarte de listeners, observer, geometrias, materiais e texturas;
- carregamento sob demanda do módulo do Planner para reduzir o bundle inicial.

As regras e a persistência foram validadas por testes de código. A renderização WebGL **não foi
validada visualmente**, pois o navegador remoto bloqueou localhost. Essa pendência não é apresentada
como concluída.

## 5. Backend e segurança

- validação do IP encaminhado somente para proxy confiável;
- rate limit por cliente real atrás do proxy, sem aceitar `X-Forwarded-For` arbitrário;
- Nginx sobrescreve o cabeçalho encaminhado com o IP remoto;
- WOL bloqueia alvos públicos e permanece desativado por padrão;
- ferramentas de rede mantêm proteção SSRF para alvos privados;
- JSON desconhecido e payload acima do limite são recusados;
- timeout no cliente frontend e correção do endereço exibido no log do servidor.

## 6. Supabase e Auth

Foram mantidos cliente, sessão, repositories e criação transacional de empresa/owner. A migration
`0003_release_candidate_hardening.sql` adiciona validações e índice, e
`supabase/tests/rls_two_companies.sql` prepara o teste de isolamento entre duas empresas. O guia
`GUIA_SUPABASE_EDU.md` documenta configuração, ordem dos SQLs, primeiro usuário, erros e checklist.

Não havia instância Supabase/PostgreSQL no ambiente; portanto migrations, Auth e RLS foram revisados
e preparados, mas não executados contra serviço real.

## 7. Relatórios, matriz e deploy

- relatório TXT ampliado com empresa, escopo, ambiente, superfícies, rack/U, portas, cabos e EMI;
- matriz das 31 funções revisada, sem simular funções locais no navegador;
- IP de origem e WOL permanecem parciais/controlados;
- deploy de homologação, variáveis e procedimento de rollback documentados;
- relatório de estado para Enolla e checklist da Release Candidate incluídos.

## 8. Validações finais

| Verificação | Resultado |
|---|---|
| `npm test` | 17 aprovados, 0 falhas |
| `npm run build` | aprovado |
| `npm audit` | 0 vulnerabilidades |
| `node --check` | aprovado |
| `go test ./...` | aprovado |
| `go vet ./...` | aprovado |
| `go build -buildvcs=false ./...` | aprovado |
| execução frontend + backend | health, CORS e ferramentas prioritárias aprovados |

O parâmetro `-buildvcs=false` é necessário apenas porque a distribuição ZIP não contém metadados
Git. SSL e Latência externos não concluíram chamadas reais porque o resolvedor DNS do sandbox estava
inacessível. As rotas e proteções foram cobertas por testes, mas essa limitação externa permanece.

## 9. Arquivos principais alterados

- `frontend/src/mapa3d/`: engine, catálogo, restrições, persistência, racks e rede;
- `frontend/src/pages/`: Projetos, Planner, Conta e Relatórios;
- `frontend/src/repositories/` e `frontend/test/`: validações e cobertura dos fluxos críticos;
- `backend/internal/httpapi/` e `backend/internal/tools/`: proxy, limites, rotas e WOL;
- `supabase/`: migration 0003, roteiro RLS e documentação;
- `docs/`: testes, Planner, Supabase, deploy, matriz, checklist e relatórios.

## 10. Pendências para homologação

1. abrir a aplicação em Chrome/Edge local e validar visualmente Dashboard, Planner WebGL, console e
   responsividade;
2. validar impressão/download por interação real;
3. executar migrations e testes Auth/RLS em Supabase real com empresas A e B;
4. testar SSL e Latência em rede com DNS/TCP liberados;
5. executar Docker Compose em máquina com Docker;
6. substituir placeholders pelos GLBs finais e realizar o acabamento visual do Planner.

## 11. Conclusão

A base está consolidada como Release Candidate: builds e suítes automatizadas passam, o fluxo crítico
de projeto e o estado do Planner são persistentes, e os limites não comprovados estão registrados de
forma explícita. A aprovação final depende da homologação visual WebGL e das integrações externas
listadas acima.
