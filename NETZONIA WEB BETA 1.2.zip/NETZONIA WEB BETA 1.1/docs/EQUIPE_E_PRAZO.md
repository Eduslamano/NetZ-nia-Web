# Equipe — entrega 02/10/2026

- Yuri: líder técnico / integração Full Stack, API Go e migração das ferramentas.
- Saulo: Planejador 3D / Three.js, posicionamento, racks, cabeamento e modelos.
- Enolla: Frontend / UI/UX, responsividade e acabamento.
- Carlos Edu: Supabase/PostgreSQL/Auth/RLS, GitHub e documentação.

Feature freeze recomendado: 28/09. 29-30/09 integração/testes. 01/10 somente bugs críticos. 02/10 entrega.
