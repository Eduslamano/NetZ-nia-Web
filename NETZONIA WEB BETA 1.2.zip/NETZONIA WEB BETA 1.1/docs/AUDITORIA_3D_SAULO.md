# Auditoria 3D — contribuição do Saulo

## Bases comparadas

- fonte de verdade: `NETZONIA_WEB_RELEASE_CANDIDATE(3).zip`;
- fonte experimental: `NETZONIA_REDE_3D_com_novo_motor_mapa3d(2).zip`.

Os dois ZIPs foram extraídos separadamente antes de qualquer alteração. O pacote do Saulo é uma
aplicação Wails/desktop anterior, enquanto a RC é uma aplicação Web com Vite, Three.js por módulo,
Projetos e persistência Local/Supabase.

## Estrutura 3D encontrada no pacote do Saulo

| Arquivo | Papel | Classificação para a RC |
|---|---|---|
| `frontend/src/mapa3d/scene3d.js` | motor Three.js r128 e modelos procedurais | melhoria real, requer adaptação |
| `frontend/src/mapa3d/mapa3dView.js` | UI e fluxo do Planner Wails | conflita com RC; não utilizar |
| `frontend/src/mapa3d/equipmentCatalog.js` | catálogo amplo do desktop | obsoleto para o schema Web; referência visual |
| `frontend/src/mapa3d/meshGen.js` | caixa chanfrada em vértices/faces | novo, porém não consumido pelo motor WebGL entregue |
| `buildingFootprint.js` | pegadas OSM | idêntico à referência desktop da RC |
| `placeContextStore.js` | contexto de local do desktop | idêntico à referência desktop da RC |
| `frontend/vendor/three.min.js` | Three.js UMD r128 | incompatível/desnecessário; RC usa npm `three` 0.180 |

Não foram encontrados arquivos `.glb`, `.gltf`, texturas ou modelos Blender. Não houve dependência
npm nova; o pacote vendorizou uma cópia antiga do Three.js.

## Mudanças identificadas

### Arquivos novos

- `meshGen.js`;
- `frontend/vendor/three.min.js` e cópia em `dist/vendor/`;
- relatório de integração do motor.

### Arquivos modificados

- `scene3d.js`: troca do Canvas 2D por WebGL, raycasting e modelos procedurais;
- `mapa3dView.js`: duas chamadas passaram de caixa simples para `chamferedBox`;
- `index.html` e `build.js`: carregamento/cópia do Three.js global;
- `dist/`: saída recompilada do projeto Wails.

### Arquivos removidos, modelos e texturas

- nenhum arquivo 3D relevante removido;
- nenhum GLB/GLTF;
- nenhuma textura externa;
- nenhuma licença de asset adicional além do Three.js MIT descrito pelo autor.

## Melhorias reais encontradas

- rack com quatro montantes, tampas, trilhos e volume transparente para seleção;
- switch com corpo, portas, LEDs e ventilação;
- roteador com antenas, portas e LED;
- access point com corpo circular e anel luminoso;
- materiais com roughness, metalness e emissive;
- limpeza explícita de geometrias e materiais;
- picking por raycasting e iluminação WebGL.

## Problemas e conflitos

- o motor depende de `window.THREE` r128; a RC usa imports ES e Three.js 0.180;
- a API `Scene3D` pertence à UI Wails antiga e não conhece o `PlannerEngine` atual;
- não preserva diretamente `rackId`, `rackU`, `surfaceId`, portas explícitas e schema Web atual;
- o catálogo do desktop usa IDs, dimensões e contratos diferentes;
- o `mesh` produzido por `meshGen.js` é anexado pela view, mas o novo `scene3d.js` escolhe o modelo
  pelo campo `shape` e não lê `def.mesh`;
- não há GLB, colisão física nova ou migração de persistência a aproveitar;
- copiar `scene3d.js`, `mapa3dView.js` ou o catálogo removeria evoluções da RC.

## O que foi aproveitado e adaptado

Os conceitos visuais de rack, switch, roteador e access point foram transplantados para o novo módulo
`frontend/src/mapa3d/engine/equipmentVisuals.js`. A implementação foi reescrita para:

- importar a versão atual de `three` já usada pela RC;
- receber o catálogo oficial da Web;
- manter o pivô central esperado pelas restrições de piso/parede/teto/rack;
- não possuir IDs, portas ou regras de rede próprias;
- continuar substituível por GLB, com fallback procedural;
- participar do descarte de recursos já executado pelo `PlannerEngine`.

O catálogo recebeu somente a propriedade declarativa `visual`. O schema persistido não mudou.

## O que não foi integrado

- motor `Scene3D` completo, por conflito arquitetural;
- UI Wails `mapa3dView.js`, por substituir o fluxo Web atual;
- Three.js vendorizado r128, por duplicação e versão antiga;
- catálogo desktop, por IDs e regras incompatíveis;
- `meshGen.js`, porque o próprio motor entregue não usa a malha e a RC já possui modelos WebGL;
- pegadas OSM e contexto de local, pois pertencem ao desktop legado e não ao Planner Web atual;
- arquivos Go, instalador e demais módulos do ZIP, por estarem fora do escopo.

## Compatibilidade e dependências

Não foi adicionada dependência. O `package-lock.json` permanece com o Three.js já aprovado na RC. IDs,
portas, ocupação, instalação, rack/U, cabos, EMI, serialização e ProjectRepository não foram alterados.

