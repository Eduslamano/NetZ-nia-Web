# Sobe backend Go e frontend Vite em duas janelas do PowerShell, sem
# esconder erros: cada processo fica visível na sua própria janela.
$root = Split-Path -Parent $PSScriptRoot

Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$root/backend'; go run ./cmd/server"
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$root/frontend'; npm ci; npm run dev"

Write-Host "Backend e frontend abertos em janelas separadas. Feche-as para encerrar."
