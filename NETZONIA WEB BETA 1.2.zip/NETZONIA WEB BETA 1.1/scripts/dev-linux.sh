#!/usr/bin/env bash
# Sobe backend Go e frontend Vite juntos, sem esconder erros: cada saída
# vai prefixada (backend/frontend) para o mesmo terminal, e se qualquer um
# dos dois cair, o script mata o outro e sai com erro (set -e + trap).
set -e
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cleanup() {
  echo "Encerrando backend e frontend..."
  kill "${BACKEND_PID:-}" "${FRONTEND_PID:-}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

(cd "$ROOT_DIR/backend" && go run ./cmd/server 2>&1 | sed 's/^/[backend] /') &
BACKEND_PID=$!

(cd "$ROOT_DIR/frontend" && npm run dev 2>&1 | sed 's/^/[frontend] /') &
FRONTEND_PID=$!

wait -n "$BACKEND_PID" "$FRONTEND_PID"
