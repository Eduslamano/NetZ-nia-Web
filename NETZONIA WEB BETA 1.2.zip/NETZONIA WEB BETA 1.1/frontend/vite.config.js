import { defineConfig } from "vite";

export default defineConfig({
  build: {
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          three: ["three"],
          supabase: ["@supabase/supabase-js"],
        },
      },
    },
  },
});
