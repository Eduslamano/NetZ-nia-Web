import { postTool } from "./api.js";

function parseCSVInt(text) {
  return String(text || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => parseInt(s, 10));
}
function parseCSVFloat(text) {
  return String(text || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => parseFloat(s));
}

/** Converte os valores brutos do formulário (strings do DOM) usando o `parser` de cada field. */
export function coerceFieldValues(fields, rawValues) {
  const out = {};
  for (const f of fields || []) {
    const raw = rawValues[f.key];
    switch (f.parser) {
      case "csv-int":
        out[f.key] = parseCSVInt(raw);
        break;
      case "csv-float":
        out[f.key] = parseCSVFloat(raw);
        break;
      case "int":
        out[f.key] = raw === "" || raw === undefined ? undefined : parseInt(raw, 10);
        break;
      case "number":
        out[f.key] = raw === "" || raw === undefined ? undefined : parseFloat(raw);
        break;
      default:
        out[f.key] = f.type === "checkbox" ? !!raw : raw;
    }
  }
  return out;
}

/**
 * Registro das ferramentas com backend real nesta entrega. Cada entrada
 * mapeia o `id` de data/features.js para o endpoint da API Go e, quando o
 * payload não é 1:1 com os `fields`, uma função `buildPayload` própria.
 */
export const TOOL_RUNNERS = {
  vlsm: { endpoint: "vlsm" },
  "orcamento-optico": { endpoint: "orcamento-optico" },
  cftv: { endpoint: "cftv" },
  "conversor-telecom": { endpoint: "conversor-telecom" },
  "wifi-string": { endpoint: "wifi-string" },
  "senha-segura": { endpoint: "senha" },
  wol: { endpoint: "wol" },
  dns: {
    endpoint: "dns",
    buildPayload: (values) => ({ hostname: values.host || "google.com" }),
  },
  ssl: { endpoint: "ssl" },
  latencia: {
    endpoint: "latencia",
    buildPayload: (values) => ({ host: values.host || "1.1.1.1", port: 443, tentativas: 4 }),
  },
};

export async function runTool(toolId, fields, rawValues) {
  const runner = TOOL_RUNNERS[toolId];
  if (!runner) throw new Error("Ferramenta sem execução real configurada.");
  const payload = runner.buildPayload ? runner.buildPayload(rawValues) : coerceFieldValues(fields, rawValues);
  return postTool(runner.endpoint, payload);
}
