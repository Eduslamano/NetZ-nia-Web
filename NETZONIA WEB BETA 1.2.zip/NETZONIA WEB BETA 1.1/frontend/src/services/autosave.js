export function createAutosave(save, { delay = 700, onState = () => {} } = {}) {
  let timer;
  let running = Promise.resolve();
  let latest;
  async function flush() {
    clearTimeout(timer);
    if (latest === undefined) return running;
    const value = latest;
    latest = undefined;
    onState("saving");
    running = running.catch(() => {}).then(() => save(value)).then(() => onState("saved")).catch((error) => {
      if (latest === undefined) latest = value;
      onState("error", error);
      throw error;
    });
    return running;
  }
  return {
    schedule(value) { latest = structuredClone(value); clearTimeout(timer); onState("pending"); timer = setTimeout(() => { void flush().catch(() => {}); }, delay); },
    flush,
    cancel() { clearTimeout(timer); latest = undefined; },
  };
}
