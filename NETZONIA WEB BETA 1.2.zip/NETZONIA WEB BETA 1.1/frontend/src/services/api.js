import { INTERFACE_ONLY } from "../config/interface.js";
import { API_BASE_URL } from "../config/env.js";

/** Erro de API com mensagem já pronta para exibir ao usuário. */
export class ApiError extends Error {}

async function request(path, options) {
  if (INTERFACE_ONLY) throw new ApiError("Operações de rede estão desativadas na prévia de interfaces.");
  let res;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25_000);
  try {
    res = await fetch(`${API_BASE_URL}${path}`, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === "AbortError") throw new ApiError("A API excedeu o tempo limite da operação.");
    throw new ApiError("Não foi possível contatar a API. Verifique se o backend está em execução.");
  } finally {
    clearTimeout(timeout);
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    throw new ApiError("A API respondeu em um formato inesperado.");
  }
  if (!res.ok || !body?.ok) {
    throw new ApiError(body?.error || `Falha na API (HTTP ${res.status}).`);
  }
  return body.data;
}

export function getHealth() {
  return request("/api/health", { method: "GET" });
}

export function getIPOrigem() {
  return request("/api/tools/ip-origem", { method: "GET" });
}

export function postTool(toolPath, payload) {
  return request(`/api/tools/${toolPath}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
