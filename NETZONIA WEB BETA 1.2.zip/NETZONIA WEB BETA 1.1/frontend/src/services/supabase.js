import { INTERFACE_ONLY } from "../config/interface.js";
import { createClient } from "@supabase/supabase-js";

const env = import.meta.env || {};
const enabled = !INTERFACE_ONLY && String(env.VITE_SUPABASE_ENABLED || "false") === "true";
const url = env.VITE_SUPABASE_URL || "";
const key = env.VITE_SUPABASE_ANON_KEY || "";
let client;

export function isSupabaseEnabled() { return enabled; }
export function getSupabaseClient() {
  if (!enabled) return null;
  if (!url || !key) throw new Error("Supabase ativado sem VITE_SUPABASE_URL/VITE_SUPABASE_ANON_KEY.");
  client ||= createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true } });
  return client;
}

export async function getSupabaseContext() {
  const supabase = getSupabaseClient();
  if (!supabase) return { mode: "local", user: { id: "local-user", email: "Modo local" }, companyId: "local-company" };
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) throw new Error(error.message);
  if (!session?.user) return { mode: "supabase", user: null, companyId: null };
  const { data: membership, error: memberError } = await supabase.from("company_members")
    .select("company_id,role").eq("profile_id", session.user.id).limit(1).maybeSingle();
  if (memberError) throw new Error(memberError.message);
  return { mode: "supabase", user: session.user, companyId: membership?.company_id || null, role: membership?.role || null };
}
