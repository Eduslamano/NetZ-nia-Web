import { escapeHtml } from "../lib/html.js";

export function loading(message = "Carregando…") {
  return `<div class="loading-row" role="status"><span class="spinner" aria-hidden="true"></span>${escapeHtml(message)}</div>`;
}

export function errorMessage(error) {
  const message = error?.message || "Não foi possível concluir a operação.";
  if (/fetch|network|API|backend|Failed to/i.test(message)) return "Não foi possível acessar o serviço. Confira sua conexão e tente novamente.";
  if (/invalid login/i.test(message)) return "E-mail ou senha incorretos. Confira os dados e tente novamente.";
  return message;
}

export function errorMarkup(error) {
  return `<p class="state-msg error" role="alert">${escapeHtml(errorMessage(error))}</p>`;
}

/** Native dialog provides focus containment, Escape and an inert background. */
export function projectDialog({ title, description, project, destructive = false }) {
  return new Promise((resolve) => {
    const previous = document.activeElement;
    const dialog = document.createElement("dialog");
    dialog.className = "project-dialog";
    dialog.setAttribute("aria-labelledby", "dialog-title");
    dialog.setAttribute("aria-describedby", "dialog-description");
    dialog.innerHTML = `<form method="dialog"><h2 id="dialog-title">${escapeHtml(title)}</h2><p id="dialog-description">${escapeHtml(description)}</p>
      ${project ? `<div class="field"><label for="edit-name">Nome do projeto</label><input id="edit-name" name="name" value="${escapeHtml(project.name)}" maxlength="120" required></div><div class="field"><label for="edit-description">Descrição</label><textarea id="edit-description" name="description" maxlength="1000" rows="3">${escapeHtml(project.description || "")}</textarea></div>` : ""}
      <div class="modal-actions"><button class="btn btn-ghost" value="cancel" formnovalidate autofocus>Cancelar</button><button class="btn ${destructive ? "btn-danger" : "btn-primary"}" value="confirm">${destructive ? "Excluir projeto" : "Salvar alterações"}</button></div></form>`;
    dialog.addEventListener("close", () => {
      const result = dialog.returnValue === "confirm" ? (project ? Object.fromEntries(new FormData(dialog.querySelector("form"))) : true) : null;
      dialog.remove(); previous?.focus(); resolve(result);
    }, { once: true });
    dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close("cancel"); });
    document.body.append(dialog); dialog.showModal();
  });
}
