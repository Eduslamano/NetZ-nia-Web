import { CATEGORIES, CATEGORY_ORDER, PLANNER } from "../data/categories.js";
import { getToolById } from "../data/tools.js";

function currentRoute() {
  const [section, id] = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  if (!section) return { section: "home" };
  if (section === "ferramenta" && id) return { section, categoryId: getToolById(id)?.category };
  return { section, id, categoryId: section === "categoria" ? id : undefined };
}

function menuItem({ href, icon, label, active }) {
  return `
    <a class="side-menu-item${active ? " active" : ""}" href="${href}" ${active ? 'aria-current="page"' : ""}>
      <span class="side-menu-icon" aria-hidden="true">${icon}</span>
      <span class="side-menu-label">${label}</span>
    </a>`;
}

export function mountSideMenu() {
  const root = document.querySelector("#side-menu-root");
  const button = document.querySelector("#menu-btn");
  if (!root || !button) return;

  let open = false;
  let lastFocused = null;

  function close({ restoreFocus = true } = {}) {
    if (!open) return;
    open = false;
    root.replaceChildren();
    button.setAttribute("aria-expanded", "false");
    document.body.classList.remove("side-menu-open");
    document.querySelector(".app-header").inert = false;
    document.querySelector("#main-view").inert = false;
    if (restoreFocus) lastFocused?.focus?.();
    lastFocused = null;
  }

  function show() {
    if (open) return;
    open = true;
    lastFocused = document.activeElement;
    button.setAttribute("aria-expanded", "true");
    document.body.classList.add("side-menu-open");
    document.querySelector(".app-header").inert = true;
    document.querySelector("#main-view").inert = true;

    const route = currentRoute();
    const categoryItems = CATEGORY_ORDER.map((id) => {
      const category = CATEGORIES[id];
      return menuItem({
        href: `#/categoria/${id}`,
        icon: category.icon,
        label: category.label,
        active: route.categoryId === id,
      });
    }).join("");

    root.innerHTML = `
      <div class="side-menu-overlay">
        <aside class="side-menu-panel" id="side-menu" role="dialog" aria-modal="true" aria-label="Categorias" tabindex="-1">
          <div class="side-menu-header">
            <span class="side-menu-title">Categorias</span>
            <button class="side-menu-close" type="button" aria-label="Fechar menu">×</button>
          </div>
          <nav class="side-menu-list" aria-label="Categorias">
            ${menuItem({ href: "#/", icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 10.5 12 4l8 6.5V20H4Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 20v-6h6v6" stroke="currentColor" stroke-width="1.8"/></svg>`, label: "Início", active: route.section === "home" })}
            ${menuItem({ href: "#/visao-geral", icon: "◫", label: "Visão geral", active: route.section === "visao-geral" })}
            ${menuItem({ href: "#/projetos", icon: "▤", label: "Meus projetos", active: route.section === "projetos" })}
            ${menuItem({ href: "#/relatorios", icon: "▤", label: "Relatórios", active: route.section === "relatorios" })}
            ${menuItem({ href: "#/conta", icon: "○", label: "Minha conta", active: route.section === "conta" })}
            <span class="menu-section-label">Ferramentas por categoria</span>
            
            ${categoryItems}
            ${menuItem({ href: "#/planejador", icon: PLANNER.icon, label: PLANNER.title, active: route.section === "planejador" })}
          </nav>
        </aside>
      </div>`;

    const overlay = root.querySelector(".side-menu-overlay");
    const panel = root.querySelector(".side-menu-panel");
    root.querySelector(".side-menu-close").addEventListener("click", () => close());
    root.querySelectorAll(".side-menu-item").forEach((item) => item.addEventListener("click", () => close({ restoreFocus: false })));
    overlay.addEventListener("click", (event) => { if (event.target === overlay) close(); });

    requestAnimationFrame(() => {
      overlay.classList.add("is-open");
      panel.focus();
    });
  }

  button.addEventListener("click", () => open ? close() : show());
  document.addEventListener("keydown", (event) => {
    if (open && event.key === "Tab") {
      const items = [...root.querySelectorAll("button, a[href]")];
      const first = items[0], last = items.at(-1);
      if (event.shiftKey && (document.activeElement === first || document.activeElement === root.querySelector("aside"))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    if (open && event.key === "Escape") {
      event.preventDefault();
      close();
    }
  });
  window.addEventListener("hashchange", () => close({ restoreFocus: false }));
}
