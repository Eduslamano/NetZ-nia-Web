import { INTERFACE_ONLY } from "../config/interface.js";
import { CATEGORIES } from "../data/categories.js";
import { TOOL_STATUS, STATUS, STATUS_LABEL } from "../data/toolStatus.js";

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Retorna o HTML de um .feature-card para a ferramenta `tool`. */
export function renderToolCard(tool) {
  const cat = CATEGORIES[tool.category];
  const status = TOOL_STATUS[tool.id] || STATUS.POS_MVP;
  const isReady = status === STATUS.FUNCIONAL_E_TESTADO;
  const pill = INTERFACE_ONLY ? `<span class="card-pending-pill">Prévia da interface</span>` : isReady
    ? ""
    : `<span class="card-pending-pill">${escapeHtml(STATUS_LABEL[status])}</span>`;
  return `
    <button class="feature-card ${cat ? cat.tone : ""}" data-tool-id="${tool.id}" type="button">
      <div class="card-top">
        <span class="card-icon">${tool.icon}</span>
        <span class="card-number">#${String(tool.number).padStart(2, "0")}</span>
      </div>
      <div class="card-body">
        <div class="card-title">${escapeHtml(tool.title)}</div>
        <div class="card-desc">${escapeHtml(tool.subtitle || "")}</div>
      </div>
      <div class="card-footer">
        <span class="card-tag">${cat ? escapeHtml(cat.shortLabel) : ""}</span>
        ${pill}
      </div>
    </button>`;
}
