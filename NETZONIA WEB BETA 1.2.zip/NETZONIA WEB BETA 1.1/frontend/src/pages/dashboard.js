import { CATEGORIES, CATEGORY_ORDER, PLANNER } from "../data/categories.js";
import { ALL_TOOLS, searchTools, toolsByCategory, countByCategory } from "../data/tools.js";
import { renderToolCard } from "../components/toolCard.js";

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Renderiza a home (todas categorias) ou uma categoria específica. */
export function renderDashboard(root, { categoryId = "all", query = "" } = {}) {
  const normalizedQuery = query.trim();
  const tools = normalizedQuery
    ? searchTools(query, categoryId)
    : categoryId === "all"
      ? ALL_TOOLS
      : toolsByCategory(categoryId);

  const categoryCards = CATEGORY_ORDER.map((id) => {
    const c = CATEGORIES[id];
    return `
      <button class="category-card ${id === "ferramentas" ? "category-card-wide" : ""} ${c.tone}" data-category-id="${id}" type="button" aria-label="Abrir ${escapeHtml(c.label)}">
        <div class="category-card-main">
          <span class="category-card-icon">${c.icon}</span>
          <div class="category-card-title">${escapeHtml(c.label)}</div>
          <div class="category-card-desc">${escapeHtml(c.description)}</div>
        </div>
        <div class="category-card-footer">
          <span class="category-card-count">${countByCategory(id)} ferramentas</span>
          <span class="category-card-open">Abrir <span aria-hidden="true">→</span></span>
        </div>
      </button>`;
  }).join("");

  const plannerBanner = `
    <button class="planner-banner tone-violet" data-open-planner type="button">
      <span class="planner-banner-icon">${PLANNER.icon}</span>
      <div class="planner-banner-body">
        <div class="planner-banner-eyebrow">Módulo especial</div>
        <div class="planner-banner-title">${escapeHtml(PLANNER.title)}</div>
        <div class="planner-banner-desc">${escapeHtml(PLANNER.description)}</div>
      </div>
      <span class="planner-banner-cta">Abrir →</span>
    </button>`;

  const grid = tools.length
    ? `<div class="tool-grid">${tools.map(renderToolCard).join("")}</div>`
    : `<div class="empty-state"><strong>Nada encontrado.</strong><p>Tente outro termo de busca.</p></div>`;

  const showCategories = categoryId === "all" && !normalizedQuery;

  if (showCategories) {
    root.innerHTML = `
      <section class="view dashboard-view">
        <div class="dashboard-heading">
          <h1 class="view-title">NetZônia</h1>
          <p class="view-subtitle">Escolha uma categoria para acessar as ferramentas do toolkit de rede.</p>
        </div>
        <div class="category-grid">${categoryCards}</div>
        ${plannerBanner}
      </section>`;
    return;
  }

  const selectedCategory = CATEGORIES[categoryId];
  const heading = normalizedQuery ? "Resultados da busca" : selectedCategory?.label || "Ferramentas";
  const scope = selectedCategory ? ` em ${selectedCategory.label}` : "";
  const subtitle = normalizedQuery
    ? `${tools.length} resultado${tools.length === 1 ? "" : "s"} para “${escapeHtml(normalizedQuery)}”${escapeHtml(scope)}.`
    : selectedCategory?.description || "Ferramentas disponíveis no NetZônia.";

  root.innerHTML = `
    <section class="view tools-view">
      <div class="tools-heading">
        <button class="btn btn-ghost btn-sm" type="button" data-go-home>← Categorias</button>
        <div><h1 class="view-title">${escapeHtml(heading)}</h1><p class="view-subtitle">${subtitle}</p></div>
      </div>
      ${grid}
    </section>`;
}
