import { escapeHtml } from "../lib/html.js";
import { STATUS, TOOL_STATUS } from "../data/toolStatus.js";
import { CATEGORIES } from "../data/categories.js";
import { loading } from "../components/feedback.js";

const extraFields = {
  roteador: [{ key: "gateway", label: "Endereço do roteador", placeholder: "192.0.2.1", required: true }],
  dispositivos: [{ key: "subnet", label: "Sub-rede", value: "192.0.2.0/24", required: true }],
  wifi: [{ key: "band", label: "Faixa", type: "select", options: [["all","Todas as faixas"],["2.4","2,4 GHz"],["5","5 GHz"]], value: "all" }],
  "ping-sonoro": [{ key: "host", label: "Destino", value: "192.0.2.1", required: true }, { key: "interval", label: "Intervalo (segundos)", type: "number", value: "2", min: "1" }, { key: "sound", label: "Alerta sonoro", type: "checkbox", value: false }],
  "servidor-lan": [{ key: "port", label: "Porta local", type: "number", value: "8080", min: "1", max: "65535" }],
  "config-ip": [{ key: "adapter", label: "Adaptador", type: "select", value: "example", options: [["example","Ethernet — exemplo"]] }, { key: "mode", label: "Configuração", type: "select", value: "static", options: [["dhcp","Automática (DHCP)"],["static","Manual (IPv4)"]] }, { key: "ip", label: "Endereço IPv4", placeholder: "192.0.2.10" }, { key: "mask", label: "Máscara de sub-rede", placeholder: "255.255.255.0" }, { key: "gateway", label: "Gateway", placeholder: "192.0.2.1" }, { key: "dns", label: "Servidor DNS", placeholder: "192.0.2.53" }],
  credenciais: [{ key: "name", label: "Identificação", placeholder: "Roteador do laboratório", required: true }, { key: "user", label: "Usuário de exemplo", placeholder: "usuario-exemplo" }, { key: "secret", label: "Segredo de exemplo", type: "password", required: true }],
};

const resultLayouts = {
 velocidade: ["metrics", [["Download","94,8 Mbps"],["Upload","46,2 Mbps"],["Latência","12 ms"]]],
 dispositivos: ["table", [["Nome","Endereço","Fabricante"],["Roteador de exemplo","192.0.2.1","Exemplo"],["Estação de exemplo","192.0.2.10","Exemplo"]]],
 roteador: ["message", "O painel do roteador seria aberto em uma nova aba. Nenhum endereço foi acessado."],
 reparar: ["table", [["Etapa","Estado ilustrativo"],["Limpeza do DNS","Concluída"],["Renovação do endereço","Concluída"],["Verificação final","Concluída"]]],
 wifi: ["table", [["Rede","Faixa","Canal","Sinal"],["Rede de exemplo","2,4 GHz","6","−58 dBm"],["Laboratório","5 GHz","36","−64 dBm"]]],
 latencia: ["metrics", [["Mínima","10 ms"],["Média","14 ms"],["Jitter","2 ms"]]],
 relatorio: ["message", "O relatório do projeto reúne equipamentos, cabeamento e resultados. Acesse a página Relatórios para conferir sua apresentação."],
 traceroute: ["table", [["Salto","Endereço","Latência"],["1","192.0.2.1","2 ms"],["2","198.51.100.1","14 ms"],["3","203.0.113.10","23 ms"]]],
 portas: ["table", [["Porta","Serviço","Estado"],["22","SSH","Aberta"],["443","HTTPS","Aberta"],["8080","HTTP alternativo","Fechada"]]],
 adaptador: ["table", [["Propriedade","Valor"],["Adaptador","Ethernet de exemplo"],["IPv4","192.0.2.10"],["Gateway","192.0.2.1"],["Link","1 Gbps"]]],
 dns: ["table", [["Servidor","Resposta","Tempo"],["DNS de exemplo A","192.0.2.20","12 ms"],["DNS de exemplo B","192.0.2.20","18 ms"]]],
 watchdog: ["table", [["Horário","Evento","Latência"],["10:00:00","Disponível","12 ms"],["10:00:05","Sem resposta","—"],["10:00:10","Restabelecido","15 ms"]]],
 "ip-externo": ["metrics", [["IP de exemplo","203.0.113.10"],["Origem","Conexão com o serviço"]]],
 mtu: ["metrics", [["MTU estimada","1.500 bytes"],["Carga útil","1.472 bytes"]]],
 vlsm: ["table", [["Rede","Máscara","Hosts","Broadcast"],["192.0.2.0/26","255.255.255.192","62","192.0.2.63"],["192.0.2.64/27","255.255.255.224","30","192.0.2.95"]]],
 "orcamento-optico": ["metrics", [["Perda total","18,2 dB"],["Potência recebida","−15,2 dBm"],["Margem","9,8 dB"]]],
 cftv: ["metrics", [["Banda total","32 Mbps"],["Armazenamento","10,4 TB"],["Retenção","30 dias"]]],
 "conversor-telecom": ["metrics", [["Valor de exemplo","20 dBm"],["Conversão ilustrativa","100 mW"]]],
 ssh: ["console", "usuario-exemplo@equipamento\n> show version\nEquipamento demonstrativo · versão 1.0\nNenhuma conexão SSH foi iniciada."],
 wol: ["message", "Aqui será apresentada a confirmação de envio. Nenhum pacote foi enviado nesta prévia."],
 "ping-sonoro": ["table", [["Amostra","Latência","Estado"],["1","12 ms","Resposta"],["2","13 ms","Resposta"],["3","—","Tempo esgotado"]]],
 pppoe: ["message", "Área reservada ao resultado da autenticação PPPoE. Nenhuma credencial foi transmitida."],
 "servidor-lan": ["metrics", [["Porta de exemplo","8080"],["Transferência ilustrativa","100 MB"],["Estado","Demonstração"]]],
 "wifi-string": ["console", "WIFI:T:WPA;S:RedeExemplo;P:senha-ficticia;;\nExemplo de formato. Não use como credencial real."],
 snmp: ["table", [["OID","Tipo","Valor"],["1.3.6.1.2.1.1.3.0","TimeTicks","Exemplo: 24 horas"]]],
 ssl: ["metrics", [["Hostname","example.com"],["Validade ilustrativa","90 dias"],["Estado","Exemplo válido"]]],
 "senha-segura": ["console", "Exemplo-De-Formato!27\nTexto ilustrativo. Não é uma senha gerada com segurança."],
 "atalhos-windows": ["message", "O atalho selecionado seria aberto no aplicativo desktop. O navegador não executa esta ação."],
 "config-ip": ["table", [["Configuração","Valor ilustrativo"],["IPv4","192.0.2.10"],["Máscara","255.255.255.0"],["Gateway","192.0.2.1"]]],
 ipv6: ["table", [["Verificação","Resultado ilustrativo"],["Endereço global","2001:db8::10"],["Resolução AAAA","Disponível"],["Conectividade","Disponível"]]],
 credenciais: ["table", [["Identificação","Usuário","Segredo"],["Equipamento de exemplo","usuario-exemplo","••••••••"]]],
};

export function previewFields(tool) {
  if (extraFields[tool.id]) return extraFields[tool.id];
  if (tool.fields) return tool.fields;
  if (tool.type === "host-input" || tool.type === "watchdog") return [{ key: "host", label: tool.inputLabel || "Destino", placeholder: tool.inputPlaceholder || "192.0.2.1", value: tool.defaultHost || "", required: tool.inputRequired ?? true }];
  return [];
}

export function previewResult(toolId) {
  const [kind, data] = resultLayouts[toolId] || ["message", "Resultado ilustrativo disponível após a integração."];
  if (kind === "metrics") return `<div class="stat-grid">${data.map(([label,value])=>`<div class="stat-card"><div class="stat-label">${escapeHtml(label)}</div><div class="stat-value is-long">${escapeHtml(value)}</div></div>`).join("")}</div>`;
  if (kind === "table") return `<div class="result-table-wrap" tabindex="0" role="region" aria-label="Tabela de exemplo"><table class="result-table"><caption class="sr-only">Dados ilustrativos</caption><thead><tr>${data[0].map(v=>`<th scope="col">${escapeHtml(v)}</th>`).join("")}</tr></thead><tbody>${data.slice(1).map(row=>`<tr>${row.map(v=>`<td>${escapeHtml(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  if (kind === "console") return `<pre class="console-box">${escapeHtml(data)}</pre>`;
  return `<p class="state-msg info">${escapeHtml(data)}</p>`;
}

export function renderToolPreview(root, tool, renderField) {
  const cat = CATEGORIES[tool.category], fields = previewFields(tool);
  const status = TOOL_STATUS[tool.id];
  const limitation = status === STATUS.DESKTOP_ONLY ? "Esta operação depende do aplicativo desktop. A tela abaixo permite revisar sua apresentação." : status === STATUS.REQUER_AGENTE_LOCAL ? "Esta ferramenta precisa de acesso ao equipamento ou à rede local para funcionar. Aqui você pode revisar a interface." : "Configure os campos para conferir a apresentação. Esta prévia não executa diagnósticos nem salva os valores informados.";
  root.innerHTML = `<section class="feature-view"><a href="#/categoria/${tool.category}" class="feature-back">← ${escapeHtml(cat.label)}</a><div class="feature-header ${cat.tone}"><span class="feature-icon-badge">${tool.icon}</span><div class="feature-heading"><div class="feature-eyebrow">#${String(tool.number).padStart(2,"0")} · ${escapeHtml(cat.shortLabel)}</div><h1 class="feature-title">${escapeHtml(tool.title)}</h1><p class="feature-desc">${escapeHtml(tool.description)}</p></div></div><p class="state-msg info"><strong>Prévia da interface.</strong> ${limitation}</p>
    <section class="feature-panel"><h2 class="panel-section-title">${fields.length ? "Configuração" : "Preparação"}</h2><form id="preview-tool-form">${fields.length ? fields.map(renderField).join("") : '<p class="section-description">Esta ferramenta não exige parâmetros iniciais. O resultado será apresentado no painel abaixo.</p>'}${fields.some(f=>f.type === "password") ? '<p class="field-hint">Use somente dados fictícios. Nenhum segredo será armazenado nesta prévia.</p>' : ""}<div class="project-actions"><button class="btn btn-primary" type="submit">Visualizar exemplo</button><button class="btn btn-ghost" type="reset">Restaurar campos</button></div></form></section>
    <section class="feature-panel"><div class="view-heading-row"><h2 class="panel-section-title">Resultado</h2><span class="badge badge-neutral">Dados ilustrativos</span></div><div id="preview-result" role="status" aria-live="polite" aria-atomic="true"></div>
    <details class="preview-states"><summary>Conferir estados desta interface</summary><div class="field"><label for="preview-state">Estado de apresentação</label><select id="preview-state"><option value="empty">Aguardando execução</option><option value="loading">Carregando</option><option value="success">Resultado de exemplo</option><option value="error">Falha com nova tentativa</option></select></div></details></section></section>`;
  const area = root.querySelector("#preview-result"), stateSelect = root.querySelector("#preview-state");
  let timer;
  function show(state) {
    clearTimeout(timer); stateSelect.value = state;
    area.innerHTML = state === "loading" ? loading("Demonstração de carregamento…") : state === "success" ? `<p class="field-hint">Exemplo de apresentação. Os valores abaixo são fictícios e não foram calculados a partir dos campos.</p>${previewResult(tool.id)}` : state === "error" ? '<p class="state-msg error" role="alert">Exemplo de falha: não foi possível concluir a operação. Confira os dados e tente novamente.</p><button class="btn btn-ghost" id="preview-retry">Tentar novamente na prévia</button>' : '<div class="empty-state"><strong>Aguardando execução</strong><p>O resultado aparecerá aqui. Selecione Visualizar exemplo para conferir o layout.</p></div>';
    root.querySelector("#preview-retry")?.addEventListener("click",run);
  }
  function run() { show("loading"); timer = setTimeout(()=>show("success"),500); }
  root.querySelector("#preview-tool-form").addEventListener("submit",event=>{event.preventDefault();run();});
  root.querySelector("#preview-tool-form").addEventListener("reset",()=>show("empty"));
  stateSelect.addEventListener("change",()=>show(stateSelect.value));
  show("empty");
  return () => clearTimeout(timer);
}
