import { INTERFACE_ONLY } from "../config/interface.js";
import { errorMessage } from "../components/feedback.js";
import { getSupabaseClient, getSupabaseContext, isSupabaseEnabled } from "../services/supabase.js";
import { resetProjectRepository } from "../repositories/getProjectRepository.js";
import { setCurrentProject } from "../state/projectSession.js";
import { escapeHtml } from "../lib/html.js";

export async function renderAccount(root) {
  if (INTERFACE_ONLY) {
    root.innerHTML = `<section class="feature-view account-view"><span class="section-eyebrow">CONTA E ACESSO</span><h1 class="view-title">Seu espaço no NetZônia</h1><p class="view-subtitle">Confira as telas de acesso antes da integração com sua conta.</p><div class="feature-panel"><h2 class="section-title">Acesso à plataforma</h2><p class="section-description">As telas abaixo estão em prévia. Nenhuma conta é criada e nenhuma credencial é enviada.</p><div class="account-options"><a href="#/login">Entrar na conta <span>→</span></a><a href="#/cadastro">Criar uma conta <span>→</span></a><a href="#/recuperar-senha">Recuperar senha <span>→</span></a></div></div><div class="feature-panel"><h2 class="section-title">Projetos locais</h2><p class="section-description">Projetos de revisão ficam neste navegador. Limpar os dados do navegador remove esses projetos; eles não são sincronizados com outros dispositivos.</p><a class="btn btn-ghost" href="#/projetos">Abrir projetos</a></div></section>`; return;
  }
  if (!isSupabaseEnabled()) {
    root.innerHTML = `<section class="feature-view account-view"><h1 class="view-title">Conta e ambiente</h1><div class="feature-panel"><p class="state-msg info"><strong>Seu espaço neste navegador.</strong> Você pode criar e editar projetos localmente. Eles não são sincronizados com outros dispositivos; limpar os dados do navegador remove os projetos.</p><a class="btn btn-primary" href="#/projetos">Abrir projetos locais</a></div></section>`;
    return;
  }
  const client = getSupabaseClient();
  const context = await getSupabaseContext();
  if (context.user) {
    root.innerHTML = `<section class="feature-view account-view"><h1 class="view-title">Conta</h1><div class="feature-panel"><p><strong>${escapeHtml(context.user.email)}</strong></p><p class="view-subtitle">Empresa: ${escapeHtml(context.companyId || "nenhuma associação")} · papel: ${escapeHtml(context.role || "—")}</p>
      ${context.companyId ? "" : '<form id="company-form"><div class="field"><label for="company-name">Nome da empresa</label><input id="company-name" minlength="2" maxlength="120" required></div><button class="btn btn-primary" type="submit">Criar empresa</button><p class="state-msg info">Você será responsável pela empresa e poderá organizar seus projetos neste espaço.</p><p id="company-error" class="state-msg error" role="alert" hidden></p></form>'}
      <p id="logout-error" class="state-msg error" role="alert" hidden></p><button class="btn btn-danger" id="logout">Sair da conta</button></div></section>`;
    root.querySelector("#company-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.currentTarget.querySelector("button");
      const errorBox = root.querySelector("#company-error");
      button.disabled = true; errorBox.hidden = true;
      try {
      const { error } = await client.rpc("create_company_with_owner", { company_name: root.querySelector("#company-name").value });
      if (error) { errorBox.textContent = errorMessage(error); errorBox.hidden = false; button.disabled = false; return; }
      resetProjectRepository(); location.hash = "#/projetos"; location.reload();
      } catch (error) { errorBox.textContent = errorMessage(error); errorBox.hidden = false; }
      finally { button.disabled = false; }
    });
    root.querySelector("#logout").addEventListener("click", async (event) => {
      const button = event.currentTarget; button.disabled = true;
      try {
        const { error } = await client.auth.signOut();
        if (error) throw error;
        resetProjectRepository(); setCurrentProject(null); location.hash = "#/conta"; location.reload();
      } catch (error) {
        const box = root.querySelector("#logout-error"); box.textContent = errorMessage(error); box.hidden = false;
      } finally { button.disabled = false; }
    });
    return;
  }
  root.innerHTML = `
    <section class="feature-view account-view"><h1 class="view-title">Entrar no NetZônia</h1><p class="view-subtitle">Acesse sua conta para continuar seus projetos e o planejamento da sua rede.</p>
      <div class="feature-panel"><form id="login-form"><div class="field"><label for="email">E-mail</label><input id="email" type="email" autocomplete="username" required></div><div class="field"><label for="password">Senha</label><input id="password" type="password" autocomplete="current-password" minlength="8" required></div><button class="btn btn-primary" type="submit">Entrar</button></form><p id="login-error" class="state-msg error" role="alert" hidden></p></div>
    </section>`;
  root.querySelector("#login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.currentTarget.querySelector("button"); const errorBox = root.querySelector("#login-error");
    button.disabled = true; errorBox.hidden = true;
    button.textContent = "Entrando…";
    try {
    const { error } = await client.auth.signInWithPassword({ email: root.querySelector("#email").value, password: root.querySelector("#password").value });
    button.disabled = false;
    if (error) { errorBox.textContent = errorMessage(error); errorBox.hidden = false; return; }
    resetProjectRepository(); location.hash = "#/projetos"; location.reload();
    } catch (error) { errorBox.textContent = errorMessage(error); errorBox.hidden = false; }
    finally { button.disabled = false; button.textContent = "Entrar"; }
  });
}
