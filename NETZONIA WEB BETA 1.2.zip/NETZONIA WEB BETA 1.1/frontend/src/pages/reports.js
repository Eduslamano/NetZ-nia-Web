import { getCurrentProject } from "../state/projectSession.js";
import { escapeHtml, formatDate } from "../lib/html.js";

export function buildProjectReport(project) {
  const planner = project.data?.planner3d || {};
  const environment = planner.environment || {};
  const equipment = planner.equipment || []; const racks = planner.racks || []; const cables = planner.cables || []; const zones = planner.zones || [];
  const results = project.data?.toolResults || [];
  const warnings = cables.flatMap((cable) => cable.validation?.warnings || []);
  const entityName = (id) => equipment.find((entity) => entity.id === id)?.name || id || "—";
  return [
    "NETZÔNIA — RELATÓRIO DE PROJETO",
    `Projeto: ${project.name}`, `Descrição: ${project.description || "—"}`,
    `Empresa/escopo: ${project.companyName || project.companyId || "modo local"}`,
    `Criado em: ${formatDate(project.createdAt)}`, `Atualizado em: ${formatDate(project.updatedAt)}`,
    "", "RESUMO DO AMBIENTE",
    `Dimensões: ${environment.width || "—"} m × ${environment.depth || "—"} m × ${environment.height || "—"} m`,
    `Equipamentos: ${equipment.length}`, `Racks: ${racks.length}`, `Cabos: ${cables.length}`, `Zonas EMI: ${zones.length}`,
    "", "EQUIPAMENTOS", ...(equipment.length ? equipment.map((e) => `- ${e.name} | instalação: ${e.installation?.type || "não definida"}${e.installation?.surfaceId ? ` | superfície: ${e.installation.surfaceId}` : ""}${e.installation?.rackId ? ` | rack: ${e.installation.rackId} | U${e.installation.rackU}` : ""}`) : ["- Nenhum equipamento"]),
    "", "RACKS", ...(racks.length ? racks.map((r) => `- ${r.name} | ${r.slots?.length || 0} equipamentos | ${r.units}U`) : ["- Nenhum rack"]),
    "", "CABEAMENTO", ...(cables.length ? cables.map((c) => `- ${entityName(c.originEquipmentId)} [${c.originPortId}] → ${entityName(c.destinationEquipmentId)} [${c.destinationPortId}] | ${c.type} | ${c.length} m | ${c.validation?.valid ? "OK" : "ATENÇÃO"}`) : ["- Nenhum cabo"]),
    "", "ZONAS EMI", ...(zones.length ? zones.map((zone) => `- ${zone.name || "Zona EMI"} | raio: ${zone.radius || "—"} m | x ${zone.position?.x ?? "—"}, z ${zone.position?.z ?? "—"}`) : ["- Nenhuma zona EMI"]),
    "", "ALERTAS", ...(warnings.length ? warnings.map((w) => `- ${w}`) : ["- Sem alertas"]),
    "", "RESULTADOS DE FERRAMENTAS", ...(results.length ? results.map((r) => `- ${r.toolId} em ${formatDate(r.createdAt)}: ${JSON.stringify(r.result)}`) : ["- Nenhum resultado salvo"]),
  ].join("\n");
}

function downloadText(filename, content) {
  const url = URL.createObjectURL(new Blob([content], { type: "text/plain;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function renderReports(root) {
  const project = await getCurrentProject({ refresh: true });
  if (!project) {
    root.innerHTML = '<section class="view"><h1 class="view-title">Relatórios</h1><p class="state-msg warn">Abra um projeto para gerar um relatório.</p><a class="btn btn-primary" href="#/projetos">Ir para Meus Projetos</a></section>';
    return;
  }
  const report = buildProjectReport(project);
  root.innerHTML = `
    <section class="view reports-view"><h1 class="view-title">Relatório do Projeto</h1><p class="view-subtitle">${escapeHtml(project.name)} · dados atuais do projeto, ferramentas e Planejador 3D.</p>
    <div class="project-actions"><button class="btn btn-primary" id="download-report">Baixar TXT</button><button class="btn" id="print-report">Imprimir / Salvar PDF</button></div>
    <p id="report-feedback" class="state-msg info" role="status" hidden></p><pre class="report-preview" tabindex="0" aria-label="Prévia do relatório">${escapeHtml(report)}</pre></section>`;
  root.querySelector("#download-report").addEventListener("click", () => downloadText(`${project.name.replace(/[^a-z0-9_-]+/gi, "_")}.txt`, report));
  root.querySelector("#print-report").addEventListener("click", () => {
    const popup = window.open("", "_blank");
    if (!popup) {
      const box = root.querySelector("#report-feedback");
      box.textContent = "A janela de impressão foi bloqueada. Permita pop-ups para este site ou use a opção Baixar TXT.";
      box.hidden = false; return;
    }
    popup.opener = null;
    popup.document.write(`<!doctype html><meta charset="utf-8"><title>Relatório — ${escapeHtml(project.name)}</title><style>body{font:14px system-ui;max-width:900px;margin:40px auto;white-space:pre-wrap;color:#123}pre{white-space:pre-wrap}</style><pre>${escapeHtml(report)}</pre><script>window.print()<\/script>`);
    popup.document.close();
  });
}
