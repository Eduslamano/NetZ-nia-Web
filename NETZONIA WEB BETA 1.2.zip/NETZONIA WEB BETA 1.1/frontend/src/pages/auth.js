import { escapeHtml } from "../lib/html.js";

const content = {
  login: { title: "Bem-vindo ao NetZônia", subtitle: "Seu espaço para diagnosticar, organizar e planejar redes.", action: "Conferir acesso" },
  cadastro: { title: "Crie seu espaço de trabalho", subtitle: "Organize seus projetos e mantenha seu planejamento em um só lugar.", action: "Conferir cadastro" },
  "redefinir-senha": { title: "Escolha uma nova senha", subtitle: "Esta é a tela que será aberta pelo link de recuperação de acesso.", action: "Conferir nova senha" },
  "recuperar-senha": { title: "Recuperar acesso", subtitle: "Informe o e-mail da sua conta para solicitar a recuperação de senha.", action: "Conferir solicitação" },
};

export function renderAuth(root, kind = "login") {
  const copy = content[kind] || content.login;
  const register = kind === "cadastro", reset = kind === "recuperar-senha", redefine = kind === "redefinir-senha";
  root.innerHTML = `<section class="view auth-layout">
    <aside class="auth-story"><span class="section-eyebrow">TECNOLOGIA COM RAÍZES</span><h2>Da conexão ao planejamento.</h2><p>Um ambiente para entender a rede, organizar projetos e visualizar sua infraestrutura.</p><ul><li>Diagnóstico e ferramentas em um só lugar</li><li>Projetos organizados por contexto</li><li>Planejamento visual em 3D</li></ul><a href="#/visao-geral" class="btn btn-ghost">Explorar a prévia</a></aside>
    <div class="auth-form-panel"><a class="feature-back" href="#/visao-geral">← Voltar à visão geral</a><h1 class="view-title">${copy.title}</h1><p class="view-subtitle">${copy.subtitle}</p>
    <p class="state-msg info">Prévia da interface. Nenhuma conta será criada e nenhum e-mail será enviado. Use dados fictícios para conferir este formulário.</p>
    <form id="auth-preview" novalidate>
      ${register ? '<div class="field"><label for="auth-name">Nome</label><input id="auth-name" name="name" autocomplete="off" required minlength="2" maxlength="100"></div><div class="field"><label for="auth-company">Empresa ou equipe (opcional)</label><input id="auth-company" name="company" autocomplete="off" maxlength="120"></div>' : ""}
      ${!redefine ? '<div class="field"><label for="auth-email">E-mail</label><input id="auth-email" name="email" type="email" placeholder="voce@exemplo.com" autocomplete="off" required></div>' : ""}
      ${!reset ? `<div class="field"><label for="auth-password">Senha de exemplo</label><div class="password-control"><input id="auth-password" name="password" type="password" autocomplete="off" minlength="8" required aria-describedby="password-hint"><button class="btn btn-sm btn-ghost" type="button" id="toggle-password" aria-label="Mostrar senha" aria-pressed="false">Mostrar</button></div><span id="password-hint" class="field-hint">Use ao menos 8 caracteres. Não informe sua senha real nesta prévia.</span></div>` : ""}
      ${register || redefine ? '<div class="field"><label for="auth-confirm">Confirmar senha de exemplo</label><input id="auth-confirm" name="confirm" type="password" autocomplete="off" required></div>' : ""}
      <p id="auth-error" class="state-msg error" role="alert" hidden></p><button class="btn btn-primary" type="submit">${copy.action}</button>
    </form><div id="auth-feedback" role="status" aria-live="polite"></div>
    <div class="auth-links">${kind === "login" ? '<a href="#/recuperar-senha">Esqueci minha senha</a><a href="#/cadastro">Criar conta</a>' : '<a href="#/login">Já tenho uma conta · Entrar</a>'}</div>
    </div></section>`;
  const password = root.querySelector("#auth-password");
  root.querySelector("#toggle-password")?.addEventListener("click", (event) => {
    const visible = password.type === "password";
    password.type = visible ? "text" : "password";
    event.currentTarget.textContent = visible ? "Ocultar" : "Mostrar";
    event.currentTarget.setAttribute("aria-label", visible ? "Ocultar senha" : "Mostrar senha");
    event.currentTarget.setAttribute("aria-pressed", String(visible));
  });
  root.querySelector("#auth-preview").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget, box = root.querySelector("#auth-error");
    box.hidden = true;
    form.querySelectorAll("[aria-invalid]").forEach((field) => field.removeAttribute("aria-invalid"));
    root.querySelector("#auth-feedback").replaceChildren();
    const invalid = [...form.elements].find((field) => field.willValidate && !field.validity.valid);
    const confirm = root.querySelector("#auth-confirm");
    const mismatch = confirm && confirm.value !== password.value;
    if (invalid || mismatch) {
      const field = invalid || confirm;
      field.setAttribute("aria-invalid", "true");
      box.textContent = mismatch && !invalid ? "As senhas não coincidem. Confira a confirmação." : "Confira os campos obrigatórios, o formato do e-mail e o tamanho da senha.";
      box.hidden = false; field.focus(); return;
    }
    // This form deliberately never sends or stores its contents.
    form.reset();
    root.querySelector("#auth-feedback").innerHTML = `<p class="state-msg success">${escapeHtml(reset ? "Formato do e-mail validado. Na versão conectada, esta etapa solicitará o link de recuperação. Nenhum e-mail foi enviado." : redefine ? "Formato da nova senha validado. Nenhuma senha foi alterada; o link e a sessão de recuperação serão conectados depois." : register ? "Campos validados. A criação da conta será conectada na próxima etapa. Nenhuma conta foi criada." : "Campos validados. A autenticação será conectada na próxima etapa.")}</p><a class="btn btn-ghost" href="${reset ? "#/redefinir-senha" : "#/visao-geral"}">${reset ? "Conferir tela de nova senha" : "Continuar na prévia"}</a>`;
  });
}
