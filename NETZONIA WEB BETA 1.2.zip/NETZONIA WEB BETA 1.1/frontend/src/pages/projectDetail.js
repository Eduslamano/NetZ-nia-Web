import { getProjectRepository } from "../repositories/getProjectRepository.js";
import { setCurrentProject, currentProjectId } from "../state/projectSession.js";
import { escapeHtml, formatDate } from "../lib/html.js";

export async function renderProjectDetail(root, id) {
  const project = await (await getProjectRepository()).get(id);
  if (!project) {
    root.innerHTML = '<section class="view empty-page"><h1 class="view-title">Projeto não encontrado</h1><p class="view-subtitle">O projeto pode ter sido removido ou pertencer a outro navegador.</p><a class="btn btn-primary" href="#/projetos">Voltar aos projetos</a></section>'; return;
  }
  const planner = project.data?.planner3d || {}, results = project.data?.toolResults || [];
  root.innerHTML = `<section class="view"><a href="#/projetos" class="feature-back">← Meus projetos</a><div class="view-heading-row"><div><span class="section-eyebrow">${currentProjectId() === id ? "PROJETO ABERTO" : "DETALHES DO PROJETO"}</span><h1 class="view-title">${escapeHtml(project.name)}</h1><p class="view-subtitle">${escapeHtml(project.description || "Este projeto ainda não tem uma descrição.")}</p></div><button class="btn btn-primary" data-project-destination="planejador">Abrir Planejador 3D</button></div>
    <div class="overview-stats">${[["Equipamentos",planner.equipment?.length||0],["Cabos",planner.cables?.length||0],["Resultados salvos",results.length]].map(([label,n])=>`<div class="stat-card"><span class="stat-label">${label}</span><strong class="stat-value">${n}</strong></div>`).join("")}</div>
    <div class="overview-columns"><section class="feature-panel"><h2 class="section-title">Organização do projeto</h2><dl class="project-details"><div><dt>Criado em</dt><dd>${formatDate(project.createdAt)}</dd></div><div><dt>Última atualização</dt><dd>${formatDate(project.updatedAt)}</dd></div><div><dt>Revisão</dt><dd>${project.revision || 1}</dd></div></dl><div class="project-actions"><button class="btn btn-ghost" data-project-destination="">Abrir ferramentas neste projeto</button><button class="btn btn-ghost" data-project-destination="relatorios">Ver relatório</button><a class="btn btn-ghost" href="#/projetos">Gerenciar projetos</a></div></section><section class="feature-panel"><h2 class="section-title">Atividade das ferramentas</h2>${results.length ? `<ul class="activity-list">${results.slice(0,5).map(r=>`<li><strong>${escapeHtml(r.toolId)}</strong><span>${formatDate(r.createdAt)}</span></li>`).join("")}</ul>` : '<p class="section-description">Nenhum resultado salvo. Os diagnósticos associados a este projeto aparecerão aqui após a integração.</p>'}</section></div></section>`;
  root.querySelectorAll("[data-project-destination]").forEach(button=>button.addEventListener("click",()=>{
    setCurrentProject(project); location.hash = `#/${button.dataset.projectDestination}`;
  }));
}
