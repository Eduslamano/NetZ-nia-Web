import { PlannerEngine } from "../mapa3d/engine/plannerEngine.js";
import { EQUIPMENT_CATALOG, catalogItem } from "../mapa3d/equipmentCatalog.js";
import { createEntity, findEntity, rebuildPortOccupancy, removeEntity } from "../mapa3d/model.js";
import { createCable, CABLE_TYPES, validateCablePath } from "../mapa3d/networkValidator.js";
import { installInRack, removeFromRack } from "../mapa3d/rackManager.js";
import { restorePlanner, serializePlanner } from "../mapa3d/persistence.js";
import { constrainAllEntities, constrainEntityToInstallation, defaultSurfaceFor, WALL_SURFACES } from "../mapa3d/installationConstraints.js";
import { createAutosave } from "../services/autosave.js";
import { getCurrentProject, updateCurrentProject } from "../state/projectSession.js";
import { escapeHtml } from "../lib/html.js";

const mountingLabel = (type) => ({ floor: "piso", wall: "parede", ceiling: "teto", rack: "rack" }[type] || type);

export async function renderPlanner3D(root) {
  const project = await getCurrentProject({ refresh: true });
  if (!project) {
    root.innerHTML = `<section class="view"><h1 class="view-title">Planejador 3D</h1><p class="state-msg warn">Abra ou crie um projeto antes de abrir o planejador.</p><a class="btn btn-primary" href="#/projetos">Ir para Meus Projetos</a></section>`;
    return () => {};
  }
  const state = restorePlanner(project.data?.planner3d);
  let selectedId = null;
  let destroyed = false;
  let dirty = false;
  const cableSelection = { originId: "", originPortId: "", destinationId: "", destinationPortId: "" };
  const protectUnsaved = (event) => {
    if (!dirty) return;
    event.preventDefault();
    event.returnValue = "";
  };
  window.addEventListener("beforeunload", protectUnsaved);

  root.innerHTML = `
    <section class="view mapa3d-view">
      <div class="view-heading-row"><div><h1 class="view-title">Planejador 3D</h1><p class="view-subtitle">${escapeHtml(project.name)} · selecione, mova, rotacione e conecte equipamentos.</p></div><span class="badge" id="save-state" role="status">Salvo</span></div>
      <div class="mapa3d-layout">
        <aside class="mapa3d-palette"><div class="feature-panel compact"><strong>Ambiente</strong><form id="environment-form">
          <div class="mapa3d-dimensions"><label>Largura (m)<input id="environment-width" type="number" min="4" max="200" step="0.5" value="${state.environment.width}"></label><label>Profundidade (m)<input id="environment-depth" type="number" min="4" max="200" step="0.5" value="${state.environment.depth}"></label><label>Altura (m)<input id="environment-height" type="number" min="2" max="20" step="0.1" value="${state.environment.height}"></label></div>
          <button class="btn btn-sm" type="submit">Aplicar ambiente</button></form></div><strong>Equipamentos</strong><div class="mapa3d-palette-list">
          ${Object.values(EQUIPMENT_CATALOG).map((item) => `<button class="mapa3d-palette-item" data-add-type="${item.id}"><span class="mapa3d-swatch" style="background:${item.color}"></span><span class="mapa3d-palette-text"><strong>${escapeHtml(item.name)}</strong><span class="mapa3d-palette-sub">${item.mounting === "rack" ? "Instalação em rack" : `Instalação: ${mountingLabel(item.mounting)}`}</span></span><span class="mapa3d-palette-place">+ Adicionar</span></button>`).join("")}
        </div><button class="btn" id="add-emi">+ Zona de risco EMI</button></aside>
        <div class="mapa3d-stage">
          <div class="mapa3d-toolbar"><span class="mapa3d-toolbar-status" id="planner-status" role="status" aria-live="polite">Clique em um objeto para selecionar.</span><div class="mapa3d-toolbar-actions"><button class="btn active" data-mode="translate" aria-pressed="true">Mover</button><button class="btn" data-mode="rotate" aria-pressed="false">Rotacionar</button><button class="btn btn-danger" id="delete-selected" disabled>Excluir</button><button class="btn btn-primary" id="save-now">Salvar</button></div></div>
          <div class="mapa3d-canvas-wrap" id="planner-canvas" role="region" aria-label="Ambiente de planejamento em 3D"></div><p class="field-hint">Arraste para explorar o ambiente. Use a lista de objetos abaixo para selecionar um item pelo teclado.</p><div class="field"><label for="object-select">Selecionar objeto</label><select id="object-select"><option value="">Nenhum objeto</option></select></div>
        </div>
        <aside class="mapa3d-sidepanel">
          <div id="selection-panel"></div>
          <div class="feature-panel compact"><strong>Cabeamento: ORIGEM → DESTINO</strong>
            <div class="field"><label for="cable-origin">Origem</label><select id="cable-origin"></select></div>
            <div class="field"><label for="cable-origin-port">Porta de origem</label><select id="cable-origin-port"></select></div>
            <div class="field"><label for="cable-destination">Destino</label><select id="cable-destination"></select></div>
            <div class="field"><label for="cable-destination-port">Porta de destino</label><select id="cable-destination-port"></select></div>
            <div class="field"><label for="cable-type">Tipo</label><select id="cable-type">${Object.entries(CABLE_TYPES).map(([id, t]) => `<option value="${id}">${t.name}</option>`).join("")}</select></div>
            <button class="btn btn-primary" id="create-cable">Criar cabo</button>
          </div>
          <div id="planner-summary"></div>
        </aside>
      </div>
    </section>`;

  const saveState = root.querySelector("#save-state");
  const status = root.querySelector("#planner-status");
  const autosave = createAutosave(async (snapshot) => {
    const latest = await getCurrentProject();
    await updateCurrentProject({ data: { ...(latest.data || {}), planner3d: snapshot } });
  }, {
    onState: (value, error) => {
      dirty = value === "pending" || value === "saving" || value === "error";
      saveState.textContent = value === "saving" ? "Salvando…" : value === "error" ? "Erro ao salvar" : value === "pending" ? "Alterações pendentes" : "Salvo";
      saveState.className = `badge ${value === "error" ? "badge-bad" : value === "saved" ? "badge-good" : "badge-warn"}`;
      if (error) status.textContent = error.message;
    },
  });

  let engine;
  try { engine = new PlannerEngine(root.querySelector("#planner-canvas"), state, {
    onSelect: (id) => { selectedId = id; renderPanels(); },
    onTransform: () => {
      state.cables.forEach((c) => {
        const a = findEntity(state, c.originEquipmentId); const b = findEntity(state, c.destinationEquipmentId);
        c.validation = validateCablePath(a, b, c.type, state.zones); c.length = c.validation.length;
      });
      engine.refreshCables(); changed(false);
    },
  });

  } catch (error) {
    window.removeEventListener("beforeunload", protectUnsaved);
    throw new Error("Não foi possível iniciar a visualização 3D. Verifique se a aceleração gráfica está ativada e tente novamente em um navegador compatível.");
  }
  root.querySelector("#object-select").addEventListener("change", (event) => {
    selectedId = event.target.value || null; engine.select(selectedId); renderPanels();
  });
  function changed(rebuild = true) {
    if (destroyed) return;
    if (rebuild) engine.rebuild(state);
    autosave.schedule(serializePlanner(state));
    renderPanels();
  }

  function endpointOptions() {
    return state.equipment.filter((e) => e.ports?.length).map((e) => `<option value="${e.id}">${escapeHtml(e.name)} · ${e.ports.filter((p) => !p.occupiedBy).length} portas livres</option>`).join("");
  }

  function portOptions(entityId, selectedPortId) {
    const entity = findEntity(state, entityId);
    const options = (entity?.ports || []).filter((port) => !port.occupiedBy || port.id === selectedPortId);
    return `<option value="">Selecione…</option>${options.map((port) => `<option value="${escapeHtml(port.id)}" ${port.id === selectedPortId ? "selected" : ""}>${escapeHtml(port.name)} · ${escapeHtml(port.type || "porta")}</option>`).join("")}`;
  }

  function renderCableSelectors() {
    const options = endpointOptions();
    const originSelect = root.querySelector("#cable-origin");
    const destinationSelect = root.querySelector("#cable-destination");
    originSelect.innerHTML = `<option value="">Selecione…</option>${options}`;
    destinationSelect.innerHTML = `<option value="">Selecione…</option>${options}`;
    originSelect.value = cableSelection.originId;
    destinationSelect.value = cableSelection.destinationId;
    root.querySelector("#cable-origin-port").innerHTML = portOptions(cableSelection.originId, cableSelection.originPortId);
    root.querySelector("#cable-destination-port").innerHTML = portOptions(cableSelection.destinationId, cableSelection.destinationPortId);
  }

  function renderPanels() {
    const selected = findEntity(state, selectedId);
    const objectSelect = root.querySelector("#object-select");
    objectSelect.innerHTML = `<option value="">Nenhum objeto</option>${[...state.racks, ...state.equipment].map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`).join("")}`;
    objectSelect.value = selectedId || "";
    root.querySelector("#delete-selected").disabled = !selected;

    root.querySelector("#selection-panel").innerHTML = selected ? `
      <div class="feature-panel compact"><strong>Selecionado</strong><div class="field"><label for="selected-name">Nome</label><input id="selected-name" maxlength="80" value="${escapeHtml(selected.name)}"></div>
      <div class="field"><label for="installation-type">Instalação lógica</label><select id="installation-type" ${selected.slots ? "disabled" : ""}>${["floor","wall","ceiling","rack"].map((type) => `<option value="${type}" ${selected.installation.type === type ? "selected" : ""}>${mountingLabel(type)}</option>`).join("")}</select></div>
      ${selected.installation.type === "wall" ? `<div class="field"><label for="wall-surface">Superfície da parede</label><select id="wall-surface">${WALL_SURFACES.map((surface) => `<option value="${surface}" ${selected.installation.surfaceId === surface ? "selected" : ""}>${surface.replace("wall-", "parede ")}</option>`).join("")}</select></div>` : ""}
      <span class="mapa3d-row-sub">x ${selected.transform.position.x.toFixed(1)} · y ${selected.transform.position.y.toFixed(1)} · z ${selected.transform.position.z.toFixed(1)}${selected.installation.rackU ? ` · U${selected.installation.rackU}` : ""}</span></div>`
      : '<p class="state-msg info">Nenhum objeto selecionado.</p>';
    renderCableSelectors();
    root.querySelector("#planner-summary").innerHTML = `
      <div class="feature-panel compact"><strong>Projeto</strong><p class="mapa3d-row-sub">${state.equipment.length} equipamentos · ${state.racks.length} racks · ${state.cables.length} cabos</p>
      ${state.zones.length ? `<p class="state-msg warn">${state.zones.length} zona(s) EMI ativa(s). <button class="btn btn-sm" id="clear-emi">Limpar zonas</button></p>` : ""}
      ${state.cables.map((c) => `<div class="mapa3d-row"><span class="mapa3d-row-text"><strong>${escapeHtml(CABLE_TYPES[c.type]?.name)}</strong><span class="mapa3d-row-sub">${c.length} m ${c.validation?.warnings?.join(" · ") || "· OK"}</span></span><button class="mapa3d-row-del" data-delete-cable="${c.id}" title="Excluir cabo">×</button></div>`).join("")}</div>`;
    root.querySelector("#selected-name")?.addEventListener("change", (event) => { selected.name = event.target.value.trim() || catalogItem(selected.type).name; changed(); });
    root.querySelector("#installation-type")?.addEventListener("change", (event) => {
      const type = event.target.value;
      if (type === "rack") {
        const rack = state.racks[0];
        if (!rack) { status.textContent = "Adicione um rack antes de instalar o equipamento."; renderPanels(); return; }
        try { installInRack(rack, selected); } catch (error) { status.textContent = error.message; return; }
      } else {
        removeFromRack(state.racks, selected);
        selected.installation = { type, surfaceId: defaultSurfaceFor(type), rackId: null, rackU: null };
      }
      constrainEntityToInstallation(state, selected);
      changed();
    });
    root.querySelector("#wall-surface")?.addEventListener("change", (event) => {
      selected.installation.surfaceId = event.target.value;
      constrainEntityToInstallation(state, selected);
      changed();
    });
    root.querySelector("#cable-origin")?.addEventListener("change", (event) => {
      cableSelection.originId = event.target.value; cableSelection.originPortId = ""; renderCableSelectors();
    });
    root.querySelector("#cable-destination")?.addEventListener("change", (event) => {
      cableSelection.destinationId = event.target.value; cableSelection.destinationPortId = ""; renderCableSelectors();
    });
    root.querySelector("#cable-origin-port")?.addEventListener("change", (event) => { cableSelection.originPortId = event.target.value; });
    root.querySelector("#cable-destination-port")?.addEventListener("change", (event) => { cableSelection.destinationPortId = event.target.value; });
    root.querySelector("#clear-emi")?.addEventListener("click", () => { state.zones = []; state.cables.forEach((c) => { c.validation = validateCablePath(findEntity(state, c.originEquipmentId), findEntity(state, c.destinationEquipmentId), c.type, []); c.length = c.validation.length; }); changed(); });
  }

  root.querySelectorAll("[data-add-type]").forEach((button, index) => button.addEventListener("click", () => {
    const spec = catalogItem(button.dataset.addType);
    const entity = createEntity(spec.id, { x: (index % 4) * 1.8 - 2.7, y: 0, z: Math.floor(index / 4) * 1.8 - 1.8 });
    if (spec.kind === "rack") {
      state.racks.push(entity);
      state.environment.height = Math.min(20, Math.max(state.environment.height, spec.size[1] + 0.2));
      root.querySelector("#environment-height").value = state.environment.height;
    }
    else {
      if (spec.mounting === "rack") {
        const rack = state.racks[0];
        if (!rack) { status.textContent = "Este equipamento exige rack. Adicione um Rack 24U ou 42U primeiro."; return; }
        try { installInRack(rack, entity); } catch (error) { status.textContent = error.message; return; }
      }
      state.equipment.push(entity);
    }
    constrainEntityToInstallation(state, entity);
    selectedId = entity.id; status.textContent = `${entity.name} adicionado.`; changed(); engine.select(entity.id);
  }));

  root.querySelector("#environment-form").addEventListener("submit", (event) => {
    event.preventDefault();
    state.environment.width = Math.min(200, Math.max(4, Number(root.querySelector("#environment-width").value) || 24));
    state.environment.depth = Math.min(200, Math.max(4, Number(root.querySelector("#environment-depth").value) || 18));
    state.environment.height = Math.min(20, Math.max(2, Number(root.querySelector("#environment-height").value) || 3));
    constrainAllEntities(state);
    state.cables.forEach((cable) => {
      cable.validation = validateCablePath(findEntity(state, cable.originEquipmentId), findEntity(state, cable.destinationEquipmentId), cable.type, state.zones);
      cable.length = cable.validation.length;
    });
    status.textContent = "Dimensões do ambiente atualizadas.";
    changed();
  });

  root.querySelector("#add-emi").addEventListener("click", () => {
    state.zones.push({ id: crypto.randomUUID(), name: `Zona EMI ${state.zones.length + 1}`, position: { x: 0, y: 0, z: 0 }, radius: 2 });
    state.cables.forEach((c) => { c.validation = validateCablePath(findEntity(state, c.originEquipmentId), findEntity(state, c.destinationEquipmentId), c.type, state.zones); c.length = c.validation.length; });
    status.textContent = "Zona EMI criada no centro do ambiente."; changed(false);
  });
  root.querySelectorAll("[data-mode]").forEach((button) => button.addEventListener("click", () => {
    root.querySelectorAll("[data-mode]").forEach((b) => { b.classList.toggle("active", b === button); b.setAttribute("aria-pressed", String(b === button)); });
    engine.setTransformMode(button.dataset.mode);
  }));
  root.querySelector("#delete-selected").addEventListener("click", () => {
    if (!selectedId) return;
    removeEntity(state, selectedId); selectedId = null; engine.select(null); changed();
  });
  root.querySelector("#create-cable").addEventListener("click", () => {
    try {
      const cable = createCable(state, cableSelection.originId, cableSelection.destinationId, root.querySelector("#cable-type").value, cableSelection.originPortId, cableSelection.destinationPortId);
      cableSelection.originPortId = ""; cableSelection.destinationPortId = "";
      status.textContent = cable.validation.warnings.join(" ") || `Cabo criado: ${cable.length} m.`;
      changed();
    } catch (error) { status.textContent = error.message; }
  });
  root.querySelector("#planner-summary").addEventListener("click", (event) => {
    const button = event.target.closest("[data-delete-cable]");
    if (!button) return;
    state.cables = state.cables.filter((c) => c.id !== button.dataset.deleteCable); rebuildPortOccupancy(state); changed();
  });
  root.querySelector("#save-now").addEventListener("click", () => { void autosave.flush().catch(() => { status.textContent = "Não foi possível salvar. Suas alterações continuam nesta tela. Confira a conexão e clique em Salvar novamente."; }); });
  renderPanels();

  return async () => {
    try { await autosave.flush(); } catch { /* estado visual já informa a falha */ }
    destroyed = true;
    window.removeEventListener("beforeunload", protectUnsaved);
    engine.dispose();
  };
}
