import { projectDialog, errorMessage } from "../components/feedback.js";
import { getProjectRepository } from "../repositories/getProjectRepository.js";
import { currentProjectId, setCurrentProject } from "../state/projectSession.js";
import { escapeHtml, formatDate } from "../lib/html.js";

function projectCard(project, active) {
  const equipment = project.data?.planner3d?.equipment?.length || 0;
  const cables = project.data?.planner3d?.cables?.length || 0;
  return `
    <article class="project-card ${active ? "is-active" : ""}" data-project-id="${escapeHtml(project.id)}">
      <div class="project-card-head">
        <div><span class="project-kicker">${active ? "Projeto aberto" : "Projeto"}</span><h2>${escapeHtml(project.name)}</h2></div>
        <span class="badge ${active ? "badge-good" : ""}">r${project.revision || 1}</span>
      </div>
      <p>${escapeHtml(project.description || "Sem descrição.")}</p>
      <div class="project-meta"><span>Atualizado: ${formatDate(project.updatedAt)}</span><span>${equipment} equipamentos · ${cables} cabos</span></div>
      <div class="project-actions">
        <a class="btn btn-primary" href="#/projeto/${encodeURIComponent(project.id)}">Ver projeto</a><button class="btn btn-ghost" data-project-action="open">Selecionar</button>
        <button class="btn" data-project-action="planner">Planejador 3D</button>
        <button class="btn" data-project-action="edit">Editar</button>
        <button class="btn" data-project-action="duplicate">Duplicar</button>
        <button class="btn btn-danger" data-project-action="delete">Excluir</button>
      </div>
    </article>`;
}

export async function renderProjects(root, { create = false } = {}) {
  root.innerHTML = `<section class="view"><div class="loading-row"><span class="spinner"></span> Carregando projetos…</div></section>`;
  const repository = await getProjectRepository();
  let query = "";
  let feedback = "";
  let feedbackType = "info";
  let drawId = 0;

  async function draw() {
    const requestId = ++drawId;
    const searching = root.querySelector("#project-search") === document.activeElement;
    const projects = await repository.list(query);
    if (requestId !== drawId) return;
    root.innerHTML = `
      <section class="view projects-view">
        <div class="view-heading-row">
          <div><h1 class="view-title">Meus Projetos</h1><p class="view-subtitle">Projetos concentram ferramentas, ambiente 3D, cabeamento e relatórios.</p></div>
          <button class="btn btn-primary" id="new-project">+ Novo projeto</button>
        </div>
        <div class="project-search"><input id="project-search" aria-label="Pesquisar projetos" type="search" value="${escapeHtml(query)}" placeholder="Pesquisar projetos…"></div>
        <p id="project-feedback" role="status" aria-live="polite" class="state-msg ${feedbackType}" ${feedback ? "" : "hidden"}>${escapeHtml(feedback)}</p>
        <form class="project-form" id="project-form" hidden>
          <div class="field"><label for="project-name">Nome *</label><input id="project-name" maxlength="120" required></div>
          <div class="field"><label for="project-description">Descrição</label><input id="project-description" maxlength="1000"></div>
          <div class="project-actions"><button class="btn btn-primary" type="submit">Criar e abrir</button><button class="btn" id="cancel-project" type="button">Cancelar</button></div>
        </form>
        <div class="project-grid" id="project-grid">
          ${projects.length ? projects.map((p) => projectCard(p, p.id === currentProjectId())).join("") : '<div class="empty-state"><strong>Nenhum projeto encontrado.</strong><p>Crie um projeto para começar a planejar.</p></div>'}
        </div>
      </section>`;
    bind();
    if (searching) root.querySelector("#project-search")?.focus();
  }

  function bind() {
    const showFeedback = (message, type = "info") => {
      feedback = message;
      feedbackType = type;
      const box = root.querySelector("#project-feedback");
      if (box) { box.textContent = message; box.className = `state-msg ${type}`; box.hidden = !message; box.setAttribute("role", type === "error" ? "alert" : "status"); }
    };
    const search = root.querySelector("#project-search");
    let timer;
    search?.addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(() => { query = search.value; void draw().catch((error) => showFeedback(errorMessage(error), "error")); }, 180);
    });
    root.querySelector("#new-project")?.addEventListener("click", () => {
      const form = root.querySelector("#project-form");
      form.hidden = false; form.querySelector("#project-name").focus();
    });
    root.querySelector("#cancel-project")?.addEventListener("click", () => { root.querySelector("#project-form").hidden = true; root.querySelector("#new-project").focus(); });
    root.querySelector("#project-form")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.currentTarget.querySelector('button[type="submit"]');
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
      try {
        const project = await repository.create({
          name: root.querySelector("#project-name").value,
          description: root.querySelector("#project-description").value,
          data: {},
        });
        setCurrentProject(project);
        location.hash = "#/planejador";
      } catch (error) {
        showFeedback(errorMessage(error), "error");
        button.disabled = false; button.removeAttribute("aria-busy");
      }
    });
    root.querySelector("#project-grid")?.addEventListener("click", async (event) => {
      const button = event.target.closest("[data-project-action]");
      const card = event.target.closest("[data-project-id]");
      if (!button || !card) return;
      button.disabled = true;
      button.setAttribute("aria-busy", "true");
      try {
        const project = await repository.get(card.dataset.projectId);
        if (!project) throw new Error("Projeto não encontrado.");
        const action = button.dataset.projectAction;
        if (action === "open" || action === "planner") {
          setCurrentProject(project);
          location.hash = action === "planner" ? "#/planejador" : "#/";
        } else if (action === "edit") {
          const values = await projectDialog({ title: "Editar projeto", description: "Atualize o nome e a descrição para identificar seu planejamento.", project });
          if (!values) { button.disabled = false; button.removeAttribute("aria-busy"); button.focus(); return; }
          const updated = await repository.update(project.id, values);
          if (currentProjectId() === project.id) setCurrentProject(updated);
          feedback = "Projeto atualizado."; feedbackType = "success";
          await draw();
        } else if (action === "duplicate") {
          const duplicate = await repository.duplicate(project.id);
          feedback = `Cópia criada: ${duplicate.name}.`; feedbackType = "success";
          await draw();
        } else if (action === "delete" && await projectDialog({ title: "Excluir projeto?", description: `“${project.name}” será excluído definitivamente, incluindo seu planejamento e resultados. Esta ação não pode ser desfeita.`, destructive: true })) {
          await repository.delete(project.id);
          if (currentProjectId() === project.id) setCurrentProject(null);
          feedback = "Projeto excluído."; feedbackType = "success";
          await draw();
        } else {
          button.disabled = false; button.removeAttribute("aria-busy"); button.focus();
        }
      } catch (error) {
        showFeedback(errorMessage(error), "error");
        button.disabled = false; button.removeAttribute("aria-busy");
      }
    });
  }

  await draw();
  if (create) { root.querySelector("#project-form").hidden = false; root.querySelector("#project-name").focus(); }
}
