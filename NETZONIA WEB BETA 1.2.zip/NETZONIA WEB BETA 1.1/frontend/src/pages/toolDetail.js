import { INTERFACE_ONLY } from "../config/interface.js";
import { renderToolPreview } from "./toolPreview.js";
import { errorMarkup, loading } from "../components/feedback.js";
import { getToolById } from "../data/tools.js";
import { CATEGORIES } from "../data/categories.js";
import { TOOL_STATUS, STATUS, STATUS_LABEL, STATUS_NOTE } from "../data/toolStatus.js";
import { runTool } from "../services/toolRunner.js";
import { getIPOrigem } from "../services/api.js";
import { saveToolResult } from "../state/projectSession.js";

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function fieldHtml(f) {
  const id = `f-${f.key}`;
  if (f.type === "checkbox") {
    return `
      <div class="field-checkbox">
        <label class="checkbox-label">
          <input type="checkbox" id="${id}" name="${f.key}" ${f.value ? "checked" : ""}/>
          ${escapeHtml(f.label)}
        </label>
      </div>`;
  }
  if (f.type === "select") {
    const opts = (f.options || [])
      .map(([v, l]) => `<option value="${escapeHtml(v)}" ${v === f.value ? "selected" : ""}>${escapeHtml(l)}</option>`)
      .join("");
    return `<div class="field"><label for="${id}">${escapeHtml(f.label)}</label><select id="${id}" name="${f.key}">${opts}</select></div>`;
  }
  const type = f.type === "number" ? "number" : f.type === "password" ? "password" : "text";
  return `
    <div class="field">
      <label for="${id}">${escapeHtml(f.label)}${f.required ? " *" : ""}</label>
      <input type="${type}" id="${id}" name="${f.key}"
        value="${escapeHtml(f.value ?? "")}"
        placeholder="${escapeHtml(f.placeholder ?? "")}"
        ${f.min !== undefined ? `min="${f.min}"` : ""}
        ${f.max !== undefined ? `max="${f.max}"` : ""}
        ${f.step !== undefined ? `step="${f.step}"` : ""}
        ${f.required ? "required" : ""}/>
    </div>`;
}

function readFormValues(form, fields) {
  const out = {};
  for (const f of fields || []) {
    const el = form.elements[f.key];
    if (!el) continue;
    out[f.key] = f.type === "checkbox" ? el.checked : el.value;
  }
  return out;
}

function renderResult(data) {
  if (data == null) return "";
  if (Array.isArray(data)) {
    if (data.length === 0) return `<p class="state-msg info">Sem resultados.</p>`;
    if (typeof data[0] === "object") {
      const cols = Object.keys(data[0]);
      const rows = data
        .map((row) => `<tr>${cols.map((c) => `<td>${escapeHtml(row[c])}</td>`).join("")}</tr>`)
        .join("");
      return `
        <div class="result-table-wrap" tabindex="0" role="region" aria-label="Resultados da ferramenta">
          <table class="result-table">
            <thead><tr>${cols.map((c) => `<th scope="col">${escapeHtml(c)}</th>`).join("")}</tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    }
    return `<p class="mono-cell">${data.map(escapeHtml).join(", ")}</p>`;
  }
  if (typeof data === "object") {
    // Objeto com um único campo textual relevante (string/senha) ganha destaque.
    const keys = Object.keys(data);
    if (keys.length === 1 && typeof data[keys[0]] === "string") {
      return `<p class="mono-cell" style="font-size:16px;padding:12px;background:var(--surface-2);border-radius:8px;word-break:break-all">${escapeHtml(data[keys[0]])}</p>`;
    }
    if (Array.isArray(data.resultados)) {
      return renderResult(data.resultados) + (data.origem ? `<p class="state-msg info">Origem: ${escapeHtml(data.origem)}</p>` : "");
    }
    if (Array.isArray(data.alertas)) {
      const badge = data.ok
        ? `<span class="badge badge-good">OK</span>`
        : `<span class="badge badge-warn">Atenção</span>`;
      return `
        <div class="stat-grid">
          <div class="stat-card"><div class="stat-label">Host</div><div class="stat-value">${escapeHtml(data.host)}</div></div>
          <div class="stat-card"><div class="stat-label">Dias restantes</div><div class="stat-value">${escapeHtml(data.diasRestantes)}</div></div>
          <div class="stat-card"><div class="stat-label">Emissor</div><div class="stat-value is-long">${escapeHtml(data.emissor)}</div></div>
        </div>
        <p>${badge} ${data.alertas.map(escapeHtml).join(" · ") || "Sem alertas"}</p>`;
    }
    return `
      <div class="stat-grid">
        ${keys.map((k) => `<div class="stat-card"><div class="stat-label">${escapeHtml(k)}</div><div class="stat-value is-long">${escapeHtml(typeof data[k] === "object" ? JSON.stringify(data[k]) : data[k])}</div></div>`).join("")}
      </div>`;
  }
  return `<p class="mono-cell">${escapeHtml(data)}</p>`;
}

export function renderToolDetail(root, toolId) {
  const tool = getToolById(toolId);
  if (!tool) {
    root.innerHTML = `<section class="view empty-page"><h1 class="view-title">Ferramenta não encontrada</h1><a class="btn btn-primary" href="#/">Voltar às categorias</a></section>`;
    return;
  }
  if (INTERFACE_ONLY) return renderToolPreview(root, tool, fieldHtml);
  const cat = CATEGORIES[tool.category];
  const status = TOOL_STATUS[tool.id] || STATUS.POS_MVP;
  const isReady = status === STATUS.FUNCIONAL_E_TESTADO || status === STATUS.FUNCIONAL_CONTROLADO;

  root.innerHTML = `
    <section class="feature-view">
      <a class="feature-back" href="#/categoria/${tool.category}">← ${escapeHtml(cat?.label || "Categorias")}</a>
      <div class="feature-header ${cat ? cat.tone : ""}">
        <span class="feature-icon-badge">${tool.icon}</span>
        <div class="feature-heading">
          <div class="feature-eyebrow">#${String(tool.number).padStart(2, "0")} · ${cat ? escapeHtml(cat.shortLabel) : ""}</div>
          <h1 class="feature-title">${escapeHtml(tool.title)}</h1>
          <div class="feature-desc">${escapeHtml(tool.description)}</div>
        </div>
      </div>

      ${
        isReady
          ? `<div class="feature-panel" id="tool-panel"></div>`
          : `<div class="feature-panel">
              <p class="state-msg ${status === STATUS.DESKTOP_ONLY ? "warn" : "pending"}">
                <strong>${escapeHtml(STATUS_LABEL[status])}.</strong>
                ${escapeHtml(STATUS_NOTE[tool.id] || "Ainda não migrado para a Web nesta entrega.")}
              </p>
            </div>`
      }
    </section>`;

  if (!isReady) return;

  const panel = root.querySelector("#tool-panel");

  // Casos especiais sem formulário genérico.
  if (tool.id === "ip-externo") {
    panel.innerHTML = `
      <p class="panel-section-title">IP de origem visto pelo servidor</p>
      <p class="state-msg info">Consulte o endereço IP visto pelo serviço na conexão atual. Esta consulta não informa sua localização.</p>
      <button class="btn btn-primary" id="run-ip-origem" type="button">Consultar</button>
      <div id="result-area" role="status" aria-live="polite" aria-atomic="true"></div>`;
    panel.querySelector("#run-ip-origem").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      const area = panel.querySelector("#result-area");
      btn.disabled = true;
      area.innerHTML = `<div class="loading-row"><span class="spinner"></span> Consultando…</div>`;
      try {
        const data = await getIPOrigem();
        area.innerHTML = renderResult(data);
        try { await saveToolResult(tool.id, {}, data); } catch { area.insertAdjacentHTML("beforeend", '<p class="state-msg warn">Consulta concluída, mas o resultado não foi salvo no projeto. Tente novamente quando a conexão voltar.</p>'); }
      } catch (err) {
        area.innerHTML = errorMarkup(err);
      } finally {
        btn.disabled = false;
      }
    });
    return;
  }

  if (tool.id === "roteador") {
    panel.innerHTML = `
      <p class="panel-section-title">Abrir painel do roteador</p>
      <p class="state-msg info">A detecção automática do gateway depende da rede local do usuário. Informe o IP do roteador para abrir o painel em uma nova aba.</p>
      <div class="field">
        <label for="gw">Endereço do gateway</label>
        <input type="text" id="gw" placeholder="ex.: 192.168.0.1" value="192.168.0.1"/>
      </div>
      <button class="btn btn-primary" id="open-gw" type="button">Abrir painel</button>`;
    panel.querySelector("#open-gw").addEventListener("click", () => {
      const val = panel.querySelector("#gw").value.trim();
      if (val) window.open(`http://${val}`, "_blank", "noopener,noreferrer");
    });
    return;
  }

  // Formulário genérico dirigido pelos `fields` de data/features.js.
  const fields = tool.fields || (tool.type === "host-input"
    ? [{ key: "host", label: tool.inputLabel || "Host", placeholder: tool.inputPlaceholder, required: !!tool.inputRequired, value: tool.defaultHost || "" }]
    : []);

  panel.innerHTML = `
    ${status === STATUS.FUNCIONAL_CONTROLADO ? `<p class="state-msg warn">${escapeHtml(STATUS_NOTE[tool.id])}</p>` : ""}
    <form id="tool-form">
      ${fields.map(fieldHtml).join("")}
      <button class="btn btn-primary" type="submit">${escapeHtml(tool.buttonLabel || "Executar")}</button>
    </form>
    <div id="result-area" role="status" aria-live="polite" aria-atomic="true"></div>`;

  const form = panel.querySelector("#tool-form");
  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const area = panel.querySelector("#result-area");
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    area.innerHTML = `<div class="loading-row"><span class="spinner"></span> Executando… Aguarde o resultado.</div>`;
    try {
      const raw = readFormValues(form, fields);
      const data = await runTool(tool.id, fields, raw);
      area.innerHTML = renderResult(data);
      try { await saveToolResult(tool.id, raw, data); } catch { area.insertAdjacentHTML("beforeend", '<p class="state-msg warn">Resultado disponível, mas não foi salvo no projeto. Confira sua conexão antes de tentar novamente.</p>'); }
    } catch (err) {
      area.innerHTML = errorMarkup(err);
    } finally {
      submitBtn.disabled = false;
    }
  });
}
