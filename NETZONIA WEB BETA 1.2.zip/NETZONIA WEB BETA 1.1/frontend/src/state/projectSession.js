import { getProjectRepository } from "../repositories/getProjectRepository.js";

const CURRENT_KEY = "netzonia:current-project-id";
let current;

export function currentProjectId() { return sessionStorage.getItem(CURRENT_KEY); }
export async function getCurrentProject({ refresh = false } = {}) {
  const id = currentProjectId();
  if (!id) return null;
  if (!current || current.id !== id || refresh) current = await (await getProjectRepository()).get(id);
  if (!current) sessionStorage.removeItem(CURRENT_KEY);
  return current ? structuredClone(current) : null;
}
export function setCurrentProject(project) {
  current = project ? structuredClone(project) : null;
  if (project) sessionStorage.setItem(CURRENT_KEY, project.id); else sessionStorage.removeItem(CURRENT_KEY);
  window.dispatchEvent(new CustomEvent("netzonia:project-changed", { detail: current }));
}
export async function updateCurrentProject(changes) {
  const project = await getCurrentProject();
  if (!project) throw new Error("Abra um projeto antes de salvar.");
  const updated = await (await getProjectRepository()).update(project.id, changes);
  setCurrentProject(updated);
  return updated;
}
export async function saveToolResult(toolId, input, result) {
  if (["senha-segura", "wifi-string", "credenciais", "ssh"].includes(toolId)) return null;
  const project = await getCurrentProject();
  if (!project) return null;
  const entry = { id: crypto.randomUUID(), toolId, input, result, createdAt: new Date().toISOString() };
  const history = [entry, ...(project.data?.toolResults || [])].slice(0, 100);
  return updateCurrentProject({ data: { ...(project.data || {}), toolResults: history } });
}
