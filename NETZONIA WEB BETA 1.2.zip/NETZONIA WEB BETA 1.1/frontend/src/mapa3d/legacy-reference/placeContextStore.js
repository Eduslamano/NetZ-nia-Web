// ---------------------------------------------------------------------
// placeContextStore.js — pequena "caixa postal" em memória para passar
// os dados do local (nome, endereço, lat/lng) escolhidos em #/local até
// #/mapa3d/:placeId, já que o roteador por hash só carrega o placeId na
// URL. Depois do primeiro "Salvar projeto", os dados completos passam a
// vir do próprio arquivo salvo (ver Go: CarregarProjetoLocal).
// ---------------------------------------------------------------------

const pending = new Map();

/** @param {{placeId:string, nome?:string, endereco?:string, lat:number, lng:number}} place */
export function setPendingPlace(place) {
  if (!place || !place.placeId) return;
  pending.set(place.placeId, place);
}

export function takePendingPlace(placeId) {
  return pending.get(placeId) || null;
}
