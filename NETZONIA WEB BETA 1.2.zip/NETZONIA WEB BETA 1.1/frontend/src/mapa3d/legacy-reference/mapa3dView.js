// ---------------------------------------------------------------------
// mapa3dView.js — view do Mapa 3D de Infraestrutura.
//
// Fluxo de uso:
//   1) Usuário clica num item da biblioteca (sidebar esquerda) → arma o
//      "modo colocação" daquele equipamento.
//   2) Clique na planta 3D → posiciona o equipamento no piso (ou teto,
//      no caso do AP Wi-Fi).
//   3) Usuário escolhe "Cabo Metálico" ou "Cabo Fibra" → arma o modo
//      cabo; clica em dois equipamentos para conectá-los.
//   4) O trajeto (roteamento ortogonal / Manhattan) é enviado ao
//      backend Go (bridge.calcularCabo) para validar a norma (limite de
//      90m, cruzamento de Zona de Risco EMI) — com fallback simulado
//      quando não há backend Wails conectado.
// ---------------------------------------------------------------------

import { el, clear } from "../lib/dom.js";
import { showToast } from "../components/toast.js";
import * as bridge from "../lib/wails-bridge.js";
import { Scene3D } from "./scene3d.js";
import { EQUIPMENT_TYPES, EQUIPMENT_ORDER, CABLE_TYPES, CABLE_ORDER, novoId } from "./equipmentCatalog.js";
import { takePendingPlace } from "./placeContextStore.js";
import { fetchBuildingFootprint } from "./buildingFootprint.js";

function normalizeSearch(str) {
  return (str || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

const MAX_SAVED_NODES = 5000;
const MAX_SAVED_CABLES = 10000;
const MAX_SAVED_WALLS = 10000;
const MAX_COORD_ABS = 1_000_000;

function finiteCoord(value) {
  return Number.isFinite(value) && Math.abs(value) <= MAX_COORD_ABS;
}

function validPoint2D(p) {
  return p && finiteCoord(p.x) && finiteCoord(p.z);
}

function validPoint3D(p) {
  return p && finiteCoord(p.x) && finiteCoord(p.y) && finiteCoord(p.z);
}

function sanitizeSavedState(dados) {
  if (!dados || typeof dados !== "object" || Array.isArray(dados)) throw new Error("estado do projeto inválido");
  const rawNodes = Array.isArray(dados.nodes) ? dados.nodes : [];
  const rawCables = Array.isArray(dados.cables) ? dados.cables : [];
  const rawWalls = Array.isArray(dados.walls) ? dados.walls : [];
  if (rawNodes.length > MAX_SAVED_NODES || rawCables.length > MAX_SAVED_CABLES || rawWalls.length > MAX_SAVED_WALLS) {
    throw new Error("projeto salvo excede os limites de segurança");
  }

  const ids = new Set();
  const nodes = rawNodes.filter((n) => {
    if (!n || typeof n !== "object" || typeof n.id !== "string" || n.id.length < 1 || n.id.length > 160) return false;
    if (ids.has(n.id) || !EQUIPMENT_TYPES[n.tipo] || !validPoint3D(n.position)) return false;
    if (n.raio != null && (!Number.isFinite(n.raio) || n.raio < 0 || n.raio > 100000)) return false;
    ids.add(n.id);
    return true;
  });

  const cables = rawCables.filter((c) => {
    if (!c || typeof c !== "object" || typeof c.id !== "string" || c.id.length < 1 || c.id.length > 160) return false;
    if (!CABLE_TYPES[c.tipo] || !ids.has(c.aId) || !ids.has(c.bId) || c.aId === c.bId) return false;
    const d = c.resultado?.distanciaM;
    return Number.isFinite(d) && d >= 0 && d <= 10_000_000;
  });

  const walls = rawWalls.filter((w) => w && validPoint2D(w.a) && validPoint2D(w.b));

  let building = null;
  if (dados.building && typeof dados.building === "object" && Array.isArray(dados.building.footprint)) {
    const fp = dados.building.footprint;
    const h = dados.building.height;
    if (fp.length >= 3 && fp.length <= 10000 && fp.every(validPoint2D) && Number.isFinite(h) && h > 0 && h <= 10000) {
      building = dados.building;
    }
  }

  const lat = Number.isFinite(dados.lat) && dados.lat >= -90 && dados.lat <= 90 ? dados.lat : 0;
  const lng = Number.isFinite(dados.lng) && dados.lng >= -180 && dados.lng <= 180 ? dados.lng : 0;
  const endereco = typeof dados.endereco === "string" ? dados.endereco.slice(0, 2048) : "";
  const wallColor = typeof dados.wallColor === "string" && /^#[0-9a-fA-F]{6}$/.test(dados.wallColor) ? dados.wallColor : "#AEB9B2";
  return { ...dados, endereco, lat, lng, building, walls, nodes, cables, wallColor };
}

/**
 * @param {HTMLElement} container
 * @param {string|null} placeId - quando vindo de #/mapa3d/:placeId (busca de
 *   local em #/local), carrega/salva o projeto vinculado àquele endereço.
 *   null → mapa 3D "em branco", sem persistência de local.
 */
export function renderMapa3DView(container, placeId = null) {
  clear(container);

  /** @type {{id:string, tipo:string, position:{x:number,y:number,z:number}, portasUsadas:number, raio?:number}[]} */
  const nodes = [];
  /** @type {{id:string, tipo:string, aId:string, bId:string, resultado:object}[]} */
  const cables = [];

  let tool = null; // { kind:'place', tipo } | { kind:'cable', tipo } | { kind:'remove' }
  let paletteSearch = ""; // texto da busca na biblioteca de equipamentos/cabos
  let cableFirstId = null;

  /** @type {{footprint:{x:number,z:number}[], height:number}|null} */
  let building = null;
  /** @type {{a:{x:number,z:number}, b:{x:number,z:number}}[]} */
  const wallSegments = [];
  let wallColor = "#AEB9B2";
  /** @type {{x:number,z:number}[]} */
  let wallDraft = [];

  // Contexto de local (vindo de #/local → "Gerar estrutura 3D", ou de um
  // projeto salvo anteriormente para esse placeId).
  let placeContext = placeId ? takePendingPlace(placeId) || { placeId, nome: null, endereco: null, lat: null, lng: null } : null;
  let manualNameDraft = ""; // rascunho do nome quando não veio nenhum local da busca (#/mapa3d direto)

  const backLink = el("a", { href: placeId ? "#/local" : "#/", class: "feature-back" }, placeId ? "← Voltar à busca de local" : "← Voltar às funcionalidades");

  const placeBanner = el("div", { class: "mapa3d-place-banner", style: "display:none" });
  const saveBtn = el("button", { type: "button", class: "btn btn-primary btn-sm" }, "Salvar projeto");

  const view = el("div", { class: "view mapa3d-view" }, [
    backLink,
    placeBanner,
    el("div", { class: "mapa3d-heading" }, [
      el("h1", { class: "view-title", text: "Mapa 3D de Infraestrutura" }),
      el("p", {
        class: "view-subtitle",
        text: "Arraste equipamentos para a planta, conecte com cabos e o motor de regras (Go) audita a norma em tempo real — limite de 90m, ocupação de rack e cruzamento de zonas de risco EMI.",
      }),
    ]),
  ]);

  const palette = el("div", { class: "mapa3d-palette" });
  const paletteSearchInput = el("input", {
    type: "search",
    class: "mapa3d-search-input",
    placeholder: "Pesquisar equipamento ou cabo...",
  });
  const paletteList = el("div", { class: "mapa3d-palette-list" });
  palette.appendChild(el("div", { class: "panel-section-title", text: "Biblioteca de Equipamentos" }));
  palette.appendChild(paletteSearchInput);
  palette.appendChild(paletteList);
  paletteSearchInput.addEventListener("input", (e) => {
    paletteSearch = e.target.value;
    buildPalette();
  });
  const canvasWrap = el("div", { class: "mapa3d-canvas-wrap" });
  const canvas = el("canvas", { class: "mapa3d-canvas" });
  const hint = el("div", { class: "mapa3d-hint", text: "Selecione um item na biblioteca para começar." });
  canvasWrap.appendChild(canvas);
  canvasWrap.appendChild(hint);

  const exitFullscreenFab = el("button", { type: "button", class: "mapa3d-exit-fullscreen-fab", title: "Sair da tela cheia" }, "✕ Sair");
  exitFullscreenFab.addEventListener("click", () => document.exitFullscreen?.());
  canvasWrap.appendChild(exitFullscreenFab);

  const sidePanel = el("div", { class: "mapa3d-sidepanel" });

  const toolbar = el("div", { class: "mapa3d-toolbar" });

  const layout = el("div", { class: "mapa3d-layout" }, [palette, el("div", { class: "mapa3d-stage" }, [toolbar, canvasWrap]), sidePanel]);

  view.appendChild(layout);
  container.appendChild(view);

  // -----------------------------------------------------------------
  // Cena 3D
  // -----------------------------------------------------------------
  const scene = new Scene3D(canvas, { gridSize: 34, gridStep: 1 });
  const GHOST_ID = "__preview_fantasma__";

  function nodeCatalog(node) {
    return EQUIPMENT_TYPES[node.tipo];
  }

  function hasInternet() {
    const routers = nodes.filter((node) => ["roteador", "roteador-enterprise"].includes(node.tipo) && node.ligado !== false);
    const switches = new Set(nodes.filter((node) => node.tipo.startsWith("switch-") && node.ligado !== false).map((node) => node.id));
    return routers.some((router) => cables.some((cable) =>
      (cable.aId === router.id && switches.has(cable.bId)) || (cable.bId === router.id && switches.has(cable.aId))
    ));
  }

  function toggleRouter(node) {
    node.ligado = node.ligado === false;
    renderAll();
    showToast(`${nodeCatalog(node).nome}: ${node.ligado ? "ligado" : "desligado"}.`, node.ligado ? "success" : "warn");
  }

  function nodeTopPoint(node) {
    const cat = nodeCatalog(node);
    const h = cat.isZone ? 0 : cat.size.h;
    return { x: node.position.x, y: node.position.y + h, z: node.position.z };
  }

  function footprintToSegments(footprint) {
    if (!footprint || footprint.length < 2) return [];
    const segs = [];
    for (let i = 0; i < footprint.length; i++) {
      segs.push({ a: footprint[i], b: footprint[(i + 1) % footprint.length] });
    }
    return segs;
  }

  // Paredes "candidatas" pra fixar equipamento: as desenhadas manualmente
  // (Construtor Manual) + as arestas do contorno do prédio carregado do
  // local (OpenStreetMap ou traçado à mão em #/local) — antes só as
  // manuais contavam, então um AP de parede numa planta só com contorno de
  // prédio nunca encontrava onde encaixar e ficava "flutuando" no chão.
  function wallCandidateSegments() {
    const segs = wallSegments.slice();
    if (building?.footprint) segs.push(...footprintToSegments(building.footprint));
    return segs;
  }

  function rackForPoint(point) {
    return nodes
      .filter((node) => EQUIPMENT_TYPES[node.tipo]?.alturaU)
      .map((rack) => ({ rack, distance: Math.hypot(rack.position.x - point.x, rack.position.z - point.z) }))
      .filter(({ rack, distance }) => distance <= Math.max(rackCatalog(rack).size.w, rackCatalog(rack).size.d) * 1.5)
      .sort((a, b) => a.distance - b.distance)[0]?.rack || null;
  }

  function nearestWallPoint(point, segments = wallCandidateSegments(), maxDist = 2.5) {
    let nearest = null;
    for (const segment of segments) {
      const dx = segment.b.x - segment.a.x;
      const dz = segment.b.z - segment.a.z;
      const length2 = dx * dx + dz * dz || 1;
      const t = Math.max(0, Math.min(1, ((point.x - segment.a.x) * dx + (point.z - segment.a.z) * dz) / length2));
      const candidate = { x: segment.a.x + t * dx, z: segment.a.z + t * dz };
      const distance = Math.hypot(point.x - candidate.x, point.z - candidate.z);
      if (!nearest || distance < nearest.distance) nearest = { point: candidate, distance, segment };
    }
    return nearest && nearest.distance <= maxDist ? nearest : null;
  }

  // Calcula onde um equipamento de PAREDE deve ficar: encaixado (snap) no
  // ponto mais próximo da parede/contorno mais perto do clique, deslocado
  // pra fora dela (no sentido de onde o usuário clicou) pela metade da
  // profundidade do item — assim ele fica "colado" na face da parede em
  // vez de atravessá-la — e na altura de montagem típica do equipamento.
  function wallMountPosition(cat, groundPoint) {
    const hit = nearestWallPoint(groundPoint);
    if (!hit) {
      return { position: { x: groundPoint.x, y: cat.alturaParede ?? 1.2, z: groundPoint.z }, snapped: false };
    }
    const seg = hit.segment;
    const dx = seg.b.x - seg.a.x;
    const dz = seg.b.z - seg.a.z;
    const len = Math.hypot(dx, dz) || 1;
    let nx = -dz / len;
    let nz = dx / len;
    const towardClick = { x: groundPoint.x - hit.point.x, z: groundPoint.z - hit.point.z };
    if (nx * towardClick.x + nz * towardClick.z < 0) {
      nx = -nx;
      nz = -nz;
    }
    const offset = Math.max((cat.size?.d ?? cat.size?.w ?? 0.1) / 2, 0.06);
    return {
      position: { x: hit.point.x + nx * offset, y: cat.alturaParede ?? 1.2, z: hit.point.z + nz * offset },
      snapped: true,
    };
  }

  function pointOnWall(point, clearance = 0.18) {
    return wallSegments.some((segment) => {
      const dx = segment.b.x - segment.a.x;
      const dz = segment.b.z - segment.a.z;
      const length2 = dx * dx + dz * dz || 1;
      const t = Math.max(0, Math.min(1, ((point.x - segment.a.x) * dx + (point.z - segment.a.z) * dz) / length2));
      const closestX = segment.a.x + t * dx;
      const closestZ = segment.a.z + t * dz;
      return Math.hypot(point.x - closestX, point.z - closestZ) < clearance;
    });
  }

  function rackCatalog(rack) {
    return EQUIPMENT_TYPES[rack.tipo];
  }

  function addNodeSceneObject(node) {
    const cat = nodeCatalog(node);
    if (cat.isZone) {
      scene.addObject({
        id: node.id,
        type: "zone",
        position: node.position,
        raio: node.raio,
        label: cat.nome,
        pickable: true,
      });
      return;
    }
    if (cat.renderAs === "disc") {
      scene.addObject({
        id: node.id,
        type: "disc",
        position: node.position,
        radius: cat.discRadius || cat.size.w / 2,
        thickness: cat.size.h,
        color: cat.color,
        label: cat.nome,
        pickable: true,
      });
    } else {
      scene.addObject({
        id: node.id,
        type: "box",
        position: node.position,
        size: cat.size,
        color: cat.color,
        shape: cat.shape,
        label: cat.nome,
        pickable: true,
      });
    }
    updateWifiWaveSceneObject(node);
  }

  /** Projeta o alcance do sinal Wi-Fi no piso, embaixo do equipamento —
   * como num levantamento de cobertura, e não uma "bolha" 3D. Chamada tanto
   * ao colocar/carregar o nó quanto ao editar o alcance no painel lateral. */
  function updateWifiWaveSceneObject(node) {
    const waveId = `${node.id}_wifiwave`;
    scene.removeObject(waveId);
    const cat = nodeCatalog(node);
    if (!cat.wifi || !node.alcanceM || node.alcanceM <= 0) return;
    scene.addObject({
      id: waveId,
      type: "wifiwave",
      position: { x: node.position.x, y: 0.015, z: node.position.z },
      radius: node.alcanceM,
      color: cat.color,
      label: `${node.alcanceM}m`,
      pickable: false,
    });
  }

  // -----------------------------------------------------------------
  // Preview "fantasma" — mostra o formato/silhueta do item selecionado
  // seguindo o cursor sobre a planta ANTES do clique, pra dar noção clara
  // de onde ele vai encaixar (contorno tracejado, verde = pode soltar
  // aqui, vermelho = posição inválida).
  // -----------------------------------------------------------------
  function clearGhostPreview() {
    scene.removeObject(GHOST_ID);
  }

  function updateGhostPreview(screenPoint) {
    if (!tool || tool.kind !== "place") {
      clearGhostPreview();
      return;
    }
    const cat = EQUIPMENT_TYPES[tool.tipo];
    const planeY = cat.teto ? cat.tetoAltura : 0;
    const p = scene.unprojectToPlane(screenPoint.x, screenPoint.y, planeY);
    clearGhostPreview();
    if (!p) return;

    let invalid = false;
    let ghostPos = { x: p.x, y: planeY, z: p.z };
    if (cat.mountingType === "rack") {
      const rack = rackForPoint(p);
      invalid = !rack;
      if (rack) {
        const rackCat = rackCatalog(rack);
        ghostPos = {
          x: rack.position.x,
          y: rack.position.y + ((rack.usedU || 0) / rackCat.alturaU) * rackCat.size.h,
          z: rack.position.z,
        };
      }
    } else if (cat.mountingType === "wall" && !cat.isZone) {
      const mount = wallMountPosition(cat, p);
      invalid = !mount.snapped;
      ghostPos = mount.position;
    } else if (!cat.isZone && cat.size) {
      invalid = pointOnWall(p, Math.max(cat.size.w, cat.size.d) / 2);
    }

    if (cat.isZone) {
      scene.addObject({
        id: GHOST_ID,
        type: "zone",
        position: { x: p.x, y: 0, z: p.z },
        raio: cat.raio,
        label: cat.nome,
        ghost: true,
        ghostInvalid: invalid,
        pickable: false,
      });
    } else if (cat.renderAs === "disc") {
      scene.addObject({
        id: GHOST_ID,
        type: "disc",
        position: ghostPos,
        radius: cat.discRadius || cat.size.w / 2,
        thickness: cat.size.h,
        color: cat.color,
        label: cat.nome,
        ghost: true,
        ghostInvalid: invalid,
        pickable: false,
      });
    } else {
      scene.addObject({
        id: GHOST_ID,
        type: "box",
        position: ghostPos,
        size: cat.size,
        color: cat.color,
        shape: cat.shape,
        label: cat.nome,
        ghost: true,
        ghostInvalid: invalid,
        pickable: false,
      });
    }
    scene.render();
  }

  function routedPoints(a, b) {
    // roteamento ortogonal (Manhattan): sobe do topo de A até uma altura
    // de "via" comum, anda na horizontal, desce até o topo de B — cabos
    // não cruzam paredes/piso em diagonal.
    const pa = nodeTopPoint(a);
    const pb = nodeTopPoint(b);
    const viaY = Math.max(pa.y, pb.y) + 0.35;
    return [
      pa,
      { x: pa.x, y: viaY, z: pa.z },
      { x: pb.x, y: viaY, z: pb.z },
      pb,
    ];
  }

  function cableColor(resultado, tipoCabo) {
    if (resultado.excedeLimite) return "#D24E42";
    if (resultado.alertaEMI && !resultado.emiAtenuado) return "#DB932C";
    if (resultado.alertaEMI && resultado.emiAtenuado) return "#B8860B";
    return CABLE_TYPES[tipoCabo].color;
  }

  // -----------------------------------------------------------------
  // Biblioteca (sidebar esquerda)
  // -----------------------------------------------------------------
  function makeEquipmentItem(tipoId) {
    const cat = EQUIPMENT_TYPES[tipoId];
    const isActive = tool && tool.kind === "place" && tool.tipo === tipoId;
    const item = el(
      "button",
      {
        type: "button",
        class: `mapa3d-palette-item${isActive ? " active" : ""}`,
        title: cat.descricao,
      },
      [
        el("span", { class: "mapa3d-swatch", style: `background:${cat.color}` }),
        el("span", { class: "mapa3d-palette-text" }, [
          el("strong", { text: cat.nome }),
          el("span", { class: "mapa3d-palette-sub", text: cat.categoria }),
        ]),
        el("span", { class: "mapa3d-palette-place", text: isActive ? "Colocando…" : "+ Colocar" }),
      ]
    );
    item.addEventListener("click", () => {
      setTool(isActive ? null : { kind: "place", tipo: tipoId });
    });
    return item;
  }

  function makeCableItem(caboId) {
    const cabo = CABLE_TYPES[caboId];
    const isActive = tool && tool.kind === "cable" && tool.tipo === cabo.id;
    const item = el(
      "button",
      { type: "button", class: `mapa3d-palette-item${isActive ? " active" : ""}` },
      [
        el("span", { class: "mapa3d-swatch", style: `background:${cabo.color}` }),
        el("span", { class: "mapa3d-palette-text" }, [
          el("strong", { text: cabo.nome }),
          el("span", {
            class: "mapa3d-palette-sub",
            text: cabo.limiteM ? `Limite de ${cabo.limiteM}m (canal)` : "Sem limite de 90m",
          }),
        ]),
        el("span", { class: "mapa3d-palette-place", text: isActive ? "Conectando…" : "+ Usar" }),
      ]
    );
    item.addEventListener("click", () => {
      setTool(isActive ? null : { kind: "cable", tipo: cabo.id });
    });
    return item;
  }

  // -----------------------------------------------------------------
  // Biblioteca (sidebar esquerda) — pesquisa unificada: com o campo vazio
  // mostra tudo agrupado por categoria; ao digitar, filtra equipamentos +
  // cabos numa lista só de resultados, cada um já com o botão de colocar.
  // -----------------------------------------------------------------
  function buildPalette() {
    clear(paletteList);
    const query = normalizeSearch(paletteSearch);

    if (query) {
      const equipMatches = EQUIPMENT_ORDER.filter((tipoId) => {
        const cat = EQUIPMENT_TYPES[tipoId];
        return normalizeSearch(cat.nome).includes(query) || normalizeSearch(cat.categoria).includes(query);
      });
      const cableMatches = CABLE_ORDER.filter((caboId) => normalizeSearch(CABLE_TYPES[caboId].nome).includes(query));

      paletteList.appendChild(
        el("div", { class: "panel-section-title", text: `Resultados (${equipMatches.length + cableMatches.length})` })
      );
      if (equipMatches.length + cableMatches.length === 0) {
        paletteList.appendChild(el("div", { class: "state-msg info", text: "Nada encontrado — tente outro termo." }));
      } else {
        equipMatches.forEach((tipoId) => paletteList.appendChild(makeEquipmentItem(tipoId)));
        cableMatches.forEach((caboId) => paletteList.appendChild(makeCableItem(caboId)));
      }
      return;
    }

    EQUIPMENT_ORDER.forEach((tipoId) => paletteList.appendChild(makeEquipmentItem(tipoId)));

    paletteList.appendChild(el("div", { class: "panel-section-title", text: "Cabos" }));
    CABLE_ORDER.forEach((caboId) => paletteList.appendChild(makeCableItem(caboId)));

    paletteList.appendChild(el("div", { class: "panel-section-title", text: "Estrutura" }));
    const wallActive = tool && tool.kind === "wall";
    const wallBtn = el(
      "button",
      { type: "button", class: `mapa3d-palette-item${wallActive ? " active" : ""}` },
      [
        el("span", { class: "mapa3d-swatch", style: "background:#7FA8B8" }),
        el("span", { class: "mapa3d-palette-text" }, [
          el("strong", { text: "Desenhar Parede" }),
          el("span", { class: "mapa3d-palette-sub", text: "Construtor manual — clique a clique" }),
        ]),
      ]
    );
    wallBtn.addEventListener("click", () => setTool(wallActive ? null : { kind: "wall" }));
    paletteList.appendChild(wallBtn);
  }

  // -----------------------------------------------------------------
  // Barra de ferramentas
  // -----------------------------------------------------------------
  function buildToolbar() {
    clear(toolbar);
    const actions = [];

    if (tool && tool.kind === "wall") {
      const concluirBtn = el("button", { type: "button", class: "btn btn-sm btn-primary", disabled: wallDraft.length < 2 }, "Concluir parede");
      concluirBtn.addEventListener("click", finalizeWallDraft);
      const desfazerBtn = el("button", { type: "button", class: "btn btn-sm btn-ghost", disabled: wallDraft.length === 0 }, "Desfazer ponto");
      desfazerBtn.addEventListener("click", undoWallPoint);
      actions.push(concluirBtn, desfazerBtn);
    }

    const removeBtn = el(
      "button",
      { type: "button", class: `btn btn-sm btn-ghost${tool && tool.kind === "remove" ? " active" : ""}` },
      "🗑 Remover"
    );
    removeBtn.addEventListener("click", () => setTool(tool && tool.kind === "remove" ? null : { kind: "remove" }));
    actions.push(removeBtn);

    const clearBtn = el("button", { type: "button", class: "btn btn-sm btn-ghost" }, "Limpar tudo");
    clearBtn.addEventListener("click", () => {
      nodes.length = 0;
      cables.length = 0;
      wallSegments.length = 0;
      scene.clearObjects();
      if (building) addBuildingSceneObject(null);
      setTool(null);
      renderAll();
      showToast("Mapa reiniciado.", "info");
    });
    actions.push(clearBtn);

    const isFull = document.fullscreenElement === view;
    const fullscreenBtn = el(
      "button",
      { type: "button", class: "btn btn-sm btn-ghost" },
      isFull ? "⛶ Sair da tela cheia" : "⛶ Tela cheia"
    );
    fullscreenBtn.addEventListener("click", toggleFullscreen);
    actions.push(fullscreenBtn);

    toolbar.appendChild(el("div", { class: "mapa3d-toolbar-status", text: toolStatusText() }));

    if (building) {
      const colorInput = el("input", { type: "color", value: building.color || "#5FA36E" });
      colorInput.addEventListener("input", (e) => setBuildingColor(e.target.value));
      toolbar.appendChild(
        el("div", { class: "mapa3d-building-color" }, [el("span", { text: "Cor do prédio" }), colorInput])
      );
    }
    const wallColorInput = el("input", { type: "color", value: wallColor });
    wallColorInput.addEventListener("input", (e) => setWallColor(e.target.value));
    toolbar.appendChild(el("div", { class: "mapa3d-building-color" }, [el("span", { text: "Cor das paredes" }), wallColorInput]));

    toolbar.appendChild(el("div", { class: "mapa3d-toolbar-actions" }, actions));
  }

  function toolStatusText() {
    if (!tool) return "Arraste a câmera para orbitar · Scroll para zoom.";
    if (tool.kind === "place") return `Colocando: ${EQUIPMENT_TYPES[tool.tipo].nome} — clique na planta.`;
    if (tool.kind === "cable")
      return cableFirstId
        ? `${CABLE_TYPES[tool.tipo].nome}: clique no equipamento de destino.`
        : `${CABLE_TYPES[tool.tipo].nome}: clique no primeiro equipamento.`;
    if (tool.kind === "wall") return `Desenhar parede: clique pra cada canto (${wallDraft.length} ponto${wallDraft.length === 1 ? "" : "s"}).`;
    if (tool.kind === "remove") return "Modo remover: clique num equipamento para excluí-lo.";
    return "";
  }

  function setTool(next) {
    tool = next;
    cableFirstId = null;
    if (wallDraft.length > 0) {
      wallDraft = [];
      scene.removeObject("rascunho-parede");
    }
    if (!tool || tool.kind !== "place") clearGhostPreview();
    highlightNode(null);
    buildPalette();
    buildToolbar();
  }

  function highlightNode(id) {
    scene.objects.forEach((o) => {
      o.highlight = o.id === id;
    });
    scene.render();
  }

  // -----------------------------------------------------------------
  // Painel lateral (lista de equipamentos e cabos)
  // -----------------------------------------------------------------
  function buildSidePanel() {
    clear(sidePanel);
    sidePanel.appendChild(el("div", { class: "panel-section-title", text: `Equipamentos (${nodes.length})` }));
    sidePanel.appendChild(el("div", { class: `mapa3d-network-status ${hasInternet() ? "online" : "offline"}` }, [
      el("strong", { text: hasInternet() ? "Internet: VERDADEIRO" : "Internet: FALSO" }),
      el("span", { text: "Roteador ligado por cabo a um switch" }),
    ]));

    if (nodes.length === 0) {
      sidePanel.appendChild(el("div", { class: "state-msg info", text: "Nenhum equipamento no mapa ainda." }));
    } else {
      nodes.forEach((node) => {
        const cat = nodeCatalog(node);
        const routerButton = ["roteador", "roteador-enterprise"].includes(node.tipo)
          ? el("button", { type: "button", class: "mapa3d-row-power", "aria-pressed": node.ligado !== false, title: "Ligar/desligar roteador" }, node.ligado === false ? "OFF" : "ON")
          : null;
        const portInfo = cat.portasPadrao
          ? el("span", { class: "mapa3d-row-sub", text: `${node.portasUsadas}/${cat.portasPadrao} portas` })
          : null;
        const alcanceInput = cat.wifi
          ? el("input", {
              type: "number",
              class: "mapa3d-row-alcance",
              min: "1",
              max: "300",
              step: "1",
              value: String(node.alcanceM ?? 15),
              title: "Alcance do sinal Wi-Fi, em metros",
            })
          : null;
        const alcanceField = cat.wifi
          ? el("label", { class: "mapa3d-row-alcance-field" }, [alcanceInput, el("span", { class: "mapa3d-row-sub", text: "m de alcance" })])
          : null;
        sidePanel.appendChild(
          el("div", { class: "mapa3d-row" }, [
            el("span", { class: "mapa3d-swatch", style: `background:${cat.color}` }),
            el("div", { class: "mapa3d-row-text" }, [el("strong", { text: cat.nome }), portInfo, alcanceField]),
            routerButton,
            el(
              "button",
              { type: "button", class: "mapa3d-row-del", title: "Remover" },
              "×"
            ),
          ])
        );
        const row = sidePanel.lastChild;
        if (routerButton) routerButton.addEventListener("click", () => toggleRouter(node));
        if (alcanceInput) {
          alcanceInput.addEventListener("input", (e) => {
            node.alcanceM = Math.max(1, Math.min(500, parseInt(e.target.value, 10) || 1));
            updateWifiWaveSceneObject(node);
            scene.render();
          });
        }
        row.querySelector(".mapa3d-row-del").addEventListener("click", () => removeNode(node.id));
      });
    }

    sidePanel.appendChild(el("div", { class: "panel-section-title", text: `Cabos (${cables.length})` }));
    if (cables.length === 0) {
      sidePanel.appendChild(el("div", { class: "state-msg info", text: "Nenhum cabo conectado ainda." }));
    } else {
      cables.forEach((cable) => {
        const res = cable.resultado;
        const tone = res.excedeLimite ? "bad" : res.alertaEMI ? "warn" : "good";
        sidePanel.appendChild(
          el("div", { class: "mapa3d-row" }, [
            el("span", { class: "mapa3d-swatch", style: `background:${CABLE_TYPES[cable.tipo].color}` }),
            el("div", { class: "mapa3d-row-text" }, [
              el("strong", { text: `${CABLE_TYPES[cable.tipo].nome}` }),
              el("span", { class: "mapa3d-row-sub", text: `${res.distanciaM.toFixed(1)}m` }),
              el("span", { class: `badge badge-${tone}`, text: res.excedeLimite ? "Excede 90m" : res.alertaEMI ? "Alerta EMI" : "OK" }),
            ]),
            el("button", { type: "button", class: "mapa3d-row-del", title: "Remover cabo" }, "×"),
          ])
        );
        sidePanel.lastChild.lastChild.addEventListener("click", () => removeCable(cable.id));
        if (res.mensagem) {
          sidePanel.appendChild(el("div", { class: `state-msg ${tone === "bad" ? "error" : tone === "warn" ? "warn" : "success"} mapa3d-cable-msg`, text: res.mensagem }));
        }
      });
    }

    sidePanel.appendChild(el("div", { class: "panel-section-title", text: "Orçamento" }));
    const exportBtn = el(
      "button",
      { type: "button", class: "btn btn-sm btn-primary", style: "width:100%", disabled: nodes.length === 0 },
      "Exportar Orçamento (CSV)"
    );
    exportBtn.addEventListener("click", exportarOrcamento);
    sidePanel.appendChild(exportBtn);
    sidePanel.appendChild(
      el("div", { class: "state-msg info", text: "Gera Material + Quantidade a partir do que está no mapa. Descrição do modelo e preço ficam em branco pra você preencher." })
    );
  }

  // -----------------------------------------------------------------
  // Orçamento 3D — conta os equipamentos e soma o comprimento dos cabos
  // já colocados no mapa, agrupados por categoria do catálogo.
  // -----------------------------------------------------------------
  function gerarItensOrcamento() {
    const porMaterial = new Map(); // nome -> {quantidade, unidade}

    nodes.forEach((node) => {
      const cat = nodeCatalog(node);
      if (!cat || cat.isZone) return; // zona de risco é marcador, não material físico
      const atual = porMaterial.get(cat.nome) || { quantidade: 0, unidade: "un" };
      atual.quantidade += 1;
      porMaterial.set(cat.nome, atual);
    });

    const metrosPorTipoCabo = new Map(); // nome do cabo -> metros somados
    cables.forEach((cable) => {
      const cat = CABLE_TYPES[cable.tipo];
      if (!cat) return;
      const atual = metrosPorTipoCabo.get(cat.nome) || 0;
      metrosPorTipoCabo.set(cat.nome, atual + (cable.resultado?.distanciaM || 0));
    });
    metrosPorTipoCabo.forEach((metros, nome) => {
      porMaterial.set(`${nome} (cabo)`, { quantidade: Math.round(metros * 10) / 10, unidade: "m" });
    });

    return Array.from(porMaterial.entries()).map(([material, { quantidade, unidade }]) => ({ material, quantidade, unidade }));
  }

  async function exportarOrcamento() {
    const itens = gerarItensOrcamento();
    if (itens.length === 0) {
      showToast("Nenhum equipamento no mapa ainda — não há o que orçar.", "warn");
      return;
    }
    try {
      const caminho = await bridge.exportarOrcamento(itens, placeContext?.endereco || placeContext?.nome || "");
      if (!caminho) return; // usuário cancelou o diálogo — silencioso, não é erro
      showToast(`Orçamento salvo em ${caminho}`, "success", 6000);
    } catch (err) {
      showToast(`Falha ao exportar orçamento: ${err?.message || err}`, "error");
    }
  }

  function renderAll() {
    buildPalette();
    buildToolbar();
    buildSidePanel();
    if (nodes.length === 0) {
      hint.textContent = tool ? "Clique na planta 3D para posicionar o equipamento." : "Selecione um item na biblioteca para começar.";
      hint.style.display = "flex";
    } else {
      hint.style.display = "none";
    }
    scene.render();
  }

  // -----------------------------------------------------------------
  // Banner do local + persistência (salvar/carregar projeto por local)
  // -----------------------------------------------------------------
  function addBuildingSceneObject(buildingData) {
    building = buildingData;
    scene.removeObject("edificio");
    if (!building) return;
    if (!building.color) building.color = "#5FA36E"; // verde-construção por padrão, agora escolhível
    scene.addObject({
      id: "edificio",
      type: "building",
      footprint: building.footprint,
      height: building.height,
      color: building.color,
      label: "Contorno do prédio (OpenStreetMap)",
      pickable: false,
    });

    // amplia a grade/câmera pra caber o prédio inteiro em vez do
    // tamanho fixo pensado pra uma sala só
    const xs = building.footprint.map((p) => p.x);
    const zs = building.footprint.map((p) => p.z);
    const span = Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...zs) - Math.min(...zs));
    scene.gridSize = Math.max(34, Math.ceil(span * 1.6));
    scene.camera.distance = Math.max(scene.camera.distance, span * 1.3);
    buildToolbar();
  }

  function setBuildingColor(hex) {
    if (!building) return;
    building.color = hex;
    const obj = scene.getObject("edificio");
    if (obj) obj.color = hex;
    scene.render();
  }

  // -----------------------------------------------------------------
  // Construtor Manual de paredes (independe de API/internet)
  // -----------------------------------------------------------------
  function rebuildWallsSceneObject() {
    scene.removeObject("paredes-manuais");
    if (wallSegments.length === 0) return;
    scene.addObject({ id: "paredes-manuais", type: "walls", segments: wallSegments, height: 2.6, color: wallColor, pickable: false });
  }

  function setWallColor(hex) {
    wallColor = hex;
    rebuildWallsSceneObject();
    scene.render();
  }

  function updateWallDraftVisual() {
    scene.removeObject("rascunho-parede");
    if (wallDraft.length >= 2) {
      const pontos3d = wallDraft.map((p) => ({ x: p.x, y: 0.03, z: p.z }));
      scene.addObject({ id: "rascunho-parede", type: "line", points: pontos3d, color: "#7FA8B8", dashed: true, pickable: false });
    }
    scene.render();
  }

  function finalizeWallDraft() {
    if (wallDraft.length < 2) return;
    for (let i = 0; i < wallDraft.length - 1; i++) {
      wallSegments.push({ a: wallDraft[i], b: wallDraft[i + 1] });
    }
    wallDraft = [];
    scene.removeObject("rascunho-parede");
    rebuildWallsSceneObject();
    renderAll();
    showToast("Paredes adicionadas ao mapa.", "success");
  }

  function undoWallPoint() {
    wallDraft.pop();
    updateWallDraftVisual();
    buildToolbar();
  }

  async function loadBuilding() {
    if (!placeContext || placeContext.lat == null || placeContext.lng == null) return;

    // contorno traçado à mão em #/local tem prioridade sobre a busca automática
    if (placeContext.manualFootprint) {
      addBuildingSceneObject(placeContext.manualFootprint);
      scene.render();
      showToast("Contorno do prédio (traçado à mão) carregado.", "success");
      return;
    }

    try {
      const encontrado = await fetchBuildingFootprint(placeContext.lat, placeContext.lng);
      if (!encontrado) {
        showToast("Nenhum contorno de prédio encontrado no OpenStreetMap para este local — volte em #/local e desenhe o contorno à mão, ou continue com a planta em branco.", "info", 7000);
        return;
      }
      addBuildingSceneObject(encontrado);
      scene.render();
      showToast("Contorno do prédio carregado do OpenStreetMap.", "success");
    } catch (err) {
      showToast(`Não foi possível buscar o contorno do prédio: ${err?.message || err}`, "warn", 6000);
    }
  }

  function renderPlaceBanner() {
    clear(placeBanner);
    placeBanner.style.display = "flex";

    if (placeContext) {
      placeBanner.appendChild(
        el("div", { class: "mapa3d-place-text" }, [
          el("span", { class: "mapa3d-place-eyebrow", text: "Local selecionado" }),
          el("strong", { text: placeContext.endereco || placeContext.nome || placeContext.placeId }),
        ])
      );
      placeBanner.appendChild(saveBtn);
      return;
    }

    // Sem local vindo da busca (#/mapa3d direto): pede um nome — é o que
    // identifica o projeto depois na lista de "Projetos salvos" em #/local.
    const nameInput = el("input", {
      type: "text",
      class: "mapa3d-manual-name-input",
      placeholder: "Nome do projeto — ex.: Escritório Centro",
      value: manualNameDraft,
    });
    nameInput.addEventListener("input", (e) => {
      manualNameDraft = e.target.value;
    });
    nameInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") saveProject();
    });

    placeBanner.appendChild(
      el("div", { class: "mapa3d-place-text" }, [
        el("span", { class: "mapa3d-place-eyebrow", text: "Projeto sem endereço" }),
        nameInput,
      ])
    );
    placeBanner.appendChild(saveBtn);
  }

  function serializeState() {
    return JSON.stringify({
      endereco: placeContext?.endereco || "",
      lat: placeContext?.lat ?? 0,
      lng: placeContext?.lng ?? 0,
      building,
      walls: wallSegments,
      wallColor,
      nodes,
      cables,
    });
  }

  async function saveProject() {
    if (!placeContext) {
      const nome = manualNameDraft.trim();
      if (!nome) {
        showToast("Dê um nome ao projeto antes de salvar.", "warn");
        return;
      }
      placeContext = { placeId: novoId("manual"), nome, endereco: nome, lat: 0, lng: 0 };
      renderPlaceBanner();
    }
    setBusyBtn(saveBtn, true, "Salvando...");
    try {
      await bridge.salvarProjetoLocal(placeContext.placeId, placeContext.endereco || placeContext.nome || "", placeContext.lat || 0, placeContext.lng || 0, serializeState());
      showToast("Projeto salvo.", "success");
    } catch (err) {
      showToast(`Falha ao salvar: ${err?.message || err}`, "error");
    } finally {
      setBusyBtn(saveBtn, false, "Salvar projeto");
    }
  }

  function setBusyBtn(btn, busy, label) {
    btn.disabled = busy;
    btn.textContent = label;
  }

  async function loadProjectIfAny() {
    if (!placeId) return;
    let raw;
    try {
      raw = await bridge.carregarProjetoLocal(placeId);
    } catch {
      raw = null;
    }
    if (!raw) {
      renderPlaceBanner();
      loadBuilding();
      return;
    }
    let dados;
    try {
      dados = sanitizeSavedState(JSON.parse(raw));
    } catch {
      showToast("O projeto salvo está corrompido ou contém dados inválidos. O arquivo foi ignorado com segurança.", "warn", 7000);
      loadBuilding();
      return;
    }

    if (dados.endereco) {
      placeContext = { ...placeContext, endereco: dados.endereco, lat: dados.lat, lng: dados.lng };
    }

    nodes.length = 0;
    cables.length = 0;
    scene.clearObjects();
    if (dados.building) addBuildingSceneObject(dados.building);
    wallColor = dados.wallColor || wallColor;
    wallSegments.length = 0;
    (dados.walls || []).forEach((w) => wallSegments.push(w));
    rebuildWallsSceneObject();
    (dados.nodes || []).forEach((n) => {
      const cat = EQUIPMENT_TYPES[n.tipo];
      if (cat?.mountingType === "rack") {
        n.unidadesU = n.unidadesU || cat.unidadesU || 1;
        n.rackId = n.rackId || null;
      }
      if (["roteador", "roteador-enterprise"].includes(n.tipo) && n.ligado === undefined) n.ligado = true;
      if (cat?.wifi && n.alcanceM === undefined) n.alcanceM = 15;
      if (cat?.alturaU) n.usedU = n.usedU || 0;
      nodes.push(n);
      addNodeSceneObject(n);
    });
    (dados.cables || []).forEach((c) => {
      cables.push(c);
      const a = nodes.find((n) => n.id === c.aId);
      const b = nodes.find((n) => n.id === c.bId);
      if (!a || !b) return;
      scene.addObject({
        id: c.id,
        type: "line",
        points: routedPoints(a, b),
        color: cableColor(c.resultado, c.tipo),
        dashed: CABLE_TYPES[c.tipo]?.categoria === "fibra",
        label: `${c.resultado.distanciaM.toFixed(1)}m`,
        pickable: false,
      });
    });

    renderPlaceBanner();
    renderAll();
    if (!dados.building) loadBuilding();
    showToast("Projeto carregado a partir do local salvo.", "info");
  }

  // -----------------------------------------------------------------
  // Ações: colocar / conectar / remover
  // -----------------------------------------------------------------
  function placeNode(tipoId, groundPoint) {
    const cat = EQUIPMENT_TYPES[tipoId];
    const id = novoId(tipoId);

    if (cat.isZone) {
      const node = { id, tipo: tipoId, position: { x: groundPoint.x, y: 0, z: groundPoint.z }, portasUsadas: 0, raio: cat.raio };
      nodes.push(node);
      addNodeSceneObject(node);
      showToast(`${cat.nome} demarcada no mapa.`, "info");
    } else {
      let position = { x: groundPoint.x, y: cat.teto ? cat.tetoAltura : 0, z: groundPoint.z };
      let rackId = null;
      const unidadesU = cat.unidadesU || 1;
      if (cat.mountingType === "rack") {
        const rack = rackForPoint(groundPoint);
        if (!rack) {
          showToast("Crie ou aproxime o equipamento de um rack antes de encaixá-lo.", "warn");
          return;
        }
        const rackCat = rackCatalog(rack);
        rack.usedU = rack.usedU || 0;
        if (rack.usedU + unidadesU > rackCat.alturaU) {
          showToast(`${rackCat.nome} sem espaço: ${rack.usedU}/${rackCat.alturaU}U ocupados.`, "error");
          return;
        }
        rackId = rack.id;
        position = {
          x: rack.position.x,
          y: rack.position.y + (rack.usedU / rackCat.alturaU) * rackCat.size.h,
          z: rack.position.z,
        };
        rack.usedU += unidadesU;
      } else if (cat.mountingType === "wall") {
        const mount = wallMountPosition(cat, groundPoint);
        if (!mount.snapped) {
          showToast("Nenhuma parede ou contorno de prédio por perto — desenhe uma parede (ou carregue o contorno do local) antes de fixar este equipamento.", "warn", 6000);
          return;
        }
        position = mount.position;
      } else if (pointOnWall(groundPoint, Math.max(cat.size.w, cat.size.d) / 2)) {
        showToast("Parede sólida: escolha uma área livre ou fixe este equipamento na parede.", "warn");
        return;
      }
      const node = { id, tipo: tipoId, position, portasUsadas: 0, rackId, unidadesU };
      if (cat.wifi) node.alcanceM = 15;
      nodes.push(node);
      addNodeSceneObject(node);
      showToast(`${cat.nome} adicionado ao mapa.`, "success");
    }
    renderAll();
  }

  async function connectCable(tipoCabo, a, b) {
    const catA = nodeCatalog(a);
    const catB = nodeCatalog(b);

    if (catA.portasPadrao && a.portasUsadas >= catA.portasPadrao) {
      showToast(`${catA.nome} já está com todas as ${catA.portasPadrao} portas ocupadas.`, "error");
      return;
    }
    if (catB.portasPadrao && b.portasUsadas >= catB.portasPadrao) {
      showToast(`${catB.nome} já está com todas as ${catB.portasPadrao} portas ocupadas.`, "error");
      return;
    }

    const pontos = routedPoints(a, b);
    const zonas = nodes.filter((n) => EQUIPMENT_TYPES[n.tipo].isZone).map((n) => ({ x: n.position.x, y: n.position.y, z: n.position.z, raio: n.raio }));

    let resultado;
    try {
      resultado = await bridge.calcularCabo(pontos, CABLE_TYPES[tipoCabo], zonas);
    } catch (err) {
      showToast(`Falha ao calcular o cabo: ${err?.message || err}`, "error");
      return;
    }

    const cableId = novoId("cabo");
    cables.push({
      id: cableId,
      tipo: tipoCabo,
      aId: a.id,
      bId: b.id,
      resultado,
    });
    if (catA.portasPadrao) a.portasUsadas += 1;
    if (catB.portasPadrao) b.portasUsadas += 1;

    scene.addObject({
      id: cableId,
      type: "line",
      points: pontos,
      color: cableColor(resultado, tipoCabo),
      dashed: CABLE_TYPES[tipoCabo]?.categoria === "fibra",
      label: `${resultado.distanciaM.toFixed(1)}m`,
      pickable: false,
    });

    if (resultado.excedeLimite) {
      showToast(`Cabo de ${resultado.distanciaM.toFixed(1)}m excede o limite de 90m — insira um Ponto de Consolidação.`, "error", 6000);
    } else if (resultado.alertaEMI) {
      showToast("Cabo cruza uma Zona de Risco EMI — recomenda-se blindagem (F/UTP ou S/FTP).", "error", 6000);
    } else {
      showToast(`Cabo conectado — ${resultado.distanciaM.toFixed(1)}m, dentro da norma.`, "success");
    }

    renderAll();
  }

  function removeNode(id) {
    const node = nodes.find((candidate) => candidate.id === id);
    if (!node) return;
    const ids = [id, ...nodes.filter((candidate) => candidate.rackId === id).map((candidate) => candidate.id)];
    ids.forEach((nodeId) => {
      const current = nodes.find((candidate) => candidate.id === nodeId);
      if (!current) return;
      if (current.rackId) {
        const rack = nodes.find((candidate) => candidate.id === current.rackId);
        if (rack) rack.usedU = Math.max(0, (rack.usedU || 0) - (current.unidadesU || 1));
      }
      nodes.splice(nodes.indexOf(current), 1);
      scene.removeObject(nodeId);
      scene.removeObject(`${nodeId}_wifiwave`);
    });

    // remove cabos ligados a este nó e libera portas do outro extremo
    const ligados = cables.filter((c) => ids.includes(c.aId) || ids.includes(c.bId));
    ligados.forEach((c) => {
      scene.removeObject(c.id);
      const outroId = ids.includes(c.aId) ? c.bId : c.aId;
      const outro = nodes.find((n) => n.id === outroId);
      if (outro && EQUIPMENT_TYPES[outro.tipo].portasPadrao) outro.portasUsadas = Math.max(0, outro.portasUsadas - 1);
    });
    for (let i = cables.length - 1; i >= 0; i--) {
      if (ids.includes(cables[i].aId) || ids.includes(cables[i].bId)) cables.splice(i, 1);
    }
    renderAll();
  }

  function removeCable(id) {
    const cable = cables.find((c) => c.id === id);
    if (!cable) return;
    scene.removeObject(id);
    const a = nodes.find((n) => n.id === cable.aId);
    const b = nodes.find((n) => n.id === cable.bId);
    if (a && EQUIPMENT_TYPES[a.tipo].portasPadrao) a.portasUsadas = Math.max(0, a.portasUsadas - 1);
    if (b && EQUIPMENT_TYPES[b.tipo].portasPadrao) b.portasUsadas = Math.max(0, b.portasUsadas - 1);
    cables.splice(cables.indexOf(cable), 1);
    renderAll();
  }

  // -----------------------------------------------------------------
  // Interação com a cena
  // -----------------------------------------------------------------
  scene.onClick = (screenPoint) => {
    if (!tool) return;

    if (tool.kind === "place") {
      const cat = EQUIPMENT_TYPES[tool.tipo];
      const planeY = cat.teto ? cat.tetoAltura : 0;
      const p = scene.unprojectToPlane(screenPoint.x, screenPoint.y, planeY);
      if (!p) {
        showToast("Clique dentro da planta (piso/teto visível).", "warn");
        return;
      }
      clearGhostPreview();
      placeNode(tool.tipo, p);
      return;
    }

    if (tool.kind === "wall") {
      const p = scene.unprojectToPlane(screenPoint.x, screenPoint.y, 0);
      if (!p) {
        showToast("Clique dentro da planta.", "warn");
        return;
      }
      wallDraft.push({ x: p.x, z: p.z });
      updateWallDraftVisual();
      buildToolbar();
      return;
    }

    if (tool.kind === "remove") {
      const picked = scene.pickObject(screenPoint.x, screenPoint.y);
      if (picked) removeNode(picked.id);
      return;
    }

    if (tool.kind === "cable") {
      const picked = scene.pickObject(screenPoint.x, screenPoint.y);
      if (!picked || picked.type === "line") {
        showToast("Clique sobre um equipamento para conectar o cabo.", "warn");
        return;
      }
      if (!cableFirstId) {
        cableFirstId = picked.id;
        highlightNode(picked.id);
        buildToolbar();
        return;
      }
      if (cableFirstId === picked.id) {
        showToast("Escolha um equipamento diferente para o outro extremo.", "warn");
        return;
      }
      const a = nodes.find((n) => n.id === cableFirstId);
      const b = nodes.find((n) => n.id === picked.id);
      cableFirstId = null;
      highlightNode(null);
      if (a && b) connectCable(tool.tipo, a, b);
    }
  };

  scene.onHover = (screenPoint) => {
    if (!tool) {
      clearGhostPreview();
      return;
    }
    canvas.style.cursor = tool.kind === "remove" ? "not-allowed" : "crosshair";
    if (tool.kind === "place") updateGhostPreview(screenPoint);
    else clearGhostPreview();
  };

  canvas.addEventListener("pointerleave", () => {
    clearGhostPreview();
    scene.render();
  });

  // -----------------------------------------------------------------
  // Tela cheia — o mapa (biblioteca + planta + painel) ocupa a tela toda,
  // com um botão de saída sempre visível sobre o canvas (além do Esc
  // padrão do navegador), como pedido: "fullscreen com opção de sair".
  // -----------------------------------------------------------------
  function toggleFullscreen() {
    if (document.fullscreenElement) {
      document.exitFullscreen?.();
    } else {
      (view.requestFullscreen?.() || Promise.reject())?.catch(() => {
        showToast("Este ambiente não permite tela cheia.", "warn");
      });
    }
  }

  function onFullscreenChange() {
    const isFull = document.fullscreenElement === view;
    view.classList.toggle("is-fullscreen", isFull);
    buildToolbar();
    requestAnimationFrame(() => scene.render());
  }
  document.addEventListener("fullscreenchange", onFullscreenChange);

  // -----------------------------------------------------------------
  // Boot + responsividade
  // -----------------------------------------------------------------
  saveBtn.addEventListener("click", saveProject);

  const resizeObserver = new ResizeObserver(() => scene.render());
  resizeObserver.observe(canvasWrap);

  renderPlaceBanner();
  renderAll();
  loadProjectIfAny();
  // primeiro render pode ocorrer antes do layout aplicar largura final
  requestAnimationFrame(() => scene.render());

  return () => {
    resizeObserver.disconnect();
    document.removeEventListener("fullscreenchange", onFullscreenChange);
    scene.destroy();
  };
}
