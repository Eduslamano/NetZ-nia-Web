// ---------------------------------------------------------------------
// scene3d.js — motor 3D minimalista em Canvas 2D (sem dependências).
//
// O restante do app é 100% offline e sem bundler/dependências (ver
// build.js), então em vez de embutir uma lib externa (Three.js/Cesium)
// escrevemos aqui uma câmera orbital + projeção em perspectiva "à mão".
// É o suficiente para o caso de uso: visualizar racks/switches/cabos
// numa planta e medir distâncias — não precisamos de um motor gráfico
// completo para isso.
//
// Convenção de eixos: X e Z formam o plano do piso (planta baixa),
// Y é a altura (pé-direito). 1 unidade = 1 metro.
// ---------------------------------------------------------------------

// ---- vetores -----------------------------------------------------------
const add = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const scale = (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s });
const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
const cross = (a, b) => ({
  x: a.y * b.z - a.z * b.y,
  y: a.z * b.x - a.x * b.z,
  z: a.x * b.y - a.y * b.x,
});
const length = (a) => Math.sqrt(dot(a, a));
const normalize = (a) => {
  const l = length(a) || 1e-6;
  return { x: a.x / l, y: a.y / l, z: a.z / l };
};
const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

export const vec3 = { add, sub, scale, dot, cross, length, normalize };

// ---- câmera orbital -----------------------------------------------------
export class Camera3D {
  constructor({ target = { x: 0, y: 0.6, z: 0 }, distance = 13, yaw = 0.8, pitch = 0.55, fov = 620 } = {}) {
    this.target = { ...target };
    this.distance = distance;
    this.yaw = yaw;
    this.pitch = pitch;
    this.fov = fov;
  }

  get position() {
    const cp = Math.cos(this.pitch);
    const sp = Math.sin(this.pitch);
    const cy = Math.cos(this.yaw);
    const sy = Math.sin(this.yaw);
    return {
      x: this.target.x + this.distance * cp * sy,
      y: this.target.y + this.distance * sp,
      z: this.target.z + this.distance * cp * cy,
    };
  }

  basis() {
    const pos = this.position;
    const fwd = normalize(sub(this.target, pos));
    let right = normalize(cross(fwd, { x: 0, y: 1, z: 0 }));
    if (!Number.isFinite(right.x) || length(right) < 1e-4) right = { x: 1, y: 0, z: 0 };
    const up = normalize(cross(right, fwd));
    return { pos, fwd, right, up };
  }

  orbit(dYaw, dPitch) {
    this.yaw += dYaw;
    this.pitch = clamp(this.pitch + dPitch, -1.4, 1.45);
  }

  zoom(factor) {
    this.distance = clamp(this.distance * factor, 3, 55);
  }
}

// ---- cena -----------------------------------------------------------
export class Scene3D {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.camera = new Camera3D(opts.camera);
    this.objects = [];
    this.gridSize = opts.gridSize || 34;
    this.gridStep = opts.gridStep || 1;
    this.bg = opts.bg || "#07131F";

    this.onClick = null; // (screenPoint) => void
    this.onHover = null; // (screenPoint) => void

    this._dragging = false;
    this._moved = false;
    this._lastX = 0;
    this._lastY = 0;

    this._onPointerDown = this._onPointerDown.bind(this);
    this._onPointerMove = this._onPointerMove.bind(this);
    this._onPointerUp = this._onPointerUp.bind(this);
    this._onWheel = this._onWheel.bind(this);

    canvas.addEventListener("pointerdown", this._onPointerDown);
    canvas.addEventListener("pointermove", this._onPointerMove);
    window.addEventListener("pointerup", this._onPointerUp);
    canvas.addEventListener("wheel", this._onWheel, { passive: false });
  }

  destroy() {
    this.canvas.removeEventListener("pointerdown", this._onPointerDown);
    this.canvas.removeEventListener("pointermove", this._onPointerMove);
    window.removeEventListener("pointerup", this._onPointerUp);
    this.canvas.removeEventListener("wheel", this._onWheel);
  }

  resize() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width * dpr));
    const h = Math.max(1, Math.round(rect.height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  addObject(obj) {
    this.objects.push(obj);
    return obj;
  }

  removeObject(id) {
    this.objects = this.objects.filter((o) => o.id !== id);
  }

  getObject(id) {
    return this.objects.find((o) => o.id === id) || null;
  }

  clearObjects() {
    this.objects = [];
  }

  // ---- projeção 3D → 2D ------------------------------------------------
  project(p) {
    const { pos, fwd, right, up } = this.camera.basis();
    const rel = sub(p, pos);
    const zc = dot(rel, fwd);
    if (zc < 0.08) return null;
    const xc = dot(rel, right);
    const yc = dot(rel, up);
    const f = this.camera.fov;
    return {
      x: this.canvas.width / 2 + (xc / zc) * f,
      y: this.canvas.height / 2 - (yc / zc) * f,
      depth: zc,
    };
  }

  // ---- raio da tela → ponto no plano Y = planeY (colocar equipamentos) --
  unprojectToPlane(sx, sy, planeY = 0) {
    const { pos, fwd, right, up } = this.camera.basis();
    const f = this.camera.fov;
    const xn = (sx - this.canvas.width / 2) / f;
    const yn = -(sy - this.canvas.height / 2) / f;
    const dir = normalize(add(fwd, add(scale(right, xn), scale(up, yn))));
    if (Math.abs(dir.y) < 1e-5) return null;
    const t = (planeY - pos.y) / dir.y;
    if (t <= 0) return null;
    return add(pos, scale(dir, t));
  }

  screenPointFromEvent(evt) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (evt.clientX - rect.left) * (this.canvas.width / rect.width),
      y: (evt.clientY - rect.top) * (this.canvas.height / rect.height),
    };
  }

  pickObject(sx, sy, maxDist = 30) {
    let best = null;
    let bestDist = maxDist;
    for (const obj of this.objects) {
      if (!obj.pickable) continue;
      const anchor = obj.type === "line" ? obj.points[Math.floor(obj.points.length / 2)] : obj.position;
      const p = this.project(anchor);
      if (!p) continue;
      const d = Math.hypot(p.x - sx, p.y - sy);
      if (d < bestDist) {
        bestDist = d;
        best = obj;
      }
    }
    return best;
  }

  // ---- eventos de input --------------------------------------------------
  _onPointerDown(e) {
    this._dragging = true;
    this._moved = false;
    this._lastX = e.clientX;
    this._lastY = e.clientY;
  }

  _onPointerMove(e) {
    if (!this._dragging) {
      if (this.onHover) this.onHover(this.screenPointFromEvent(e));
      return;
    }
    const dx = e.clientX - this._lastX;
    const dy = e.clientY - this._lastY;
    if (Math.abs(dx) > 2 || Math.abs(dy) > 2) this._moved = true;
    this._lastX = e.clientX;
    this._lastY = e.clientY;
    this.camera.orbit(-dx * 0.0065, dy * 0.0065);
    this.render();
  }

  _onPointerUp(e) {
    if (!this._dragging) return;
    this._dragging = false;
    if (!this._moved && this.onClick) {
      this.onClick(this.screenPointFromEvent(e));
    }
  }

  _onWheel(e) {
    e.preventDefault();
    this.camera.zoom(e.deltaY > 0 ? 1.09 : 0.91);
    this.render();
  }

  // ---- desenho ------------------------------------------------------------
  _drawGrid() {
    const ctx = this.ctx;
    const half = this.gridSize / 2;

    // limita o total de "blocos" desenhados por frame pra não pesar o
    // canvas quando o cenário cresce (prédios grandes ampliam o gridSize)
    let step = this.gridStep;
    while ((this.gridSize / step) ** 2 > 2500) step *= 2;

    // paleta "grama em blocos" estilo Minecraft: duas tonalidades de
    // verde alternadas em xadrez, no lugar da grade fina de prancheta
    const corA = "#5FA83C";
    const corB = "#549934";

    for (let gx = -half; gx < half; gx += step) {
      for (let gz = -half; gz < half; gz += step) {
        const c0 = this.project({ x: gx, y: 0, z: gz });
        const c1 = this.project({ x: gx + step, y: 0, z: gz });
        const c2 = this.project({ x: gx + step, y: 0, z: gz + step });
        const c3 = this.project({ x: gx, y: 0, z: gz + step });
        if (!c0 || !c1 || !c2 || !c3) continue;

        const ix = Math.round((gx + half) / step);
        const iz = Math.round((gz + half) / step);
        ctx.fillStyle = (ix + iz) % 2 === 0 ? corA : corB;
        ctx.beginPath();
        ctx.moveTo(c0.x, c0.y);
        ctx.lineTo(c1.x, c1.y);
        ctx.lineTo(c2.x, c2.y);
        ctx.lineTo(c3.x, c3.y);
        ctx.closePath();
        ctx.fill();
        // borda escura sutil entre blocos — reforça a leitura pixelada/voxel
        ctx.strokeStyle = "rgba(30, 60, 20, 0.28)";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    // eixos centrais um pouco mais visíveis, só pra dar referência de orientação
    ctx.strokeStyle = "rgba(255,255,255,0.16)";
    ctx.lineWidth = 1.4;
    this._line3d({ x: 0, y: 0.008, z: -half }, { x: 0, y: 0.008, z: half });
    this._line3d({ x: -half, y: 0.008, z: 0 }, { x: half, y: 0.008, z: 0 });
  }

  _line3d(p1, p2) {
    const a = this.project(p1);
    const b = this.project(p2);
    if (!a || !b) return;
    const ctx = this.ctx;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  _shade(hex, amount) {
    // amount > 0 clareia (mistura com branco), < 0 escurece.
    // Escurecer é MULTIPLICATIVO (r *= 1+amount) em vez de subtrair um valor
    // fixo de cada canal — a versão antiga (r + 255*amount) zerava canais já
    // escuros e pintava a face inteira de preto puro (era o "switch preto").
    // Multiplicar preserva a matiz/cor do equipamento em qualquer face.
    const c = hex.replace("#", "");
    const num = parseInt(c.length === 3 ? c.split("").map((ch) => ch + ch).join("") : c, 16);
    let r = (num >> 16) & 255;
    let g = (num >> 8) & 255;
    let b = num & 255;
    if (amount >= 0) {
      r = r + (255 - r) * amount;
      g = g + (255 - g) * amount;
      b = b + (255 - b) * amount;
    } else {
      const f = 1 + amount; // amount ∈ [-1,0] → f ∈ [0,1]
      r *= f;
      g *= f;
      b *= f;
    }
    r = clamp(Math.round(r), 0, 255);
    g = clamp(Math.round(g), 0, 255);
    b = clamp(Math.round(b), 0, 255);
    return `rgb(${r},${g},${b})`;
  }

  _drawAntenna(basePoint, height, tiltX = 0, tiltZ = 0) {
    const ctx = this.ctx;
    const tip = { x: basePoint.x + tiltX, y: basePoint.y + height, z: basePoint.z + tiltZ };
    const a = this.project(basePoint);
    const b = this.project(tip);
    if (!a || !b) return;
    ctx.strokeStyle = "#E8F6F2";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.fillStyle = "#22D3C5";
    ctx.beginPath();
    ctx.arc(b.x, b.y, 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  _drawPortRow(faceCorners, count, insetRatio = 0.14) {
    // faceCorners: [bottomLeft, bottomRight] em espaço de mundo (aresta
    // inferior da face frontal já escolhida em _drawBox).
    const [blW, brW] = faceCorners;
    const bl = this.project(blW);
    const br = this.project(brW);
    if (!bl || !br) return;
    const ctx = this.ctx;
    const n = Math.max(2, count);
    for (let i = 0; i < n; i++) {
      const t0 = insetRatio + (i / n) * (1 - insetRatio * 2);
      const t1 = insetRatio + ((i + 0.72) / n) * (1 - insetRatio * 2);
      const x0 = bl.x + (br.x - bl.x) * t0;
      const x1 = bl.x + (br.x - bl.x) * t1;
      const y0 = bl.y + (br.y - bl.y) * t0;
      const y1 = bl.y + (br.y - bl.y) * t1;
      ctx.fillStyle = "rgba(10,25,22,0.55)";
      ctx.fillRect(Math.min(x0, x1), Math.min(y0, y1) - 2, Math.abs(x1 - x0) || 2, 4);
    }
  }

  _drawLedRow(faceCorners, count, baseColor = "#3FE07A") {
    // fileira de LEDs de status acima das portas — cada 3ª luz âmbar, o
    // resto verde, imitando o piscar de link/atividade de um switch real.
    const [blW, brW] = faceCorners;
    const bl = this.project(blW);
    const br = this.project(brW);
    if (!bl || !br) return;
    const ctx = this.ctx;
    const n = Math.max(2, count);
    for (let i = 0; i < n; i++) {
      const t = 0.14 + ((i + 0.5) / n) * (1 - 0.14 * 2);
      const x = bl.x + (br.x - bl.x) * t;
      const y = bl.y + (br.y - bl.y) * t;
      ctx.fillStyle = i % 3 === 0 ? "#FFD24D" : baseColor;
      ctx.beginPath();
      ctx.arc(x, y, 1.15, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  _drawJackRow(faceCorners, count, insetRatio = 0.05) {
    // fileira de jaques RJ45 "de verdade": bezel metálico claro + furo
    // escuro no centro, em vez do traço fino usado nos switches genéricos
    // — referência: foto de switch/patch enviada pelo usuário.
    const [blW, brW] = faceCorners;
    const bl = this.project(blW);
    const br = this.project(brW);
    if (!bl || !br) return;
    const ctx = this.ctx;
    const n = Math.max(2, count);
    for (let i = 0; i < n; i++) {
      const t0 = insetRatio + (i / n) * (1 - insetRatio * 2);
      const t1 = insetRatio + ((i + 0.82) / n) * (1 - insetRatio * 2);
      const x0 = bl.x + (br.x - bl.x) * t0;
      const x1 = bl.x + (br.x - bl.x) * t1;
      const y0 = bl.y + (br.y - bl.y) * t0;
      const y1 = bl.y + (br.y - bl.y) * t1;
      const cx = (x0 + x1) / 2;
      const cy = (y0 + y1) / 2;
      const jw = Math.max(2.6, Math.abs(x1 - x0));
      const jh = 5.2;
      ctx.fillStyle = "#B9C2C8";
      ctx.fillRect(cx - jw / 2, cy - jh / 2, jw, jh);
      ctx.fillStyle = "rgba(8,12,14,0.9)";
      ctx.fillRect(cx - jw / 2 + 0.6, cy - jh / 2 + 1, Math.max(1, jw - 1.2), jh - 2);
    }
  }

  _drawRackRails(topCorners, bottomCorners) {
    // duas linhas verticais sutis sugerindo os trilhos do rack + réguas
    // horizontais (simulando as unidades "U").
    const ctx = this.ctx;
    const [tl, tr] = topCorners;
    const [bl, br] = bottomCorners;
    const pTl = this.project(tl);
    const pTr = this.project(tr);
    const pBl = this.project(bl);
    const pBr = this.project(br);
    if (!pTl || !pTr || !pBl || !pBr) return;
    ctx.strokeStyle = "rgba(10,25,22,0.4)";
    ctx.lineWidth = 1;
    const steps = 10;
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const x0 = pTl.x + (pBl.x - pTl.x) * t;
      const y0 = pTl.y + (pBl.y - pTl.y) * t;
      const x1 = pTr.x + (pBr.x - pTr.x) * t;
      const y1 = pTr.y + (pBr.y - pTr.y) * t;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();
    }
  }

  _drawShapeDetails(obj, base, w, d, h, faceZIdx, corners) {
    const shape = obj.shape;
    if (!shape) return;
    const camPos = this.camera.position;
    const frontZ = camPos.z > base.z ? d : -d; // profundidade do lado que está de frente pra câmera

    if (shape === "rack") {
      const top = { x: base.x, y: base.y + h, z: base.z + frontZ };
      const bottom = { x: base.x, y: base.y, z: base.z + frontZ };
      const topL = { ...top, x: top.x - w * 0.85 };
      const topR = { ...top, x: top.x + w * 0.85 };
      const botL = { ...bottom, x: bottom.x - w * 0.85 };
      const botR = { ...bottom, x: bottom.x + w * 0.85 };
      this._drawRackRails([topL, topR], [botL, botR]);
    } else if (shape === "switch" || shape === "patch-panel") {
      const y = base.y + h * 0.5;
      const bl = { x: base.x - w * 0.42, y, z: base.z + frontZ };
      const br = { x: base.x + w * 0.42, y, z: base.z + frontZ };
      this._drawPortRow([bl, br], shape === "switch" ? 12 : 16, 0.08);
      if (shape === "switch") {
        const yLed = base.y + h * 0.84;
        const blLed = { x: base.x - w * 0.42, y: yLed, z: base.z + frontZ };
        const brLed = { x: base.x + w * 0.42, y: yLed, z: base.z + frontZ };
        this._drawLedRow([blLed, brLed], 12);
      }
    } else if (shape === "switch-2row") {
      // switch/patch combo de 24 portas em 2 fileiras — referência: foto
      // enviada pelo usuário (chassis preto fosco, jaques metálicos).
      const yTop = base.y + h * 0.66;
      const yBot = base.y + h * 0.3;
      const blT = { x: base.x - w * 0.42, y: yTop, z: base.z + frontZ };
      const brT = { x: base.x + w * 0.42, y: yTop, z: base.z + frontZ };
      const blB = { x: base.x - w * 0.42, y: yBot, z: base.z + frontZ };
      const brB = { x: base.x + w * 0.42, y: yBot, z: base.z + frontZ };
      this._drawJackRow([blT, brT], 12);
      this._drawJackRow([blB, brB], 12);
      const yLed = base.y + h * 0.95;
      const blLed = { x: base.x - w * 0.42, y: yLed, z: base.z + frontZ };
      const brLed = { x: base.x + w * 0.42, y: yLed, z: base.z + frontZ };
      this._drawLedRow([blLed, brLed], 12);
    } else if (shape === "ap-wifi") {
      const top = { x: base.x, y: base.y + h, z: base.z };
      this._drawAntenna(top, 0.16, -0.09, 0);
      this._drawAntenna(top, 0.16, 0.09, 0.05);
    } else if (shape === "roteador") {
      // corpo com 4 antenas (referência: roteadores enterprise/CPE reais)
      // em vez de 2, além de uma fileira de LEDs de status na frente.
      const top = { x: base.x, y: base.y + h, z: base.z };
      [-0.85, -0.3, 0.3, 0.85].forEach((f) => {
        this._drawAntenna({ x: top.x + f * w, y: top.y, z: top.z }, 0.2 + Math.abs(f) * 0.05, f * 0.12, -0.03);
      });
      const yLed = base.y + h * 0.8;
      [-0.18, 0, 0.18].forEach((f, i) => {
        const p = this.project({ x: base.x + f * w, y: yLed, z: base.z + frontZ });
        if (!p) return;
        this.ctx.fillStyle = i === 1 ? "#22D3C5" : "#3FE07A";
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        this.ctx.fill();
      });
    } else if (shape === "tomada") {
      const p = this.project({ x: base.x, y: base.y + h * 0.5, z: base.z + frontZ });
      if (p) {
        this.ctx.strokeStyle = "rgba(10,25,22,0.6)";
        this.ctx.lineWidth = 1.2;
        this.ctx.strokeRect(p.x - 2.5, p.y - 3, 5, 6);
      }
    }
  }

  _drawDropShadow(base, radiusX, radiusZ) {
    const ctx = this.ctx;
    const segs = 16;
    const pts = [];
    for (let i = 0; i <= segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      const p = this.project({ x: base.x + Math.cos(a) * radiusX, y: 0.012, z: base.z + Math.sin(a) * radiusZ });
      if (!p) return;
      pts.push(p);
    }
    ctx.beginPath();
    pts.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.closePath();
    ctx.fillStyle = "rgba(15, 35, 15, 0.28)";
    ctx.fill();
  }

  _drawBox(obj) {
    const { position: base, size, color } = obj;
    const w = size.w / 2;
    const d = size.d / 2;
    const h = size.h;
    const c0 = add(base, { x: -w, y: 0, z: -d });
    const c1 = add(base, { x: w, y: 0, z: -d });
    const c2 = add(base, { x: w, y: 0, z: d });
    const c3 = add(base, { x: -w, y: 0, z: d });
    const c4 = add(c0, { x: 0, y: h, z: 0 });
    const c5 = add(c1, { x: 0, y: h, z: 0 });
    const c6 = add(c2, { x: 0, y: h, z: 0 });
    const c7 = add(c3, { x: 0, y: h, z: 0 });

    const P = [c0, c1, c2, c3, c4, c5, c6, c7].map((p) => this.project(p));
    if (P.some((p) => !p)) return; // ponto atrás da câmera: pula este frame

    const ctx = this.ctx;
    const camPos = this.camera.position;
    const faceX = camPos.x > base.x ? [1, 2, 6, 5] : [0, 3, 7, 4];
    const faceZ = camPos.z > base.z ? [3, 2, 6, 7] : [0, 1, 5, 4];

    // sombra "de brinquedo" no chão — reforça o clima cartoon/miniatura
    if (base.y < 0.05 && !obj.ghost) this._drawDropShadow(base, w * 1.12, d * 1.12);

    if (obj.ghost) ctx.globalAlpha = 0.5;

    const poly = (idx, fill) => {
      ctx.beginPath();
      idx.forEach((i, k) => (k === 0 ? ctx.moveTo(P[i].x, P[i].y) : ctx.lineTo(P[i].x, P[i].y)));
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      // contorno grosso e escuro — estilo "toon outline" (tracejado colorido
      // quando é uma prévia "fantasma" seguindo o cursor antes de posicionar)
      ctx.strokeStyle = obj.ghost ? (obj.ghostInvalid ? "#E1685B" : "#22D3C5") : "rgba(15, 25, 15, 0.85)";
      ctx.lineWidth = obj.ghost ? 2 : 2.2;
      ctx.lineJoin = "round";
      if (obj.ghost) ctx.setLineDash([5, 4]);
      ctx.stroke();
      if (obj.ghost) ctx.setLineDash([]);
    };

    poly(faceZ, this._shade(color, -0.2));
    poly(faceX, this._shade(color, -0.4));
    poly([4, 5, 6, 7], this._shade(color, obj.highlight ? 0.4 : 0.2));

    this._drawShapeDetails(obj, base, w, d, h, faceZ, [c0, c1, c2, c3, c4, c5, c6, c7]);

    if (obj.ghost) ctx.globalAlpha = 1;

    if (obj.highlight) {
      ctx.save();
      ctx.strokeStyle = "#22D3C5";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      [4, 5, 6, 7].forEach((i, k) => (k === 0 ? ctx.moveTo(P[i].x, P[i].y) : ctx.lineTo(P[i].x, P[i].y)));
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }

    if (obj.label) {
      const top = { x: base.x, y: base.y + h, z: base.z };
      const tp = this.project(top);
      if (tp) {
        ctx.font = "600 12px var(--font-mono, monospace)";
        ctx.fillStyle = "#EAF6F3";
        ctx.textAlign = "center";
        ctx.shadowColor = "rgba(0,0,0,0.6)";
        ctx.shadowBlur = 4;
        ctx.fillText(obj.label, tp.x, tp.y - 8);
        ctx.shadowBlur = 0;
      }
    }
  }

  _drawZone(obj) {
    const ctx = this.ctx;
    const segs = 24;
    const pts = [];
    for (let i = 0; i <= segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      pts.push(this.project({
        x: obj.position.x + Math.cos(a) * obj.raio,
        y: 0.015,
        z: obj.position.z + Math.sin(a) * obj.raio,
      }));
    }
    if (pts.some((p) => !p)) return;
    if (obj.ghost) ctx.globalAlpha = 0.6;
    ctx.beginPath();
    pts.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.closePath();
    ctx.fillStyle = "rgba(225,104,91,0.20)";
    ctx.fill();
    ctx.strokeStyle = obj.highlight ? "#E1685B" : "rgba(225,104,91,0.65)";
    ctx.lineWidth = obj.highlight ? 2.4 : 1.5;
    ctx.setLineDash([6, 5]);
    ctx.stroke();
    ctx.setLineDash([]);
    if (obj.ghost) ctx.globalAlpha = 1;

    const label = this.project({ x: obj.position.x, y: 0.9, z: obj.position.z });
    if (label && obj.label) {
      ctx.font = "600 11px var(--font-mono, monospace)";
      ctx.fillStyle = "#E1685B";
      ctx.textAlign = "center";
      ctx.fillText(obj.label, label.x, label.y);
    }
  }

  _drawLine(obj) {
    const ctx = this.ctx;
    const pts = obj.points.map((p) => this.project(p));
    if (pts.some((p) => !p)) return;
    const baseWidth = obj.highlight ? 5 : 3.2;

    // "casca" mais escura e um pouco mais grossa por baixo — dá volume de
    // cabo redondo em vez de um traço 2D chapado (referência: fotos de
    // patch cord real, cilíndrico e com brilho na parte de cima).
    ctx.beginPath();
    pts.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.strokeStyle = this._shade(obj.color, -0.42);
    ctx.lineWidth = baseWidth + 2;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    if (obj.dashed) ctx.setLineDash([9, 6]);
    ctx.stroke();

    ctx.beginPath();
    pts.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.strokeStyle = obj.color;
    ctx.lineWidth = baseWidth;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    if (obj.dashed) ctx.setLineDash([9, 6]);
    ctx.stroke();
    ctx.setLineDash([]);

    // conectores nas pontas — plug retangular (estilo RJ45) em vez de bolinha
    [pts[0], pts[pts.length - 1]].forEach((p) => {
      ctx.save();
      const pw = 7.5;
      const ph = 5;
      ctx.fillStyle = "#EDEAE2";
      ctx.strokeStyle = "rgba(15,25,15,0.75)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(p.x - pw / 2, p.y - ph / 2, pw, ph, 1.3);
      else ctx.rect(p.x - pw / 2, p.y - ph / 2, pw, ph);
      ctx.fill();
      ctx.stroke();
      // trava dourada do RJ45
      ctx.fillStyle = "#C9A227";
      ctx.fillRect(p.x - pw / 2 + 1.4, p.y - 0.6, pw - 2.8, 1.2);
      ctx.restore();
    });

    if (obj.label) {
      const mid = pts[Math.floor(pts.length / 2)];
      ctx.font = "700 11px var(--font-mono, monospace)";
      ctx.fillStyle = "#FFFFFF";
      ctx.textAlign = "center";
      ctx.shadowColor = "rgba(0,0,0,0.7)";
      ctx.shadowBlur = 4;
      ctx.fillText(obj.label, mid.x, mid.y - 6);
      ctx.shadowBlur = 0;
    }
  }

  _hexToRgba(hex, alpha) {
    const c = hex.replace("#", "");
    const num = parseInt(c.length === 3 ? c.split("").map((ch) => ch + ch).join("") : c, 16);
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  }

  _drawBuilding(obj) {
    const ctx = this.ctx;
    const pts = obj.footprint; // [{x,z}, ...] em metros, local ao centro do local pesquisado
    if (!pts || pts.length < 3) return;
    const cor = obj.color || "#7896AA"; // cor padrão se o usuário não escolher

    // piso: preenchimento translúcido no chão (y=0.01, acima da grade)
    const floorProj = pts.map((p) => this.project({ x: p.x, y: 0.01, z: p.z }));
    if (!floorProj.some((p) => !p)) {
      ctx.beginPath();
      floorProj.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
      ctx.closePath();
      ctx.fillStyle = this._hexToRgba(cor, 0.32);
      ctx.fill();
      ctx.strokeStyle = this._hexToRgba(cor, 0.75);
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }

    // paredes: um quad por aresta do polígono, do chão até a altura —
    // opacidade mais alta que antes (a versão anterior ficava quase
    // invisível, parecendo só contorno/wireframe)
    const h = obj.height || 9;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const p0 = this.project({ x: a.x, y: 0, z: a.z });
      const p1 = this.project({ x: b.x, y: 0, z: b.z });
      const p2 = this.project({ x: b.x, y: h, z: b.z });
      const p3 = this.project({ x: a.x, y: h, z: a.z });
      if (!p0 || !p1 || !p2 || !p3) continue;
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(p3.x, p3.y);
      ctx.closePath();
      ctx.fillStyle = this._hexToRgba(cor, 0.26);
      ctx.fill();
      ctx.strokeStyle = this._hexToRgba(cor, 0.7);
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    if (obj.label) {
      const centroid = pts.reduce((acc, p) => ({ x: acc.x + p.x / pts.length, z: acc.z + p.z / pts.length }), { x: 0, z: 0 });
      const lp = this.project({ x: centroid.x, y: h + 0.4, z: centroid.z });
      if (lp) {
        ctx.font = "600 12px var(--font-mono, monospace)";
        ctx.fillStyle = "rgba(230,240,235,0.9)";
        ctx.textAlign = "center";
        ctx.fillText(obj.label, lp.x, lp.y);
      }
    }
  }

  _drawWalls(obj) {
    const ctx = this.ctx;
    const color = obj.color || "#96AFC3";
    const h = obj.height || 2.6;
    (obj.segments || []).forEach(({ a, b }) => {
      const p0 = this.project({ x: a.x, y: 0, z: a.z });
      const p1 = this.project({ x: b.x, y: 0, z: b.z });
      const p2 = this.project({ x: b.x, y: h, z: b.z });
      const p3 = this.project({ x: a.x, y: h, z: a.z });
      if (!p0 || !p1 || !p2 || !p3) return;
      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.lineTo(p3.x, p3.y);
      ctx.closePath();
      ctx.fillStyle = this._hexToRgba(color, 0.92);
      ctx.fill();
      ctx.strokeStyle = obj.highlight ? "#22D3C5" : this._hexToRgba(color, 0.8);
      ctx.lineWidth = obj.highlight ? 2 : 1.2;
      ctx.stroke();
    });
  }

  _drawDisc(obj) {
    const ctx = this.ctx;
    const { position: base, radius, thickness, color } = obj;
    const segs = 20;
    const topY = base.y + thickness;

    const ring = (y) => {
      const pts = [];
      for (let i = 0; i <= segs; i++) {
        const a = (i / segs) * Math.PI * 2;
        pts.push(this.project({ x: base.x + Math.cos(a) * radius, y, z: base.z + Math.sin(a) * radius }));
      }
      return pts;
    };

    const bottomRing = ring(base.y);
    const topRing = ring(topY);
    if (bottomRing.some((p) => !p) || topRing.some((p) => !p)) return;

    if (obj.ghost) ctx.globalAlpha = 0.5;

    // borda lateral (o "corpo" fino do disco) — algumas fatias representativas
    for (let i = 0; i < segs; i += 4) {
      const b0 = bottomRing[i], b1 = bottomRing[i + 1];
      const t0 = topRing[i], t1 = topRing[i + 1];
      ctx.beginPath();
      ctx.moveTo(b0.x, b0.y);
      ctx.lineTo(b1.x, b1.y);
      ctx.lineTo(t1.x, t1.y);
      ctx.lineTo(t0.x, t0.y);
      ctx.closePath();
      ctx.fillStyle = this._shade(color, -0.15);
      ctx.fill();
    }

    // face de cima do disco (o que se vê olhando de baixo/lado, encostado no teto)
    ctx.beginPath();
    topRing.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.closePath();
    ctx.fillStyle = obj.highlight ? this._shade(color, 0.3) : this._shade(color, 0.08);
    ctx.fill();
    ctx.strokeStyle = obj.ghost ? (obj.ghostInvalid ? "#E1685B" : "#22D3C5") : "rgba(15,25,15,0.85)";
    ctx.lineWidth = obj.ghost ? 2 : 1.8;
    if (obj.ghost) ctx.setLineDash([5, 4]);
    ctx.stroke();
    ctx.setLineDash([]);

    // bojo central (o "logo"/LED do AP360) + anel de status
    const centro = this.project({ x: base.x, y: topY + 0.002, z: base.z });
    if (centro) {
      ctx.beginPath();
      ctx.arc(centro.x, centro.y, Math.max(3, radius * 40), 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.fill();
      ctx.strokeStyle = "#22D3C5";
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }

    if (obj.label) {
      const lp = this.project({ x: base.x, y: topY, z: base.z });
      if (lp) {
        ctx.font = "600 12px var(--font-mono, monospace)";
        ctx.fillStyle = "#EAF6F3";
        ctx.textAlign = "center";
        ctx.shadowColor = "rgba(0,0,0,0.6)";
        ctx.shadowBlur = 4;
        ctx.fillText(obj.label, lp.x, lp.y - 10);
        ctx.shadowBlur = 0;
      }
    }

    if (obj.ghost) ctx.globalAlpha = 1;
  }

  // Ondas de sinal Wi-Fi — projeção do alcance no piso, como num levantamento
  // de cobertura (Ekahau/NetSpot), em vez de uma "bolha" 3D sólida. Só o
  // CONTORNO de cada anel é desenhado (sem fillStyle/fill) e a opacidade cai
  // do anel mais interno pro mais externo, imitando a atenuação do sinal —
  // de propósito, pra não pintar o piso por cima de cabos/equipamentos e
  // virar poluição visual no mapa.
  _drawWifiWave(obj) {
    const ctx = this.ctx;
    const segs = 28;
    const aneis = [
      { fracao: 1 / 3, alpha: 0.5 },
      { fracao: 2 / 3, alpha: 0.28 },
      { fracao: 1, alpha: 0.14 },
    ];

    aneis.forEach(({ fracao, alpha }) => {
      const raio = obj.radius * fracao;
      const pts = [];
      for (let i = 0; i <= segs; i++) {
        const a = (i / segs) * Math.PI * 2;
        pts.push(this.project({
          x: obj.position.x + Math.cos(a) * raio,
          y: obj.position.y,
          z: obj.position.z + Math.sin(a) * raio,
        }));
      }
      if (pts.some((p) => !p)) return;
      ctx.beginPath();
      pts.forEach((p, k) => (k === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
      ctx.closePath();
      ctx.strokeStyle = this._hexToRgba(obj.color, alpha);
      ctx.lineWidth = 1.2;
      ctx.stroke();
    });

    if (obj.label) {
      const lp = this.project({ x: obj.position.x, y: obj.position.y + 0.3, z: obj.position.z });
      if (lp) {
        ctx.font = "500 10px var(--font-mono, monospace)";
        ctx.fillStyle = this._hexToRgba(obj.color, 0.85);
        ctx.textAlign = "center";
        ctx.fillText(obj.label, lp.x, lp.y);
      }
    }
  }

  render() {
    this.resize();
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    ctx.clearRect(0, 0, w, h);
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#040817");
    sky.addColorStop(0.65, this.bg);
    sky.addColorStop(1, "#10291F");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
    this._drawNightSky(w, h);

    this._drawGrid();

    // edifício (se houver) desenha antes dos equipamentos — é o "chão de fábrica"
    const building = this.objects.find((o) => o.type === "building");
    if (building) this._drawBuilding(building);

    const walls = this.objects.filter((o) => o.type === "walls");
    walls.forEach((w) => this._drawWalls(w));

    const wifiWaves = this.objects.filter((o) => o.type === "wifiwave");
    wifiWaves.forEach((w) => this._drawWifiWave(w));

    // pinta zonas de risco (piso) antes dos objetos "sólidos"
    const zones = this.objects.filter((o) => o.type === "zone");
    const solids = this.objects.filter((o) => o.type === "box" || o.type === "line" || o.type === "disc");
    zones.forEach((z) => this._drawZone(z));

    // ordena do mais distante para o mais próximo (pintor)
    const depthOf = (o) => {
      const p = o.type === "line" ? o.points[Math.floor(o.points.length / 2)] : o.position;
      const proj = this.project(p);
      return proj ? proj.depth : -1;
    };
    solids
      .slice()
      .sort((a, b) => depthOf(b) - depthOf(a))
      .forEach((o) => {
        if (o.type === "box") this._drawBox(o);
        else if (o.type === "line") this._drawLine(o);
        else if (o.type === "disc") this._drawDisc(o);
      });
  }

  _drawNightSky(w, h) {
    const ctx = this.ctx;
    for (let i = 0; i < 70; i++) {
      const x = (i * 83 + 17) % w;
      const y = (i * 47 + 11) % Math.max(1, h * 0.55);
      ctx.fillStyle = i % 5 === 0 ? "rgba(255,220,154,0.9)" : "rgba(220,240,255,0.8)";
      ctx.beginPath();
      ctx.arc(x, y, i % 9 === 0 ? 1.35 : 0.7, 0, Math.PI * 2);
      ctx.fill();
    }
    const moonX = w * 0.84;
    const moonY = h * 0.16;
    const glow = ctx.createRadialGradient(moonX, moonY, 8, moonX, moonY, 62);
    glow.addColorStop(0, "rgba(255,239,190,0.22)");
    glow.addColorStop(1, "rgba(255,239,190,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(moonX - 70, moonY - 70, 140, 140);
    ctx.fillStyle = "#FFF0BD";
    ctx.beginPath();
    ctx.arc(moonX, moonY, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#040817";
    ctx.beginPath();
    ctx.arc(moonX + 7, moonY - 5, 16, 0, Math.PI * 2);
    ctx.fill();
  }
}
