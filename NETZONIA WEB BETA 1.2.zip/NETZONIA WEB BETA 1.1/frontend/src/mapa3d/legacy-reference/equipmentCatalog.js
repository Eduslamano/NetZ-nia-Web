// ---------------------------------------------------------------------
// equipmentCatalog.js — biblioteca "Drag & Drop" de equipamentos do
// Mapa 3D + catálogo de meios físicos (cabos).
//
// size: { w, h, d } em metros. position.y do nó = altura da BASE do
// objeto (0 = piso; ceiling nasce fixado no teto).
//
// mountingType — como o equipamento se fixa no ambiente:
//   floor   → apoiado no chão livremente
//   wall    → encaixa (snap) na face de uma parede mais próxima
//   ceiling → ancora no teto do ambiente
//   rack    → vive DENTRO de um rack, ocupando a quantidade indicada em
//             unidadesU.
//
// shape — dica visual pro renderer (scene3d.js → _drawShapeDetails).
// Itens sem 3D dedicado ainda reaproveitam a forma mais parecida da
// lista (rack / switch / patch-panel / ap-wifi / roteador / tomada) ou
// ficam como caixa lisa colorida — distinção fina por peça é trabalho
// futuro, o catálogo já está com a metadata certa pra isso evoluir.
// ---------------------------------------------------------------------

export const EQUIPMENT_TYPES = {
  // ---- ACONDICIONAMENTO ----------------------------------------------
  "rack-parede-12u": {
    id: "rack-parede-12u", nome: "Mini-rack de Parede (12U)", categoria: "Acondicionamento",
    descricao: "Mini rack de parede (3U a 16U) — salas técnicas pequenas ou PDs secundários.",
    size: { w: 0.55, h: 0.7, d: 0.5 }, color: "#3B4A55", shape: "rack", mountingType: "wall", alturaU: 12, alturaParede: 1.6,
  },
  "rack-24u": {
    id: "rack-24u", nome: "Rack de Piso 24U", categoria: "Acondicionamento",
    descricao: "Rack de piso de porte médio — salas de telecom por andar.",
    size: { w: 0.6, h: 1.2, d: 0.8 }, color: "#3B4A55", shape: "rack", mountingType: "floor", alturaU: 24,
  },
  "rack-42u": {
    id: "rack-42u", nome: "Rack de Piso 42U", categoria: "Acondicionamento",
    descricao: "Rack de piso cheio — backbone de andar/prédio.",
    size: { w: 0.6, h: 2.0, d: 1.0 }, color: "#2E3A43", shape: "rack", mountingType: "floor", alturaU: 42,
  },
  "rack-44u": {
    id: "rack-44u", nome: "Rack de Piso 44U (CPD)", categoria: "Acondicionamento",
    descricao: "Rack de CPD/datacenter — nó raiz do backbone do prédio.",
    size: { w: 0.6, h: 2.1, d: 1.05 }, color: "#26313A", shape: "rack", mountingType: "floor", alturaU: 44,
  },
  "rack-aberto": {
    id: "rack-aberto", nome: "Rack Aberto / Torre", categoria: "Acondicionamento",
    descricao: "Estrutura aberta (sem portas/laterais) — ventilação melhor, comum em CPDs de alta densidade.",
    size: { w: 0.6, h: 1.8, d: 0.9 }, color: "#4A5A64", shape: "rack", mountingType: "floor", alturaU: 42,
  },
  "caixa-outdoor": {
    id: "caixa-outdoor", nome: "Caixa Hermética Outdoor", categoria: "Acondicionamento",
    descricao: "Gabinete IP65/67 — abriga ativos expostos a intempérie (poste, fachada externa).",
    size: { w: 0.4, h: 0.5, d: 0.25 }, color: "#5C6B63", shape: "rack", mountingType: "wall", alturaParede: 1.8,
  },

  // ---- ATIVOS DE REDE --------------------------------------------------
  "switch-core": {
    id: "switch-core", nome: "Switch Core (Chassis)", categoria: "Ativo de Rede",
    descricao: "Chassis modular — espinha dorsal da rede, agrega os switches de acesso.",
    size: { w: 0.44, h: 0.35, d: 0.45 }, color: "#0E5C52", shape: "switch", mountingType: "rack", unidadesU: 8, portasPadrao: 96,
  },
  "switch-access-1u": {
    id: "switch-access-1u", nome: "Switch Access 1U", categoria: "Ativo de Rede",
    descricao: "Switch de acesso padrão, sem PoE — interliga estações de trabalho.",
    size: { w: 0.44, h: 0.09, d: 0.3 }, color: "#187266", shape: "switch", mountingType: "rack", unidadesU: 1, portasPadrao: 24,
  },
  "switch-access-2u-poe": {
    id: "switch-access-2u-poe", nome: "Switch Access 2U PoE", categoria: "Ativo de Rede",
    descricao: "Switch de acesso com Power over Ethernet — alimenta APs e câmeras direto pelo cabo de rede.",
    size: { w: 0.44, h: 0.18, d: 0.35 }, color: "#1B8A78", shape: "switch", mountingType: "rack", unidadesU: 2, portasPadrao: 48,
  },
  "switch-24p-2fileiras": {
    id: "switch-24p-2fileiras", nome: "Switch 24p (2 fileiras)", categoria: "Ativo de Rede",
    descricao: "Switch/patch combo compacto de 24 portas em 2 fileiras de 12 — chassis preto fosco com jaques metálicos, modelo enviado por foto de referência.",
    size: { w: 0.44, h: 0.1, d: 0.3 }, color: "#1C1F22", shape: "switch-2row", mountingType: "rack", unidadesU: 1, portasPadrao: 24,
  },
  "switch-industrial-din": {
    id: "switch-industrial-din", nome: "Switch Industrial (Trilho DIN)", categoria: "Ativo de Rede",
    descricao: "Switch reforçado para painéis elétricos/industriais, fixado em trilho DIN.",
    size: { w: 0.15, h: 0.12, d: 0.1 }, color: "#8A6D1B", shape: "switch", mountingType: "wall", portasPadrao: 8, alturaParede: 1.2,
  },
  "roteador-enterprise": {
    id: "roteador-enterprise", nome: "Roteador Enterprise", categoria: "Ativo de Rede",
    descricao: "Roteador de borda para redes corporativas — 1U de rack, alta capacidade de roteamento.",
    size: { w: 0.44, h: 0.09, d: 0.32 }, color: "#1F5F8A", shape: "switch", mountingType: "rack", unidadesU: 1, portasPadrao: 8,
  },
  roteador: {
    id: "roteador", nome: "Roteador CPE (mesa/piso)", categoria: "Ativo de Rede",
    descricao: "Roteador standalone com antenas — borda de rede pequena, home office, sala sem rack. 4 portas LAN.",
    size: { w: 0.28, h: 0.16, d: 0.18 }, color: "#1F7FA8", shape: "roteador", mountingType: "rack", unidadesU: 1, portasPadrao: 4, wifi: true,
  },
  firewall: {
    id: "firewall", nome: "Firewall", categoria: "Ativo de Rede",
    descricao: "Appliance de segurança de borda — filtra tráfego entre a rede interna e a internet.",
    size: { w: 0.44, h: 0.09, d: 0.3 }, color: "#8A2E2E", shape: "switch", mountingType: "rack", unidadesU: 1, portasPadrao: 8,
  },

  // ---- WLAN -------------------------------------------------------------
  "ap-teto": {
    id: "ap-teto", nome: "Access Point (teto) — estilo AP 360", categoria: "WLAN",
    descricao: "Disco branco fixado no teto, no estilo Intelbras AP 360. Mostra o alcance do sinal (raio configurável) em volta dele.",
    size: { w: 0.24, h: 0.045, d: 0.24 }, color: "#F2F5F3", renderAs: "disc", discRadius: 0.12,
    mountingType: "ceiling", teto: true, tetoAltura: 2.8, portasPadrao: 1, wifi: true,
  },
  "ap-parede": {
    id: "ap-parede", nome: "Access Point (parede)", categoria: "WLAN",
    descricao: "AP in-wall — corredores estreitos ou quando o teto não é acessível.",
    size: { w: 0.18, h: 0.12, d: 0.04 }, color: "#2AA7C4", shape: "ap-wifi", mountingType: "wall", wifi: true, alturaParede: 2.2,
  },
  "ap-outdoor": {
    id: "ap-outdoor", nome: "Access Point Outdoor (IP67)", categoria: "WLAN",
    descricao: "AP robusto para área externa — pátios, estacionamentos, fachadas.",
    size: { w: 0.22, h: 0.22, d: 0.08 }, color: "#1F8FA8", shape: "ap-wifi", mountingType: "wall", wifi: true, alturaParede: 2.5,
  },

  // ---- INFRAESTRUTURA PASSIVA --------------------------------------------
  "patch-panel-24": {
    id: "patch-panel-24", nome: "Patch Panel 24 portas", categoria: "Passivo",
    descricao: "Régua de manobra: a traseira recebe o cabo horizontal, a frente liga ao switch.",
    size: { w: 0.44, h: 0.045, d: 0.1 }, color: "#DB932C", shape: "patch-panel", mountingType: "rack", portasPadrao: 24,
  },
  "patch-panel-48": {
    id: "patch-panel-48", nome: "Patch Panel 48 portas", categoria: "Passivo",
    descricao: "Versão de maior densidade — 2U, para racks com muitos pontos concentrados.",
    size: { w: 0.44, h: 0.09, d: 0.1 }, color: "#DB932C", shape: "patch-panel", mountingType: "rack", portasPadrao: 48,
  },
  "voice-panel": {
    id: "voice-panel", nome: "Voice Panel", categoria: "Passivo",
    descricao: "Patch panel dedicado a voz/telefonia (blocos 110 ou RJ11/RJ45).",
    size: { w: 0.44, h: 0.045, d: 0.1 }, color: "#B98B4E", shape: "patch-panel", mountingType: "rack", portasPadrao: 25,
  },
  "dio-odf": {
    id: "dio-odf", nome: "DIO / ODF Óptico", categoria: "Passivo",
    descricao: "Distribuidor interno óptico — recebe e organiza as fusões/conectores de fibra do backbone.",
    size: { w: 0.44, h: 0.09, d: 0.25 }, color: "#B45A2E", shape: "patch-panel", mountingType: "rack", portasPadrao: 12,
  },
  "roseta-optica": {
    id: "roseta-optica", nome: "Roseta Óptica", categoria: "Passivo",
    descricao: "Ponto final de fibra na mesa/parede do usuário (equivalente óptico da tomada TO).",
    size: { w: 0.08, h: 0.08, d: 0.04 }, color: "#B45A2E", shape: "tomada", mountingType: "wall", alturaParede: 0.3,
  },
  tomada: {
    id: "tomada", nome: "Tomada de Rede (Faceplate/Keystone)", categoria: "Passivo",
    descricao: "Ponto final de conexão metálica — nó de destino da infraestrutura (mesa/parede).",
    size: { w: 0.1, h: 0.1, d: 0.05 }, color: "#8065B0", shape: "tomada", mountingType: "wall", alturaParede: 0.3,
  },

  // ---- ENERGIA E TELECOM --------------------------------------------------
  "ups-rack": {
    id: "ups-rack", nome: "Nobreak/UPS (Rack)", categoria: "Energia",
    descricao: "Nobreak em formato de rack — autonomia de energia pros ativos do rack.",
    size: { w: 0.44, h: 0.18, d: 0.55 }, color: "#5B4A8A", mountingType: "rack", unidadesU: 2,
  },
  "ups-torre": {
    id: "ups-torre", nome: "Nobreak/UPS (Torre)", categoria: "Energia",
    descricao: "Nobreak standalone de piso — salas sem rack dedicado ou de maior capacidade.",
    size: { w: 0.3, h: 0.5, d: 0.3 }, color: "#5B4A8A", mountingType: "floor",
  },
  pdu: {
    id: "pdu", nome: "PDU (Régua de Energia de Rack)", categoria: "Energia",
    descricao: "Distribui energia entre os equipamentos do rack — monitorada ou básica.",
    size: { w: 0.44, h: 0.045, d: 0.06 }, color: "#7A6BA8", mountingType: "rack", unidadesU: 1,
  },
  onu: {
    id: "onu", nome: "ONU / Conversor de Mídia", categoria: "Energia",
    descricao: "Converte o sinal óptico da operadora (GPON) em Ethernet cobre pro usuário final.",
    size: { w: 0.15, h: 0.03, d: 0.1 }, color: "#4E8AB4", mountingType: "wall", alturaParede: 1.2,
  },

  // ---- MARCADOR -----------------------------------------------------------
  "zona-emi": {
    id: "zona-emi", nome: "Zona de Risco (EMI)", categoria: "Marcador",
    descricao: "Demarca poços de elevador, motores ou geradores. Cabos sem blindagem que cruzam esta zona geram alerta.",
    color: "#E1685B", isZone: true, raio: 1.2, mountingType: "floor",
  },
};

export const EQUIPMENT_ORDER = [
  "rack-parede-12u", "rack-24u", "rack-42u", "rack-44u", "rack-aberto", "caixa-outdoor",
  "switch-core", "switch-access-1u", "switch-access-2u-poe", "switch-24p-2fileiras", "switch-industrial-din", "roteador-enterprise", "roteador", "firewall",
  "ap-teto", "ap-parede", "ap-outdoor",
  "patch-panel-24", "patch-panel-48", "voice-panel", "dio-odf", "roseta-optica", "tomada",
  "ups-rack", "ups-torre", "pdu", "onu",
  "zona-emi",
];

export const EQUIPMENT_CATEGORIES = [
  "Acondicionamento", "Ativo de Rede", "WLAN", "Passivo", "Energia", "Marcador",
];

// ---------------------------------------------------------------------
// Meios físicos (cabos) — categoria define a regra de validação no Go:
//   "nao-blindado" → limite estrito de 90m, EMI reduz confiabilidade
//   "blindado"     → mesmo limite de 90m, mas a blindagem ATENUA o
//                    impacto de cruzar uma Zona de Risco EMI
//   "fibra"        → imune a EMI, sem limite de 90m (aceita >100m)
// ---------------------------------------------------------------------
export const CABLE_TYPES = {
  "utp-cat5e": { id: "utp-cat5e", nome: "UTP Cat5e", color: "#4FB3C9", categoria: "nao-blindado", limiteM: 90 },
  "utp-cat6": { id: "utp-cat6", nome: "UTP Cat6", color: "#2AA7C4", categoria: "nao-blindado", limiteM: 90 },
  "futp-cat6": { id: "futp-cat6", nome: "F/UTP Cat6 (blindado)", color: "#1F7FA8", categoria: "blindado", limiteM: 90 },
  "sftp-cat6a": { id: "sftp-cat6a", nome: "S/FTP Cat6a (blindado)", color: "#155C7A", categoria: "blindado", limiteM: 90 },
  "fibra-mm-om4": { id: "fibra-mm-om4", nome: "Fibra MM OM4", color: "#DB932C", categoria: "fibra", limiteM: null },
  "fibra-sm-os2": { id: "fibra-sm-os2", nome: "Fibra SM OS2", color: "#C97A1B", categoria: "fibra", limiteM: null },
};

export const CABLE_ORDER = ["utp-cat5e", "utp-cat6", "futp-cat6", "sftp-cat6a", "fibra-mm-om4", "fibra-sm-os2"];

export function novoId(prefixo) {
  return `${prefixo}_${Date.now().toString(36)}_${Math.floor(Math.random() * 9999)}`;
}
