// ---------------------------------------------------------------------
// buildingFootprint.js — busca o contorno (footprint) de um prédio no
// OpenStreetMap via Overpass API e converte para coordenadas locais em
// metros, prontas para desenhar na cena 3D (scene3d.js → tipo "building").
//
// Sem chave, sem billing — mesma filosofia do resto do módulo de mapa.
// A Overpass API é pública e tem cota generosa para uso pontual como
// este (uma consulta por vez que o usuário gera um cenário 3D).
// ---------------------------------------------------------------------

const OVERPASS_URL = "https://overpass-api.de/api/interpreter";
const RAIO_BUSCA_M = 90;
const OVERPASS_TIMEOUT_MS = 18000;
const OVERPASS_MAX_RESPONSE_BYTES = 5 * 1024 * 1024;
const OVERPASS_MAX_WAYS = 1000;
const OVERPASS_MAX_POINTS_PER_WAY = 10000;

// metros por grau, aproximação equiretangular (suficiente pra escala de
// um único prédio/quarteirão — erro desprezível nessa distância).
export function metrosPorGrau(latCentralGraus) {
  const latRad = (latCentralGraus * Math.PI) / 180;
  return {
    lat: 110574, // ~constante
    lng: 111320 * Math.cos(latRad),
  };
}

export function paraCoordLocal(lat, lng, origem, escala) {
  return {
    x: (lng - origem.lng) * escala.lng,
    z: (origem.lat - lat) * escala.lat, // norte (lat crescente) vira -Z
  };
}

// teste ponto-em-polígono (ray casting), em graus — só usado pra decidir
// QUAL prédio é o certo quando há mais de um perto do ponto buscado.
function pontoDentroPoligono(lat, lng, pontos) {
  let dentro = false;
  for (let i = 0, j = pontos.length - 1; i < pontos.length; j = i++) {
    const xi = pontos[i].lon, yi = pontos[i].lat;
    const xj = pontos[j].lon, yj = pontos[j].lat;
    const intersecta = yi > lat !== yj > lat && lng < ((xj - xi) * (lat - yi)) / (yj - yi) + xi;
    if (intersecta) dentro = !dentro;
  }
  return dentro;
}

function alturaEstimada(tags) {
  if (!tags) return 9;
  if (tags.height) {
    const h = parseFloat(String(tags.height).replace(/[^\d.]/g, ""));
    if (Number.isFinite(h) && h > 0) return h;
  }
  if (tags["building:levels"]) {
    const niveis = parseFloat(tags["building:levels"]);
    if (Number.isFinite(niveis) && niveis > 0) return niveis * 3;
  }
  return 9; // ~3 andares, chute conservador quando o OSM não tem a info
}

/**
 * Busca o prédio mais próximo/mais provável no OSM para o ponto dado.
 * @returns {Promise<{footprint: {x:number,z:number}[], height:number, fonte:string}|null>}
 */
export async function fetchBuildingFootprint(lat, lng) {
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    throw new Error("Coordenadas inválidas para consulta do edifício.");
  }
  const query = `[out:json][timeout:15];(way(around:${RAIO_BUSCA_M},${lat},${lng})["building"];);out geom;`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), OVERPASS_TIMEOUT_MS);
  let resp;
  try {
    resp = await fetch(OVERPASS_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: query,
      signal: controller.signal,
    });
  } catch (err) {
    if (err?.name === "AbortError") {
      throw new Error("A consulta de edifícios excedeu o tempo limite. Tente novamente.");
    }
    throw new Error("Não foi possível consultar os edifícios do OpenStreetMap. Verifique a internet.");
  } finally {
    clearTimeout(timer);
  }

  if (!resp.ok) throw new Error("O serviço de edifícios está temporariamente indisponível. Tente novamente em instantes.");

  const declaredLength = Number(resp.headers.get("content-length") || 0);
  if (Number.isFinite(declaredLength) && declaredLength > OVERPASS_MAX_RESPONSE_BYTES) {
    throw new Error("A resposta do serviço de edifícios excedeu o limite seguro.");
  }

  let data;
  try {
    const raw = await resp.text();
    if (raw.length > OVERPASS_MAX_RESPONSE_BYTES) throw new Error("response-too-large");
    data = JSON.parse(raw);
  } catch (err) {
    if (err?.message === "response-too-large") throw new Error("A resposta do serviço de edifícios excedeu o limite seguro.");
    throw new Error("O serviço de edifícios devolveu uma resposta inválida.");
  }

  const elements = Array.isArray(data?.elements) ? data.elements.slice(0, OVERPASS_MAX_WAYS) : [];
  const ways = elements.filter((el) =>
    el?.type === "way" && Array.isArray(el.geometry) && el.geometry.length >= 3 && el.geometry.length <= OVERPASS_MAX_POINTS_PER_WAY &&
    el.geometry.every((p) => Number.isFinite(p?.lat) && Number.isFinite(p?.lon) && p.lat >= -90 && p.lat <= 90 && p.lon >= -180 && p.lon <= 180)
  );
  if (ways.length === 0) return null;

  // prioriza um prédio cujo contorno realmente contenha o ponto buscado;
  // se nenhum contiver, cai pro mais próximo do centróide
  let escolhido = ways.find((w) => pontoDentroPoligono(lat, lng, w.geometry));
  if (!escolhido) {
    let melhorDist = Infinity;
    for (const w of ways) {
      const cLat = w.geometry.reduce((s, p) => s + p.lat, 0) / w.geometry.length;
      const cLng = w.geometry.reduce((s, p) => s + p.lon, 0) / w.geometry.length;
      const d = Math.hypot(cLat - lat, cLng - lng);
      if (d < melhorDist) {
        melhorDist = d;
        escolhido = w;
      }
    }
  }
  if (!escolhido) return null;

  const escala = metrosPorGrau(lat);
  const origem = { lat, lng };
  const footprint = escolhido.geometry.map((p) => paraCoordLocal(p.lat, p.lon, origem, escala));

  return {
    footprint,
    height: alturaEstimada(escolhido.tags),
    fonte: "OpenStreetMap (Overpass)",
  };
}
