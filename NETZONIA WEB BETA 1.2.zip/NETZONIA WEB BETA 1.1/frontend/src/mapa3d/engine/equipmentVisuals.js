import * as THREE from "three";

function material(color, options = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: options.roughness ?? 0.55,
    metalness: options.metalness ?? 0.2,
    transparent: options.transparent ?? false,
    opacity: options.opacity ?? 1,
    emissive: options.emissive || 0x000000,
    emissiveIntensity: options.emissiveIntensity ?? 1,
  });
}

function mesh(geometry, meshMaterial) {
  const value = new THREE.Mesh(geometry, meshMaterial);
  value.castShadow = true;
  value.receiveShadow = true;
  return value;
}

function genericVisual(spec) {
  const [width, height, depth] = spec.size;
  const group = new THREE.Group();
  const body = mesh(new THREE.BoxGeometry(width, height, depth), material(spec.color));
  group.add(body);
  const edges = new THREE.LineSegments(
    new THREE.EdgesGeometry(body.geometry),
    new THREE.LineBasicMaterial({ color: 0x071916, transparent: true, opacity: 0.35 }),
  );
  group.add(edges);
  return group;
}

function rackVisual(spec) {
  const [width, height, depth] = spec.size;
  const group = new THREE.Group();
  const frameMaterial = material("#232A28", { roughness: 0.42, metalness: 0.58 });
  const railMaterial = material("#63736E", { roughness: 0.35, metalness: 0.7 });
  const postGeometry = new THREE.BoxGeometry(Math.min(0.08, width * 0.07), height, Math.min(0.08, depth * 0.07));
  for (const [xSign, zSign] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
    const post = mesh(postGeometry, frameMaterial);
    post.position.set(xSign * (width / 2 - 0.06), 0, zSign * (depth / 2 - 0.06));
    group.add(post);
  }
  const capGeometry = new THREE.BoxGeometry(width, 0.06, depth);
  for (const y of [-height / 2 + 0.03, height / 2 - 0.03]) {
    const cap = mesh(capGeometry, frameMaterial);
    cap.position.y = y;
    group.add(cap);
  }
  const railGeometry = new THREE.BoxGeometry(0.045, Math.max(0.1, height - 0.14), 0.035);
  for (const xSign of [-1, 1]) {
    const rail = mesh(railGeometry, railMaterial);
    rail.position.set(xSign * (width / 2 - 0.13), 0, depth / 2 - 0.09);
    group.add(rail);
  }
  const shell = mesh(
    new THREE.BoxGeometry(width, height, depth),
    material(spec.color, { roughness: 0.6, metalness: 0.2, transparent: true, opacity: 0.12 }),
  );
  group.add(shell);
  return group;
}

function switchVisual(spec) {
  const [width, height, depth] = spec.size;
  const group = genericVisual(spec);
  const portCount = Math.max(1, spec.ports?.length || 24);
  const rows = portCount > 24 ? 2 : 1;
  const perRow = Math.ceil(portCount / rows);
  const usableWidth = width * 0.88;
  const gap = usableWidth / perRow;
  const portMaterial = material("#080C0B", { roughness: 0.85, metalness: 0.05 });
  for (let index = 0; index < portCount; index += 1) {
    const row = Math.floor(index / perRow);
    const column = index % perRow;
    const port = mesh(
      new THREE.BoxGeometry(Math.max(0.018, gap * 0.62), Math.min(0.06, height * 0.22), 0.025),
      portMaterial,
    );
    port.position.set(-usableWidth / 2 + gap * (column + 0.5), rows === 1 ? 0 : (row === 0 ? height * 0.2 : -height * 0.2), depth / 2 + 0.012);
    group.add(port);
    const active = index % 4 !== 3;
    const led = mesh(
      new THREE.BoxGeometry(Math.max(0.01, gap * 0.28), 0.014, 0.012),
      material("#13201C", active ? { emissive: "#39D98A", emissiveIntensity: 1.8 } : {}),
    );
    led.position.set(port.position.x, port.position.y - Math.min(0.045, height * 0.18), depth / 2 + 0.02);
    group.add(led);
  }
  return group;
}

function routerVisual(spec) {
  const [width, height, depth] = spec.size;
  const group = genericVisual(spec);
  const antennaMaterial = material("#15181A", { roughness: 0.4, metalness: 0.5 });
  const antennaHeight = Math.max(0.18, height * 0.9);
  for (const [xSign, zSign] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const antenna = mesh(new THREE.CylinderGeometry(0.025, 0.025, antennaHeight, 10), antennaMaterial);
    antenna.position.set(xSign * (width / 2 - 0.1), height / 2 + antennaHeight / 2, zSign * (depth / 2 - 0.1));
    antenna.rotation.z = xSign * -0.14;
    group.add(antenna);
  }
  const led = mesh(
    new THREE.BoxGeometry(0.08, 0.025, 0.018),
    material("#10201B", { emissive: "#39D98A", emissiveIntensity: 1.6 }),
  );
  led.position.set(0, height * 0.2, depth / 2 + 0.012);
  group.add(led);
  return group;
}

function accessPointVisual(spec) {
  const [width, height, depth] = spec.size;
  const group = new THREE.Group();
  const radius = Math.max(width, depth) / 2;
  const puck = mesh(new THREE.CylinderGeometry(radius, radius * 0.94, height, 36), material(spec.color, { roughness: 0.34, metalness: 0.08 }));
  group.add(puck);
  const ring = mesh(
    new THREE.TorusGeometry(radius * 0.58, Math.max(0.012, radius * 0.045), 10, 36),
    material("#DFFFF8", { emissive: "#22D3C5", emissiveIntensity: 0.75 }),
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = -height / 2 - 0.008;
  group.add(ring);
  return group;
}

const BUILDERS = {
  rack: rackVisual,
  switch: switchVisual,
  router: routerVisual,
  "access-point": accessPointVisual,
};

/** Cria apenas a representação visual. IDs, portas e instalação permanecem no modelo lógico. */
export function createEquipmentVisual(spec) {
  return (BUILDERS[spec.visual] || genericVisual)(spec);
}

