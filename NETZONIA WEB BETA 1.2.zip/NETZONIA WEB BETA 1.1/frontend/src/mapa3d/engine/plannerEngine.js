import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { catalogItem } from "../equipmentCatalog.js";
import { CABLE_TYPES } from "../networkValidator.js";
import { constrainAllEntities, constrainEntityToInstallation, syncRackEquipment } from "../installationConstraints.js";
import { loadEquipmentModelOrFallback } from "../modelLoader.js";
import { createEquipmentVisual } from "./equipmentVisuals.js";

export class PlannerEngine {
  constructor(container, state, { onSelect = () => {}, onTransform = () => {} } = {}) {
    this.container = container;
    this.state = state;
    this.onSelect = onSelect;
    this.onTransform = onTransform;
    this.objects = new Map();
    this.selectedId = null;
    this.disposed = false;
    this.environmentSignature = "";
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color("#102922");
    this.scene.fog = new THREE.Fog("#102922", 35, 80);

    const { width, height } = container.getBoundingClientRect();
    this.camera = new THREE.PerspectiveCamera(50, width / Math.max(height, 1), 0.1, 300);
    this.camera.position.set(16, 14, 18);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.className = "mapa3d-canvas";
    container.append(this.renderer.domElement);

    this.orbit = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbit.enableDamping = true;
    this.orbit.target.set(0, 1.2, 0);
    this.orbit.maxPolarAngle = Math.PI / 2.02;
    this.orbit.minDistance = 3;
    this.orbit.maxDistance = 80;

    this.transform = new TransformControls(this.camera, this.renderer.domElement);
    this.scene.add(this.transform.getHelper());
    this.transform.addEventListener("dragging-changed", (event) => { this.orbit.enabled = !event.value; });
    this.transform.addEventListener("objectChange", () => this.#captureTransform());

    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.boundPointer = (event) => this.#handlePointer(event);
    this.renderer.domElement.addEventListener("pointerdown", this.boundPointer);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.#setupLighting();
    this.#setupEnvironment();
    this.rebuild(state);
    this.renderer.setAnimationLoop(() => {
      this.orbit.update();
      this.renderer.render(this.scene, this.camera);
    });
  }

  #setupLighting() {
    this.scene.add(new THREE.HemisphereLight(0xd9fff5, 0x17342c, 2.2));
    const sun = new THREE.DirectionalLight(0xffffff, 2.8);
    sun.position.set(10, 18, 8);
    sun.castShadow = true;
    this.scene.add(sun);
  }

  #setupEnvironment() {
    if (this.environmentGroup) {
      this.scene.remove(this.environmentGroup);
      this.#disposeObject(this.environmentGroup);
    }
    this.environmentGroup = new THREE.Group();
    this.environmentGroup.name = "environment";

    const { width, depth, height } = this.state.environment;
    this.environmentSignature = `${width}:${depth}:${height}`;
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(width, depth),
      new THREE.MeshStandardMaterial({ color: 0x315a4b, roughness: 0.88, metalness: 0.05 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    floor.name = "floor";
    floor.userData.surfaceId = "floor";
    this.environmentGroup.add(floor);
    this.environmentGroup.add(new THREE.GridHelper(Math.max(width, depth), Math.max(width, depth), 0x22d3c5, 0x3c6a5a));

    const makeWall = (surfaceId, wallWidth, position, rotationY = 0) => {
      const material = new THREE.MeshStandardMaterial({
        color: 0xdceae5, transparent: true, opacity: 0.13, depthWrite: false, side: THREE.DoubleSide,
      });
      const wall = new THREE.Mesh(new THREE.PlaneGeometry(wallWidth, height), material);
      wall.position.copy(position); wall.rotation.y = rotationY; wall.name = surfaceId; wall.userData.surfaceId = surfaceId;
      this.environmentGroup.add(wall);
    };
    makeWall("wall-north", width, new THREE.Vector3(0, height / 2, -depth / 2));
    makeWall("wall-south", width, new THREE.Vector3(0, height / 2, depth / 2), Math.PI);
    makeWall("wall-west", depth, new THREE.Vector3(-width / 2, height / 2, 0), Math.PI / 2);
    makeWall("wall-east", depth, new THREE.Vector3(width / 2, height / 2, 0), -Math.PI / 2);
    const ceiling = new THREE.Mesh(
      new THREE.PlaneGeometry(width, depth),
      new THREE.MeshStandardMaterial({ color: 0xdceae5, transparent: true, opacity: 0.06, depthWrite: false, side: THREE.DoubleSide }),
    );
    ceiling.rotation.x = Math.PI / 2; ceiling.position.y = height; ceiling.name = "ceiling"; ceiling.userData.surfaceId = "ceiling";
    this.environmentGroup.add(ceiling);
    this.scene.add(this.environmentGroup);
  }

  rebuild(state = this.state) {
    this.state = state;
    constrainAllEntities(this.state);
    const environmentSignature = `${state.environment.width}:${state.environment.depth}:${state.environment.height}`;
    if (environmentSignature !== this.environmentSignature) this.#setupEnvironment();
    this.transform.detach();
    for (const object of this.objects.values()) {
      this.scene.remove(object);
      this.#disposeObject(object);
    }
    this.objects.clear();
    for (const rack of state.racks) this.#addEntity(rack, true);
    for (const equipment of state.equipment) this.#addEntity(equipment, false);
    for (const zone of state.zones) this.#addZone(zone);
    for (const cable of state.cables) this.#addCable(cable);
    if (this.selectedId && this.objects.has(this.selectedId)) this.select(this.selectedId);
    else if (this.selectedId) this.select(null);
  }

  #addEntity(entity, rack) {
    const spec = catalogItem(entity.type);
    const group = new THREE.Group();
    group.userData.entityId = entity.id;
    const visual = createEquipmentVisual(spec);
    visual.traverse((child) => { child.userData.entityId = entity.id; });
    group.add(visual);
    if (!rack) {
      const labelCanvas = document.createElement("canvas");
      labelCanvas.width = 320; labelCanvas.height = 64;
      const ctx = labelCanvas.getContext("2d");
      ctx.fillStyle = "rgba(7,25,22,.82)"; ctx.fillRect(0, 0, 320, 64);
      ctx.fillStyle = "#e6f5f1"; ctx.font = "26px sans-serif"; ctx.textAlign = "center"; ctx.fillText(entity.name, 160, 41);
      const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(labelCanvas), transparent: true }));
      label.scale.set(2.8, 0.56, 1); label.position.y = spec.size[1] / 2 + 0.48; label.userData.entityId = entity.id; group.add(label);
    }
    const p = entity.transform.position; const r = entity.transform.rotation;
    group.position.set(p.x, p.y, p.z);
    group.rotation.set(r.x || 0, r.y || 0, r.z || 0);
    this.scene.add(group); this.objects.set(entity.id, group);
    if (spec.model?.url) void this.#tryLoadModel(entity.id, group, visual, spec);
  }

  async #tryLoadModel(entityId, group, placeholder, spec) {
    try {
      const result = await loadEquipmentModelOrFallback(spec.model.url, placeholder);
      if (!result.loaded) return;
      const model = result.object;
      if (this.disposed || this.objects.get(entityId) !== group) {
        this.#disposeObject(model);
        return;
      }
      const box = new THREE.Box3().setFromObject(model);
      const size = box.getSize(new THREE.Vector3());
      if (size.x > 0 && size.y > 0 && size.z > 0) {
        const fit = Math.min(spec.size[0] / size.x, spec.size[1] / size.y, spec.size[2] / size.z);
        model.scale.multiplyScalar(fit * (spec.model.scale || 1));
        const fitted = new THREE.Box3().setFromObject(model);
        model.position.sub(fitted.getCenter(new THREE.Vector3()));
      }
      model.rotation.set(...(spec.model.rotation || [0, 0, 0]));
      model.traverse((child) => { child.userData.entityId = entityId; child.castShadow = true; child.receiveShadow = true; });
      group.remove(placeholder); this.#disposeObject(placeholder); group.add(model);
    } catch {
      // O placeholder permanece ativo quando o GLB estiver ausente ou inválido.
    }
  }

  #addCable(cable) {
    const origin = this.objects.get(cable.originEquipmentId);
    const destination = this.objects.get(cable.destinationEquipmentId);
    if (!origin || !destination) return;
    const middleY = Math.max(origin.position.y, destination.position.y) + 0.35;
    const points = [
      origin.position.clone(),
      new THREE.Vector3(origin.position.x, middleY, origin.position.z),
      new THREE.Vector3(destination.position.x, middleY, destination.position.z),
      destination.position.clone(),
    ];
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({ color: CABLE_TYPES[cable.type]?.color || "#22D3C5", linewidth: 2 });
    const line = new THREE.Line(geometry, material);
    line.userData.cableId = cable.id;
    this.scene.add(line); this.objects.set(`cable:${cable.id}`, line);
  }

  #addZone(zone) {
    const geometry = new THREE.CylinderGeometry(zone.radius || 2, zone.radius || 2, 0.08, 36);
    const material = new THREE.MeshBasicMaterial({ color: 0xe1685b, transparent: true, opacity: 0.34 });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(zone.position?.x || 0, 0.05, zone.position?.z || 0);
    this.scene.add(mesh);
    this.objects.set(`zone:${zone.id}`, mesh);
  }

  refreshCables() {
    for (const [key, object] of this.objects) {
      if (!key.startsWith("cable:")) continue;
      this.scene.remove(object); object.geometry?.dispose?.(); object.material?.dispose?.(); this.objects.delete(key);
    }
    for (const cable of this.state.cables) this.#addCable(cable);
  }

  #handlePointer(event) {
    if (this.transform.dragging) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hit = this.raycaster.intersectObjects([...this.objects.values()].filter((o) => !o.userData.cableId), true)
      .find((entry) => entry.object.userData.entityId || entry.object.parent?.userData.entityId);
    this.select(hit ? (hit.object.userData.entityId || hit.object.parent.userData.entityId) : null);
  }

  select(id) {
    this.selectedId = id;
    this.transform.detach();
    const object = id ? this.objects.get(id) : null;
    if (object) this.transform.attach(object);
    this.onSelect(id);
  }

  setTransformMode(mode) { this.transform.setMode(mode === "rotate" ? "rotate" : "translate"); }

  #captureTransform() {
    const entity = [...this.state.equipment, ...this.state.racks].find((item) => item.id === this.selectedId);
    const object = this.objects.get(this.selectedId);
    if (!entity || !object) return;
    entity.transform.position = { x: object.position.x, y: object.position.y, z: object.position.z };
    entity.transform.rotation = { x: object.rotation.x, y: object.rotation.y, z: object.rotation.z };
    constrainEntityToInstallation(this.state, entity);
    if (entity.slots) syncRackEquipment(this.state, entity.id);
    const affected = entity.slots
      ? [entity, ...this.state.equipment.filter((item) => item.installation?.rackId === entity.id)]
      : [entity];
    for (const item of affected) {
      const target = this.objects.get(item.id);
      if (!target) continue;
      target.position.set(item.transform.position.x, item.transform.position.y, item.transform.position.z);
      target.rotation.set(item.transform.rotation.x, item.transform.rotation.y, item.transform.rotation.z);
    }
    this.onTransform(entity);
  }

  resize() {
    const { width, height } = this.container.getBoundingClientRect();
    if (!width || !height) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.resizeObserver.disconnect();
    this.renderer.domElement.removeEventListener("pointerdown", this.boundPointer);
    this.transform.dispose(); this.orbit.dispose();
    this.#disposeObject(this.scene);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  #disposeObject(object) {
    object?.traverse?.((child) => {
      child.geometry?.dispose?.();
      const materials = Array.isArray(child.material) ? child.material : child.material ? [child.material] : [];
      for (const material of materials) {
        material.map?.dispose?.();
        material.dispose?.();
      }
    });
  }
}
