import { catalogItem } from "./equipmentCatalog.js";

export const WALL_SURFACES = ["wall-north", "wall-south", "wall-west", "wall-east"];

const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clamp = (value, min, max) => Math.max(min, Math.min(max, finite(value, min)));

export function defaultSurfaceFor(type) {
  if (type === "floor") return "floor";
  if (type === "ceiling") return "ceiling";
  if (type === "wall") return "wall-west";
  return null;
}

function ensureTransform(entity) {
  entity.transform ||= {};
  entity.transform.position ||= { x: 0, y: 0, z: 0 };
  entity.transform.rotation ||= { x: 0, y: 0, z: 0 };
  entity.transform.scale ||= { x: 1, y: 1, z: 1 };
  return entity.transform;
}

function clampToRoom(position, spec, environment) {
  const halfWidth = environment.width / 2;
  const halfDepth = environment.depth / 2;
  position.x = clamp(position.x, -halfWidth + spec.size[0] / 2, halfWidth - spec.size[0] / 2);
  position.z = clamp(position.z, -halfDepth + spec.size[2] / 2, halfDepth - spec.size[2] / 2);
}

export function constrainEntityToInstallation(state, entity) {
  const spec = catalogItem(entity.type);
  const transform = ensureTransform(entity);
  const position = {
    x: finite(transform.position.x), y: finite(transform.position.y), z: finite(transform.position.z),
  };
  const rotation = {
    x: finite(transform.rotation.x), y: finite(transform.rotation.y), z: finite(transform.rotation.z),
  };
  const environment = state.environment;
  entity.installation ||= { type: spec.mounting, surfaceId: defaultSurfaceFor(spec.mounting), rackId: null, rackU: null };

  if (spec.kind === "rack") {
    entity.installation = { type: "floor", surfaceId: "floor", rackId: null, rackU: null };
  }

  if (entity.installation.type === "rack") {
    const rack = state.racks.find((candidate) => candidate.id === entity.installation.rackId);
    const slot = rack?.slots?.find((candidate) => candidate.equipmentId === entity.id);
    if (rack && slot) {
      const rackSpec = catalogItem(rack.type);
      const bottom = rack.transform.position.y - rackSpec.size[1] / 2;
      const pitch = rackSpec.size[1] / rack.units;
      const equipmentUnits = slot.endU - slot.startU + 1;
      position.x = rack.transform.position.x;
      position.y = bottom + (slot.startU - 1 + equipmentUnits / 2) * pitch;
      position.z = rack.transform.position.z;
      rotation.x = 0; rotation.y = finite(rack.transform.rotation?.y); rotation.z = 0;
      entity.installation.surfaceId = null;
      entity.installation.rackU = slot.startU;
    } else {
      entity.installation = { type: "floor", surfaceId: "floor", rackId: null, rackU: null };
    }
  }

  if (entity.installation.type === "floor") {
    clampToRoom(position, spec, environment);
    position.y = spec.size[1] / 2;
    rotation.x = 0; rotation.z = 0;
    entity.installation.surfaceId = "floor";
    entity.installation.rackId = null; entity.installation.rackU = null;
  } else if (entity.installation.type === "ceiling") {
    clampToRoom(position, spec, environment);
    position.y = Math.max(spec.size[1] / 2, environment.height - spec.size[1] / 2);
    rotation.x = 0; rotation.z = 0;
    entity.installation.surfaceId = "ceiling";
    entity.installation.rackId = null; entity.installation.rackU = null;
  } else if (entity.installation.type === "wall") {
    const surfaceId = WALL_SURFACES.includes(entity.installation.surfaceId) ? entity.installation.surfaceId : "wall-west";
    const halfWidth = environment.width / 2;
    const halfDepth = environment.depth / 2;
    const horizontalHalf = spec.size[0] / 2;
    const normalHalf = spec.size[2] / 2;
    position.y = clamp(position.y, spec.size[1] / 2, Math.max(spec.size[1] / 2, environment.height - spec.size[1] / 2));
    if (surfaceId === "wall-north" || surfaceId === "wall-south") {
      position.x = clamp(position.x, -halfWidth + horizontalHalf, halfWidth - horizontalHalf);
      position.z = surfaceId === "wall-north" ? -halfDepth + normalHalf : halfDepth - normalHalf;
      rotation.y = surfaceId === "wall-north" ? 0 : Math.PI;
    } else {
      position.x = surfaceId === "wall-west" ? -halfWidth + normalHalf : halfWidth - normalHalf;
      position.z = clamp(position.z, -halfDepth + horizontalHalf, halfDepth - horizontalHalf);
      rotation.y = surfaceId === "wall-west" ? Math.PI / 2 : -Math.PI / 2;
    }
    rotation.x = 0; rotation.z = 0;
    entity.installation.surfaceId = surfaceId;
    entity.installation.rackId = null; entity.installation.rackU = null;
  }

  transform.position = position;
  transform.rotation = rotation;
  transform.scale = {
    x: Math.max(0.1, finite(transform.scale.x, 1)),
    y: Math.max(0.1, finite(transform.scale.y, 1)),
    z: Math.max(0.1, finite(transform.scale.z, 1)),
  };
  return entity;
}

export function syncRackEquipment(state, rackId = null) {
  for (const equipment of state.equipment) {
    if (equipment.installation?.type !== "rack") continue;
    if (rackId && equipment.installation.rackId !== rackId) continue;
    constrainEntityToInstallation(state, equipment);
  }
}

export function constrainAllEntities(state) {
  for (const rack of state.racks) constrainEntityToInstallation(state, rack);
  syncRackEquipment(state);
  for (const equipment of state.equipment) {
    if (equipment.installation?.type !== "rack") constrainEntityToInstallation(state, equipment);
  }
  return state;
}
