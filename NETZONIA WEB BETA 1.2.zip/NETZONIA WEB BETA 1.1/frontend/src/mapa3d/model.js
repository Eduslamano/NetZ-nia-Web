import { catalogItem } from "./equipmentCatalog.js";
import { defaultSurfaceFor } from "./installationConstraints.js";

export const PLANNER_SCHEMA_VERSION = 2;
export function createEmptyPlannerState() {
  return {
    schemaVersion: PLANNER_SCHEMA_VERSION,
    environment: { width: 24, depth: 18, height: 3, grid: 1 },
    equipment: [],
    racks: [],
    cables: [],
    zones: [],
  };
}

export function createEntity(type, position = { x: 0, y: 0, z: 0 }) {
  const item = catalogItem(type);
  const base = {
    id: crypto.randomUUID(), type, name: item.name,
    transform: { position: { ...position }, rotation: { x: 0, y: 0, z: 0 }, scale: { x: 1, y: 1, z: 1 } },
    installation: { type: item.mounting, surfaceId: defaultSurfaceFor(item.mounting), rackId: null, rackU: null },
    ports: structuredClone(item.ports || []),
  };
  if (item.kind === "rack") return { ...base, units: item.rackUnits, slots: [] };
  return base;
}

export function findEntity(state, id) {
  return [...state.equipment, ...state.racks].find((entity) => entity.id === id) || null;
}

export function removeEntity(state, id) {
  const removedIds = new Set([id, ...state.equipment.filter((entity) => entity.installation?.rackId === id).map((entity) => entity.id)]);
  state.equipment = state.equipment.filter((entity) => !removedIds.has(entity.id));
  state.racks = state.racks.filter((rack) => rack.id !== id);
  state.cables = state.cables.filter((cable) => !removedIds.has(cable.originEquipmentId) && !removedIds.has(cable.destinationEquipmentId));
  for (const rack of state.racks) rack.slots = rack.slots.filter((slot) => slot.equipmentId !== id);
  rebuildPortOccupancy(state);
}

export function rebuildPortOccupancy(state) {
  for (const entity of state.equipment) for (const port of entity.ports || []) port.occupiedBy = null;
  for (const cable of state.cables) {
    const origin = findEntity(state, cable.originEquipmentId);
    const destination = findEntity(state, cable.destinationEquipmentId);
    const originPort = origin?.ports?.find((p) => p.id === cable.originPortId);
    const destinationPort = destination?.ports?.find((p) => p.id === cable.destinationPortId);
    if (originPort) originPort.occupiedBy = cable.id;
    if (destinationPort) destinationPort.occupiedBy = cable.id;
  }
}
