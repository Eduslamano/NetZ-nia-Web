import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

const loader = new GLTFLoader();

/** Carrega o asset final quando existir; o chamador mantém o placeholder se falhar. */
export function loadEquipmentModel(url) {
  return new Promise((resolve, reject) => {
    loader.load(url, (gltf) => resolve(gltf.scene), undefined, (error) => reject(new Error(`Falha ao carregar modelo GLB: ${error.message}`)));
  });
}

/** Mantém o visual procedural quando o asset final estiver ausente ou falhar. */
export async function loadEquipmentModelOrFallback(url, fallback, load = loadEquipmentModel) {
  if (!url) return { object: fallback, loaded: false };
  try {
    return { object: await load(url), loaded: true };
  } catch {
    return { object: fallback, loaded: false };
  }
}
