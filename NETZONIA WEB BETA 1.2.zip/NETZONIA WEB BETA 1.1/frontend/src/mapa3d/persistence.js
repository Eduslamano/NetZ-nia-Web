import { createEmptyPlannerState, PLANNER_SCHEMA_VERSION, rebuildPortOccupancy } from "./model.js";
import { EQUIPMENT_CATALOG } from "./equipmentCatalog.js";
import { constrainAllEntities, defaultSurfaceFor } from "./installationConstraints.js";
import { CABLE_TYPES, validateCablePath } from "./networkValidator.js";
import { installInRackAt } from "./rackManager.js";

const MAX_ENTITIES = 500;
const MAX_CABLES = 1000;
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const identifier = (value) => typeof value === "string" && value.length > 0 && value.length <= 120 ? value : crypto.randomUUID();

function normalizeEntity(raw, expectedKind, usedIds) {
  const spec = EQUIPMENT_CATALOG[raw?.type];
  if (!spec || spec.kind !== expectedKind) return null;
  let id = identifier(raw.id);
  if (usedIds.has(id)) id = crypto.randomUUID();
  usedIds.add(id);
  const allowedInstallations = new Set(["floor", "wall", "ceiling", "rack"]);
  const type = allowedInstallations.has(raw.installation?.type) ? raw.installation.type : spec.mounting;
  const entity = {
    id,
    type: spec.id,
    name: String(raw.name || spec.name).trim().slice(0, 80) || spec.name,
    transform: {
      position: {
        x: finite(raw.transform?.position?.x),
        y: finite(raw.transform?.position?.y),
        z: finite(raw.transform?.position?.z),
      },
      rotation: {
        x: finite(raw.transform?.rotation?.x),
        y: finite(raw.transform?.rotation?.y),
        z: finite(raw.transform?.rotation?.z),
      },
      scale: {
        x: finite(raw.transform?.scale?.x, 1),
        y: finite(raw.transform?.scale?.y, 1),
        z: finite(raw.transform?.scale?.z, 1),
      },
    },
    installation: {
      type,
      surfaceId: raw.installation?.surfaceId || defaultSurfaceFor(type),
      rackId: raw.installation?.rackId || null,
      rackU: Number.isInteger(Number(raw.installation?.rackU)) ? Number(raw.installation.rackU) : null,
    },
    ports: structuredClone(spec.ports || []).map((port) => ({ ...port, occupiedBy: null })),
  };
  if (expectedKind === "rack") {
    entity.units = spec.rackUnits;
    entity.slots = [];
  }
  return entity;
}

function normalizeZone(raw, usedIds, environment) {
  if (!raw || typeof raw !== "object") return null;
  let id = identifier(raw.id);
  if (usedIds.has(id)) id = crypto.randomUUID();
  usedIds.add(id);
  return {
    id,
    name: String(raw.name || "Zona EMI").trim().slice(0, 80) || "Zona EMI",
    position: {
      x: Math.max(-environment.width / 2, Math.min(environment.width / 2, finite(raw.position?.x))),
      y: 0,
      z: Math.max(-environment.depth / 2, Math.min(environment.depth / 2, finite(raw.position?.z))),
    },
    radius: Math.max(0.2, Math.min(50, finite(raw.radius, 2))),
  };
}

export function serializePlanner(state) {
  return JSON.parse(JSON.stringify({ ...state, schemaVersion: PLANNER_SCHEMA_VERSION }));
}

export function restorePlanner(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return createEmptyPlannerState();
  const base = createEmptyPlannerState();
  const state = {
    ...base,
    environment: {
      width: Math.min(200, Math.max(4, finite(raw.environment?.width, base.environment.width))),
      depth: Math.min(200, Math.max(4, finite(raw.environment?.depth, base.environment.depth))),
      height: Math.min(20, Math.max(2, finite(raw.environment?.height, base.environment.height))),
      grid: 1,
    },
    equipment: [], racks: [], cables: [], zones: [],
  };
  const entityIds = new Set();
  state.racks = (Array.isArray(raw.racks) ? raw.racks : []).slice(0, MAX_ENTITIES)
    .map((entity) => normalizeEntity(entity, "rack", entityIds)).filter(Boolean);
  const requiredHeight = state.racks.reduce((height, rack) => Math.max(height, EQUIPMENT_CATALOG[rack.type].size[1] + 0.2), state.environment.height);
  state.environment.height = Math.min(20, requiredHeight);
  state.equipment = (Array.isArray(raw.equipment) ? raw.equipment : []).slice(0, MAX_ENTITIES)
    .map((entity) => normalizeEntity(entity, "equipment", entityIds)).filter(Boolean);

  for (const equipment of state.equipment) {
    if (equipment.installation.type !== "rack") continue;
    const rack = state.racks.find((candidate) => candidate.id === equipment.installation.rackId);
    if (!rack || !installInRackAt(state, rack, equipment, equipment.installation.rackU)) {
      equipment.installation = { type: "floor", surfaceId: "floor", rackId: null, rackU: null };
    }
  }
  constrainAllEntities(state);

  const zoneIds = new Set();
  state.zones = (Array.isArray(raw.zones) ? raw.zones : []).slice(0, 100)
    .map((zone) => normalizeZone(zone, zoneIds, state.environment)).filter(Boolean);

  const cableIds = new Set();
  for (const rawCable of (Array.isArray(raw.cables) ? raw.cables : []).slice(0, MAX_CABLES)) {
    const origin = state.equipment.find((entity) => entity.id === rawCable?.originEquipmentId);
    const destination = state.equipment.find((entity) => entity.id === rawCable?.destinationEquipmentId);
    if (!origin || !destination || origin.id === destination.id || !CABLE_TYPES[rawCable?.type]) continue;
    const originPort = origin.ports.find((port) => port.id === rawCable.originPortId && !port.occupiedBy);
    const destinationPort = destination.ports.find((port) => port.id === rawCable.destinationPortId && !port.occupiedBy);
    if (!originPort || !destinationPort) continue;
    let id = identifier(rawCable.id);
    if (cableIds.has(id)) id = crypto.randomUUID();
    cableIds.add(id);
    const validation = validateCablePath(origin, destination, rawCable.type, state.zones);
    const cable = {
      id,
      originEquipmentId: origin.id,
      originPortId: originPort.id,
      destinationEquipmentId: destination.id,
      destinationPortId: destinationPort.id,
      type: rawCable.type,
      length: validation.length,
      validation,
    };
    originPort.occupiedBy = id;
    destinationPort.occupiedBy = id;
    state.cables.push(cable);
  }
  rebuildPortOccupancy(state);
  return state;
}
