const ports = (prefix, count, type = "RJ45") => Array.from({ length: count }, (_, i) => ({
  id: `${prefix}${i + 1}`, name: `${prefix}${i + 1}`, type, occupiedBy: null,
}));

const equipment = (definition) => ({
  kind: "equipment",
  visual: "box",
  model: { url: null, scale: 1, rotation: [0, 0, 0] },
  ...definition,
});

const rack = (definition) => ({
  kind: "rack",
  visual: "rack",
  model: { url: null, scale: 1, rotation: [0, 0, 0] },
  ...definition,
});

export const EQUIPMENT_CATALOG = {
  router: equipment({ id: "router", name: "Roteador", visual: "router", color: "#1F7FA8", size: [1.4, 0.35, 0.9], mounting: "floor", ports: [...ports("LAN", 4), { id: "WAN", name: "WAN", type: "RJ45", occupiedBy: null }] }),
  switch24: equipment({ id: "switch24", name: "Switch 24 portas", visual: "switch", color: "#187266", size: [1.6, 0.25, 0.8], mounting: "rack", rackU: 1, ports: ports("LAN", 24) }),
  onu: equipment({ id: "onu", name: "ONU/ONT", color: "#8A6D1B", size: [0.8, 0.25, 0.55], mounting: "wall", ports: [{ id: "PON", name: "PON", type: "PON", occupiedBy: null }, ...ports("LAN", 4)] }),
  accessPoint: equipment({ id: "accessPoint", name: "Access Point", visual: "access-point", color: "#E4E9EA", size: [0.8, 0.16, 0.8], mounting: "ceiling", ports: [{ id: "LAN1", name: "LAN1", type: "RJ45", occupiedBy: null }] }),
  server: equipment({ id: "server", name: "Servidor 2U", color: "#3D4A54", size: [1.6, 0.45, 1.1], mounting: "rack", rackU: 2, ports: [...ports("LAN", 4), ...ports("SFP", 2, "SFP")] }),
  camera: equipment({ id: "camera", name: "Câmera IP", color: "#C5CDD0", size: [0.55, 0.42, 0.55], mounting: "wall", ports: [{ id: "LAN1", name: "LAN1", type: "RJ45", occupiedBy: null }] }),
  ups: equipment({ id: "ups", name: "Nobreak", color: "#343B40", size: [0.8, 1.1, 0.8], mounting: "floor", ports: [] }),
  rack24: rack({ id: "rack24", name: "Rack 24U", color: "#26313A", size: [1.8, 3.6, 1.8], mounting: "floor", rackUnits: 24, ports: [] }),
  rack42: rack({ id: "rack42", name: "Rack 42U", color: "#1C252B", size: [1.8, 5.5, 2.0], mounting: "floor", rackUnits: 42, ports: [] }),
};

export function catalogItem(type) {
  const item = EQUIPMENT_CATALOG[type];
  if (!item) throw new Error(`Tipo de equipamento desconhecido: ${type}`);
  return item;
}

export function availablePort(entity) {
  return entity.ports?.find((port) => !port.occupiedBy) || null;
}
