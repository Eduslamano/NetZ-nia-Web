import { catalogItem } from "./equipmentCatalog.js";
import { constrainEntityToInstallation } from "./installationConstraints.js";

export function findFreeRackU(rack, units = 1) {
  for (let start = 1; start <= rack.units - units + 1; start += 1) {
    const end = start + units - 1;
    if (!(rack.slots || []).some((slot) => start <= slot.endU && end >= slot.startU)) return start;
  }
  return null;
}

export function installInRack(rack, equipment) {
  rack.slots = (rack.slots || []).filter((slot) => slot.equipmentId !== equipment.id);
  const units = catalogItem(equipment.type).rackU || 1;
  const startU = findFreeRackU(rack, units);
  if (startU === null) throw new Error(`${rack.name} não possui ${units}U livres contíguas.`);
  const slot = { equipmentId: equipment.id, startU, endU: startU + units - 1 };
  rack.slots.push(slot);
  equipment.installation = { type: "rack", surfaceId: null, rackId: rack.id, rackU: startU };
  return slot;
}

export function removeFromRack(racks, equipment) {
  for (const rack of racks) rack.slots = (rack.slots || []).filter((slot) => slot.equipmentId !== equipment.id);
  equipment.installation = { type: "floor", surfaceId: "floor", rackId: null, rackU: null };
}

export function installInRackAt(state, rack, equipment, requestedU) {
  rack.slots = (rack.slots || []).filter((slot) => slot.equipmentId !== equipment.id);
  const units = catalogItem(equipment.type).rackU || 1;
  const startU = Number(requestedU);
  const endU = startU + units - 1;
  const conflict = !Number.isInteger(startU) || startU < 1 || endU > rack.units ||
    rack.slots.some((slot) => startU <= slot.endU && endU >= slot.startU);
  if (conflict) return null;
  const slot = { equipmentId: equipment.id, startU, endU };
  rack.slots.push(slot);
  equipment.installation = { type: "rack", surfaceId: null, rackId: rack.id, rackU: startU };
  constrainEntityToInstallation(state, equipment);
  return slot;
}

export function validateRack(rack) {
  const slots = [...(rack.slots || [])].sort((a, b) => a.startU - b.startU);
  const errors = [];
  for (let i = 0; i < slots.length; i += 1) {
    if (slots[i].startU < 1 || slots[i].endU > rack.units) errors.push("Equipamento fora dos limites do rack.");
    if (i && slots[i].startU <= slots[i - 1].endU) errors.push("Sobreposição de equipamentos no rack.");
  }
  return errors;
}
