import { availablePort } from "./equipmentCatalog.js";
import { findEntity } from "./model.js";

export const CABLE_TYPES = {
  "copper-unshielded": { name: "Cobre U/UTP", color: "#22D3C5", limit: 90, shielded: false, fiber: false },
  "copper-shielded": { name: "Cobre blindado", color: "#DB932C", limit: 90, shielded: true, fiber: false },
  fiber: { name: "Fibra óptica", color: "#8065B0", limit: 0, shielded: true, fiber: true },
};

function segmentDistanceXZ(point, a, b) {
  const vx = b.x - a.x; const vz = b.z - a.z;
  const lengthSq = vx * vx + vz * vz;
  if (!lengthSq) return Math.hypot(point.x - a.x, point.z - a.z);
  const t = Math.max(0, Math.min(1, ((point.x - a.x) * vx + (point.z - a.z) * vz) / lengthSq));
  return Math.hypot(point.x - (a.x + t * vx), point.z - (a.z + t * vz));
}

export function validateCablePath(origin, destination, type, zones = []) {
  const spec = CABLE_TYPES[type];
  if (!spec) throw new Error("Tipo de cabo inválido.");
  const a = origin.transform.position; const b = destination.transform.position;
  const length = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z);
  const crossedZones = spec.fiber ? [] : zones.filter((zone) => segmentDistanceXZ(zone.position, a, b) <= (zone.radius || 1.5));
  const exceedsLimit = !!spec.limit && length > spec.limit;
  return {
    length: Number(length.toFixed(2)), limit: spec.limit, exceedsLimit,
    emi: crossedZones.length > 0, emiMitigated: crossedZones.length > 0 && spec.shielded,
    valid: !exceedsLimit && (crossedZones.length === 0 || spec.shielded),
    warnings: [
      ...(exceedsLimit ? [`Comprimento de ${length.toFixed(1)} m excede o limite de ${spec.limit} m.`] : []),
      ...(crossedZones.length ? [spec.shielded ? "Trajeto cruza zona EMI; blindagem atenua o risco e exige aterramento correto." : "Trajeto cruza zona EMI; use fibra ou cabo blindado."] : []),
    ],
  };
}

export function createCable(state, originId, destinationId, type = "copper-unshielded", originPortId = null, destinationPortId = null) {
  if (originId === destinationId) throw new Error("Origem e destino devem ser diferentes.");
  const origin = findEntity(state, originId); const destination = findEntity(state, destinationId);
  if (!origin || !destination || state.racks.some((rack) => rack.id === originId || rack.id === destinationId)) {
    throw new Error("Origem e destino precisam ser equipamentos de rede, não racks.");
  }
  const originPort = originPortId ? origin.ports?.find((port) => port.id === originPortId) : availablePort(origin);
  const destinationPort = destinationPortId ? destination.ports?.find((port) => port.id === destinationPortId) : availablePort(destination);
  if (!originPort || !destinationPort) throw new Error("Selecione portas válidas para origem e destino.");
  if (originPort.occupiedBy || destinationPort.occupiedBy) throw new Error("Uma das portas selecionadas já está ocupada.");
  const validation = validateCablePath(origin, destination, type, state.zones);
  const cable = {
    id: crypto.randomUUID(), originEquipmentId: origin.id, originPortId: originPort.id,
    destinationEquipmentId: destination.id, destinationPortId: destinationPort.id,
    type, length: validation.length, validation,
  };
  originPort.occupiedBy = cable.id; destinationPort.occupiedBy = cable.id;
  state.cables.push(cable);
  return cable;
}
