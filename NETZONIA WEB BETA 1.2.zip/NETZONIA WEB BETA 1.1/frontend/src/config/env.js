const env = import.meta.env || {};
export const API_BASE_URL = env.VITE_API_BASE_URL || (env.PROD ? "" : "http://localhost:8080");
