/** Preview is the default until the application is connected to real services. */
export const INTERFACE_ONLY = String(import.meta.env?.VITE_INTERFACE_ONLY ?? "true") !== "false";
