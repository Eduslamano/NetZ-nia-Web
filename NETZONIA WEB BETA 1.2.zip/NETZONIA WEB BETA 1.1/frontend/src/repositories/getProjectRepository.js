import { LocalProjectRepository } from "./localProjectRepository.js";
import { SupabaseProjectRepository } from "./supabaseProjectRepository.js";
import { getSupabaseClient, getSupabaseContext, isSupabaseEnabled } from "../services/supabase.js";

let cached;
export async function getProjectRepository() {
  if (cached) return cached;
  if (!isSupabaseEnabled()) return (cached = new LocalProjectRepository());
  const context = await getSupabaseContext();
  if (!context.user) throw new Error("Faça login para acessar os projetos.");
  if (!context.companyId) throw new Error("Seu usuário ainda não pertence a uma empresa.");
  cached = new SupabaseProjectRepository(getSupabaseClient(), context.companyId, context.user.id);
  return cached;
}
export function resetProjectRepository() { cached = undefined; }
