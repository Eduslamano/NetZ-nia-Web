/** Contrato de persistência usado pelas implementações local e Supabase. */
export class ProjectRepository {
  async list(_query = "") { throw new Error("list não implementado"); }
  async get(_id) { throw new Error("get não implementado"); }
  async create(_input) { throw new Error("create não implementado"); }
  async update(_id, _changes) { throw new Error("update não implementado"); }
  async delete(_id) { throw new Error("delete não implementado"); }
  async duplicate(_id) { throw new Error("duplicate não implementado"); }
}

export const PROJECT_SCHEMA_VERSION = 2;
export const MAX_PROJECT_BYTES = 4 * 1024 * 1024;

export function createProject(input = {}) {
  const now = new Date().toISOString();
  const name = String(input.name || "Novo projeto").trim().slice(0, 120);
  if (!name) throw new Error("Informe o nome do projeto.");
  return {
    id: input.id || crypto.randomUUID(),
    companyId: input.companyId || "local-company",
    ownerId: input.ownerId || "local-user",
    name,
    description: String(input.description || "").trim().slice(0, 1000),
    createdAt: input.createdAt || now,
    updatedAt: now,
    schemaVersion: PROJECT_SCHEMA_VERSION,
    revision: Number.isInteger(input.revision) ? input.revision : 1,
    data: input.data && typeof input.data === "object" ? structuredClone(input.data) : {},
  };
}

export function validateProject(project) {
  if (!project || typeof project !== "object" || Array.isArray(project)) throw new Error("Projeto inválido.");
  if (!project.id || !project.name) throw new Error("Projeto sem identificação ou nome.");
  if (String(project.name).length > 120 || String(project.description || "").length > 1000) throw new Error("Nome ou descrição excede o limite permitido.");
  const bytes = new TextEncoder().encode(JSON.stringify(project)).byteLength;
  if (bytes > MAX_PROJECT_BYTES) throw new Error("O projeto excede o limite local de 4 MB.");
  return project;
}
