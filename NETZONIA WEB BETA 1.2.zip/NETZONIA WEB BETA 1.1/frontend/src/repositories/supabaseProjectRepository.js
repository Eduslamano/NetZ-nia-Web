import { ProjectRepository, createProject, validateProject } from "./projectRepository.js";

/** Adapter multiempresa. A chave publishable/anon é protegida pelas políticas RLS. */
export class SupabaseProjectRepository extends ProjectRepository {
  constructor(client, companyId, ownerId) {
    super();
    if (!client || !companyId || !ownerId) throw new Error("Sessão Supabase/empresa incompleta.");
    this.client = client;
    this.companyId = companyId;
    this.ownerId = ownerId;
  }

  #map(row) {
    const projectData = Array.isArray(row.project_data) ? row.project_data[0] : row.project_data;
    return {
      id: row.id, companyId: row.company_id, ownerId: row.created_by,
      name: row.name, description: row.description || "",
      createdAt: row.created_at, updatedAt: row.updated_at,
      schemaVersion: row.schema_version || 2, revision: row.revision || 1,
      data: projectData?.data || {},
    };
  }

  async list(query = "") {
    let request = this.client.from("projects")
      .select("id,company_id,created_by,name,description,created_at,updated_at,schema_version,revision,project_data(data)")
      .eq("company_id", this.companyId).order("updated_at", { ascending: false });
    if (String(query).trim()) request = request.ilike("name", `%${String(query).trim().replace(/[%_]/g, "")}%`);
    const { data, error } = await request;
    if (error) throw new Error(error.message);
    return (data || []).map((row) => this.#map(row));
  }

  async get(id) {
    const { data, error } = await this.client.from("projects")
      .select("id,company_id,created_by,name,description,created_at,updated_at,schema_version,revision,project_data(data)")
      .eq("company_id", this.companyId).eq("id", id).maybeSingle();
    if (error) throw new Error(error.message);
    return data ? this.#map(data) : null;
  }

  async create(input) {
    const local = validateProject(createProject({ ...input, companyId: this.companyId, ownerId: this.ownerId }));
    const { data, error } = await this.client.from("projects").insert({
      company_id: this.companyId, created_by: this.ownerId, name: local.name,
      description: local.description, schema_version: local.schemaVersion, revision: 1,
    }).select("*").single();
    if (error) throw new Error(error.message);
    const { error: dataError } = await this.client.from("project_data").insert({ project_id: data.id, data: local.data });
    if (dataError) {
      await this.client.from("projects").delete().eq("id", data.id);
      throw new Error(dataError.message);
    }
    return this.get(data.id);
  }

  async update(id, changes) {
    const current = await this.get(id);
    if (!current) throw new Error("Projeto não encontrado.");
    const candidate = validateProject({
      ...current,
      name: changes.name === undefined ? current.name : String(changes.name).trim().slice(0, 120),
      description: changes.description === undefined ? current.description : String(changes.description).trim().slice(0, 1000),
      data: changes.data === undefined ? current.data : structuredClone(changes.data),
    });
    const patch = {};
    if (changes.name !== undefined) patch.name = candidate.name;
    if (changes.description !== undefined) patch.description = candidate.description;
    if (changes.data !== undefined) {
      const { error } = await this.client.from("project_data").upsert({ project_id: id, data: candidate.data });
      if (error) throw new Error(error.message);
    }
    if (Object.keys(patch).length) {
      const { error } = await this.client.from("projects").update(patch).eq("company_id", this.companyId).eq("id", id);
      if (error) throw new Error(error.message);
    }
    return this.get(id);
  }

  async delete(id) {
    const { error } = await this.client.from("projects").delete().eq("company_id", this.companyId).eq("id", id);
    if (error) throw new Error(error.message);
    return true;
  }

  async duplicate(id) {
    const source = await this.get(id);
    if (!source) throw new Error("Projeto não encontrado.");
    return this.create({ name: `${source.name} — cópia`, description: source.description, data: source.data });
  }
}
