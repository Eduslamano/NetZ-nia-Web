import { ProjectRepository, createProject, validateProject } from "./projectRepository.js";

export const STORAGE_KEY = "netzonia:projects:v2";
const LEGACY_KEY = "netzonia:projetos-locais";

export class LocalProjectRepository extends ProjectRepository {
  constructor(storage = globalThis.localStorage) {
    super();
    this.storage = storage;
    if (!storage) throw new Error("Armazenamento local indisponível.");
    this.#migrateLegacy();
  }

  #read() {
    try {
      const parsed = JSON.parse(this.storage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      throw new Error("Não foi possível ler os projetos locais. Exporte seus dados e limpe o armazenamento corrompido.");
    }
  }

  #write(projects) {
    try {
      this.storage.setItem(STORAGE_KEY, JSON.stringify(projects));
    } catch (error) {
      if (error?.name === "QuotaExceededError") throw new Error("Espaço local esgotado. Exclua ou exporte projetos antigos.");
      throw error;
    }
  }

  #migrateLegacy() {
    if (this.storage.getItem(STORAGE_KEY) || !this.storage.getItem(LEGACY_KEY)) return;
    try {
      const legacy = JSON.parse(this.storage.getItem(LEGACY_KEY));
      const migrated = Object.values(legacy || {}).map((old) => {
        let data = {};
        try { data = JSON.parse(old.dadosJSON || "{}"); } catch { data = {}; }
        return createProject({
          name: old.endereco || `Projeto ${old.placeId || "migrado"}`,
          description: "Migrado automaticamente do armazenamento local da Fase 1.",
          data: { ...data, location: { placeId: old.placeId, lat: old.lat, lng: old.lng } },
        });
      });
      this.#write(migrated);
    } catch {
      // O legado permanece intacto para recuperação manual.
    }
  }

  async list(query = "") {
    const term = String(query).trim().toLocaleLowerCase("pt-BR");
    return this.#read()
      .filter((p) => !term || `${p.name} ${p.description}`.toLocaleLowerCase("pt-BR").includes(term))
      .sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
      .map((p) => structuredClone(p));
  }

  async get(id) {
    const found = this.#read().find((p) => p.id === id);
    return found ? structuredClone(found) : null;
  }

  async create(input) {
    const project = validateProject(createProject(input));
    const all = this.#read();
    all.push(project);
    this.#write(all);
    return structuredClone(project);
  }

  async update(id, changes) {
    const all = this.#read();
    const index = all.findIndex((p) => p.id === id);
    if (index < 0) throw new Error("Projeto não encontrado.");
    const current = all[index];
    const next = validateProject({
      ...current,
      name: changes.name === undefined ? current.name : String(changes.name).trim().slice(0, 120),
      description: changes.description === undefined ? current.description : String(changes.description).trim().slice(0, 1000),
      data: changes.data === undefined ? current.data : structuredClone(changes.data),
      id: current.id, companyId: current.companyId, ownerId: current.ownerId, createdAt: current.createdAt,
      schemaVersion: current.schemaVersion,
      updatedAt: new Date().toISOString(), revision: (current.revision || 0) + 1,
    });
    all[index] = next;
    this.#write(all);
    return structuredClone(next);
  }

  async delete(id) {
    const all = this.#read();
    const filtered = all.filter((p) => p.id !== id);
    if (filtered.length === all.length) return false;
    this.#write(filtered);
    return true;
  }

  async duplicate(id) {
    const source = await this.get(id);
    if (!source) throw new Error("Projeto não encontrado.");
    return this.create({ name: `${source.name} — cópia`, description: source.description, data: structuredClone(source.data) });
  }
}
