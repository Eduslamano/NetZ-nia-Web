import { INTERFACE_ONLY } from "./config/interface.js";
import { renderAuth } from "./pages/auth.js";
import { renderOverview } from "./pages/overview.js";
import { renderProjectDetail } from "./pages/projectDetail.js";
import "./styles/base.css";
import "./styles/theme.css";
import "./styles/layout.css";
import "./styles/components.css";
import "./styles/mapa3d.css";
import "./styles/responsive.css";

import "./styles/web-polish.css";
import { loading, errorMarkup } from "./components/feedback.js";
import { getHealth } from "./services/api.js";
import { getSupabaseContext } from "./services/supabase.js";
import { renderDashboard } from "./pages/dashboard.js";
import { renderToolDetail } from "./pages/toolDetail.js";
import { renderProjects } from "./pages/projects.js";
import { renderReports } from "./pages/reports.js";
import { renderAccount } from "./pages/account.js";
import { escapeHtml } from "./lib/html.js";
import { CATEGORIES, CATEGORY_ORDER, PLANNER } from "./data/categories.js";
import { mountSideMenu } from "./components/sideMenu.js";

const app = document.querySelector("#app");
app.innerHTML = `
  <a class="skip-link" href="#main-view">Pular para o conteúdo</a>
  <header class="app-header"><div class="header-inner">
    <button id="menu-btn" class="menu-btn" type="button" title="Abrir menu de categorias" aria-label="Abrir menu de categorias" aria-expanded="false" aria-controls="side-menu">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 6.5h16M4 12h16M4 17.5h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
    </button>
    <a class="brand" href="#/visao-geral" aria-label="NetZônia — página inicial"><img class="brand-logo" src="/logo-netzonia.png" alt="NetZônia"><span class="web-label">WEB</span></a>
    <nav class="main-nav" aria-label="Navegação principal">
      <a href="#/visao-geral">Visão geral</a><a href="#/">Ferramentas</a><a href="#/projetos">Projetos</a><a href="#/relatorios">Relatórios</a><a href="#/conta">Conta</a>
    </nav>
    <div class="search-wrap">
      <span class="search-icon">⌕</span><input class="search-input" id="global-search" type="search" aria-label="Pesquisar ferramentas" placeholder="Pesquisar ferramentas…" autocomplete="off" spellcheck="false">
      <div class="search-filter-wrap"><select id="category-filter" class="search-filter-select" title="Filtrar busca por categoria" aria-label="Filtrar busca por categoria">
        <option value="all">Todas as categorias</option>
        ${CATEGORY_ORDER.map((id) => `<option value="${id}">${CATEGORIES[id].shortLabel}</option>`).join("")}
        <option value="planner">Planejador de Rede 3D</option>
      </select></div>
    </div>
    <span class="badge" id="api-status" role="status">Conectando…</span>
  </div></header>
  ${INTERFACE_ONLY ? '<div class="preview-banner"><span><strong>Prévia das interfaces</strong> · Ferramentas e acesso sem conexão com serviços.</span><a href="#/login">Conferir login →</a></div>' : ""}
  <main class="app-main" id="main-view" tabindex="-1"></main><span class="sr-only" id="route-announcement" role="status"></span>
  <div id="side-menu-root"></div>`;

const mainView = document.querySelector("#main-view");
const apiStatusEl = document.querySelector("#api-status");
const searchInput = document.querySelector("#global-search");
const categoryFilter = document.querySelector("#category-filter");
let cleanup = null;
let renderId = 0;

async function refreshHeader() {
  if (INTERFACE_ONLY) { apiStatusEl.className = "badge badge-neutral"; apiStatusEl.textContent = "Modo de prévia"; return; }
  try {
    await getHealth();
    apiStatusEl.className = "badge badge-good"; apiStatusEl.textContent = "Serviço disponível";
  } catch {
    apiStatusEl.className = "badge badge-bad"; apiStatusEl.textContent = "Serviço indisponível";
  }
}

function parseHash() {
  const [section, id] = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  return { section: section || "home", id };
}

let lastRoute = null;
async function render() {
  const token = ++renderId;
  const route = location.hash;
  const navigation = route !== lastRoute;
  lastRoute = route;
  const previousCleanup = cleanup;
  cleanup = null;
  const page = document.createElement("div");
  page.className = "route-content";
  page.innerHTML = `<section class="view">${loading("Preparando sua área de trabalho…")}</section>`;
  mainView.replaceChildren(page);
  mainView.setAttribute("aria-busy", "true");
  const { section, id } = parseHash();
  document.querySelectorAll(".main-nav a").forEach((a) => {
    const active = a.hash === route || (["home", "categoria", "ferramenta"].includes(section) && a.hash === "#/") || (["projeto", "projetos", "planejador"].includes(section) && a.hash === "#/projetos") || (["login", "cadastro", "recuperar-senha", "redefinir-senha"].includes(section) && a.hash === "#/conta");
    a.classList.toggle("active", active);
    if (active) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
  searchInput.closest(".search-wrap").hidden = !["home", "categoria"].includes(section);
  categoryFilter.value = section === "categoria" && CATEGORIES[id] ? id : "all";
  try {
    await previousCleanup?.();
    if (token !== renderId) return;
    const context = await getSupabaseContext();
    if (token !== renderId) return;
    if (["projetos", "planejador", "relatorios"].includes(section) && context.mode === "supabase" && (!context.user || !context.companyId)) {
      await renderAccount(page);
    } else if (section === "ferramenta" && id) cleanup = renderToolDetail(page, id);
    else if (section === "categoria" && CATEGORIES[id]) renderDashboard(page, { categoryId: id, query: searchInput.value });
    else if (section === "projetos") await renderProjects(page, { create: id === "novo" });
    else if (section === "projeto" && id) await renderProjectDetail(page, decodeURIComponent(id));
    else if (section === "visao-geral") await renderOverview(page);
    else if (["login", "cadastro", "recuperar-senha", "redefinir-senha"].includes(section)) {
      if (INTERFACE_ONLY) renderAuth(page, section);
      else await renderAccount(page);
    }
    else if (section === "planejador") {
      const { renderPlanner3D } = await import("./pages/planner3d.js");
      if (token !== renderId) return;
      const dispose = await renderPlanner3D(page);
      if (token === renderId) cleanup = dispose; else await dispose?.();
    } else if (section === "relatorios") await renderReports(page);
    else if (section === "conta") await renderAccount(page);
    else if (section === "home") renderDashboard(page, { query: searchInput.value });
    else page.innerHTML = `<section class="view empty-page"><h1 class="view-title">Página não encontrada</h1><p class="view-subtitle">Este endereço não está disponível. Volte às categorias para continuar.</p><a class="btn btn-primary" href="#/">Ir para o início</a></section>`;
  } catch (error) {
    page.innerHTML = `<section class="view empty-page"><h1 class="view-title">Não foi possível abrir esta área</h1>${errorMarkup(error)}<div class="project-actions"><button class="btn btn-primary" id="retry-page">Tentar novamente</button><a class="btn btn-ghost" href="#/">Voltar ao início</a></div></section>`;
    page.querySelector("#retry-page").addEventListener("click", () => void render());
  } finally {
    if (token === renderId) {
      mainView.removeAttribute("aria-busy");
      const heading = page.querySelector("h1");
      document.title = `${heading?.textContent || "NetZônia"} — NetZônia Web`;
      document.querySelector("#route-announcement").textContent = heading?.textContent || "Página carregada";
      if (navigation && !(section === "projetos" && id === "novo")) {
        mainView.scrollTop = 0;
        if (heading) { heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
      }
    }
  }
}

window.addEventListener("hashchange", () => void render());
window.addEventListener("netzonia:project-changed", () => void refreshHeader());
mainView.addEventListener("click", (event) => {
  const cat = event.target.closest("[data-category-id]");
  const tool = event.target.closest("[data-tool-id]");
  if (cat) location.hash = `#/categoria/${cat.dataset.categoryId}`;
  else if (tool) location.hash = tool.dataset.toolId === "relatorio" ? "#/relatorios" : `#/ferramenta/${tool.dataset.toolId}`;
  else if (event.target.closest("[data-go-home]")) {
    searchInput.value = "";
    if (location.hash === "#/" || location.hash === "") void render();
    else location.hash = "#/";
  }
  else if (event.target.closest("[data-open-planner]")) location.hash = "#/planejador";
});

document.querySelectorAll('.brand, .main-nav a[href="#/"]').forEach((link) => link.addEventListener("click", () => {
  searchInput.value = "";
}));

let searchTimer;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { if (["home", "categoria"].includes(parseHash().section)) void render(); }, 150);
});
categoryFilter.addEventListener("change", () => {
  const selected = categoryFilter.value;
  searchInput.value = "";
  if (selected === "planner") location.hash = "#/planejador";
  else if (selected === "all") {
    if (location.hash === "#/" || location.hash === "") void render();
    else location.hash = "#/";
  } else location.hash = `#/categoria/${selected}`;
});
document.querySelector(".skip-link").addEventListener("click", (event) => { event.preventDefault(); mainView.focus(); });
mountSideMenu();
window.addEventListener("beforeunload", () => { cleanup?.(); });
void refreshHeader();
if (!INTERFACE_ONLY) setInterval(refreshHeader, 15000);
void render();
