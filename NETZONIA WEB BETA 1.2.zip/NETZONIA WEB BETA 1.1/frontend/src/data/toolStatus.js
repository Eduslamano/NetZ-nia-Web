// Estados possíveis (mesmo vocabulário do PROMPT_MESTRE, seção 14):
//   FUNCIONAL_E_TESTADO        — implementado, testado (automatizado e/ou manual) e ligado à API real.
//   REQUER_AGENTE_LOCAL        — depende de hardware/SO do usuário; precisa de um agente futuro.
//   DESKTOP_ONLY               — só faz sentido no aplicativo Desktop (Wails/Windows).
//   PREPARADO_AGUARDANDO_SUPABASE — desenho pronto, mas depende de Auth/Supabase ativos.
//   POS_MVP                    — fora do escopo desta rodada; não é um botão falso, é ausência honesta.
export const STATUS = {
  FUNCIONAL_E_TESTADO: "FUNCIONAL_E_TESTADO",
  FUNCIONAL_CONTROLADO: "FUNCIONAL_CONTROLADO",
  REQUER_AGENTE_LOCAL: "REQUER_AGENTE_LOCAL",
  DESKTOP_ONLY: "DESKTOP_ONLY",
  PREPARADO_AGUARDANDO_SUPABASE: "PREPARADO_AGUARDANDO_SUPABASE",
  POS_MVP: "POS_MVP",
};

export const STATUS_LABEL = {
  FUNCIONAL_E_TESTADO: "Disponível",
  FUNCIONAL_CONTROLADO: "Disponível sob configuração",
  REQUER_AGENTE_LOCAL: "Requer acesso à rede local",
  DESKTOP_ONLY: "Somente no Desktop",
  PREPARADO_AGUARDANDO_SUPABASE: "Requer conta conectada",
  POS_MVP: "Em breve",
};

// id da funcionalidade (data/features.js) → estado real nesta entrega.
export const TOOL_STATUS = {
  velocidade: STATUS.POS_MVP,
  dispositivos: STATUS.REQUER_AGENTE_LOCAL,
  roteador: STATUS.FUNCIONAL_E_TESTADO, // abre o gateway informado — só front-end, sem detecção automática
  reparar: STATUS.DESKTOP_ONLY,
  wifi: STATUS.REQUER_AGENTE_LOCAL,
  latencia: STATUS.FUNCIONAL_E_TESTADO, // medição TCP a partir do servidor (ver nota na tela da ferramenta)
  relatorio: STATUS.FUNCIONAL_E_TESTADO,
  traceroute: STATUS.POS_MVP,
  portas: STATUS.POS_MVP,
  adaptador: STATUS.REQUER_AGENTE_LOCAL,
  dns: STATUS.FUNCIONAL_E_TESTADO,
  watchdog: STATUS.POS_MVP,
  "ip-externo": STATUS.FUNCIONAL_E_TESTADO, // reformulado: IP de origem visto pelo servidor, não geolocalização
  mtu: STATUS.POS_MVP,
  vlsm: STATUS.FUNCIONAL_E_TESTADO,
  "orcamento-optico": STATUS.FUNCIONAL_E_TESTADO,
  cftv: STATUS.FUNCIONAL_E_TESTADO,
  "conversor-telecom": STATUS.FUNCIONAL_E_TESTADO,
  ssh: STATUS.POS_MVP,
  wol: STATUS.FUNCIONAL_CONTROLADO,
  "ping-sonoro": STATUS.POS_MVP,
  pppoe: STATUS.DESKTOP_ONLY,
  "servidor-lan": STATUS.DESKTOP_ONLY,
  "wifi-string": STATUS.FUNCIONAL_E_TESTADO,
  snmp: STATUS.POS_MVP,
  ssl: STATUS.FUNCIONAL_E_TESTADO,
  "senha-segura": STATUS.FUNCIONAL_E_TESTADO,
  "atalhos-windows": STATUS.DESKTOP_ONLY,
  "config-ip": STATUS.DESKTOP_ONLY,
  ipv6: STATUS.POS_MVP,
  credenciais: STATUS.PREPARADO_AGUARDANDO_SUPABASE,
};

export const STATUS_NOTE = {
  velocidade: "Medir velocidade real exige um protocolo de teste de banda (download/upload de payload grande) que ainda não foi implementado nesta rodada.",
  dispositivos: "Depende de varredura ARP da rede local do usuário — impossível a partir do navegador ou de um servidor remoto.",
  wifi: "Depende do adaptador Wi-Fi da máquina do usuário.",
  reparar: "Usa comandos nativos do Windows (netsh, ipconfig) — permanece exclusivo do aplicativo Desktop.",
  traceroute: "Traceroute real (ICMP/UDP com TTL crescente) normalmente exige privilégio de socket bruto; não implementado nesta rodada.",
  portas: "Scanner de portas em produção precisa de limites de autorização/escopo (ver docs/AUDITORIA_MIGRACAO_WEB.md) antes de ir ao ar.",
  adaptador: "Depende de dados do adaptador de rede local (ipconfig/WMI).",
  watchdog: "Monitoramento contínuo por sessão fica para depois de definir limites de recursos no servidor.",
  mtu: "Descoberta de MTU por path costuma exigir socket bruto com flag DF; não implementado nesta rodada.",
  ssh: "Requer fluxo de credencial autenticado no backend; adiado para não expor segredo sem desenho de Auth pronto.",
  wol: "Desativado por padrão. Só habilite NETZONIA_ALLOW_WOL=true em servidor autorizado dentro da LAN/VLAN do equipamento.",
  "ping-sonoro": "Depende de ping contínuo via stream (SSE/WebSocket) + Web Audio API no navegador.",
  snmp: "Depende do binário snmpget instalado no servidor de produção — dependência operacional a confirmar antes de ativar.",
  ipv6: "Testar a prontidão IPv6 do usuário corretamente precisa rodar no navegador dele, não no servidor; verificação client-side ainda não implementada.",
  credenciais: "O modelo DPAPI do Desktop não migra para a Web; precisa de Auth Supabase + segredo cifrado server-side.",
};
