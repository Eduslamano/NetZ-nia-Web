// ---------------------------------------------------------------------
// tools.js — registro único usado pela navegação (home, categoria,
// busca, cartões). Fusão P15 + Enolla: aqui só existe FEATURES (as 31
// funcionalidades já com bridgeFn e lógica reais do P15) — não há mais
// um conjunto separado de "ferramentas novas pendentes", porque todas
// as 31 já têm backend funcional em NETZONIA_3.2_P15_FINAL.
//
// `isPending` é mantida por compatibilidade com featureCard.js (selo
// "Aguardando backend"): hoje nunca é true, pois nenhuma funcionalidade
// desta versão está com type "pending"/"shortcuts-sem-backend".
// ---------------------------------------------------------------------

import { FEATURES } from "./features.js";
import { CATEGORIES } from "./categories.js";

export const ALL_TOOLS = [...FEATURES].sort((a, b) => a.number - b.number);

export function getToolById(id) {
  return ALL_TOOLS.find((t) => t.id === id) || null;
}

/** Todas as ferramentas de uma categoria, na ordem numérica oficial (1–31). */
export function toolsByCategory(categoryId) {
  return ALL_TOOLS.filter((t) => t.category === categoryId);
}

export function countByCategory(categoryId) {
  return toolsByCategory(categoryId).length;
}

/** Mantido por compatibilidade de interface — nenhuma ferramenta desta versão está pendente. */
export function isPending(tool) {
  return tool.type === "pending" || tool.type === "shortcuts";
}

/**
 * Busca global por texto livre — título, subtítulo, descrição, categoria
 * — com filtro opcional de categoria.
 */
export function searchTools(query, categoryId = "all") {
  const q = (query || "").trim().toLowerCase();
  const scoped = !categoryId || categoryId === "all" ? ALL_TOOLS : ALL_TOOLS.filter((t) => t.category === categoryId);

  if (!q) return scoped;

  return scoped.filter((t) => {
    const categoryLabel = CATEGORIES[t.category]?.label || "";
    const haystack = [t.title, t.subtitle, t.description, categoryLabel].join(" ").toLowerCase();
    return haystack.includes(q);
  });
}
