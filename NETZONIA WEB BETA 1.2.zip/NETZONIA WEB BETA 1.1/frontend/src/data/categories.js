// ---------------------------------------------------------------------
// categories.js — fonte única de verdade sobre as categorias da
// interface. Cada uma das 31 funcionalidades (data/features.js, fusão
// com a lógica real do P15) aponta para um destes IDs através do campo
// `category`.
//
// O Planejador / Mapa 3D é modelado à parte (PLANNER, mais abaixo):
// por pedido do time, ele mantém destaque próprio na interface e não
// entra na grade de categorias nem na lógica de busca por ferramentas.
// ---------------------------------------------------------------------

import { icons } from "./icons.js";

export const CATEGORIES = {
  diagnostico: {
    id: "diagnostico",
    label: "Diagnóstico de Rede",
    shortLabel: "Diagnóstico",
    description: "Meça desempenho, caminho e alcance da conexão: velocidade, latência, rotas, DNS, MTU e mais.",
    icon: icons.catDiagnostico,
    tone: "tone-teal",
  },
  dispositivos: {
    id: "dispositivos",
    label: "Dispositivos e Administração",
    shortLabel: "Dispositivos",
    description: "Enxergue e controle o que está na rede: inventário, roteador, adaptador, Wake-on-LAN, SSH e SNMP.",
    icon: icons.catDispositivos,
    tone: "tone-leaf",
  },
  "wifi-infra": {
    id: "wifi-infra",
    label: "Wi-Fi e Infraestrutura",
    shortLabel: "Wi-Fi & Infra",
    description: "Planeje redes sem fio e cabeadas: canais Wi-Fi, VLSM, orçamento óptico e banda de CFTV.",
    icon: icons.catWifiInfra,
    tone: "tone-cyan",
  },
  monitoramento: {
    id: "monitoramento",
    label: "Monitoramento e Testes",
    shortLabel: "Monitoramento",
    description: "Acompanhe a saúde da rede em tempo real: watchdog, portas, PPPoE, servidor LAN e certificados SSL.",
    icon: icons.catMonitoramento,
    tone: "tone-amber",
  },
  ferramentas: {
    id: "ferramentas",
    label: "Ferramentas",
    shortLabel: "Ferramentas",
    description: "Utilitários do dia a dia: reparo de conexão, conversor de grandezas, gerador de senhas e relatórios.",
    icon: icons.catFerramentas,
    tone: "tone-coral",
  },
};

/** Ordem de exibição das categorias na home e na navegação inferior. */
export const CATEGORY_ORDER = ["diagnostico", "dispositivos", "wifi-infra", "monitoramento", "ferramentas"];

/**
 * Planejador / Mapa 3D — módulo já existente, com lógica própria que não
 * deve ser tocada. Aqui ele só ganha uma entrada visual de destaque (na
 * home e na navegação inferior) e uma tela de abertura dedicada.
 */
export const PLANNER = {
  id: "planejador-3d",
  title: "Planejador de Rede / Mapa 3D",
  shortLabel: "Planejador 3D",
  description: "Planeje visualmente racks, equipamentos, cabeamento, zonas EMI e orçamento em um mapa 3D interativo.",
  icon: icons.catPlanejador,
  tone: "tone-violet",
};
