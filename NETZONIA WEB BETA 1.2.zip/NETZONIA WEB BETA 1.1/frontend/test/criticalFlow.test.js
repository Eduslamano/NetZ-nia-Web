import test from "node:test";
import assert from "node:assert/strict";
import { LocalProjectRepository } from "../src/repositories/localProjectRepository.js";
import { createEmptyPlannerState, createEntity } from "../src/mapa3d/model.js";
import { constrainEntityToInstallation } from "../src/mapa3d/installationConstraints.js";
import { installInRack } from "../src/mapa3d/rackManager.js";
import { createCable } from "../src/mapa3d/networkValidator.js";
import { restorePlanner, serializePlanner } from "../src/mapa3d/persistence.js";
import { buildProjectReport } from "../src/pages/reports.js";

class MemoryStorage {
  constructor() { this.data = new Map(); }
  getItem(key) { return this.data.has(key) ? this.data.get(key) : null; }
  setItem(key, value) { this.data.set(key, String(value)); }
  removeItem(key) { this.data.delete(key); }
}

test("fluxo crítico local salva e reabre projeto, Planner e relatório", async () => {
  const storage = new MemoryStorage();
  const repository = new LocalProjectRepository(storage);
  const project = await repository.create({ name: "Homologação RC", description: "Fluxo completo" });
  const planner = createEmptyPlannerState();
  planner.environment = { width: 30, depth: 20, height: 6, grid: 1 };

  const rack = createEntity("rack24", { x: 3, y: 0, z: 2 });
  planner.racks.push(rack);
  constrainEntityToInstallation(planner, rack);

  const router = createEntity("router", { x: -3, y: 0, z: 0 });
  const onu = createEntity("onu", { x: 0, y: 1.8, z: 3 });
  onu.installation.surfaceId = "wall-south";
  const switch24 = createEntity("switch24");
  installInRack(rack, switch24);
  planner.equipment.push(router, onu, switch24);
  constrainEntityToInstallation(planner, router);
  constrainEntityToInstallation(planner, onu);
  constrainEntityToInstallation(planner, switch24);

  createCable(planner, router.id, onu.id, "copper-unshielded", "LAN1", "LAN1");
  createCable(planner, router.id, switch24.id, "copper-shielded", "LAN2", "LAN1");
  await repository.update(project.id, { data: { planner3d: serializePlanner(planner) } });

  const reopened = await new LocalProjectRepository(storage).get(project.id);
  const restored = restorePlanner(reopened.data.planner3d);
  assert.equal(restored.environment.width, 30);
  assert.equal(restored.racks.length, 1);
  assert.equal(restored.equipment.length, 3);
  assert.equal(restored.cables.length, 2);
  assert.equal(restored.equipment.find((item) => item.id === onu.id).installation.surfaceId, "wall-south");
  assert.equal(restored.equipment.find((item) => item.id === switch24.id).installation.rackU, 1);

  const report = buildProjectReport({ ...reopened, data: { ...reopened.data, planner3d: restored } });
  assert.match(report, /Homologação RC/);
  assert.match(report, /wall-south/);
  assert.match(report, /LAN1/);
});
