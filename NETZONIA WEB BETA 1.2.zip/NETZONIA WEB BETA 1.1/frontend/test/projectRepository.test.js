import test from "node:test";
import assert from "node:assert/strict";
import { LocalProjectRepository } from "../src/repositories/localProjectRepository.js";

class MemoryStorage {
  constructor() { this.data = new Map(); }
  getItem(key) { return this.data.has(key) ? this.data.get(key) : null; }
  setItem(key, value) { this.data.set(key, String(value)); }
  removeItem(key) { this.data.delete(key); }
}

test("CRUD, busca e duplicação de projetos locais", async () => {
  const repository = new LocalProjectRepository(new MemoryStorage());
  const created = await repository.create({ name: "Escritório Centro", description: "Rede principal" });
  assert.equal((await repository.list("centro")).length, 1);
  const updated = await repository.update(created.id, { name: "Escritório Norte", data: { ok: true } });
  assert.equal(updated.revision, 2);
  assert.equal((await repository.get(created.id)).data.ok, true);
  const protectedScope = await repository.update(created.id, { ownerId: "invasor", companyId: "outra" });
  assert.equal(protectedScope.ownerId, "local-user");
  assert.equal(protectedScope.companyId, "local-company");
  const duplicate = await repository.duplicate(created.id);
  assert.match(duplicate.name, /cópia/);
  assert.equal((await repository.list()).length, 2);
  assert.equal(await repository.delete(created.id), true);
  assert.equal((await repository.list()).length, 1);
});

test("projeto mantém identidade, timestamps e rejeita nome vazio", async () => {
  const repository = new LocalProjectRepository(new MemoryStorage());
  const created = await repository.create({ name: "Projeto A" });
  const updated = await repository.update(created.id, { description: "Atualizado" });
  assert.equal(updated.id, created.id);
  assert.equal(updated.createdAt, created.createdAt);
  assert.ok(Date.parse(updated.updatedAt) >= Date.parse(created.updatedAt));
  await assert.rejects(repository.update(created.id, { name: "   " }), /identificação ou nome/);
});

test("armazenamento local corrompido produz erro orientativo", async () => {
  const storage = new MemoryStorage();
  storage.setItem("netzonia:projects:v2", "{json inválido");
  const repository = new LocalProjectRepository(storage);
  await assert.rejects(repository.list(), /armazenamento corrompido/);
});
