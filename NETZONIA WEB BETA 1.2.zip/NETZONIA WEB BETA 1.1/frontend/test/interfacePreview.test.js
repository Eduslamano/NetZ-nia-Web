import test from "node:test";
import assert from "node:assert/strict";
import { FEATURES } from "../src/data/features.js";
import { previewFields, previewResult } from "../src/pages/toolPreview.js";
import { INTERFACE_ONLY } from "../src/config/interface.js";
import { getHealth, postTool } from "../src/services/api.js";

test("prévia cobre as 31 ferramentas com resultado próprio e campos identificáveis", () => {
  assert.equal(FEATURES.length, 31);
  for (const tool of FEATURES) {
    const fields = previewFields(tool);
    assert.equal(new Set(fields.map(f => f.key)).size, fields.length, tool.id);
    assert.ok(fields.every(f => f.key && f.label), tool.id);
    const result = previewResult(tool.id);
    assert.ok(result.length > 40, tool.id);
    assert.doesNotMatch(result, /Resultado ilustrativo disponível após a integração/, tool.id);
  }
});

test("modo de interface bloqueia requisições antes de acessar a rede", async () => {
  assert.equal(INTERFACE_ONLY, true);
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => { calls++; throw new Error("Não deve ser chamado"); };
  try {
    await assert.rejects(getHealth(), /desativadas/);
    await assert.rejects(postTool("dns", { host: "example.com" }), /desativadas/);
    assert.equal(calls, 0);
  } finally { globalThis.fetch = originalFetch; }
});
