import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { renderDashboard } from "../src/pages/dashboard.js";

function render(options) {
  const root = { innerHTML: "" };
  renderDashboard(root, options);
  return root.innerHTML;
}

test("dashboard usa a marca NetZônia e organiza categorias antes do Planner", () => {
  const html = render();
  assert.match(html, />NetZônia</);
  assert.doesNotMatch(html, /Netzônia Web/i);
  assert.ok(html.indexOf("category-grid") < html.indexOf("planner-banner"));
  assert.match(html, /category-card-wide/);
  assert.doesNotMatch(html, /class="tool-grid"/);
});

test("categoria e busca exibem apenas a grade de ferramentas correspondente", () => {
  const category = render({ categoryId: "diagnostico" });
  assert.match(category, /Diagnóstico de Rede/);
  assert.match(category, /class="tool-grid"/);
  assert.doesNotMatch(category, /class="category-grid"/);

  const search = render({ categoryId: "diagnostico", query: "DNS" });
  assert.match(search, /Resultados da busca/);
  assert.match(search, /Teste de DNS/);
  assert.doesNotMatch(search, /Testar Velocidade/);
});

test("cabeçalho mantém navegação, busca por categoria e os indicadores aprovados", async () => {
  const source = await readFile(new URL("../src/main.js", import.meta.url), "utf8");
  const header = source.match(/app\.innerHTML = `([\s\S]*?)`;/)?.[1] || "";

  assert.match(header, /id="menu-btn"/);
  assert.match(header, /placeholder="Pesquisar ferramentas…"/);
  assert.match(header, /id="category-filter"/);
  assert.match(header, /Planejador de Rede 3D/);
  assert.match(header, /href="#\/visao-geral"[^>]*>Visão geral<\/a>[\s\S]*href="#\/projetos">Projetos<\/a>/);
  assert.match(header, /id="api-status"/);
  assert.match(header, />Relatórios<\/a>/);
  assert.doesNotMatch(header, /current-project|account-badge|Nenhum projeto|MODO LOCAL/);
});

test("menu lateral lista início, cinco categorias e Planejador 3D", async () => {
  const source = await readFile(new URL("../src/components/sideMenu.js", import.meta.url), "utf8");
  assert.match(source, /label: "Início"/);
  assert.match(source, /CATEGORY_ORDER\.map/);
  assert.match(source, /label: PLANNER\.title/);
  assert.match(source, /href: "#\/planejador"/);
});
