import test from "node:test";
import assert from "node:assert/strict";
import { createAutosave } from "../src/services/autosave.js";

test("autosave aplica debounce e persiste somente o snapshot mais recente", async () => {
  const saved = [];
  const states = [];
  const autosave = createAutosave(async (value) => { saved.push(value); }, {
    delay: 10,
    onState: (state) => states.push(state),
  });
  autosave.schedule({ revision: 1 });
  autosave.schedule({ revision: 2 });
  autosave.schedule({ revision: 3 });
  await new Promise((resolve) => setTimeout(resolve, 30));
  await autosave.flush();
  assert.deepEqual(saved, [{ revision: 3 }]);
  assert.ok(states.includes("pending"));
  assert.ok(states.includes("saving"));
  assert.equal(states.at(-1), "saved");
});

test("autosave informa erro e aceita uma gravação posterior", async () => {
  let attempts = 0;
  const states = [];
  const autosave = createAutosave(async () => {
    attempts += 1;
    if (attempts === 1) throw new Error("falha simulada");
  }, { delay: 1000, onState: (state) => states.push(state) });
  autosave.schedule({ revision: 1 });
  await assert.rejects(autosave.flush(), /falha simulada/);
  autosave.schedule({ revision: 2 });
  await autosave.flush();
  assert.equal(attempts, 2);
  assert.ok(states.includes("error"));
  assert.equal(states.at(-1), "saved");
});
