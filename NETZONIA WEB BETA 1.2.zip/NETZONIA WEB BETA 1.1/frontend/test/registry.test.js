import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { ALL_TOOLS, searchTools } from "../src/data/tools.js";
import { CATEGORIES, CATEGORY_ORDER } from "../src/data/categories.js";
import { STATUS, TOOL_STATUS } from "../src/data/toolStatus.js";
import { TOOL_RUNNERS } from "../src/services/toolRunner.js";

test("registro contém exatamente 31 funções válidas e sem duplicidade", () => {
  assert.equal(ALL_TOOLS.length, 31);
  assert.equal(new Set(ALL_TOOLS.map((tool) => tool.id)).size, 31);
  assert.deepEqual(ALL_TOOLS.map((tool) => tool.number), Array.from({ length: 31 }, (_, index) => index + 1));

  for (const tool of ALL_TOOLS) {
    assert.ok(tool.title?.trim(), `Título ausente em ${tool.id}`);
    assert.ok(tool.description?.trim(), `Descrição ausente em ${tool.id}`);
    assert.ok(CATEGORIES[tool.category], `Categoria inválida em ${tool.id}`);
    assert.ok(TOOL_STATUS[tool.id], `Status ausente em ${tool.id}`);
  }

  assert.deepEqual(Object.keys(CATEGORIES), CATEGORY_ORDER);
  assert.equal(searchTools("", "all").length, 31);
});

test("toda função marcada como executável possui implementação ligada", () => {
  const implementedInThePage = new Set(["roteador", "ip-externo", "relatorio"]);
  const executableStatuses = new Set([STATUS.FUNCIONAL_E_TESTADO, STATUS.FUNCIONAL_CONTROLADO]);

  for (const tool of ALL_TOOLS.filter((item) => executableStatuses.has(TOOL_STATUS[item.id]))) {
    assert.ok(TOOL_RUNNERS[tool.id] || implementedInThePage.has(tool.id), `Execução não ligada em ${tool.id}`);
  }
});

test("paleta 3D contém proteções responsivas contra sobreposição", async () => {
  const css = await readFile(new URL("../src/styles/mapa3d.css", import.meta.url), "utf8");
  assert.match(css, /\.mapa3d-palette\s*>\s*\*[\s\S]*?flex-shrink:\s*0/);
  assert.match(css, /\.mapa3d-palette-text[\s\S]*?min-width:\s*0[\s\S]*?overflow-wrap:\s*anywhere/);
  assert.match(css, /@media \(max-width:\s*480px\)[\s\S]*?\.mapa3d-palette-item[\s\S]*?grid-template-columns:\s*14px minmax\(0, 1fr\)/);
});
