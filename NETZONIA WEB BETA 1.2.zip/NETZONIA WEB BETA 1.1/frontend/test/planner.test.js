import test from "node:test";
import assert from "node:assert/strict";
import { createEmptyPlannerState, createEntity, removeEntity } from "../src/mapa3d/model.js";
import { createCable, validateCablePath } from "../src/mapa3d/networkValidator.js";
import { installInRack, validateRack } from "../src/mapa3d/rackManager.js";
import { restorePlanner, serializePlanner } from "../src/mapa3d/persistence.js";
import { constrainEntityToInstallation, syncRackEquipment } from "../src/mapa3d/installationConstraints.js";
import { buildProjectReport } from "../src/pages/reports.js";
import * as THREE from "three";
import { catalogItem } from "../src/mapa3d/equipmentCatalog.js";
import { createEquipmentVisual } from "../src/mapa3d/engine/equipmentVisuals.js";
import { loadEquipmentModelOrFallback } from "../src/mapa3d/modelLoader.js";

test("cobre respeita 90 m e fibra não aplica o limite", () => {
  const a = createEntity("router", { x: 0, y: 0, z: 0 });
  const b = createEntity("onu", { x: 100, y: 0, z: 0 });
  assert.equal(validateCablePath(a, b, "copper-unshielded").exceedsLimit, true);
  assert.equal(validateCablePath(a, b, "fiber").exceedsLimit, false);
});

test("EMI é calculada pelo segmento e blindagem atenua", () => {
  const a = createEntity("router", { x: -5, y: 0, z: 0 });
  const b = createEntity("onu", { x: 5, y: 0, z: 0 });
  const zones = [{ position: { x: 0, z: 1 }, radius: 1.1 }];
  const unshielded = validateCablePath(a, b, "copper-unshielded", zones);
  const shielded = validateCablePath(a, b, "copper-shielded", zones);
  assert.equal(unshielded.emi, true);
  assert.equal(unshielded.valid, false);
  assert.equal(shielded.emiMitigated, true);
  assert.equal(shielded.valid, true);
});

test("rack aloca U sem sobreposição", () => {
  const rack = createEntity("rack24");
  const first = createEntity("server");
  const second = createEntity("switch24");
  installInRack(rack, first);
  installInRack(rack, second);
  assert.deepEqual(rack.slots.map((s) => [s.startU, s.endU]), [[1, 2], [3, 3]]);
  assert.deepEqual(validateRack(rack), []);
});

test("cabo ocupa portas e estado restaura", () => {
  const state = createEmptyPlannerState();
  const router = createEntity("router");
  const onu = createEntity("onu", { x: 4, y: 0, z: 0 });
  state.equipment.push(router, onu);
  const cable = createCable(state, router.id, onu.id, "copper-unshielded");
  const restored = restorePlanner(serializePlanner(state));
  assert.equal(restored.cables[0].id, cable.id);
  assert.equal(restored.equipment[0].ports.find((p) => p.id === cable.originPortId).occupiedBy, cable.id);
});

test("relatório agrega projeto, 3D e alertas", () => {
  const text = buildProjectReport({
    name: "Matriz", description: "Teste", createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-02T00:00:00Z",
    data: { planner3d: { equipment: [{ name: "Router", installation: { type: "floor" } }], racks: [], cables: [{ type: "copper-unshielded", length: 92, validation: { valid: false, warnings: ["Excede 90 m"] } }] }, toolResults: [] },
  });
  assert.match(text, /Matriz/);
  assert.match(text, /Excede 90 m/);
});

test("excluir rack remove equipamentos instalados e seus cabos", () => {
  const state = createEmptyPlannerState();
  const rack = createEntity("rack24");
  const server = createEntity("server");
  const router = createEntity("router");
  installInRack(rack, server);
  state.racks.push(rack); state.equipment.push(server, router);
  createCable(state, server.id, router.id, "copper-unshielded");
  removeEntity(state, rack.id);
  assert.equal(state.equipment.some((e) => e.id === server.id), false);
  assert.equal(state.cables.length, 0);
});

test("equipamento de parede permanece preso à superfície e restaura orientação", () => {
  const state = createEmptyPlannerState();
  state.environment = { width: 10, depth: 8, height: 3, grid: 1 };
  const onu = createEntity("onu", { x: 99, y: 99, z: 99 });
  onu.installation = { type: "wall", surfaceId: "wall-west", rackId: null, rackU: null };
  state.equipment.push(onu);
  constrainEntityToInstallation(state, onu);
  assert.equal(onu.transform.position.x, -5 + 0.55 / 2);
  assert.ok(onu.transform.position.y <= 3 - 0.25 / 2);
  assert.ok(onu.transform.position.z <= 4 - 0.8 / 2);
  assert.equal(onu.transform.rotation.y, Math.PI / 2);
  const restored = restorePlanner(serializePlanner(state));
  assert.equal(restored.equipment[0].installation.surfaceId, "wall-west");
  assert.equal(restored.equipment[0].transform.position.x, onu.transform.position.x);
});

test("equipamento de teto não flutua e permanece dentro do ambiente", () => {
  const state = createEmptyPlannerState();
  const accessPoint = createEntity("accessPoint", { x: 100, y: -20, z: 100 });
  state.equipment.push(accessPoint);
  constrainEntityToInstallation(state, accessPoint);
  assert.equal(accessPoint.installation.type, "ceiling");
  assert.equal(accessPoint.transform.position.y, state.environment.height - 0.16 / 2);
  assert.ok(accessPoint.transform.position.x <= state.environment.width / 2 - 0.8 / 2);
});

test("equipamento instalado acompanha movimento do rack e preserva U", () => {
  const state = createEmptyPlannerState();
  const rack = createEntity("rack24");
  state.racks.push(rack);
  constrainEntityToInstallation(state, rack);
  const server = createEntity("server");
  installInRack(rack, server);
  state.equipment.push(server);
  constrainEntityToInstallation(state, server);
  rack.transform.position.x = 3;
  rack.transform.position.z = 2;
  rack.transform.rotation.y = 0.5;
  constrainEntityToInstallation(state, rack);
  syncRackEquipment(state, rack.id);
  assert.equal(server.transform.position.x, 3);
  assert.equal(server.transform.position.z, 2);
  assert.equal(server.transform.rotation.y, 0.5);
  assert.equal(server.installation.rackU, 1);
});

test("cabo usa portas explícitas e bloqueia porta ocupada", () => {
  const state = createEmptyPlannerState();
  const router = createEntity("router");
  const onu = createEntity("onu", { x: 4, y: 0, z: 0 });
  state.equipment.push(router, onu);
  const cable = createCable(state, router.id, onu.id, "fiber", "WAN", "PON");
  assert.equal(cable.originPortId, "WAN");
  assert.equal(cable.destinationPortId, "PON");
  assert.throws(() => createCable(state, router.id, onu.id, "fiber", "WAN", "PON"), /ocupada/);
});

test("restauração descarta cabos inválidos e conflitos de porta", () => {
  const state = createEmptyPlannerState();
  const router = createEntity("router");
  const onu = createEntity("onu", { x: 4, y: 0, z: 0 });
  const rack = createEntity("rack24");
  state.equipment.push(router, onu); state.racks.push(rack);
  const valid = createCable(state, router.id, onu.id, "copper-unshielded", "LAN1", "LAN1");
  const raw = serializePlanner(state);
  raw.cables.push({ ...valid, id: crypto.randomUUID() });
  raw.cables.push({ ...valid, id: crypto.randomUUID(), originEquipmentId: rack.id, originPortId: "X" });
  const restored = restorePlanner(raw);
  assert.equal(restored.cables.length, 1);
  assert.equal(restored.cables[0].id, valid.id);
});

test("visuais integrados preservam dimensões e detalham equipamentos", () => {
  const rack = createEquipmentVisual(catalogItem("rack24"));
  const rackSize = new THREE.Box3().setFromObject(rack).getSize(new THREE.Vector3());
  assert.ok(Math.abs(rackSize.x - catalogItem("rack24").size[0]) < 0.001);
  assert.ok(Math.abs(rackSize.y - catalogItem("rack24").size[1]) < 0.001);
  const networkSwitch = createEquipmentVisual(catalogItem("switch24"));
  const router = createEquipmentVisual(catalogItem("router"));
  assert.ok(networkSwitch.children.length >= 49, "switch deve conter corpo, portas e LEDs");
  assert.ok(router.children.length >= 6, "roteador deve conter corpo, antenas e LED");
});

test("falha de GLB mantém fallback procedural", async () => {
  const fallback = createEquipmentVisual(catalogItem("onu"));
  const result = await loadEquipmentModelOrFallback("/modelo-ausente.glb", fallback, async () => {
    throw new Error("asset ausente");
  });
  assert.equal(result.loaded, false);
  assert.equal(result.object, fallback);
});
