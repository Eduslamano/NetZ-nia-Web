# Supabase

Consulte `docs/SUPABASE.md`. A ordem é:

1. `migrations/0001_init.sql`
2. `migrations/0002_phase2_projects.sql`
3. `migrations/0003_release_candidate_hardening.sql`
4. `policies/0001_rls_policies.sql`
5. `policies/0002_hardened_rls.sql`

O arquivo `0002_hardened_rls.sql` substitui as policies iniciais por versões sem recursão. Nenhuma
credencial real deve ser adicionada ao repositório.

O passo a passo operacional para Carlos Edu está em `docs/GUIA_SUPABASE_EDU.md`.
