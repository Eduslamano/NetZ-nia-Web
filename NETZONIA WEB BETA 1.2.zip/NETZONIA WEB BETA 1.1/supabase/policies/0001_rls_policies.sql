-- 0001_rls_policies.sql — RLS deny-by-default, baseada em company_members.
-- Nenhuma policy usa service_role; tudo aqui assume o usuário autenticado
-- via Supabase Auth (auth.uid()) chamando com a chave anon/publishable.
-- Regra geral: usuário só enxerga/edita dados de empresas das quais é
-- membro (company_members). Não há acesso entre empresas.

-- profiles: cada usuário só lê/edita o próprio perfil.
create policy profiles_select_own on profiles
  for select using (id = auth.uid());
create policy profiles_update_own on profiles
  for update using (id = auth.uid());
create policy profiles_insert_own on profiles
  for insert with check (id = auth.uid());

-- companies: visível para quem é membro; criação livre para qualquer
-- usuário autenticado (ele vira 'owner' via company_members em seguida,
-- feito na mesma transação pelo backend/aplicação, não por policy).
create policy companies_select_member on companies
  for select using (
    exists (
      select 1 from company_members cm
      where cm.company_id = companies.id and cm.profile_id = auth.uid()
    )
  );
create policy companies_insert_authenticated on companies
  for insert with check (created_by = auth.uid());
create policy companies_update_owner_admin on companies
  for update using (
    exists (
      select 1 from company_members cm
      where cm.company_id = companies.id and cm.profile_id = auth.uid()
        and cm.role in ('owner', 'admin')
    )
  );

-- company_members: membro enxerga a lista de membros da própria empresa;
-- só owner/admin gerenciam (insert/update/delete) membros.
create policy company_members_select_same_company on company_members
  for select using (
    exists (
      select 1 from company_members cm
      where cm.company_id = company_members.company_id and cm.profile_id = auth.uid()
    )
  );
create policy company_members_write_owner_admin on company_members
  for insert with check (
    exists (
      select 1 from company_members cm
      where cm.company_id = company_members.company_id and cm.profile_id = auth.uid()
        and cm.role in ('owner', 'admin')
    )
    or not exists (select 1 from company_members cm2 where cm2.company_id = company_members.company_id)
    -- permite o primeiro membro (owner) se registrar ao criar a empresa
  );
create policy company_members_update_owner_admin on company_members
  for update using (
    exists (
      select 1 from company_members cm
      where cm.company_id = company_members.company_id and cm.profile_id = auth.uid()
        and cm.role in ('owner', 'admin')
    )
  );
create policy company_members_delete_owner_admin on company_members
  for delete using (
    exists (
      select 1 from company_members cm
      where cm.company_id = company_members.company_id and cm.profile_id = auth.uid()
        and cm.role in ('owner', 'admin')
    )
  );

-- projects: qualquer membro da empresa lê; membro cria/edita.
create policy projects_select_member on projects
  for select using (
    exists (
      select 1 from company_members cm
      where cm.company_id = projects.company_id and cm.profile_id = auth.uid()
    )
  );
create policy projects_insert_member on projects
  for insert with check (
    created_by = auth.uid() and exists (
      select 1 from company_members cm
      where cm.company_id = projects.company_id and cm.profile_id = auth.uid()
    )
  );
create policy projects_update_member on projects
  for update using (
    exists (
      select 1 from company_members cm
      where cm.company_id = projects.company_id and cm.profile_id = auth.uid()
    )
  );
create policy projects_delete_owner_admin on projects
  for delete using (
    exists (
      select 1 from company_members cm
      where cm.company_id = projects.company_id and cm.profile_id = auth.uid()
        and cm.role in ('owner', 'admin')
    )
  );

-- project_data: segue a mesma regra de membership do projeto associado.
create policy project_data_select_member on project_data
  for select using (
    exists (
      select 1 from projects p
      join company_members cm on cm.company_id = p.company_id
      where p.id = project_data.project_id and cm.profile_id = auth.uid()
    )
  );
create policy project_data_upsert_member on project_data
  for insert with check (
    exists (
      select 1 from projects p
      join company_members cm on cm.company_id = p.company_id
      where p.id = project_data.project_id and cm.profile_id = auth.uid()
    )
  );
create policy project_data_update_member on project_data
  for update using (
    exists (
      select 1 from projects p
      join company_members cm on cm.company_id = p.company_id
      where p.id = project_data.project_id and cm.profile_id = auth.uid()
    )
  );
