-- Substitui as policies iniciais por versões sem recursão em company_members.
drop policy if exists profiles_select_own on profiles;
drop policy if exists profiles_update_own on profiles;
drop policy if exists profiles_insert_own on profiles;
drop policy if exists companies_select_member on companies;
drop policy if exists companies_insert_authenticated on companies;
drop policy if exists companies_update_owner_admin on companies;
drop policy if exists company_members_select_same_company on company_members;
drop policy if exists company_members_write_owner_admin on company_members;
drop policy if exists company_members_update_owner_admin on company_members;
drop policy if exists company_members_delete_owner_admin on company_members;
drop policy if exists projects_select_member on projects;
drop policy if exists projects_insert_member on projects;
drop policy if exists projects_update_member on projects;
drop policy if exists projects_delete_owner_admin on projects;
drop policy if exists project_data_select_member on project_data;
drop policy if exists project_data_upsert_member on project_data;
drop policy if exists project_data_update_member on project_data;

create policy profiles_select_own on profiles for select using (id = auth.uid());
create policy profiles_insert_own on profiles for insert with check (id = auth.uid());
create policy profiles_update_own on profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy companies_select_member on companies for select using (private.is_company_member(id));
create policy companies_update_admin on companies for update using (private.is_company_admin(id)) with check (private.is_company_admin(id));

create policy company_members_select_member on company_members for select using (private.is_company_member(company_id));
create policy company_members_insert_admin on company_members for insert with check (private.is_company_admin(company_id));
create policy company_members_update_admin on company_members for update
  using (private.is_company_admin(company_id) and role <> 'owner')
  with check (private.is_company_admin(company_id) and role <> 'owner');
create policy company_members_delete_admin on company_members for delete using (
  private.is_company_admin(company_id) and role <> 'owner'
);

create policy projects_select_member on projects for select using (private.is_company_member(company_id));
create policy projects_insert_member on projects for insert with check (created_by = auth.uid() and private.is_company_member(company_id));
create policy projects_update_member on projects for update using (private.is_company_member(company_id))
  with check (private.is_company_member(company_id));
create policy projects_delete_admin on projects for delete using (private.is_company_admin(company_id));

create policy project_data_select_member on project_data for select using (
  exists (select 1 from projects p where p.id = project_id and private.is_company_member(p.company_id))
);
create policy project_data_insert_member on project_data for insert with check (
  exists (select 1 from projects p where p.id = project_id and private.is_company_member(p.company_id))
);
create policy project_data_update_member on project_data for update using (
  exists (select 1 from projects p where p.id = project_id and private.is_company_member(p.company_id))
) with check (
  exists (select 1 from projects p where p.id = project_id and private.is_company_member(p.company_id))
);
