-- TESTE PREPARADO (não executado sem instância Supabase real).
-- Use com psql/Supabase CLI depois de criar dois usuários reais e substituir
-- os UUIDs abaixo. Nunca execute com dados de produção.
-- O script usa transações com rollback e simula os claims JWT de cada usuário.

\set user_a '00000000-0000-0000-0000-00000000000a'
\set user_b '00000000-0000-0000-0000-00000000000b'
\set company_a '00000000-0000-0000-0000-00000000001a'
\set company_b '00000000-0000-0000-0000-00000000001b'

begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub', :'user_a', 'role', 'authenticated')::text, true);

-- Deve retornar apenas projetos da Empresa A e zero linhas da Empresa B.
select id, company_id, name from public.projects order by company_id, name;
select count(*) as deve_ser_zero from public.projects where company_id = :'company_b'::uuid;

-- Deve afetar zero linhas por RLS.
update public.projects set name = name || ' BLOQUEIO_FALHOU'
where company_id = :'company_b'::uuid;

rollback;

begin;
set local role authenticated;
select set_config('request.jwt.claims', json_build_object('sub', :'user_b', 'role', 'authenticated')::text, true);

-- Deve retornar apenas projetos da Empresa B e zero linhas da Empresa A.
select id, company_id, name from public.projects order by company_id, name;
select count(*) as deve_ser_zero from public.projects where company_id = :'company_a'::uuid;

-- Deve afetar zero linhas por RLS.
delete from public.projects where company_id = :'company_a'::uuid;

rollback;
