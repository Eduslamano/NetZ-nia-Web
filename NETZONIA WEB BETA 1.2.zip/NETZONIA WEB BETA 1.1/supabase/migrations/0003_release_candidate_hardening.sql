-- Fase 3 / Release Candidate: limites defensivos para o JSON do projeto.
-- Reexecutável: cada constraint só é criada quando ainda não existe.

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'project_data_object_only') then
    alter table public.project_data
      add constraint project_data_object_only check (jsonb_typeof(data) = 'object');
  end if;
  if not exists (select 1 from pg_constraint where conname = 'project_data_size_limit') then
    alter table public.project_data
      add constraint project_data_size_limit check (pg_column_size(data) <= 4194304);
  end if;
end
$$;

create index if not exists idx_projects_company_updated
  on public.projects(company_id, updated_at desc);

comment on column public.project_data.data is
  'Estado agregado do projeto (ferramentas e Planner 3D), limitado a objeto JSON de 4 MiB.';
