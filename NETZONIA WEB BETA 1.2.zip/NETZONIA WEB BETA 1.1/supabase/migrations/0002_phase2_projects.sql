-- Fase 2: completa o modelo Project e adiciona bootstrap seguro de empresa.
alter table projects add column if not exists description text not null default '';
alter table projects add column if not exists schema_version integer not null default 2 check (schema_version > 0);
alter table projects add column if not exists revision bigint not null default 1 check (revision > 0);
alter table projects add constraint projects_name_length check (char_length(name) between 1 and 120);
alter table projects add constraint projects_description_length check (char_length(description) <= 1000);

create or replace function increment_project_revision()
returns trigger language plpgsql as $$
begin
  if row(new.name, new.description, new.company_id, new.schema_version)
     is distinct from row(old.name, old.description, old.company_id, old.schema_version) then
    new.revision = old.revision + 1;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_projects_revision on projects;
create trigger trg_projects_revision before update on projects
  for each row execute function increment_project_revision();

create or replace function protect_project_scope()
returns trigger language plpgsql as $$
begin
  if new.company_id is distinct from old.company_id or new.created_by is distinct from old.created_by then
    raise exception 'project scope is immutable';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_projects_scope on projects;
create trigger trg_projects_scope before update on projects
  for each row execute function protect_project_scope();

create or replace function touch_project_from_data()
returns trigger language plpgsql as $$
begin
  update projects set revision = revision + 1, updated_at = now() where id = new.project_id;
  return new;
end;
$$;

drop trigger if exists trg_project_data_touch_project on project_data;
create trigger trg_project_data_touch_project after insert or update on project_data
  for each row execute function touch_project_from_data();

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

create or replace function private.is_company_member(target_company uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$ select exists (
  select 1 from company_members
  where company_id = target_company and profile_id = auth.uid()
) $$;

create or replace function private.is_company_admin(target_company uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$ select exists (
  select 1 from company_members
  where company_id = target_company and profile_id = auth.uid() and role in ('owner', 'admin')
) $$;

revoke all on function private.is_company_member(uuid) from public, anon;
revoke all on function private.is_company_admin(uuid) from public, anon;
grant usage on schema private to authenticated;
grant execute on function private.is_company_member(uuid) to authenticated;
grant execute on function private.is_company_admin(uuid) to authenticated;

create or replace function public.create_company_with_owner(company_name text)
returns uuid
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  user_id uuid := auth.uid();
  new_company_id uuid;
begin
  if user_id is null then raise exception 'authentication required'; end if;
  if char_length(trim(company_name)) not between 2 and 120 then raise exception 'invalid company name'; end if;
  insert into profiles(id, display_name) values (user_id, coalesce(auth.jwt() ->> 'email', ''))
    on conflict (id) do nothing;
  insert into companies(name, created_by) values (trim(company_name), user_id) returning id into new_company_id;
  insert into company_members(company_id, profile_id, role) values (new_company_id, user_id, 'owner');
  return new_company_id;
end;
$$;

revoke all on function public.create_company_with_owner(text) from public, anon;
grant execute on function public.create_company_with_owner(text) to authenticated;
