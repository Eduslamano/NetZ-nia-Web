-- 0001_init.sql — schema inicial multiempresa do Netzônia Web.
-- Enxuto por design (seção 4 do PROMPT_MESTRE): profiles, companies,
-- company_members, projects, project_data. RLS é habilitada aqui; as
-- políticas em si ficam em supabase/policies/0001_rls_policies.sql para
-- manter schema e regra de acesso revisáveis separadamente.

create extension if not exists "pgcrypto";

-- Um perfil por usuário autenticado (auth.users é gerenciado pelo Supabase Auth).
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references profiles(id) on delete restrict,
  created_at timestamptz not null default now()
);

-- Papel simples: 'owner' | 'admin' | 'member'. Enum textual (não enum SQL)
-- para permitir evolução de papéis sem migration de tipo.
create table if not exists company_members (
  company_id uuid not null references companies(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner', 'admin', 'member')),
  created_at timestamptz not null default now(),
  primary key (company_id, profile_id)
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  name text not null,
  place_id text, -- compatível com o identificador usado em projetos.go (placeID) no legado
  latitude double precision,
  longitude double precision,
  created_by uuid not null references profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint uq_projects_company_place unique (company_id, place_id)
);

-- Estado completo do projeto/3D como JSONB no MVP (seção 4 do PROMPT_MESTRE).
-- Uma linha por projeto; versionamento fino fica para pós-MVP.
create table if not exists project_data (
  project_id uuid primary key references projects(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists idx_company_members_profile on company_members(profile_id);
create index if not exists idx_projects_company on projects(company_id);
create index if not exists idx_project_data_gin on project_data using gin (data);

-- updated_at automático.
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on profiles;
create trigger trg_profiles_updated_at before update on profiles
  for each row execute function set_updated_at();

drop trigger if exists trg_projects_updated_at on projects;
create trigger trg_projects_updated_at before update on projects
  for each row execute function set_updated_at();

drop trigger if exists trg_project_data_updated_at on project_data;
create trigger trg_project_data_updated_at before update on project_data
  for each row execute function set_updated_at();

alter table profiles enable row level security;
alter table companies enable row level security;
alter table company_members enable row level security;
alter table projects enable row level security;
alter table project_data enable row level security;
